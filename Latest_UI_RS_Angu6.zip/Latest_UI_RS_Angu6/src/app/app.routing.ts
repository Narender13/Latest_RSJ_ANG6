import { NgModule } from '@angular/core';
import { Routes, RouterModule,CanActivate } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { Page404Component } from './core/page404/page404.component';
import {Page401Component} from './core/page401/page401.component';
import { TechnicalErrorComponent } from 'src/app/core/technicalError/technicalerror.component';
import { LoginComponent } from 'src/app/login/login/login.component';
import { AuthService } from 'src/app/core/guard/services/auth.service';
import { AuthenticationGuard } from 'microsoft-adal-angular6';

const routes: Routes = [
    { path: '', redirectTo: '/home', pathMatch: 'full',canActivate: [AuthenticationGuard]},
    {
        path: 'home', component: HomeComponent,
        canActivate:[AuthenticationGuard], 
        data: { functionid:100 }
       
    },
    { path: 'login', component: LoginComponent },
    { path: 'home/search-top', loadChildren: 'src/app/finance/finance.module#FinanceModule' ,canActivate: [AuthenticationGuard]},
    { path: 'home/search', loadChildren: 'src/app/finance/finance.module#FinanceModule' , canActivate:[AuthenticationGuard]
   
},
    { path: 'home/draft', loadChildren: 'src/app/finance/finance.module#FinanceModule',canActivate: [AuthenticationGuard]
    //canActivate:[AuthGuard] 
},
{ 
    path: 'admin', loadChildren: 'src/app/administration/administration.module#AdministrationModule', canActivate:[AuthenticationGuard]
},
{ path: '', loadChildren: 'src/app/finance/finance.module#FinanceModule',canActivate: [AuthenticationGuard]
//canActivate:[AuthGuard] 
},
  
    { path: 'technicalError', component: TechnicalErrorComponent, data: { title: 'Technical Error found' } },
    { path: 'pagenotfound', component: Page404Component, data: { title: 'page not found' } },
    { path: 'accessdenied', component: Page401Component, data: { title: 'page not found' } },
    {
        path: '**', component: Page404Component, data: { title: 'page not found' }

    },
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule],
    providers: [
        AuthService
      ]
})
export class AppRoutingModule { }
