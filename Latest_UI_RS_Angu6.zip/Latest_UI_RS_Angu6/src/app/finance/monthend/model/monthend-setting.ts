export class MonthendSetting {
    StartDate: Date;
    EndDate:Date;
    EarlyAlert: number;
    EmailIds: string;
    DetailTranCode:number;
    Module:string;
    success: boolean;
    errors: any;
    result: any;
}
