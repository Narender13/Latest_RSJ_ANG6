import { Injectable } from '@angular/core';
import { HttpParams, HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { map, catchError, tap, shareReplay } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { RSAENDPOINTConstants } from 'src/app/core/constants/rsa.api.end.points';
import { handleErrorObservable } from 'src/app/shared/utilites/helper';
import { MonthendSetting } from '../model/monthend-setting';

@Injectable({
  providedIn: 'root'
})
export class MonthendService {

    constructor(private http: HttpClient) { }

    getAllMonthEndSetting(): Observable<Array<MonthendSetting>> {
        return this.http.get(RSAENDPOINTConstants.MONTHENDSETTING + '/GetAllMonthEndSettings').pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getMonthEndSetting')));
    }
    addMonthEndSetting(params): Observable<MonthendSetting> {
        return this.http.post<MonthendSetting>(RSAENDPOINTConstants.MONTHENDSETTING + '/Create', params).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('addMonthEndSetting')));
    }
    updateMonthEndSetting(params): Observable<MonthendSetting> {
        return this.http.put<MonthendSetting>(RSAENDPOINTConstants.MONTHENDSETTING + '/Update', params).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('updateMonthEndSetting')));
    }
    setMonthEndDates(params): Observable<MonthendSetting> {
        return this.http.post<MonthendSetting>(RSAENDPOINTConstants.MONTHENDSETTING + '/SetDates', params).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('setDates')));
    }
    sendMonthEndMail(params): Observable<MonthendSetting> {
        return this.http.post<MonthendSetting>(RSAENDPOINTConstants.MONTHENDSETTING + '/SendMail?emailIds=' + params.emailIds, params).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('setDates')));
    }
    removeMonthEnd(params): Observable<MonthendSetting> {
        return this.http.delete<MonthendSetting>(RSAENDPOINTConstants.MONTHENDSETTING + '/Remove/' + params).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('removeMonthEnd')));
    }
    copySeries(isStartDate, isEarlyAlert, params): Observable<MonthendSetting> {
        return this.http.post<MonthendSetting>(RSAENDPOINTConstants.MONTHENDSETTING + '/CopySeries?isStartDate=' + isStartDate + '&isEarlyAlert=' + isEarlyAlert, params).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('setDates')));
    }
}
