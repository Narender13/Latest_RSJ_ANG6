import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpHeaders, HttpErrorResponse, HttpClient, HttpParams } from '@angular/common/http';
import { RSAENDPOINTConstants } from 'src/app/core/constants/rsa.api.end.points';
import { handleErrorObservable } from 'src/app/shared/utilites/helper';
import { map, catchError, tap, shareReplay, share } from 'rxjs/operators';
import { RSAConstants } from 'src/app/core/constants/rsaconstant';


@Injectable({ providedIn: 'root' })

export class MasterDataService {
    private cachedMasterData: Observable<any>;
    private cachedMasterData2: Observable<any>;
    private cachedLocationData: Observable<any>;
    

    constructor(private http: HttpClient) { }


    getMasterData(totacc): Observable<any> {
        let param = 'costCenter=' + localStorage.getItem('costcentre') +
            '&totallingAccCode=' + totacc;
        return this.http.get<any>(RSAENDPOINTConstants.VOUCHERMASTER + param).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getMasterData')));
    }
    getAllMasterData(totacc) {
        if (!this.cachedMasterData) {
            this.cachedMasterData = this.getMasterData(totacc).pipe(shareReplay(1));
        }
        return this.cachedMasterData;
    }

    getMasterData2(): Observable<any> {
        let regioncode = localStorage.getItem('regioncode');
        let urlpart: string = 'countryCode=' + regioncode + '&regionCode=' + regioncode;
        let url = RSAENDPOINTConstants.ADMINMASTER + urlpart;
        console.log(urlpart, 'url');
        return this.http.get<any>(url).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getMasterData')));
    }
    getAllMasterData2() {
        if (!this.cachedMasterData2) {
            this.cachedMasterData2 = this.getMasterData2().pipe(shareReplay(1));
        }
        return this.cachedMasterData2;
    }

    getTotallingData(param) {
        return this.http.get<any>(RSAENDPOINTConstants.HDR_TOT_ACC_CODES + param).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getTotallingData')));
    }
    getTotallingDetailData(param) {
        return this.http.get<any>(RSAENDPOINTConstants.DTL_TOT_ACC_CODES + param).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getTotallingDetailData')));
    }
    getPayeeBankData() {
        return this.http.get<any>(RSAENDPOINTConstants.PAYEEBANKDATA).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getPayeeBankMasterData')));
    }
    getBankData(param) {
        return this.http.get<any>(RSAENDPOINTConstants.BANKDATA + param).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getReceiverBankData')));
    }
    getGLData(param) {
        return this.http.get<any>(RSAENDPOINTConstants.GLDATA + param).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getGLData')));
    }

    getDescription(param) {
            return this.http.post<any>(RSAENDPOINTConstants.GETDESCRIPTION, param).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getDescription')));
    }


    /*new masteredata details services*/
    getLookupLocations() {
        return this.http.get<any>(RSAENDPOINTConstants.LOOKUPLOCATIONS).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getLookupLocations')));
    }

    getLookupCostCenters() {
        return this.http.get<any>(RSAENDPOINTConstants.LOOKUPCOSTCENTER).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getLookupCostCenters')));
    }
    getCostCenters() {
        return this.http.get<any>(RSAENDPOINTConstants.RECEIPTCCFETCH).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getLookupCostCenters')));
    }

    getTotallingAccount(params) {
        const param = '&ccCode=' + params.ccode;
        return this.http.get<any>(RSAENDPOINTConstants.LOOKUPTOTALINGACCOUNT + param).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getTotallingAccount')));
    }

    getLookupBanks(params) {
        const param = '&ccCode=' + params.ccode + '&totAccCode=' + params.totAccCode;
        return this.http.get<any>(RSAENDPOINTConstants.LOOKUPBANKNAMES + param).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getLookupBanks')));
    }


    getPayeeBanks() {
        return this.http.get<any>(RSAENDPOINTConstants.LOADPAYEEBANKNAMES).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getPayeeBanks')));
    }

    getTerminals() {
        return this.http.get<any>(RSAENDPOINTConstants.LOADTERMINALUMBER).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getTerminals')));
    }

    getInstrumentTypes() {
        return this.http.get<any>(RSAENDPOINTConstants.CARDTYPE).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getInstrumentTypes')));
    }
    getLookupDefaultValue() {
        return this.http.get<any>(RSAENDPOINTConstants.LOOKUPDEFAULTVALUES).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getLookupDefaultValue')));
    }

    getDetailTotallingAccount(param) {
        return this.http.get<any>(RSAENDPOINTConstants.LOOKUPDETAILTOTALINGACCOUNT + param).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getDetailTotallingAccount')));
    }

    getDetailGlAccount(param) {
        return this.http.get<any>(RSAENDPOINTConstants.GLACCOUNTINDETAILS + param).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getDetailGlAccount')));
    }

    getAllTranData() {
        return this.http.get<any>(RSAENDPOINTConstants.LOOKUPDETAILTRANS).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getAllTranData')));
    }
    getAllDeptData() {
        return this.http.get<any>(RSAENDPOINTConstants.LOOKUPDETAILDEPT).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getAllDeptData')));
    }
    getAllProjectIndData() {
        return this.http.get<any>(RSAENDPOINTConstants.LOOKUPDETAILTPROJECTIND).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getAllProjectIndData')));
    }
    getAllBankCurrencyData() {
        return this.http.get<any>(RSAENDPOINTConstants.LOOKUPBANKCURRENCY).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getAllProjectIndData')));
    }

    getAllSettlementTypeData() {
        return this.http.get<any>(RSAENDPOINTConstants.LOOKUPSETTLEMENTTYPE).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getAllSettlementTypeData')));
    }
    getAccountingDates(code: any) {
        const url: string = RSAENDPOINTConstants.GETACCOUNTINGDATES + code;
        return this.http.get<any>(url).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getAccountingDates')));
    }


    getJVMasterData(): Observable<any> {
       // let regioncode = localStorage.getItem('regioncode');
       let LoggedInUserId  = localStorage.getItem(RSAConstants.LoggedInUserId);
       console.log("LoggedInUserId>>>>>",LoggedInUserId);
        let type = 4;
         let urlpart: string = 'type='+ type + '&userid='+LoggedInUserId ;
        let url = RSAENDPOINTConstants.JVMASTERDATA + urlpart;
        console.log(url, 'url222');
        return this.http.get<any>(url).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getMasterData')));
    }
}
