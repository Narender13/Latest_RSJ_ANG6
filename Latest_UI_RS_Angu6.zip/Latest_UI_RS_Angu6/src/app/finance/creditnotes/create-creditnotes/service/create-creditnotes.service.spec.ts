import { TestBed, inject } from '@angular/core/testing';

import { CreateCreditnotesService } from './create-creditnotes.service';

describe('CreateCreditnotesService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CreateCreditnotesService]
    });
  });

  it('should be created', inject([CreateCreditnotesService], (service: CreateCreditnotesService) => {
    expect(service).toBeTruthy();
  }));
});
