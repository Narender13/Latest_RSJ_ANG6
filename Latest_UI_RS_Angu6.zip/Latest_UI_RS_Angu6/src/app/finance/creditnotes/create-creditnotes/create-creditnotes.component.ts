
import { Component, OnInit, ViewChild } from '@angular/core';
import { SharedService } from '../../services/shared.service';
import { FormBuilder, FormControl, FormGroup, FormArray, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';
import { ConfirmationDialogComponent } from 'src/app/shared/custom-model/custom-model.component';
import { BsModalService } from 'ngx-bootstrap/modal';
import { TabsetComponent } from 'ngx-bootstrap/tabs';
import { UtilityClass } from 'src/app/shared/utilites/helper-class';
import { MasterDataService } from 'src/app/finance/services/finance.masterdata.service';
import { CreateCreditNotes } from 'src/app/finance/creditnotes/create-creditnotes/model/create-cn';
import { BasevoucherComponent } from 'src/app/finance/basevoucher/basevoucher.component';
import { CreateCreditnotesService } from 'src/app/finance/creditnotes/create-creditnotes/service/create-creditnotes.service';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { CnpreviewComponent } from 'src/app/finance/preview/uae/cnpreview/cnpreview.component';
import { RSAConstants } from 'src/app/core/constants/rsaconstant';

@Component({
  selector: 'rsa-create-creditnotes',
  templateUrl: './create-creditnotes.component.html',
  styleUrls: ['./create-creditnotes.component.scss']
})
export class CreateCreditnotesComponent extends BasevoucherComponent implements OnInit {
  title = 'Credit Note';
  currency = 'AED';
  errorpayee: boolean;
  errordetail: boolean;
  errorglCode: boolean;
  /* form error-feilds */
  errorbankcodeCheque: boolean;
  level: any = 2;
  errorbankcodeBanktransfer: boolean;
  errorpaayeebanknameCheque: boolean;
  errorpaayeebanknameBanktransfer: boolean;
  errorchequedateCheque: boolean;
  errorchequedateBankT: boolean;
  errorchequedateCreditCard: boolean;
  errorchequenoCheque: boolean;
  errorchequenoCreditCard: boolean;
  errorterminalID: boolean;
  errorexpirydate: boolean;
  errorvoucherdate: boolean;
  matchedRecords = [];
  isUploadUnmatched;
  returnValue: any;
  usersReq;
  symbol;
  glAcountHeader: any = [];
  createCreditNotes: CreateCreditNotes;
  clonedCreditNotes: CreateCreditNotes;
  animatedClass = true;
  selectedRowItem: any = [];
  customerName = "";
  ondemandFlag = true;
  ondemandFlagClaim = true;
  cnVATFlag = false;
  selectedRowItemWithVAT: any = [];
  formArray: any;
  cnClaimsFlag: any;
  cnClaimDetails: any;
  headerDescription: string = "";
  isStateClosed: boolean = false;

  @ViewChild('tabset') tabset: TabsetComponent;
  ifnewlyAddedRow = false;
  toggleValueCredit = [];
  constructor(
    protected sharedService: SharedService,
    private fb: FormBuilder,
    protected modalService: BsModalService,
    protected bsModalRef: BsModalRef,
    protected masterDataService: MasterDataService,
    protected utilityClass: UtilityClass,
    protected createPaymentService: CreateCreditnotesService,
    private alertService: AlertService,
  ) {
    super(masterDataService, sharedService, modalService, utilityClass, bsModalRef);
    //super.setMinMaxDate();
  }


  ngOnInit() {
    /* super with method is calling from BasevoucherComponent */
    this.createVoucherForm(this.paymentMode);
    this.isClaimFlag = this.cnClaimsFlag;
    this.isVATFlag = this.cnVATFlag;
    this.rowClaimData = this.selectedRowItem;
    super.getAllBranchData();
    super.getAllCostCenterData({ ev: null, index: 0, flag: true });
    super.getAllTotallingData(true);
    super.getAllProjData();
    super.getAllDeptData();
    super.getAllMasterData2();
    this.fieldStatusChanges();
    super.getModelPreviousClose();
    super.closeModel();
    super.getAllTranData();
    this.symbol = (localStorage.getItem('symbol'));
    //super.setMinMaxDate();
    super.GetAccountingDates();
    this.getGlAccountHeader();
    this.getDetailsArrayFormGroup();
    super.getModelPreviousClose();
    super.getAllgetLookupBanksData();
    console.log(this.selectedRowItem, 'selectedRowItem');
    super.getTotalingHeaderDataCnDn();
    const totcode = this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.value;
    super.getGlAccountHeaderDataCnDn(totcode);
    this.setTotAccTransCreCredit();
    this.setAmountWithdecimal();
    if (this.cnClaimsFlag) {
      this.setClaimDetails();
    }
    /*multiple GL Code*/
    this.updateFromSession();
    this.sharedService.getMessage().subscribe(val => {
      if (val == 'ClearState' || val == 'close') {
        if (localStorage.getItem('EntityCNStateExists') != null) {
          localStorage.setItem('EntityCNStateExists', 'false');
          this.isStateClosed = true
        }
      }
    });
  }
  // tslint:disable-next-line:use-life-cycle-interface
  ngOnDestroy() {
    if (!this.isStateClosed) {
      this.addToSession();
    }
  }
  addToSession() {
    if (this.mainVoucherForm.dirty || this.mainVoucherForm.touched) {
      let voucherDate = this.mainVoucherForm['controls'].VoucherDate.value;
      let totallingAccCode = this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.value;
      let glCode = this.mainVoucherForm.controls.accountInfo['controls'].GLCode.value;
      let description = this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription.value;
      let payeeName = this.mainVoucherForm.controls.detailInfo['controls'].PayeeName.value;
      var commonData = { VoucherDate: voucherDate, TotallingAccCode: totallingAccCode, GLCode: glCode, Description: description, PayeeName: payeeName }
      localStorage.setItem('EntityCNData', JSON.stringify(commonData));
      localStorage.setItem('EntityCNStateExists', 'true');
    }
  }
  updateFromSession() {
    let entityCNStateExists = localStorage.getItem('EntityCNStateExists');
    if (entityCNStateExists == 'true') {
      let itemDetail = localStorage.getItem('EntityCNData');
      if (itemDetail) {
        this.mainVoucherForm.markAsDirty();
        let commonData = JSON.parse(itemDetail);
        // if(commonData.VoucherDate) this.mainVoucherForm['controls'].VoucherDate.setValue(new DatePipe('en-US').transform(new Date(commonData.VoucherDate), 'dd/MM/yyyy'));
        if (commonData.TotallingAccCode) {
          this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.setValue(commonData.TotallingAccCode);
          setTimeout(() => {
            super.getGlAccountHeaderDataCnDn(commonData.TotallingAccCode);

          }, 500);
          if (commonData.GLCode) this.mainVoucherForm.controls.accountInfo['controls'].GLCode.setValue(commonData.GLCode);
        }
        if (commonData.Description) this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription.setValue(commonData.Description);
        if (commonData.PayeeName) this.mainVoucherForm.controls.detailInfo['controls'].PayeeName.setValue(commonData.PayeeName);
      }
    }

  }
  checkIsformDirtyCN() {
    this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
    this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
    this.bsModalRef.content.modelBodyContent = RSAMSGConstants.DIRTYFLAGMSGRECIPT;
    this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
    this.bsModalRef.content.actionBtn = RSAMSGConstants.BTNPROCEED;
    this.bsModalRef.content.valueChange.subscribe((data) => {
      if (data = 'Proceed') {
        this.modalService.hide(1);
        this.sharedService.sendMessage('close');
        this.isStateClosed = true;
        if (localStorage.getItem('EntityCNStateExists') != null) {
          localStorage.setItem('EntityCNStateExists', 'false');
        }
      }
    });
  }
  /*End*/
  /* create entiti form */
  createVoucherForm(param): void {
    this.mainVoucherForm = null;
    //let tranDate = localStorage.getItem('tranAccntMnthStrtDate') ? new Date(localStorage.getItem('tranAccntMnthStrtDate')) : new Date();
    this.mainVoucherForm = this.fb.group({
      VoucherDate: [new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy')],
      CreditNoteDate: [],
      ApprovedBy: [1],
      ArabicDescription: [],
      Amount: [],
      CountryCode: [1],
      CustomerID: [],
      CustCode: [],
      ModifiedBy: [],
      ModifiedDate: [],
      PreparedBy: [localStorage.getItem(RSAConstants.LoggedInUserId)],
      PreparedDate: [new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy')],
      ReprintNo: [],
      PrintDate: [],
      RefreshDate: [],
      PostedDate: [],
      PreprintNo: [],
      Title: [],
      RegionCode: [localStorage.getItem('regioncode')],
      Approvers: this.fb.array([]),
      detailInfo: this.fb.group({
        PayeeName: [this.customerName, Validators.required],
        EnglishDescription: ['', Validators.required],
      }),
      accountInfo: this.fb.group({
        LocationCode: [localStorage.getItem('locationcode')],
        CostCenterCode: [localStorage.getItem('costcentre')],
        TotallingAccCode: [1110],
        GLCode: [4, Validators.required],
      }),
      VoucherDetails: this.fb.array([])
    });
  }

  setHeaderDescription(desc) {
    this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription.setValue(desc);
  }
  setTotAccTransCreCredit() {
    // getTotallingDetailData
    if (this.selectedRowItem.length) {
      this.selectedRowItem.map((item, index) => {
        super.getTotallingDetailData({ index: index, flag: true });
      });
    }
  }

  // getSelectedRowValue() {
  //   this.selectedRowItem.forEach((element, index) => {
  //     if ((index % 2 === 0)) {
  //       this.toggleValueCredit[index] = element.Amount < 0 ? false : true;
  //       console.log(this.toggleValueCredit, 'this.toggleValueCredit');
  //       // this.setFormArrayCTRLDefaultValue('IsDebitEntry', index, this.toggleValueCredit);
  //     }
  //   });
  // }

  getGLdataCnDn(ev) {
    const totcode = ev.ev;
    console.log(totcode, 'totcode');
    super.getGlAccountHeaderDataCnDn(totcode);
  }

  getDetailsArrayFormGroup() {
    let control = <FormArray>this.mainVoucherForm.controls['VoucherDetails'];
    if (!this.ondemandFlag) {
      this.mainVoucherForm.controls['CustomerID'].setValue(this.selectedRowItem[0].CustomerID);
      this.mainVoucherForm.controls['CustCode'].setValue(this.selectedRowItem[0].CustCode);

      console.log(this.selectedRowItem, 'this.selectedRowItem');
      this.selectedRowItem.map((item, index) => {
        // super.getAllCostCenterData({ ev: null, index: index, flag: false });
        let group = this.createDetailsArrayGroup();
        item['IsDebitEntry'] = (item.Amount < 0) ? false : true;
        group.patchValue(item.item);
        group.get("newAddedRow").setValue(false);
        group.get('IsDebitEntry').setValue((parseFloat(group.get("Amount").value) < 0) ? false : true);

        control.push(group);
      });
    }
    if (!this.ondemandFlagClaim) {
      this.mainVoucherForm.controls['CustomerID'].setValue(this.selectedRowItem[0].CustomerID);
      this.mainVoucherForm.controls['CustCode'].setValue(this.selectedRowItem[0].CustCode);
      this.mainVoucherForm.controls['accountInfo'].get('TotallingAccCode').setValue(this.selectedRowItem[0].CNTotallingAcc);
      this.mainVoucherForm.controls['accountInfo'].get('GLCode').setValue(this.selectedRowItem[0].CNGLCode);


      console.log(this.selectedRowItem, 'this.selectedRowItem');
      this.selectedRowItem.map((item, index) => {
        let group = this.createDetailsArrayGroup();
        if (this.cnClaimsFlag) {
          group.addControl('EntryTypeCode', new FormControl());
        }
        item['IsDebitEntry'] = (item.Amount < 0) ? false : true;
        console.log(item, 'item');
        // if ((index % 2 === 0)) {
        //   this.toggleValueCredit[index] = item.Amount < 0 ? false : true;
        //   console.log(this.toggleValueCredit, 'this.toggleValueCredit');
        // }
        group.patchValue(item);
        group.get("newAddedRow").setValue(false);

        if ((index % 2) !== 0) {
          if (item.CNVATAmount !== 0) {
            //this.toggleValueCredit[index] = item.Amount < 0 ? false : true;
            control.push(group);
          }
        }
        if ((index % 2) == 0) {
         // this.toggleValueCredit[index] = item.Amount < 0 ? false : true;
          control.push(group);
        }
        const ctrl = <FormArray>this.mainVoucherForm.controls['VoucherDetails'];
        ctrl.controls.forEach((val, i) => {
       const amount = val.get('Amount').value;
       this.toggleValueCredit[i] = amount < 0 ? false : true;
     });
      });
    } else {
      control.push(this.createDetailsArrayGroup());
    }
  }
  setAmountWithdecimal() {
    (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls.forEach(item => {
      const amountVal = parseFloat(item.get('Amount').value);
      item.get('Amount').setValue(amountVal);
    });
  }

  getActualAmountSum(processFlag) {
    let total = 0;
    let amt = 0;
    let actualamt = 0;
    let flagtoggle = false;
    (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls.forEach((element, index) => {

      if (this.getFromFormArrayControlVal('Amount', index) != undefined
        && this.getFromFormArrayControlVal('Amount', index) != null) {
        flagtoggle = this.getFromFormArrayControlVal('IsDebitEntry', index);
        const Camt = parseFloat(this.getFromFormArrayControlVal('Amount', index));
        amt = Math.abs(Camt);
        if (processFlag == 'CN') {
          actualamt = (flagtoggle) ? amt : (amt * -1);
        }
        console.log('flagtoggle:' + flagtoggle + ',amt:' + amt + ',actualamt:' + actualamt);
        total = total + actualamt;
      }
    });
    this.totalAmount = total;
  }


  setDebitEntry(ev) {
    console.log(ev, '<<<<key');
    const actualData = Number(ev.data.controls['Amount'].value);

    if (actualData === 0 || actualData === undefined) {
      this.displayAlertModal({
        'title': RSAMSGConstants.MODELTITLE,
        'txt': RSAMSGConstants.EMPTYAMOUNTCHECK,
        'btnaction': RSAMSGConstants.OKTEXT
      });
      ev.event.target.checked = false;

    }
    this.setFormArrayCTRLDefaultValue(ev.isDebit, ev.index, ev.event.target.checked);
    this.getActualAmountSum('CN');
    if (this.totalAmount < 0) {
      ev.event.target.checked = true;
      this.setFormArrayCTRLDefaultValue(ev.isDebit, ev.index, true);
      this.displayAlertModal({
        'title': RSAMSGConstants.MODELTITLE,
        'txt': RSAMSGConstants.DEBITEXCEEDMSG,
        'btnaction': RSAMSGConstants.OKTEXT
      });
    }
    this.getActualAmountSum('CN');
  }

  /* form array for recept details */
  createDetailsArrayGroup(): FormGroup {
    return this.fb.group({
      Amount: [0, Validators.required],
      AnalysisCode: [],
      CostCenterCode: [localStorage.getItem('costcentre')],
      ClaimID: [],
      ClassCode: [],
      CauseOfLossCode: [],
      CounterPartyRef: [],
      CountryCode: [1],
      Description: [],
      DocumentCode: [],
      EntityID: [],
      GLCode: [4, Validators.required],
      GLCodeDesc: ['4-HSBC BANK MIDDLE EAST - Deira', Validators.required],
      LocationCode: [localStorage.getItem('locationcode')],
      LocationDesc: ['Dubai'],
      ModifiedBy: [],
      ModifiedDate: [],
      NatureOfLossCode: [],
      PolicyID: [],
      PolicyYear: [],
      PreparedBy: [localStorage.getItem(RSAConstants.LoggedInUserId)],
      PreparedDate: [],
      RefTransactionID: [],
      RefTransactionSerialNo: [],
      RefTransactionType: [10],
      RegionCode: [localStorage.getItem('regioncode')],
      TotallingAccCode: [1110],
      PolicyType: [],
      newAddedRow: true,
      VoucherNo: [],
      CNVATAmount: [],
      IsDebitEntry: [true],
      SerialNo: [],
      DepartmentCode: [],
      Department: []
    });
  }

  /* set receipt mode and set default values   */
  setReceiptMode(val, paymentname) {
    this.mainVoucherForm.controls['PaymentMode'].setValue(val);
    this.paymentMode = val;
    this.paymentname = paymentname;
    this.createVoucherForm(this.paymentMode);
    this.receiverdataBankName = this.cachedReceiverBankData;
    this.totallingacc = this.cachedTotAcc;
    this.payeedataBankName = this.cachedPayeeBankData;
    if (this.paymentMode == 1) {
      this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.setValue('1210');
    } else {
      this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.setValue('1110');
      // this.mainVoucherForm.controls.accountInfo['controls'].RecevierBankCode.setValue('14');
    }
    this.setdefaultHeaderData();
    this.fieldStatusChanges();
    super.GetAccountingDates();
  }


  /* using req fields and update status  */
  fieldStatusChanges() {
    this.clearerrors();
    this.cshpayeename.statusChanges.subscribe(
      status => {
        this.errorpayee = (status === 'INVALID');
        console.log(this.errorpayee, 'his.errorpayee');
      }
    );
    this.cshdetails.statusChanges.subscribe(
      status => {
        this.errordetail = (status === 'INVALID');
      }
    );
    if (this.voucherdate != null && this.voucherdate !== undefined) {
      this.voucherdate.statusChanges.subscribe(
        status => {
          this.errorvoucherdate = (status === 'INVALID');
        }
      );
    }

  }

  /* clear all errors after reset   */
  clearerrors() {
    this.errorpayee = false;
    this.errordetail = false;
    this.errorvoucherdate = false;
    // this.errorglCode = false;
  }

  /* get the controls of each fields   */
  get voucherdate() { return this.mainVoucherForm.get('VoucherDate'); }
  get cshpayeename() { return this.mainVoucherForm.controls.detailInfo['controls'].PayeeName; }
  get cshdetails() { return this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription; }
  // get glCodeValue() { return this.mainVoucherForm.controls.detailInfo['controls'].GLCode; }


  /* set Description in receptdetails desc   */
  setDescription() {
    (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls[0].get('Description').setValue(this.cshdetails.value);
  }


  /* add receipt in review screen */
  addReceipt(len) {
    this.ifnewlyAddedRow = (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls[len - 1].get('newAddedRow').value;
    const control = <FormArray>this.mainVoucherForm.controls['VoucherDetails'];
    const CurrentAmount = (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls[len - 1].get('Amount').value;
    if (CurrentAmount != null && CurrentAmount != 0 && CurrentAmount != undefined) {
      control.push(this.createDetailsArrayGroup());
      this.setFormArrayCTRLDefaultValue('GLCode', len, 4);
      this.setFormArrayCTRLDefaultValue('GLCodeDesc', len, '4-HSBC BANK MIDDLE EAST - Deira');
      // this.setFormArrayCTRLDefaultValue('TotallingAccCode', len, 1110);
      super.getTotallingDetailData({ index: len, flag: true });
      this.dtltotallingacc[len] = this.cachedDtlTot;
      this.glaccount[len] = this.cachedGL;
    } else {
      this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
      this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
      this.bsModalRef.content.modelBodyContent = RSAMSGConstants.AMOUNTVALIDATIONMSG;
      this.bsModalRef.content.cancelBtn = RSAMSGConstants.OKTEXT;
      return false;
    }
  }

  preSubmission(precessFlag) {
    let flagtoggle = true;
    let amt = 0;
    this.clonedCreditNotes = Object.assign({}, this.createCreditNotes);
    this.clonedCreditNotes.CreditNoteDetail.forEach((element, index) => {
      flagtoggle = element.IsDebitEntry;
      if (!flagtoggle && precessFlag == 'CN') {
        element.Amount = (Math.abs(element.Amount)) * -1;
      }
      if (this.cnVATFlag && !this.ifnewlyAddedRow) {
        if ((index % 2) !== 0) {
          console.log(element, 'element');
          element.CNVATAmount = element.Amount;
          element.Amount = element.Amount;
        }
        element['CNVATflag'] = true;
      }
    });
    console.log('this.clonedDebitNotes', this.clonedCreditNotes);
  }


  reSetForm(params) {
    const param = params.defaultParam;
    /*set default value here and reset */
    if (param == 1) {
      super.validateAllFormFields(this.mainVoucherForm);
      this.mainVoucherForm.controls.VoucherDate.setValue([new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy')]);
      this.mainVoucherForm.controls.GLCode.setValue(4);
      this.mainVoucherForm.controls.GLCodeDesc.setValue('4-HSBC BANK MIDDLE EAST - Deira');
      this.clearerrors();
    } else if (param == 2) {
      this.mainVoucherForm.controls['VoucherDetails'].reset();
      (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls.map(item => {
        item.get('LocationCode').setValue([localStorage.getItem('locationcode')]);
        item.get('CostCenterCode').setValue([localStorage.getItem('costcentre')]);
        item.get('RefTransactionType').setValue(3);
        item.get('TotallingAccCode').setValue(1110);
        item.get('GLCode').setValue(4);
        item.get('GLCodeDesc').setValue('4-HSBC BANK MIDDLE EAST - Deira');
      });
      this.getSum();
    }
    super.GetAccountingDates();
  }

  /* update  form values to create-receipt objects*/
  createCNFormValues() {
    this.createCreditNotes = new CreateCreditNotes();
    const mainFormFieldArray = ['VoucherDate', 'ApprovedBy', 'ArabicDescription',
      'CountryCode', 'CustomerID', 'CustCode', 'ModifiedDate', 'ModifiedBy', 'PostedDate',
      'PreparedBy', 'PreparedDate', 'PreprintNo', 'PrintDate', 'RefreshDate', 'RegionCode', 'Title',
      'Approvers'];
    mainFormFieldArray.forEach(item => {
      console.log('this.item****', item);
      this.createCreditNotes[item] = this.mainVoucherForm.controls[item].value;

    });
    this.createCreditNotes.CreditNoteDate = this.createCreditNotes.VoucherDate;
    this.createCreditNotes.PreparedDate = this.mainVoucherForm.controls['VoucherDate'].value;
    this.createCreditNotes.LocationCode = this.mainVoucherForm.controls.accountInfo['controls'].LocationCode.value;
    this.createCreditNotes.CostCenterCode = this.mainVoucherForm.controls.accountInfo['controls'].CostCenterCode.value;
    this.createCreditNotes.TotallingAccCode = this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.value;
    this.createCreditNotes.GLCode = this.mainVoucherForm.controls.accountInfo['controls'].GLCode.value;
    this.createCreditNotes.PayeeName = this.mainVoucherForm.controls.detailInfo['controls'].PayeeName.value;
    this.createCreditNotes.EnglishDescription = this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription.value;
    this.createCreditNotes.CreditNoteDetail = this.mainVoucherForm.controls['VoucherDetails'].value;
    console.log('this.createCreditNotes****', this.createCreditNotes);
    // this.preSubmission('CN');
  }

  /* create-receipt form*/
  submitForm() {
    console.log(this.totalAmount, 'totalAmount');
    super.validateDetailInfo();
    this.errorpayee = this.cshpayeename.invalid;
    this.errordetail = this.cshdetails.invalid;
    this.errorvoucherdate = this.voucherdate.invalid;
    //  this.errorglCode = this.glCodeValue.invalid;
    if (!(!this.errorpayee && !this.errordetail && !this.errorglCode && !this.errorvoucherdate)) {
      return false;
    }
    if (this.amountZeroCheck > 0) {
      this.alertService.warn(RSAMSGConstants.AMOUNTZEROCHECK);
      return false;
    }
    if (this.glerrorcount > 0) {
      return false;
    }
    this.usersReq = (this.approverusers !== undefined && this.approverusers !== '' &&
      this.approverusers.length > 0);
    if (this.totalAmount > 0) {
      //no approver required for UAE
      if (!(localStorage.getItem('country') == '3')) {
        if (this.totalAmount > 99999 && !this.usersReq) {
          return false;
        }
      }

      this.createCNFormValues();
      console.log(this.createCreditNotes, ' this.createCreditNotes');
      if (this.prevPreviewID == null || this.prevPreviewID == undefined) {
        this.prevPreviewID = 0;

        // this.clonedCreditNotes['CreditNoteNo'] = this.prevPreviewID;
      }
      this.createCreditNotes['CreditNoteNo'] = this.prevPreviewID;
      this.preSubmission('CN');

      if (this.cnVATFlag) {
        this.clonedCreditNotes['CNVATflag'] = true;
      }

      this.createPaymentService.createCreditNote(JSON.stringify(this.clonedCreditNotes)).subscribe(
        dataReturn => {
          this.returnValue = dataReturn;
          this.returnValue['approverlist'] = this.approverusers;
          this.returnValue['ondemand'] = true;
          this.previewFlag = true;
          this.bsModalRef = this.modalService.show(CnpreviewComponent, { class: 'preview-modal-dailog', ignoreBackdropClick: true });
          this.bsModalRef.content.data = this.returnValue;
          this.bsModalRef.content.totalAmount = this.totalAmount;
          this.bsModalRef.content.backdrop = true;
        },
        errorRturn => {
          this.errorMsg = errorRturn;
        }
      );
    }
    if (this.totalAmount <= 0) {
      this.alertService.warn(RSAMSGConstants.DEBITEXCEEDMSG);
    }
  }


  getGlAccountHeader() {
    const param = 'totAccCode=1110' +
      '&ccCode=' + localStorage.getItem('costcentre');
    this.masterDataService.getDetailGlAccount(param).subscribe(data => {
      this.glAcountHeader = data;
      console.log('gldata', data);
    })
  }

  setGLHdrHiddenValue(ev) {
    console.log(ev);
    this.mainVoucherForm.controls.detailInfo['controls'].GLCode.setValue(ev.item.Code);
  }
  clearHdrGLCode(ev) {
    this.mainVoucherForm.controls.detailInfo['controls'].GLCode.setValue('');
    this.mainVoucherForm.controls.detailInfo['controls'].GLCodeDesc.setValue('');
  }
  setClaimDetails() {
    this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription.setValue(this.cnClaimDetails);
  }
}

