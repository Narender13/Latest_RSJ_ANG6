import { Component, OnInit, ViewChild, AfterViewInit, Input, Output, EventEmitter } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { AgGridNg2 } from 'ag-grid-angular';
import { GridOptions } from 'ag-grid-community/dist/lib/entities/gridOptions';
import { GridService } from 'src/app/shared/datatable/services/grid-service';
import { Entitie } from 'src/app/shared/datatable/model/entitie';
import { MatchUnMatchService } from 'src/app/finance/search/service/match-unmatch.service';
import { GridApiService } from 'src/app/shared/datatable/services/grid-api-service';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { DrfatAgridService } from 'src/app/finance/drfats/drafts-results/services/draft.grid.service';

@Component({
  selector: 'rsa-draft-grid',
  templateUrl: './draft-grid.component.html',
  styleUrls: ['./draft-grid.component.scss']
})
export class DraftGridComponent implements OnInit, AfterViewInit {
  @ViewChild('agGrid') agGrid: AgGridNg2;
  gridApi;
  gridColumnApi;
  paginationOptions: TextValuePair[] = [];
  selectedData;
  masterData = {};
  @Input() detailRowHeight;
  @Input() detailCellRendererParams;
  @Input() gridConfiguration: GridOptions = {};
  @Input('rowData') rowData: Entitie[] = [];
  @Output() selectedRowDetails = new EventEmitter();
  @Output() deSelectCheckbox = new EventEmitter();
  @Output() hideSnackBar = new EventEmitter();
  entityMatch: TextValuePair[] = [];
  columnDefs = [];
  gridDataselectedRows = [];
  uncheck;
  totalRecepitAmount;
  ifMatched;
  frameworkComponents;
  domLayout;
  @Input() vouName:string;
  private selectedTransactionType: string;

  constructor(private http: HttpClient, private drfatAgridService: DrfatAgridService,
    private matchunmatchservice: MatchUnMatchService, private gridApiService: GridApiService,
    private alertService: AlertService) {
    console.log(this.rowData, 'rowData');
    this.paginationOptions = [
      { id: 2, value: '20' },
      { id: 2, value: '100' },
      { id: 3, value: '500' },
      { id: 4, value: '1000' }
    ];

    this.entityMatch = [
      { id: 0, value: 'UnMatched' },
      { id: 1, value: 'Matched' },
    ];

  
      
  
    // this.gridConfiguration = <GridOptions>{
    //   columnDefs: this.drfatAgridService.getEntityColumnHeaderPropertyNames(),
    //   postProcessPopup: function (params) {
    //     const ePopup = params.ePopup;
    //     ePopup.style.top = '14.9838px';
    //   },
    //   rowData: this.rowData,
    //   rowHeight: 40,
    //   headerHeight: 40,
    //   pagination: true,
    //   floatingFiltersHeight: 40,
    //   paginationPageSize: 20,
    //   enableRangeSelection: true,
    //   rowSelection: 'none',
    //   rowMultiSelectWithClick: true,
    //   animateRows: true,
    //   enableColResize: true,
    //   enableFilter: true,
    //   suppressContextMenu: true,
    //   enableSorting: true,
    //   defaultColDef: {
    //     enableRowGroup: false,
    //     enableValue: true,
    //     suppressMovable: true,
    //     minWidth: 100,
    //     menuTabs: ['filterMenuTab', '', '']
    //   },
    //   context: {
    //     componentParent: this
    //   },
    // };
    this.domLayout = 'autoHeight';
  }


  ngOnInit() {
    this.gridApiService.isUnCheck().subscribe(() => {
      this.gridConfiguration.api.deselectAll();
    });
    this.GetcolumnDefs(this.vouName);
   
    
  }

  // noinspection JSMethodCanBeStatic
  public methodFromParent(cell) {
    return cell;
  }


  setAutoHeight() {
    setTimeout(() => {
      this.gridApi.setDomLayout('autoHeight');
      //(<HTMLElement>document.querySelector('#myGrid')).style.height = '';
    }, 200);

  }

  ngAfterViewInit() {
    this.fitToCoulmn();
    this.setAutoHeight();
  }

  onGridReady(params) {
    console.log(params, 'params');
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridConfiguration.api.setRowData(this.rowData);
    params.api.paginationGoToPage(0);
    this.fitToCoulmn();
  }

  fitToCoulmn() {
    setTimeout(() => {
      this.gridApi.sizeColumnsToFit();
    }, 200);
  }

  rowGroupOpened(params) {
    if (params.node.expanded) {
      params.api.forEachNode(function (node) {
        if (node.expanded && node.id !== params.node.id && node.uiLevel === params.node.uiLevel) {
          node.setExpanded(false);
        }
      });
    }
  }

  onPageSizeChanged(newPageSize: HTMLSelectElement) {
    const value = +(newPageSize.srcElement.value);
    this.gridApi.paginationSetPageSize(value);
    this.gridApi.sizeColumnsToFit();
  }


  GetcolumnDefs(vouName){
     this.gridConfiguration = <GridOptions>{
      columnDefs: this.drfatAgridService.getEntityColumnHeaderPropertyNames(vouName),
      postProcessPopup: function (params) {
        const ePopup = params.ePopup;
        ePopup.style.top = '14.9838px';
      },
      rowData: this.rowData,
      rowHeight: 40,
      headerHeight: 40,
      pagination: true,
      floatingFiltersHeight: 40,
      paginationPageSize: 20,
      enableRangeSelection: true,
      rowSelection: 'none',
      rowMultiSelectWithClick: true,
      animateRows: true,
      enableColResize: true,
      enableFilter: true,
      suppressContextMenu: true,
      enableSorting: true,
      defaultColDef: {
        enableRowGroup: false,
        enableValue: true,
        suppressMovable: true,
        minWidth: 100,
        menuTabs: ['filterMenuTab', '', '']
      },
      context: {
        componentParent: this
      },
    };
    this.domLayout = 'autoHeight';

  }


}


interface TextValuePair {
  id: number;
  value: string;
}



