import { Component, OnInit, Input } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap';
import { CreateReceiptEntitiRowSelectionComponent } from 'src/app/finance/search/search-results/entity/create-receipt-entiti-row-selection/create-receipt-entiti-row-selection.component';
import { CreateDraftReceiptComponent } from 'src/app/finance/drfats/drafts-results/create-draft-receipt/create-draft-receipt.component';
import { ReceiptpreviewComponent } from 'src/app/finance/preview/uae/receiptpreview/receiptpreview.component';

@Component({
  selector: 'rsa-receipt-drafts',
  templateUrl: './receipt-drafts.component.html',
  styleUrls: ['./receipt-drafts.component.scss']
})
export class ReceiptDraftsComponent implements OnInit {
  @Input() receiptDraftData: any = [];
  @Input() VName:string;
  constructor(private modalService: BsModalService) { }

  ngOnInit() {
    console.log(this.receiptDraftData, 'receiptDraftsData-cpomp');
  }

}
