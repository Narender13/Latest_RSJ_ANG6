import { Component, OnInit, Input } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap';
//import { CreateReceiptEntitiRowSelectionComponent } from 'src/app/finance/search/search-results/entity/create-receipt-entiti-row-selection/create-receipt-entiti-row-selection.component';
import { CreateDraftPaymentComponent } from 'src/app/finance/drfats/drafts-results/create-draft-payment/create-draft-payment.component';
import { PaymentpreviewComponent } from 'src/app/finance/preview/uae/paymentpreview/paymentpreview.component';

@Component({
  selector: 'rsa-payment-drafts',
  templateUrl: './payment-drafts.component.html',
  styleUrls: ['./payment-drafts.component.scss']
})
export class PaymentDraftsComponent implements OnInit {
  @Input() paymentDraftData: any = [];
  @Input() VName: string;
  @Input() isClaimPayment: boolean;
  paymentHeading:string;
  constructor(private modalService: BsModalService) { }

  ngOnInit() {
    if(this.isClaimPayment)
    {
      this.paymentHeading = 'Claim Payments';
    }
    else
    {
      this.paymentHeading ='Payments';
    }
   // console.log(this.paymentDraftData, 'paymentDraftData-cpomp');
  }

}
