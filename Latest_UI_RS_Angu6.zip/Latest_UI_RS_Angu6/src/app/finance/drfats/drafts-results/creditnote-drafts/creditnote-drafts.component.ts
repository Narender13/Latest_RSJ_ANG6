import { Component, OnInit, Input } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap';
import { CreateDraftCreditnoteComponent } from '../../../drfats/drafts-results/create-draft-creditnote/create-draft-creditnote.component';
import { CnpreviewComponent } from 'src/app/finance/preview/uae/cnpreview/cnpreview.component';

@Component({
  selector: 'rsa-creditnote-drafts',
  templateUrl: './creditnote-drafts.component.html',
  styleUrls: ['./creditnote-drafts.component.scss']
})
export class CreditnoteDraftsComponent implements OnInit {

  @Input() creditnoteDraftData: any = [];
  @Input() VName:string;
  constructor(private modalService: BsModalService) { }

  ngOnInit() {
    console.log(this.creditnoteDraftData, 'creditnoteDraftData-cpomp');
  }


}
