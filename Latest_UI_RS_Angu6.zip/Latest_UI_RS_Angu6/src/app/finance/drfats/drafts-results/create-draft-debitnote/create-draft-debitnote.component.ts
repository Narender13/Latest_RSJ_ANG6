import { Component, OnInit, ViewChild } from '@angular/core';
import { SharedService } from 'src/app/finance/services/shared.service';
import { FormBuilder, FormControl, FormGroup, FormArray, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';
import { ConfirmationDialogComponent } from 'src/app/shared/custom-model/custom-model.component';
import { BsModalService } from 'ngx-bootstrap/modal';
import { TabsetComponent } from 'ngx-bootstrap/tabs';
import { CreateReceipt } from 'src/app/finance/search/model/create-receipt';
import { UtilityClass } from 'src/app/shared/utilites/helper-class';
import { MasterDataService } from 'src/app/finance/services/finance.masterdata.service';
import { CreateDebitNotes } from 'src/app/finance/debitnotes/create-debitnotes/model/create-dn';
import { BasevoucherComponent } from 'src/app/finance/basevoucher/basevoucher.component';
import { CreateDebitnotesService } from 'src/app/finance/debitnotes/create-debitnotes/service/create-debitnotes.service';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { ReceiptpreviewComponent } from 'src/app/finance/preview/uae/receiptpreview/receiptpreview.component';
import { TaxinvoicepreviewComponent } from 'src/app/finance/preview/uae/taxinvoicepreview/taxinvoicepreview.component';

@Component({
  selector: 'rsa-create-draft-debitnote',
  templateUrl: './create-draft-debitnote.component.html',
  styleUrls: ['./create-draft-debitnote.component.scss']
})
export class CreateDraftDebitnoteComponent extends BasevoucherComponent implements OnInit {
  title = 'Tax Invoice';
  currency = 'AED';
  errorpayee: boolean;
  errordetail: boolean;
  errorglCode: boolean;
  /* form error-feilds */
  errorbankcodeCheque: boolean;
  level: any = 2;
  errorbankcodeBanktransfer: boolean;
  errorpaayeebanknameCheque: boolean;
  errorpaayeebanknameBanktransfer: boolean;
  errorchequedateCheque: boolean;
  errorchequedateBankT: boolean;
  errorchequedateCreditCard: boolean;
  errorchequenoCheque: boolean;
  errorchequenoCreditCard: boolean;
  errorterminalID: boolean;
  errorexpirydate: boolean;
  matchedRecords = [];
  isUploadUnmatched;
  returnValue: any;
  usersReq;
  symbol;
  glAcountHeader: any = [];
  createDebitNotes: CreateDebitNotes;
  animatedClass = true;
  selectedRowItem: any;
  debitnoteEditData: any;
  customerName: string = "";
  ondemandFlag: boolean = false;
  ondemandFlagClaim = true;
  formArray: any;
  unApproved;
  accountingCode;
  receiptAccountingDate: any;

  @ViewChild('tabset') tabset: TabsetComponent;
  constructor(
    protected sharedService: SharedService,
    private fb: FormBuilder,
    protected modalService: BsModalService,
    protected bsModalRef: BsModalRef,
    protected masterDataService: MasterDataService,
    protected utilityClass: UtilityClass,
    protected createPaymentService: CreateDebitnotesService,
    private alertService: AlertService,
  ) {
    super(masterDataService, sharedService, modalService, utilityClass, bsModalRef);
    //super.setMinMaxDate();
  }

  ngOnInit() {
    /* super with method is calling from BasevoucherComponent */
    this.createVoucherForm(this.paymentMode);
    this.isRowDraftDN = true;
    this.dnEditData = this.debitnoteEditData;
    console.log(this.dnEditData, 'this.dnEditData');
    super.getAllBranchData();
    super.getAllCostCenterData({ ev: null, index: 0, flag: true });
    super.getAllTotallingData(true);
    super.getAllProjData();
    super.getAllDeptData();
    super.getAllMasterData2();
    this.fieldStatusChanges();
    super.closeModel();
    super.getAllTranData();
    this.symbol = (localStorage.getItem('symbol'));
    //super.setMinMaxDate();
    this.getGlAccountHeader();
    this.getDetailsArrayFormGroup();
    super.getModelPreviousClose();
    super.getAllgetLookupBanksData();
    super.getTotalingHeaderDataCnDn();
    const totcode = this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.value;
    super.getGlAccountHeaderDataCnDn(totcode);
    this.getActualAmountSum('DN');
      this.setHeaderData();
      super.GetAccountingDates();
  }

  /* create entiti form */
  createVoucherForm(param): void {
    this.mainVoucherForm = null;
    //let tranDate = localStorage.getItem('tranAccntMnthStrtDate') ? new Date(localStorage.getItem('tranAccntMnthStrtDate')) : new Date();
    this.mainVoucherForm = this.fb.group({
      VoucherDate: [new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy')],
      ApprovedBy: [],
      ArabicDescription: [],
      Amount: [''],
      CountryCode: [1],
      CustomerID: [],
      CustCode: [],
      ModifiedBy: ['1'],
      ModifiedDate: [],
      PreparedBy: [1],
      PreparedDate: [],
      ReprintNo: [],
      PrintDate: [],
      RefreshDate: [],
      PostedDate: [],
      PreprintNo: [],
      Title: ['CREDIT NOTE'],
      RegionCode: [localStorage.getItem('regioncode')],
      Approvers: this.fb.array([]),
      detailInfo: this.fb.group({
        PayeeName: [this.customerName, Validators.required],
        EnglishDescription: ['', Validators.required],
      }),
      accountInfo: this.fb.group({
        LocationCode: [localStorage.getItem('locationcode')],
        CostCenterCode: [localStorage.getItem('costcentre')],
        TotallingAccCode: [1110],
        GLCode: [4, Validators.required],
        GLCodeDesc: ['4-HSBC BANK MIDDLE EAST - Deira', Validators.required]
      }),
      VoucherDetails: this.fb.array([])
    });
  }
  setHeaderData() {
    this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.setValue(this.debitnoteEditData.TotallingAccCode);
    this.mainVoucherForm.controls.accountInfo['controls'].GLCode.setValue(this.debitnoteEditData.GLCode);
    this.mainVoucherForm.controls.accountInfo['controls'].GLCodeDesc.setValue(this.debitnoteEditData.GLCodeDesc);
    this.mainVoucherForm.controls.detailInfo['controls'].PayeeName.setValue(this.debitnoteEditData.PayeeName);
    this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription.setValue(this.debitnoteEditData.EnglishDescription);

  }
  getDetailsArrayFormGroup() {
    let control = <FormArray>this.mainVoucherForm.controls['VoucherDetails'];
    console.log('this.debitnoteEditData', this.debitnoteEditData);
    this.selectedRowItem = this.debitnoteEditData.DebitNoteDetail;
    if (!this.ondemandFlag) {
      this.mainVoucherForm.controls['CustomerID'].setValue(this.debitnoteEditData.CustomerID);
      this.mainVoucherForm.controls['CustCode'].setValue(this.debitnoteEditData.CustCode);

      this.selectedRowItem.map((item, index) => {

        super.getAllCostCenterData({ ev: null, index: index, flag: true });
        let group = this.createDetailsArrayGroup();
        group.patchValue(item);
        group.get("newAddedRow").setValue(false);
        group.get('IsDebitEntry').setValue((parseFloat(group.get("Amount").value) >= 0) ? false : true);
        control.push(group);
      });
      // } if (!this.ondemandFlagClaim) {
      //   console.log(this.selectedRowItem, 'this.selectedRowItem');
      //   this.selectedRowItem.map(item => {
      //     let group = this.createDetailsArrayGroup();
      //     group.patchValue(item);
      //     group.get("newAddedRow").setValue(false);
      //     control.push(group);
      //   });
    } else {
      control.push(this.createDetailsArrayGroup());
    }
  }


  getGLdataCnDn(ev) {
    const totcode = ev.ev;
    console.log(totcode, 'totcode');
    super.getGlAccountHeaderDataCnDn(totcode);
  }

  /* form array for recept details */
  createDetailsArrayGroup(): FormGroup {
    return this.fb.group({
      Amount: ['', Validators.required],
      AnalysisCode: [],
      CostCenterCode: [localStorage.getItem('costcentre')],
      ClaimID: [],
      ClassCode: [],
      CauseOfLossCode: [],
      CounterPartyRef: [],
      CountryCode: [1],
      Description: [],
      DocumentCode: [],
      EntityID: [],
      GLCode: [4, Validators.required],
      GLCodeDesc: ['4-HSBC BANK MIDDLE EAST - Deira', Validators.required],
      LocationCode: [localStorage.getItem('locationcode')],
      LocationDesc: ['Dubai'],
      ModifiedBy: ['1'],
      ModifiedDate: [],
      NatureOfLossCode: [],
      PolicyID: [],
      PolicyYear: [],
      PreparedBy: [],
      PreparedDate: [],
      RefTransactionID: [],
      RefTransactionSerialNo: [],
      RefTransactionType: [11],
      RegionCode: [localStorage.getItem('regioncode')],
      TotallingAccCode: [1110],
      PolicyType: [],
      newAddedRow: true,
      IsDebitEntry: [true],
      VoucherNo: [],
      SerialNo: [],
      Department: [],
      DepartmentCode: []
    });
  }

  /* set receipt mode and set default values   */
  setReceiptMode(val, paymentname) {
    this.mainVoucherForm.controls['PaymentMode'].setValue(val);
    this.paymentMode = val;
    this.paymentname = paymentname;
    this.createVoucherForm(this.paymentMode);
    this.receiverdataBankName = this.cachedReceiverBankData;
    this.totallingacc = this.cachedTotAcc;
    this.payeedataBankName = this.cachedPayeeBankData;
    if (this.paymentMode == 1) {
      this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.setValue('1210');
    } else {
      this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.setValue('1110');
      this.mainVoucherForm.controls.accountInfo['controls'].RecevierBankCode.setValue('14');
    }
    this.setdefaultHeaderData();
    this.fieldStatusChanges();
    super.GetAccountingDates();
  }


  /* using req fields and update status  */
  fieldStatusChanges() {
    this.clearerrors();
    this.cshpayeename.statusChanges.subscribe(
      status => {
        this.errorpayee = (status === 'INVALID');
        console.log(this.errorpayee, 'his.errorpayee');
      }
    );
    this.cshdetails.statusChanges.subscribe(
      status => {
        this.errordetail = (status === 'INVALID');
      }
    );

    // this.glCodeValue.statusChanges.subscribe(
    //   status => {
    //     this.errorglCode = (status === 'INVALID');
    //   }
    // );

  }

  /* clear all errors after reset   */
  clearerrors() {
    this.errorpayee = false;
    this.errordetail = false;
    //this.errorglCode = false;
  }

  /* get the controls of each fields   */
  get cshpayeename() { return this.mainVoucherForm.controls.detailInfo['controls'].PayeeName; }
  get cshdetails() { return this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription; }
  //get glCodeValue() { return this.mainVoucherForm.controls.detailInfo['controls'].GLCode; }


  /* set Description in receptdetails desc   */
  setDescription() {
    (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls[0].get('Description').setValue(this.cshdetails.value);
  }
  getActualAmountSum(processFlag) {
    let total: number = 0;
    let amt: number = 0;
    let actualamt: number = 0;
    let flagtoggle: boolean = false;
    (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls.forEach((element, index) => {

      if (this.getFromFormArrayControlVal("Amount", index) != undefined
        && this.getFromFormArrayControlVal("Amount", index) != null) {
        flagtoggle = this.getFromFormArrayControlVal("IsDebitEntry", index);
        amt = parseFloat(this.getFromFormArrayControlVal("Amount", index));
        amt = Math.abs(amt || 0);
        if (processFlag == 'DN') {
          actualamt = (flagtoggle) ? (amt * -1) : amt;
        } else if (processFlag == 'CN') {
          actualamt = (!flagtoggle) ? amt : (amt * -1);
        }
        console.log('flagtoggle:' + flagtoggle + ",amt:" + amt + ",actualamt:" + actualamt);
        total = total + actualamt;
      }

    });
    this.totalAmount = total;
  }
  setCreditEntryDn(ev) {
    const actualData = Number(ev.data.controls['Amount'].value);
    if (actualData === 0 || actualData === undefined) {
      this.displayAlertModal({
        'title': RSAMSGConstants.MODELTITLE,
        'txt': RSAMSGConstants.AMOUNTVALIDATIONMSG,
        'btnaction': RSAMSGConstants.OKTEXT
      });
      ev.event.target.checked = !ev.event.target.checked;

    }
    this.setFormArrayCTRLDefaultValue(ev.iscredit, ev.index, !ev.event.target.checked);
    this.getActualAmountSum('DN');
    if (this.totalAmount > 0) {
      ev.event.target.checked = false;
      this.setFormArrayCTRLDefaultValue(ev.iscredit, ev.index, false);
      this.displayAlertModal({
        'title': RSAMSGConstants.MODELTITLE,
        'txt': RSAMSGConstants.CREDITEXCEEDMSG,
        'btnaction': RSAMSGConstants.OKTEXT
      });
    }
    this.getActualAmountSum('DN');
  }
  /// update amount before submit
  updateDetailsAmount(processFlag) {
    let amt = 0;
    let actualamt = 0;
    let flagtoggle = true;
    (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls.forEach((element, index) => {

      if (this.getFromFormArrayControlVal('Amount', index) != undefined && this.getFromFormArrayControlVal('Amount', index) != null) {
        flagtoggle = this.getFromFormArrayControlVal('IsDebitEntry', index);
        amt = parseFloat(this.getFromFormArrayControlVal('Amount', index));
        amt = Math.abs(amt);
        if (processFlag == 'DN') {
          actualamt = (flagtoggle) ? (amt * -1) : amt;
        } else if (processFlag == 'CN') {
          actualamt = (!flagtoggle) ? amt : (amt * -1);
        }
        this.setFormArrayCTRLDefaultValue('Amount', index, actualamt);
      }
    });
  }

  /* add receipt in review screen */
  addReceipt(len) {
    const control = <FormArray>this.mainVoucherForm.controls['VoucherDetails'];
    const CurrentAmount = (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls[len - 1].get('Amount').value;
    if (CurrentAmount != 0) {
      control.push(this.createDetailsArrayGroup());
      this.setFormArrayCTRLDefaultValue('GLCode', len, 4);
      this.setFormArrayCTRLDefaultValue('GLCodeDesc', len, '4-HSBC BANK MIDDLE EAST - Deira');
      this.dtltotallingacc[len] = this.cachedDtlTot;
      this.glaccount[len] = this.cachedGL;
    } else {
      this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
      this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
      this.bsModalRef.content.modelBodyContent = RSAMSGConstants.AMOUNTVALIDATIONMSG;
      this.bsModalRef.content.cancelBtn = RSAMSGConstants.OKTEXT;
      return false;
    }
  }

  reSetForm(params) {
    const param = params.defaultParam;
    /*set default value here and reset */
    if (param == 1) {
      super.validateAllFormFields(this.mainVoucherForm);
      this.mainVoucherForm.controls.VoucherDate.setValue([new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy')]);
      this.mainVoucherForm.controls.GLCode.setValue(4);
      this.mainVoucherForm.controls.GLCodeDesc.setValue('4-HSBC BANK MIDDLE EAST - Deira');
      this.clearerrors();
    } else if (param == 2) {
      this.mainVoucherForm.controls['VoucherDetails'].reset();
      (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls.map(item => {
        item.get('LocationCode').setValue([localStorage.getItem('locationcode')]);
        item.get('CostCenterCode').setValue([localStorage.getItem('costcentre')]);
        item.get('RefTransactionType').setValue(3);
        item.get('TotallingAccCode').setValue(1110);
        item.get('GLCode').setValue(4);
        item.get('GLCodeDesc').setValue('4-HSBC BANK MIDDLE EAST - Deira');
      });
      this.getActualAmountSum('DN');
    }
    super.GetAccountingDates();
  }

  /* update  form values to create-receipt objects*/
  createCNFormValues() {
    this.createDebitNotes = new CreateDebitNotes();
    const mainFormFieldArray = ['VoucherDate', 'ApprovedBy', 'ArabicDescription',
      'CountryCode', 'CustomerID', 'CustCode', 'ModifiedDate', 'ModifiedBy', 'PostedDate',
      'PreparedBy', 'PreparedDate', 'PreprintNo', 'PrintDate', 'RefreshDate', 'RegionCode', 'Title',
      'Approvers'];
    mainFormFieldArray.forEach(item => {
      console.log('this.item****', item);
      this.createDebitNotes[item] = this.mainVoucherForm.controls[item].value;

    });
    this.createDebitNotes.LocationCode = this.mainVoucherForm.controls.accountInfo['controls'].LocationCode.value;
    this.createDebitNotes.CostCenterCode = this.mainVoucherForm.controls.accountInfo['controls'].CostCenterCode.value;
    this.createDebitNotes.TotallingAccCode = this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.value;
    this.createDebitNotes.GLCode = this.mainVoucherForm.controls.accountInfo['controls'].GLCode.value;

    this.createDebitNotes.PayeeName = this.mainVoucherForm.controls.detailInfo['controls'].PayeeName.value;
    this.createDebitNotes.EnglishDescription = this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription.value;
    this.createDebitNotes.DebitNoteDetail = this.mainVoucherForm.controls['VoucherDetails'].value;
    console.log('this.createCreditNotes****', this.createDebitNotes);

  }

  /* create-receipt form*/
  submitForm() {
    super.validateDetailInfo();
    this.errorpayee = this.cshpayeename.invalid;
    this.errordetail = this.cshdetails.invalid;

    if (!(!this.errorpayee && !this.errordetail && !this.errorglCode)) {
      return false;
    }
    this.updateDetailsAmount('DN');
    //zero amount warning
    if (this.amountZeroCheck > 0) {
      this.alertService.warn(RSAMSGConstants.AMOUNTZEROCHECK);
      return false;
    }
    if (this.glerrorcount > 0) {
      return false;
    }
    this.usersReq = (this.approverusers !== undefined && this.approverusers !== '' &&
      this.approverusers.length > 0);
    if (this.totalAmount < 0) {
      if (!(localStorage.getItem('country') == '3')) {
        if (this.totalAmount > 99999 && !this.usersReq) {
          return false;
        }
      }
      this.createCNFormValues();
      console.log(this.createDebitNotes, ' this.createCreditNotes');
      if (this.prevPreviewID == null || this.prevPreviewID == undefined) {
        this.prevPreviewID = 0;
        this.createDebitNotes['DebitNoteNo'] = this.prevPreviewID;
      }
      this.createDebitNotes['DebitNoteNo'] = this.debitnoteEditData.DebitNoteNo;
      this.createPaymentService.createDebitNote(JSON.stringify(this.createDebitNotes)).subscribe(
        dataReturn => {
          this.returnValue = dataReturn;
          this.returnValue['approverlist'] = this.approverusers;
          this.returnValue['ondemand'] = true;
          this.previewFlag = true;
          // tslint:disable-next-line:max-line-length
          this.bsModalRef = this.modalService.show(TaxinvoicepreviewComponent, { class: 'preview-modal-dailog', ignoreBackdropClick: true });
          this.bsModalRef.content.data = this.returnValue;
          this.bsModalRef.content.totalAmount = this.totalAmount;
          this.bsModalRef.content.backdrop = true;
          this.bsModalRef.content.unApproved = this.unApproved;
        },
        errorRturn => {
          this.errorMsg = errorRturn;
        }
      );
    }
    if (this.totalAmount >= 0) {
      this.alertService.warn(RSAMSGConstants.AMOUNTTEXTREQ);
    }
  }


  getGlAccountHeader() {
    const param = 'totAccCode=1110' +
      '&ccCode=' + localStorage.getItem('costcentre');
    this.masterDataService.getDetailGlAccount(param).subscribe(data => {
      this.glAcountHeader = data;
      console.log('gldata', data);
      // tslint:disable-next-line:max-line-length
      const isGLCodeAvailable = data.filter(item => item.Code == this.debitnoteEditData.GLCode);
      if (isGLCodeAvailable.length <= 0) {
        this.mainVoucherForm.controls.accountInfo['controls'].GLCode.setValue(data[0].Code);
      }
    });
  }

  setGLHdrHiddenValue(ev) {
    console.log(ev);
    this.mainVoucherForm.controls.detailInfo['controls'].GLCode.setValue(ev.item.Code);
  }
  clearHdrGLCode(ev) {
    this.mainVoucherForm.controls.detailInfo['controls'].GLCode.setValue('');
    this.mainVoucherForm.controls.detailInfo['controls'].GLCodeDesc.setValue('');
  }
}

