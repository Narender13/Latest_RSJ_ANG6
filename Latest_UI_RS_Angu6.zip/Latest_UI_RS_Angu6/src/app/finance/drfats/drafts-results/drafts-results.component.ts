import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { DrfatService } from './services/drafts.service';
import { SharedService } from '../../services/shared.service';
import { RSAConstants } from 'src/app/core/constants/rsaconstant';


@Component({
  selector: 'rsa-drafts-results',
  templateUrl: './drafts-results.component.html',
  styleUrls: ['./drafts-results.component.scss']
})
export class DraftsResultsComponent implements OnInit {
  voucherName;
  voucherCount;
  receiptDraftsData: any = [];
  debitnoteDraftsData: any = [];
  creditnoteDraftsData: any = [];
  paymentDraftsData: any = [];
  JournalDraftsData: any = [];
  clmPmtDraftsData: any = [];
  isClaimPayment: boolean;

  constructor(private route: ActivatedRoute, private drfatService: DrfatService, private sharedService: SharedService) { }

  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      console.log(params, "paramsssss");
      this.voucherName = params['voucherName'];
      this.voucherCount = params['voucherCount'];
      this.getDrfatsDetails(this.voucherName);
    });
    this.refreshGridOnFinalize();
  }

  refreshGridOnFinalize() {
    this.sharedService.getMessage().subscribe((data) => {
      console.log(data, 'data');
      const voucherName = data.voucherName;
      const message = data.message;
      console.log(voucherName, message, 'voucherName message');
      if (message === 'save-voucher') {
        this.getDrfatsDetails(voucherName);
      }
    });
  }

  getDrfatsDetails(voucherName) {
    if (voucherName == 'Receipts') {
      this.getDrfatsReceipt();
    }

    if (voucherName == 'Tax Invoice') {
      this.getDrfatsDebitnote();
    }
    if (voucherName == 'Credit Note') {
      this.getDrfatsCreditnote();
    }
    if (voucherName == 'Payments') {
      this.getDrfatsPayment();
    }
    if (voucherName == 'JV') {
      this.getDrfatsJournal();
    }
    if (voucherName == 'Claim Payments') {
      this.getClmPaymentDrafts();
    }
  }

  getDrfatsReceipt() {
    const param = 'loggedInUserId=' + localStorage.getItem(RSAConstants.LoggedInUserId);
    this.drfatService.getDraftReceipts(param).subscribe(data => {
      this.receiptDraftsData = data;
      console.log(data, 'Receiptdata');
    });
  }


  getDrfatsDebitnote() {
    const param = 'loggedInUserId='+localStorage.getItem(RSAConstants.LoggedInUserId);
    this.drfatService.getDrfatsDebitnotes(param).subscribe(data => {
      this.debitnoteDraftsData = data;
      console.log(data, 'Dndata');

    });
  }

  getDrfatsCreditnote() {
    const param = 'loggedInUserId='+localStorage.getItem(RSAConstants.LoggedInUserId);
    this.drfatService.getDrfatsCreditnotes(param).subscribe(data => {
      this.creditnoteDraftsData = data;
      console.log(data, 'Cndata...');
    });
  }

  getDrfatsPayment() {
    const param = 'loggedInUserId=' + localStorage.getItem(RSAConstants.LoggedInUserId);
    this.drfatService.getDrfatsPayments(param).subscribe(data => {
      this.paymentDraftsData = data;
      console.log(data, 'payment Data');
    });
  }

  getClmPaymentDrafts() {
    const locCode = localStorage.getItem('locationcode');
      const param = 'type=Drafts&loggedInUserId='+localStorage.getItem(RSAConstants.LoggedInUserId);
    this.drfatService.getClmPaymentDrafts(param).subscribe(data => {
      this.clmPmtDraftsData = data;
    });
  }

  getDrfatsJournal() {
 
    const param = 'loggedInUserId='+localStorage.getItem(RSAConstants.LoggedInUserId);
    this.drfatService.getDrfatsJournals(param).subscribe(data => {
      this.JournalDraftsData = data;
      console.log(data, 'jvdata');
    });
  }

}

