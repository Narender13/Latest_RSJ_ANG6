import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'rsa-drafts-header',
  templateUrl: './drafts-header.component.html',
  styleUrls: ['./drafts-header.component.scss']
})
export class DraftsHeaderComponent implements OnInit {
  @Input() catid: number;
  constructor(private router: Router) { }

  ngOnInit() {
  }
  getVoucherType(vochername) {
    const params = {
      'voucherName': vochername,
    };
    //console.log(params);
    this.router.navigate(['home/search/draft'], {
      queryParams: params
    });
  }
}

