import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'rsa-cheque',
  templateUrl: './cheque.component.html',
  styleUrls: ['./cheque.component.scss']
})
export class ChequeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
