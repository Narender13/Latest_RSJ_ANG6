import { Component, OnInit, ChangeDetectorRef, ViewChild } from '@angular/core';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { FormBuilder, FormControl, FormGroup, FormArray, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { CreateService } from './service/create.service';
import { Router } from '@angular/router';
import { MasterDataService } from 'src/app/finance/services/finance.masterdata.service';
import { ConfirmationDialogComponent } from 'src/app/shared/custom-model/custom-model.component';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';
import { ReceiptpreviewComponent } from 'src/app/finance/preview/uae/receiptpreview/receiptpreview.component';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { TabsetComponent } from 'ngx-bootstrap/tabs';
import { Customvalidators } from 'src/app/shared/validators/customvalidators';
import { SharedService } from 'src/app/finance/services/shared.service';
import { SearchService } from '../../search/service/search.service';
import { parseDate } from 'ngx-bootstrap/chronos';
import { RSAConstants } from 'src/app/core/constants/rsaconstant';
import { forEach } from '@angular/router/src/utils/collection';

@Component({
  selector: 'rsa-create-receipt',
  templateUrl: './create-receipt.component.html',
  styleUrls: ['./create-receipt.component.scss']
})
export class CreateReceiptComponent implements OnInit {
  formBuilder: any;
  title = 'Receipt';
  currency: any;
  payeedataBankName: any = [];
  receiverdataBankName: any = [];
  receiptForm: FormGroup;
  clonedReceipts: FormGroup;
  terminals: any = [];
  level: any = 1;
  collapsetoheader: boolean;
  getbankterminaldetails = {};
  getglcodeanduser: any;
  hdrtotallingacc: any = [];
  dtltotallingacc: any = [];
  errorMsg: string;
  searchkey: any;
  id: any;
  isExpaned = false;
  returnValue: any;
  results: any;
  slided;
  public Amount: number;
  pjctindicator: any = [];
  department: any = [];
  placeholder: any;
  glaccount: any = [];
  totallingacc: any = [];
  transactiontype: any = [];
  chequeTypeData: any = [];
  private masterdata: any = [];
  private masterdata2: any = [];
  costcentredata: any = [];
  branchdata: any = [];
  users: any = [];
  RcptMode = 2;
  displayApprover = false;
  approverusers: string;
  totalAmount = 0;
  symbol: string;
  arrUser: any = [];
  minDateRd;
  maxDateRd;
  minDateCr;
  currentDate;
  userlist;
  usersReq = true;
  glerrorcount: number = 0;
  paymentname = 'CASH';
  errorpayee: boolean;
  errordetail: boolean;
  errorbankcode: boolean;
  errorchequedate: boolean;
  errorreceiptdate: boolean;
  errorinstrumentdate: boolean;
  errorchequeno: boolean;
  errorChequeTypeCheque: boolean;
  errorchequetype: boolean;
  errorinstrumentrefno: boolean;
  errorterminalID: boolean;
  // errorexpirydate: boolean;
  currentTbIndex = 0;
  isDiabledToggle = true;
  /* added for caching dropdown master data */
  cachedReceiverBankData: any;
  cachedTotAcc: any;
  cachedPayeeBankData: any;
  cachedBranchdata: any;
  cachedCostcentredata: any;
  cachedDtlTot: any;
  cachedGL: any;
  previewFlag: boolean = false;
  prevReceipt: any;
  previewDataDtl: any = [];
  isUAE;
  accountingCode = '1';
  accountingStartDate: any;
  accountingEndDate: any;
  receiptAccountingDate: any;
  amountZeroCheck;
  amountLimitCheck;
  editReceiptFromPrevious = false;
  defaultUserId;
  defaultTerminalId;

  @ViewChild('tabset') tabset: TabsetComponent;
  constructor(
    private ref: ChangeDetectorRef,
    public bsModalRef: BsModalRef,
    private fb: FormBuilder,
    private createservice: CreateService,
    private masterDataService: MasterDataService,
    private modalService: BsModalService,
    private alertService: AlertService,
    private router: Router,
    private sharedService: SharedService
  ) {
    this.minDateRd = new Date();
    this.maxDateRd = new Date();
    this.minDateRd.setDate(this.minDateRd.getDate() - 0);
    this.maxDateRd.setDate(this.maxDateRd.getDate() - 0);
    this.receiptAccountingDate = new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy');
    this.currentDate = new Date();
  }

  ngOnInit() {

    this.getAllMasterData(1110);
    this.getAllMasterData2(true);
    this.createReceiptForm(this.RcptMode);
    this.getPayeeBankData(true);
    this.getTotallingData(true);
    this.getBankData(true);
    this.getActualAmountSum();
    this.getAllInstrumentTypes();
    this.symbol = (localStorage.getItem('symbol'));
    this.minDateCr = new Date();
    this.minDateCr.setDate(this.minDateCr.getDate() - 0);
    this.fieldStatusChanges();
    this.GetAccountingDates();
    this.sharedService.getMessage().subscribe(val => {
      if (val == "previous") {
        this.previewFlag = false;
        this.editReceiptFromPrevious = true;
      }
      else if (val == "close") {
        this.modalService.hide(1);
      }
      console.log(val, '%%%%%%%%%%%val');
      this.prevReceipt = val.id;
      this.previewDataDtl = val.data;
      if (this.previewDataDtl != null || this.previewDataDtl != undefined) {
        this.doPatchRefFields();
      }
    });
    this.isUAE = localStorage.getItem('country') == '3' ? true : false;
  }
  clearerrors() {
    this.errorpayee = false;
    this.errordetail = false;
    this.errorbankcode = false;
    this.errorchequedate = false;
    this.errorchequetype = false;
    this.errorchequeno = false;
    this.errorinstrumentrefno = false;
    this.errorterminalID = false;
    //this.errorexpirydate = false;
    this.errorreceiptdate = false;
    this.errorinstrumentdate = false;
  }
  doPatchRefFields() {
    let formarray = (<FormArray>this.receiptForm.controls['ReceiptDetails'])
    formarray.controls.map((item, index) => {
      item.get("RefTransactionID").setValue(this.previewDataDtl[index].RefTransactionID);
      item.get("RefTransactionSerialNo").setValue(this.previewDataDtl[index].RefTransactionSerialNo);
    });
  }
  fieldStatusChanges() {

    this.clearerrors();

    this.cshpayeename.statusChanges.subscribe(
      status => {
        this.errorpayee = (status == 'INVALID');
        console.log(this.errorpayee, 'his.errorpayee');
      }
    );
    this.cshdetails.statusChanges.subscribe(
      status => {
        this.errordetail = (status == 'INVALID');
      }
    );
    if (this.RcptMode == 2) {
      if (this.payeebankcode != null && this.payeebankcode != undefined) {
        this.payeebankcode.statusChanges.subscribe(
          status => {
            this.errorbankcode = (status == 'INVALID');
          }
        );
      }

      if (this.instrumentdate != null && this.instrumentdate != undefined) {
        this.instrumentdate.statusChanges.subscribe(
          status => {
            this.errorinstrumentdate = (status == 'INVALID');
          }
        );
      }
    }
    if (this.RcptMode == 5) {
      if (this.payeebankcode != null && this.payeebankcode != undefined && this.payeebankcode.value != '') {
        this.payeebankcode.statusChanges.subscribe(
          status => {
            this.errorbankcode = (status == 'INVALID');
          }
        );
      }
      if (this.instrumentrefno != null && this.instrumentrefno !== undefined) {
        this.instrumentrefno.statusChanges.subscribe(
          status => {
            this.errorinstrumentrefno = (status === 'INVALID');
          }
        );
      }
    }
    if (this.chequedate != null && this.chequedate != undefined) {
      this.chequedate.statusChanges.subscribe(
        status => {
          this.errorchequedate = (status == 'INVALID');

        }
      );

    }


    if (this.receiptdate != null && this.receiptdate !== undefined) {
      this.receiptdate.statusChanges.subscribe(
        status => {
          this.errorreceiptdate = (status === 'INVALID');
        }
      );
    }

    if (this.chequeno != null && this.chequeno != undefined) {
      this.chequeno.statusChanges.subscribe(
        status => {
          this.errorchequeno = (status == 'INVALID');
        }
      );
    }
    if (this.terminalid != null && this.terminalid != undefined) {
      this.terminalid.statusChanges.subscribe(
        status => {
          this.errorterminalID = (status == 'INVALID');
        }
      );
    }
    if (this.chequeType != null && this.chequeType != undefined) {
      this.chequeType.statusChanges.subscribe(
        status => {
          this.errorchequetype = (status == 'INVALID');
        }
      );
    }
    // if (this.expirydate != null && this.expirydate != undefined) {
    //   this.expirydate.statusChanges.subscribe(
    //     status => {
    //       this.errorexpirydate = (status == 'INVALID');
    //     }
    //   );
    // }

  }
  goNext() {
    this.errorpayee = this.cshpayeename.invalid;
    this.errordetail = this.cshdetails.invalid;
    if (this.RcptMode == 2) {
      if (this.payeebankcode != null && this.payeebankcode != undefined) {
        this.errorbankcode = this.payeebankcode.invalid;

      }
      if (this.instrumentdate != null && this.instrumentdate !== undefined) {
        this.errorinstrumentdate = this.instrumentdate.invalid;
      }
    }
    if (this.chequedate != null && this.chequedate !== undefined) {
      this.errorchequedate = this.chequedate.invalid;
    }
    if (this.receiptdate != null && this.receiptdate !== undefined) {
      this.errorreceiptdate = this.receiptdate.invalid;
    }

    if (this.chequeno != null && this.chequeno !== undefined) {
      this.errorchequeno = this.chequeno.invalid;
    }

    if (this.chequeType != null && this.chequeType !== undefined) {
      this.errorchequetype = this.chequeType.invalid;
    }

    // if (this.instrumentrefno != null && this.instrumentrefno != undefined)
    //   this.errorinstrumentrefno = this.instrumentrefno.invalid;
    if (this.RcptMode == 5) {
      if (this.instrumentrefno != null && this.instrumentrefno !== undefined) {
        this.errorinstrumentrefno = this.instrumentrefno.invalid;
      }
    }
    if (this.RcptMode == 8) {
      if (this.terminalid != null && this.terminalid !== undefined) {
        this.errorterminalID = this.terminalid.invalid;
      }
    }

    // if (this.expirydate != null && this.expirydate !== undefined) {
    //   this.errorexpirydate = this.expirydate.invalid;
    // }

    if (!this.errorpayee && !this.errordetail && !this.errorchequedate && !this.errorchequeno && !this.errorinstrumentrefno
      && !this.errorterminalID && !this.errorbankcode && !this.errorreceiptdate && !this.errorinstrumentdate && !this.errorchequetype) {

      (<FormArray>this.receiptForm.controls['ReceiptDetails']).controls[0].get('Description').setValue(this.cshdetails.value);
      this.getTotallingDetailData(0, true);
      this.level = 2;
      this.resetAmountReceiptDetails();
    }

  }
  getSum() {
    this.totalAmount = 0;
    const ctrl = <FormArray>this.receiptForm.controls['ReceiptDetails'];
    ctrl.controls.forEach(val => {
      console.log('val.get(Amount).value', val.get('IsCreditEntry').value);
      const amt = (val.get('Amount').value == null || isNaN(val.get('Amount').value) ||
        val.get('Amount').value == '') ? 0 : val.get('Amount').value;
      // alert(val.get('Amount').value);
      //if(val.get('IsCreditEntry').value)
      this.totalAmount += parseFloat(amt);
      //else
      //  this.totalAmount += (parseFloat(amt)*-1)
    });

    this.totalAmount = (isNaN(this.totalAmount)) ? 0 : this.totalAmount;
  }
  // getSum() {
  //   this.totalAmount = 0;
  //   const ctrl = <FormArray>this.receiptForm.controls['ReceiptDetails'];
  //   ctrl.controls.forEach(val => {

  //     const amt = Math.abs((val.get('Amount').value == null || isNaN(val.get('Amount').value) ||
  //       val.get('Amount').value == '') ? 0 : parseFloat(val.get('Amount').value));

  //       if(val.get('IsCreditEntry').value){
  //         this.totalAmount += amt;
  //       } else{
  //         this.totalAmount -= amt;
  //       }

  //  });

  //   this.totalAmount = (isNaN(this.totalAmount)) ? 0 : this.totalAmount;
  // }

  setReceiptMode(val, paymentname, ev) {
    if (!ev.tabset) { return; } // fix for tab key resetting all values
    this.receiptForm.controls['ReceiptMode'].setValue(val);
    this.RcptMode = val;
    this.paymentname = paymentname;
    console.log(this.RcptMode, 'set');
    if (!this.editReceiptFromPrevious) {
      this.createReceiptForm(this.RcptMode);
    }
    if (this.editReceiptFromPrevious) {
      const control = <FormArray>this.receiptForm.controls['ReceiptDetails'];
      this.createReceiptForm(this.RcptMode);
      this.receiptForm.controls['ReceiptDetails'] = control;
    }
    this.GetAccountingDates();
    this.receiverdataBankName = this.cachedReceiverBankData;
    this.totallingacc = this.cachedTotAcc;
    this.payeedataBankName = this.cachedPayeeBankData;

    if (this.RcptMode == 1) {
      // this.receiptForm.controls.TotallingAccCode.setValue('1210');
      this.getBankData(true);
    } else {
      this.receiptForm.controls['TotallingAccCode'].setValue('1110');
      this.receiptForm.controls['RecevierBankCode'].setValue('14');
    }
    if (this.RcptMode == 5) {
      this.receiptForm.controls['PayeeBankCode'].setValue('');
    }

    this.setdefaultHeaderData();
    this.fieldStatusChanges();
    this.getSum();
  }
  getPayeeBankData(initFlag) {
    this.masterDataService.getPayeeBankData().subscribe(
      dataReturn => {
        this.payeedataBankName = dataReturn;
        if (!initFlag) {
          if (this.RcptMode == 2 || this.RcptMode == 5) {
            this.receiptForm.controls['PayeeBankCode'].setValue('');
          }
        }
        if (initFlag) { this.cachedPayeeBankData = dataReturn; }
      },
      errorRturn => this.errorMsg = errorRturn
    );

  }
  getBankData(flagInit) {
    let ccentre = this.getFormCtrlValue('CostCenterCode');
    let totcode = this.getFormCtrlValue('TotallingAccCode');

    let param = 'totallingAccCode=' + totcode +
      '&costCenter=' + ccentre;
    this.masterDataService.getBankData(param).subscribe(
      dataReturn => {
        this.receiverdataBankName = dataReturn;
        if (!flagInit)
          this.receiptForm.controls['RecevierBankCode'].setValue(this.receiverdataBankName[0].BankCode);
        if (flagInit)
          this.cachedReceiverBankData = dataReturn;
      },
      errorRturn => this.errorMsg = errorRturn
    );
  }
  setBankData(val) {
    this.receiptForm.controls['RecevierBankCode'].setValue('');
    this.getBankData(false);
  }
  setdefaultHeaderData() {
    if (this.terminals != null && this.terminals.length > 0) {
      const terminal = this.terminals.filter(x => x.UserID == localStorage.getItem(RSAConstants.LoggedInUserId));
      this.defaultUserId = terminal != null && terminal[0] != null ? terminal[0].UserID : this.terminals[0].UserID;
      this.defaultTerminalId = terminal != null && terminal[0] != null ? terminal[0].TerminalID : this.terminals[0].TerminalID;
    }
    if (this.RcptMode == 8) {
      this.receiptForm.controls['TerminalUserID'].setValue(this.defaultUserId || this.terminals[0].UserID);
      this.receiptForm.controls['TerminalID'].setValue(this.defaultTerminalId || this.terminals[0].TerminalID);
    }
    if (this.RcptMode == 2 || this.RcptMode == 5)
      this.receiptForm.controls['PayeeBankCode'].setValue('');
    this.clearerrors();
  }
  clearGLCode(indx, val) {

    this.setFormArrayCTRLDefaultValue('GLCode', indx, '');
    this.setFormArrayCTRLDefaultValue('GLCodeDesc', indx, '');

  }
  getGLData(index, initFlag, val) {
    let ccentre = this.getFromFormArrayControlVal('CostCenterCode', index);
    let totcode = (initFlag) ? this.getFromFormArrayControlVal('TotallingAccCode', index) : val;

    let param = 'totallingAccCode=' + totcode +
      '&CostCenterCode=' + ccentre;
    console.log('param-GL', param);

    this.masterDataService.getGLData(param).subscribe(
      dataReturn => {
        this.glaccount[index] = dataReturn;
        console.log(this.glaccount, 'glacount');
        if (!initFlag) {
          // this.setFormArrayCTRLDefaultValue("GLCode", index, this.glaccount[index][0].GLCode);
          // this.setFormArrayCTRLDefaultValue("GLCodeDesc", index, this.glaccount[index][0].GLEngDescription);
        }

        if (initFlag) {
          this.cachedGL = dataReturn;
        }
        console.log(this.cachedGL, 'chaed');
      },
      errorRturn => this.errorMsg = errorRturn
    );
    if (this.level == 2) {
      (<FormArray>this.receiptForm.controls['ReceiptDetails']).controls.map(item => {

        item.get('Amount').updateValueAndValidity();
        item.get('GLCode').updateValueAndValidity();
      });
    }
  }
  changeCostcenter(index, flagInit) {
    let loccode = this.getFromFormArrayControlVal('LocationCode', index);
    this.masterDataService.getCostCenters().subscribe(
      dataReturn => {
        this.costcentredata[index] = dataReturn;
        if (loccode == "20")
          this.setFormArrayCTRLDefaultValue('CostCenterCode', index, 11);
        this.getTotallingDetailData(index, false);
      },
      errorRturn => this.errorMsg = errorRturn
    );
  }
  getTotallingDetailData(index, initFlag) {
    let ccentre = this.getFromFormArrayControlVal('CostCenterCode', index);

    const param = 'paymentMode=' + this.paymentname +
      '&costCenter=' + ccentre;

    this.masterDataService.getTotallingDetailData(param).subscribe(
      dataReturn => {
        this.dtltotallingacc[index] = dataReturn;
        let totcode = this.dtltotallingacc[index][0].TotAccCode;
        if (!initFlag)
          this.setFormArrayCTRLDefaultValue("TotallingAccCode", index, totcode);
        if (initFlag) {
          this.cachedDtlTot = dataReturn;
        }
        this.getGLData(index, initFlag, totcode);
      },
      errorRturn => this.errorMsg = errorRturn
    );
  }
  setHiddenValue(ev, iter, key, setKey) {
    (<FormArray>this.receiptForm.controls['ReceiptDetails']).controls[iter].get(key).setValue(ev.item[setKey]);
    let glAccntId = parseInt(ev.item[setKey]);
    let selGLAccnt = this.glaccount[iter].filter(data => data.GLCode === glAccntId)[0];
    //if(selAccount.length > 0){
    this.setReqValFormArrayControl('AnalysisCode', iter, selGLAccnt.ProjectIndicator ? true : false);
    this.setReqValFormArrayControl('Department', iter, selGLAccnt.Department ? true : false);
    //}
  }
  setFormArrayCTRLDefaultValue(contrlname, index, val) {
    (<FormArray>this.receiptForm.controls['ReceiptDetails']).controls[index].get(contrlname).setValue(val);
  }
  getFromFormArrayControlVal(contrlname, index) {
    return (<FormArray>this.receiptForm.controls['ReceiptDetails']).controls[index].get(contrlname).value;
  }
  getFormCtrlValue(contrlName) {
    console.log(this.receiptForm.controls, 'this.receiptForm.controls');
    return this.receiptForm.controls[contrlName].value;
  }

  getTotallingData(initflag) {
    let ccentre = this.getFormCtrlValue('CostCenterCode');
    const param = 'paymentMode=' + this.paymentname +
      '&costCenter=' + ccentre;

    this.masterDataService.getTotallingData(param).subscribe(
      dataReturn => {
        this.totallingacc = dataReturn;
        if (initflag)
          this.cachedTotAcc = dataReturn;
      },
      errorRturn => this.errorMsg = errorRturn
    );
  }

  setReqValFormArrayControl(contrlname, index, isRequired) {
    //isRequired = true;
    let selCtrl = (<FormArray>this.receiptForm.controls['ReceiptDetails']).controls[index].get(contrlname);

    if (contrlname === 'AnalysisCode') {
      this.receiptForm.value.ReceiptDetails[index].isPIRequired = isRequired;
    }
    if (contrlname === 'Department') {
      this.receiptForm.value.ReceiptDetails[index].isDepRequired = isRequired;
    }
    if (isRequired) {
      if (selCtrl.value === null || selCtrl.value === '') {
        selCtrl.setValidators([Validators.required]);
        selCtrl.markAsTouched();
        selCtrl.markAsDirty();
        selCtrl.setErrors({ 'incorrect': true });
      }
      (<FormArray>this.receiptForm.controls['ReceiptDetails']).controls[index].updateValueAndValidity();
    }
    else {
      selCtrl.clearValidators();
    }
  }

  changeDepartment(event, index) {
    this.receiptForm.value.ReceiptDetails[index].isDepRequired = false;
  }

  changeProjectIndicator(event, index) {
    this.receiptForm.value.ReceiptDetails[index].isPIRequired = false;
  }

  /* get all instrument types */
  getAllInstrumentTypes() {
    this.masterDataService.getInstrumentTypes().subscribe((data) => {
      this.chequeTypeData = data.filter(c => c.Related_Code == 8);
    },
      errorRturn => this.errorMsg = errorRturn
    );
  }

  getAllMasterData(totalacc): void {
    this.masterDataService.getAllMasterData(totalacc).subscribe(
      dataReturn => {
        this.masterdata = dataReturn;
        console.log(dataReturn, ' : master data');
        //this.payeedataBankName = this.masterdata.LoadPayeeBanks;
        this.terminals = this.masterdata.Terminals;
        this.pjctindicator = this.masterdata.ProjectIndicators;
        this.department = this.masterdata.Departments;
        this.transactiontype = this.masterdata.TransactionType;

      },
      errorRturn => this.errorMsg = errorRturn
    );
  }
  getAllMasterData2(initFlag): void {
    this.masterDataService.getAllMasterData2().subscribe(
      dataReturn => {
        this.masterdata2 = dataReturn;
        console.log(dataReturn, ' : master data');
        //this.glaccount = this.masterdata2.GLCodes;
        this.users = this.masterdata2.Users;
        // console.log(this.users, 'USERS');
        this.branchdata = this.masterdata2.Locations;
        this.costcentredata[0] = this.masterdata2.CostCenter;
        if (initFlag) {
          this.cachedBranchdata = this.masterdata2.Locations;
          this.cachedCostcentredata = this.masterdata2.CostCenter;
        }
      },
      errorRturn => this.errorMsg = errorRturn
    );
  }

  onUserChange(userid: string, isChecked: boolean, username: string) {
    const userFormArray = <FormArray>this.receiptForm.controls.Approvers;
    if (isChecked) {
      userFormArray.push(new FormControl(userid));
      this.arrUser.push(username);
    } else {
      const index = userFormArray.controls.findIndex(x => x.value == userid);
      userFormArray.removeAt(index);
      this.arrUser = this.arrUser.filter(v => v !== username);
    }
    this.approverusers = this.arrUser.join();
    console.log(this.approverusers);
  }

  createReceiptForm(param): void {
    this.receiptForm = null;
    //let tranDate = localStorage.getItem('tranAccntMnthStrtDate') ? new Date(localStorage.getItem('tranAccntMnthStrtDate')) : new Date();
    this.receiptForm = this.fb.group({
      ReceiptDate: [new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy')],
      ReceiptMode: [this.RcptMode],
      PrintDate: [new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy')],
      ReceiptType: [null],
      PreparedBy: [localStorage.getItem(RSAConstants.LoggedInUserId)],
      ModifiedBy: ['1'],
      Approvers: this.fb.array([]),
      CustomerID: [],
      TerminalID: [],
      TerminalUserID: [],
      TerminalUserName: [],
      CountryCode: [1],
      LocationCode: [localStorage.getItem('locationcode')],
      RegionCode: [localStorage.getItem('regioncode')],
      ReprintNo: [],
      CostCenterCode: [localStorage.getItem('costcentre')],
      ArabicDescription: [],
      TotallingAccCode: [1110],
      RecevierBankCode: [14],
      PayeeBankCode: ['', Validators.required],
      ChequeDateFld: [''],
      //PayeeBankName: [],
      PayeeName: ['', Validators.required],
      EnglishDescription: ['', Validators.required],
      ReceiptDetails: this.fb.array([this.createNewReceiptFormGroup()])
    });
    switch (param) {
      case 1:

        this.receiptForm.addControl('Amount', new FormControl(0));

        break;
      case 2:
        this.receiptForm.addControl('ChequeNo', new FormControl('', [Validators.required, Validators.maxLength(12)]));
        this.receiptForm.controls['ChequeNo'].updateValueAndValidity();
        this.receiptForm.addControl('InstrumentDate', new FormControl(new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy'), Validators.required));
        this.receiptForm.controls['InstrumentDate'].updateValueAndValidity();
        this.receiptForm.addControl('PayeeBankCode', new FormControl('', Validators.required));
        this.receiptForm.controls['PayeeBankCode'].updateValueAndValidity();
        this.receiptForm.addControl('PayeeBankName', new FormControl('', Validators.required));
        this.receiptForm.controls['PayeeBankName'].updateValueAndValidity();
        break;
      case 8:
        this.receiptForm.addControl('ChequeNo', new FormControl('', [Validators.required, Customvalidators.creditcardValidator]));
        this.receiptForm.controls['ChequeNo'].updateValueAndValidity();

        this.receiptForm.addControl('InstrumentRefNo', new FormControl(''));
        this.receiptForm.addControl('TransactionNo', new FormControl(''));
        // this.receiptForm.controls['InstrumentRefNo'].updateValueAndValidity();
        this.receiptForm.addControl('ChequeDate', new FormControl(new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy'), Validators.required));
        this.receiptForm.controls['ChequeDate'].updateValueAndValidity();
        this.receiptForm.addControl('TerminalUserID', new FormControl('', Validators.required));
        this.receiptForm.controls['TerminalUserID'].updateValueAndValidity();
        this.receiptForm.addControl('ChequeType', new FormControl('', Validators.required));
        this.receiptForm.controls['ChequeType'].updateValueAndValidity();
        this.receiptForm.addControl('ExpiryDate', new FormControl('', Validators.required));
        this.receiptForm.controls['ExpiryDate'].updateValueAndValidity();

        break;
      case 5:
        this.receiptForm.addControl('PayeeBankCode', new FormControl(''));
        this.receiptForm.controls['PayeeBankCode'].updateValueAndValidity();
        this.receiptForm.addControl('PayeeBankName', new FormControl('', Validators.required));
        this.receiptForm.controls['PayeeBankName'].updateValueAndValidity();
        this.receiptForm.addControl('ChequeDate', new FormControl(new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy'), Validators.required));
        this.receiptForm.controls['ChequeDate'].updateValueAndValidity();
        // defect 3080- make required for bank transfer
        this.receiptForm.addControl('InstrumentRefNo', new FormControl('', [Validators.required]));
        this.receiptForm.controls['InstrumentRefNo'].updateValueAndValidity();

        break;
    }
  }
  onDateValueChange(ev) {
    this.receiptForm.controls['ChequeDateFld'].setValue(new DatePipe('en-US').transform(new Date(ev), 'dd/MM/yyyy'));
  }

  createNewReceiptFormGroup(): FormGroup {
    return this.fb.group({
      CounterPartyRef: [],
      LocationCode: [localStorage.getItem('locationcode')],
      LocationDesc: ['Dubai'],
      CountryCode: [1],
      CostCenterCode: [localStorage.getItem('costcentre')],
      Description: [],
      Amount: [],
      RefTransactionID: [],
      RefTransactionType: [3],
      IsCreditEntry: true,
      PolicyID: [],
      PolicyNumber: [],
      ModifiedBy: ['1'],
      ReceiptDate: [],
      AnalysisCode: [''],
      DepartmentCode: [],
      Department: [],
      RefTransactionSerialNo: [],
      GLCode: [null, Validators.required],
      GLCodeDesc: [null, Validators.required],
      RegionCode: [localStorage.getItem('regioncode')],
      TotallingAccCode: [1110],
      ClassCode: [],
      PolicyYear: [],
      PolicyType: [],
      SerialNo: [0]
    });
  }
  setCreditEntry(ev, iter, key, data) {
    const actualData = Number(data.controls['Amount'].value);

    console.log(actualData, 'actualData');
    if (actualData === 0 || actualData === undefined) {
      this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
      this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
      this.bsModalRef.content.modelBodyContent = RSAMSGConstants.EMPTYAMOUNTCHECK;
      this.bsModalRef.content.cancelBtn = RSAMSGConstants.OKTEXT;
      ev.target.checked = true;
    }

    (<FormArray>this.receiptForm.controls['ReceiptDetails']).controls[iter].get(key).setValue(ev.target.checked);
    this.getActualAmountSum();
    if (this.totalAmount < 0) {
      ev.target.checked = true;
      this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
      this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
      this.bsModalRef.content.modelBodyContent = RSAMSGConstants.CREDITEXCEEDMSG;
      this.bsModalRef.content.cancelBtn = RSAMSGConstants.OKTEXT;
      //data.controls['Amount'].patchValue(-curdata);
      (<FormArray>this.receiptForm.controls['ReceiptDetails']).controls[iter].get(key).setValue(ev.target.checked);

    }
    this.getActualAmountSum();
  }

  // setCreditEntry(ev, iter, key, data) {
  //   const actualData = Number(data.controls['Amount'].value);
  //   (<FormArray>this.receiptForm.controls['ReceiptDetails']).controls[iter].get(key).setValue(ev.target.checked);
  //    this.getSum();
  //   if (actualData === 0 || actualData === undefined) {
  //     this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
  //     this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
  //     this.bsModalRef.content.modelBodyContent = RSAMSGConstants.EMPTYAMOUNTCHECK;
  //     this.bsModalRef.content.cancelBtn = RSAMSGConstants.OKTEXT;
  //     ev.target.checked = true;
  //   }     
  //   if (this.totalAmount < 0) {
  //     ev.target.checked = true;
  //     this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
  //     this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
  //     this.bsModalRef.content.modelBodyContent = RSAMSGConstants.CREDITEXCEEDMSG;
  //     this.bsModalRef.content.cancelBtn = RSAMSGConstants.OKTEXT;
  //     (<FormArray>this.receiptForm.controls['ReceiptDetails']).controls[iter].get(key).setValue(true);
  //     this.getSum();
  //   }

  // }
  setTerminalCode(ev, key, setKey) {
    console.log(ev, 'ev');
    this.receiptForm.controls[key].setValue(ev.item[setKey]);
  }
  setBankCode(ev, iter, key) {
    this.receiptForm.controls[key].setValue(ev.item.BankCode);
  }

  // setting current Tab Index to activiate tab
  setcurrentTbIndex(tab) {
    switch (tab) {
      case 'Cash':
        this.currentTbIndex = 2;
        break;
      case 'Cheque':
        this.currentTbIndex = 0;
        break;
      case 'Credit Card':
        this.currentTbIndex = 1;
        break;
      case 'Bank Transfer':
        this.currentTbIndex = 3;
    }
  }

  confirmTabSwitch(event) {
    const parentElement = event.target.parentElement;
    const target = event.target.parentElement.text;
    if (event.target.tagName === 'SPAN' && !parentElement.classList.contains('active') && parentElement.classList.contains('nav-link')) {
      if (this.receiptForm.dirty) {
        // --- showing popup only you have added or changed something
        this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
        this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
        // Will move the content to RSAMSGConstants once approved // 
        this.bsModalRef.content.modelBodyContent = RSAMSGConstants.PAYMENTMODECHANGEMSG;
        this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
        this.bsModalRef.content.actionBtn = RSAMSGConstants.BTNPROCEED;
        this.bsModalRef.content.valueChange.subscribe((data) => {
          console.log(data);
          // changing the currentTbIndex if user proceed
          if (data = RSAMSGConstants.BTNPROCEED) {
            console.log(this.currentTbIndex);
            setTimeout(() => {
              this.setcurrentTbIndex(target);
            }, 0);
            setTimeout(() => {
              this.tabset.tabs[this.currentTbIndex].active = true;
              /* Resetting the total amount if greater than  zero whiling changing payment method*/
              if (!this.editReceiptFromPrevious) {
                this.totalAmount = this.totalAmount > 0 ? 0 : this.totalAmount;
              }
            }, 1);
          }
        });
      } else {
        setTimeout(() => {
          this.setcurrentTbIndex(target);
        }, 0);
        setTimeout(() => {
          this.tabset.tabs[this.currentTbIndex].active = true;
        }, 1);

      }

    }
    return true;
  }

  addReceipt(len) {
    const control = <FormArray>this.receiptForm.controls['ReceiptDetails'];
    const CurrentAmount = (<FormArray>this.receiptForm.controls['ReceiptDetails']).controls[len - 1].get('Amount').value;
    if (CurrentAmount > 0 && len > 0) {
      control.push(this.createNewReceiptFormGroup());
      // (<FormArray>this.receiptForm.controls['ReceiptDetails']).controls[len].get('GLCode').setValue(4);
      // this.setFormArrayCTRLDefaultValue('GLCode', len, 4);
      // this.setFormArrayCTRLDefaultValue('GLCodeDesc', len, '4-HSBC BANK MIDDLE EAST - Deira');
      //this.getTotallingDetailData(11, len, false);
      this.dtltotallingacc[len] = this.cachedDtlTot;
      this.glaccount[len] = this.cachedGL;
      this.costcentredata[len] = this.cachedCostcentredata;
      //this.getGLData(1110, len, false);
    } else {
      this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md', ignoreBackdropClick: true });
      this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
      this.bsModalRef.content.modelBodyContent = RSAMSGConstants.AMOUNTVALIDATIONMSG;
      this.bsModalRef.content.cancelBtn = RSAMSGConstants.OKTEXT;
      return false;
    }
  }

  deleteReceipt(index: number, itemrow) {

    if (index >= 1) {
      this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md', ignoreBackdropClick: true });
      this.bsModalRef.content.modelTitle = '';
      this.bsModalRef.content.modelBodyContent = RSAMSGConstants.DELETEMSGRECEIPTL;
      this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
      this.bsModalRef.content.actionBtn = RSAMSGConstants.BTNPROCEED;
      this.bsModalRef.content.valueChange.subscribe((data) => {
        if (data = RSAMSGConstants.BTNPROCEED) {
          const control = <FormArray>this.receiptForm.controls['ReceiptDetails'];
          control.removeAt(index);
          this.getActualAmountSum();
        }
      });
    } else {
      this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md', ignoreBackdropClick: true });
      this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
      this.bsModalRef.content.modelBodyContent = RSAMSGConstants.CANTDELETEFIRSTROW;
      this.bsModalRef.content.cancelBtn = RSAMSGConstants.OKTEXT;

    }

    // if (index = 0) {
    //   alert('cant delete the roo');
    // }
  }

  get cshpayeename() { return this.receiptForm.get('PayeeName'); }
  get cshdetails() { return this.receiptForm.get('EnglishDescription'); }
  get payeebankcode() { return this.receiptForm.get('PayeeBankCode'); }
  get chequedate() { return this.receiptForm.get('ChequeDate'); }
  //get chequedatefld() { return this.receiptForm.get('ChequeDateFld'); }
  get instrumentrefno() { return this.receiptForm.get('InstrumentRefNo'); }

  get chequeType() { return this.receiptForm.get('ChequeType'); }
  get terminalid() { return this.receiptForm.get('TerminalUserID'); }
  get expirydate() { return this.receiptForm.get('ExpiryDate'); }
  get chequeno() { return this.receiptForm.get('ChequeNo'); }
  get receiptRows() { return <FormArray>this.receiptForm.get('ReceiptDetails'); }
  get receiptdate() { return this.receiptForm.get('ReceiptDate'); }
  get instrumentdate() { return this.receiptForm.get('InstrumentDate'); }

  validateDetailInfo() {
    this.glerrorcount = 0;
    this.amountZeroCheck = 0;
    this.amountLimitCheck = 0;
    (<FormArray>this.receiptForm.controls['ReceiptDetails']).controls.map(item => {
      item.get('Amount').updateValueAndValidity();
      item.get('Amount').markAsTouched();
      item.get('GLCode').updateValueAndValidity();
      item.get('GLCode').markAsTouched();


      if (item.get('GLCode').value == null || item.get('GLCode').value == undefined || item.get('GLCode').value == "") {
        this.glerrorcount = this.glerrorcount + 1;
      }
      if (item.get('Amount').value == null || item.get('Amount').value == 0 || item.get('Amount').value == undefined
        || item.get('Amount').value == "") {
        this.glerrorcount = this.glerrorcount + 1;
        this.amountZeroCheck = this.amountZeroCheck + 1;
      }

      if (item.get('Amount').value > 999999999.99) {
        this.glerrorcount = this.glerrorcount + 1;
        this.amountLimitCheck = this.amountLimitCheck + 1;
        return false;
      }
    });
  }
  get voucherDetailsLength() {
    return this.receiptForm.controls.ReceiptDetails['controls'].length > 1;
  }
  submitForm(bsModalRef, receiptno) {
    this.validateDetailInfo();
    if (this.amountZeroCheck > 0) {
      this.alertService.warn(RSAMSGConstants.AMOUNTZEROCHECK);
      return false;
    }
    if (this.amountLimitCheck > 0) {
      this.alertService.warn(RSAMSGConstants.AMOUNTEXCEEDMSG);
      return false;
    }
    if (this.glerrorcount > 0) {
      return false;
    }

    this.usersReq = (this.approverusers !== undefined && this.approverusers !== '' &&
      this.approverusers.length > 0);
    const formval = this.receiptForm.value;
    formval['ChequeDate'] = formval['ChequeDateFld'];
    //formval['ReceiptDate'] = new DatePipe('en-US').transform(formval['ReceiptDate'] , 'dd/MM/yyyy');
    if (this.totalAmount > 0) {
      if (!(localStorage.getItem('country') == '3')) {// UAE Approver is not needed
        if (this.totalAmount > 99999 && !this.usersReq) {
          return false;
        }
      }

      if (this.prevReceipt == null || this.prevReceipt == undefined)
        this.prevReceipt = 0;
      formval["ReceiptNo"] = this.prevReceipt;
      //send serialNo in update
      if (this.prevReceipt > 0 && (this.previewDataDtl != null || this.previewDataDtl != undefined)) {
        (<FormArray>this.receiptForm.controls["ReceiptDetails"]).value.forEach((element, index) => {
          if (index < this.previewDataDtl.length)
            element.SerialNo = this.previewDataDtl[index].SerialNo;
        });
      }
      console.log(this.receiptForm.value, 'formval');
      this.preSubmission();
      console.log('this.clonedReceipts', this.clonedReceipts);
      this.createservice.createReceipt(JSON.stringify(this.clonedReceipts.value)).subscribe(
        dataReturn => {
          this.returnValue = dataReturn;
          this.returnValue['approverlist'] = this.approverusers;
          this.returnValue['ondemand'] = true;
          console.log(this.returnValue, 'this.returnValue');
          // this.bsModalRef.hide();

          this.previewFlag = true;
          this.bsModalRef = this.modalService.show(ReceiptpreviewComponent, { class: 'preview-modal-dailog', backdrop: 'static', keyboard: false });
          this.bsModalRef.content.data = this.returnValue;
          this.bsModalRef.content.totalAmount = this.totalAmount;
        },
        errorRturn => {
          this.errorMsg = errorRturn;
        }
      );
    }
    if (this.totalAmount <= 0) {
      this.alertService.warn(RSAMSGConstants.AMOUNTTEXTREQ);
    }


  }

  reSetForm(param) {
    /*set default value here and reset */
    if (param == 1) {
      let arrayFields = ['PayeeName', 'EnglishDescription', 'ChequeNo', 'ChequeDate', 'PayeeBankCode',
        'PayeeBankName', 'ExpiryDate', 'InstrumentRefNo', 'TerminalUserID', 'ChequeType', 'TransactionNo'];

      this.receiptForm.controls['LocationCode'].reset(localStorage.getItem('locationcode'));
      this.receiptForm.controls['CostCenterCode'].reset(localStorage.getItem('costcentre'));
      this.receiptForm.controls['RegionCode'].reset(localStorage.getItem('regioncode'));
      console.log(this.RcptMode, ' this.RcptMode');
      /* if (this.RcptMode == 1) {
         this.receiptForm.controls.TotallingAccCode.setValue('1210');
       } else {*/
      this.receiptForm.controls['TotallingAccCode'].reset(1110);
      // }
      this.getBankData(true);
      this.receiptForm.controls['RecevierBankCode'].reset(14);
      this.receiptForm.controls['PayeeName'].reset();
      this.receiptForm.controls['EnglishDescription'].reset();
      arrayFields.forEach((val) => {
        if (this.receiptForm.controls[val] != null && this.receiptForm.controls[val] != undefined) {
          this.receiptForm.controls[val].reset();
        }
      });
      if (this.RcptMode == 2) {
        this.receiptForm.controls['InstrumentDate'].setValue('');
      }
      if (this.RcptMode == 5) {
        this.receiptForm.controls['PayeeBankCode'].setValue('');
      }
      if (this.RcptMode == 8) {
        this.receiptForm.controls['TerminalUserID'].setValue(this.defaultUserId || this.terminals[0].UserID);
        this.receiptForm.controls['TerminalID'].setValue(this.defaultTerminalId || this.terminals[0].TerminalID);
      }
      this.clearerrors();
    } else if (param == 2) {
      this.receiptForm.controls['ReceiptDetails'].reset();
      (<FormArray>this.receiptForm.controls['ReceiptDetails']).controls.map(item => {
        item.get('LocationCode').setValue(localStorage.getItem('locationcode'));
        item.get('CostCenterCode').setValue(localStorage.getItem('costcentre'));
        item.get('RegionCode').setValue(localStorage.getItem('regioncode'));
        item.get('RefTransactionType').setValue(3);
        item.get('TotallingAccCode').setValue(1110);
        // item.get('GLCode').setValue(4);
        // item.get('GLCodeDesc').setValue('4-HSBC BANK MIDDLE EAST - Deira');
        item.get('Description').setValue(this.cshdetails.value);
        item.get('IsCreditEntry').setValue(true);
      });
      this.getActualAmountSum();
    }
    //   this.setBankData(this.receiptForm.controls.TotallingAccCode.value);
    this.GetAccountingDates(); 
  }
  checkIsformDirty() {
    if (this.receiptForm.dirty || this.receiptForm.touched) {
      console.log('cmg here');
      this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
      this.bsModalRef.content.modelTitle = '';
      this.bsModalRef.content.modelBodyContent = RSAMSGConstants.DIRTYFLAGMSGRECIPT;
      this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
      this.bsModalRef.content.actionBtn = RSAMSGConstants.BTNPROCEED;
      this.bsModalRef.content.valueChange.subscribe((data) => {
        if (data = 'Proceed') {
          this.modalService.hide(1);
        }
      });

    } else {
      this.modalService.hide(1);
    }
  }



  goPrevious() {
    this.level = 1;
    this.resetAmountReceiptDetails();
  }

  collapseToheader() {
    this.collapsetoheader = !this.collapsetoheader;
  }
  preSubmission() {
    let flagtoggle: boolean = false;
    let amt: number = 0;
    this.clonedReceipts = Object.assign({}, this.receiptForm);
    console.log('this.clonedReceipts', this.clonedReceipts);
    this.clonedReceipts.value.ReceiptDetails = this.clonedReceipts.controls['ReceiptDetails'].value;
    (<FormArray>this.clonedReceipts.controls['ReceiptDetails']).value.forEach((element, index) => {
      flagtoggle = element.IsCreditEntry;

      if (!flagtoggle){
        element.Amount = (Math.abs(parseFloat(element.Amount)) * -1);
        console.log('flagtoggle:::::' + Math.abs(parseFloat(element.Amount)) * -1, flagtoggle);
      }
      console.log(element.Amount);

    });
    console.log('this.clonedReceipts', this.clonedReceipts);
  }
  getActualAmountSum() {
    let total: number = 0;
    let amt: number = 0;
    let actualamt: number = 0;
    let flagtoggle: boolean = false;
    (<FormArray>this.receiptForm.controls['ReceiptDetails']).controls.forEach((element, index) => {

      if (this.getFromFormArrayControlVal("Amount", index) != undefined
        && this.getFromFormArrayControlVal("Amount", index) != null) {
        flagtoggle = this.getFromFormArrayControlVal("IsCreditEntry", index);
        amt = parseFloat(this.getFromFormArrayControlVal("Amount", index));
        amt = Math.abs(amt) || 0;
        actualamt = (flagtoggle) ? amt : (amt * -1);
        console.log('flagtoggle:' + flagtoggle + ",amt:" + amt + ",actualamt:" + actualamt);
        total = total + actualamt;
      }

    });

    this.totalAmount = (total == null || total == undefined || isNaN(total)) ? 0.00 : total;
  }
  resetAmountReceiptDetails() {
    //(<FormArray>this.receiptForm.controls['ReceiptDetails']).controls.map(item => {
    //  item.get('Amount').setValue('');
    //  item.get('Amount').setErrors(null);
    //});
    this.getActualAmountSum();
  }

  GetAccountingDates() {
    this.minDateRd = new Date(localStorage.getItem('accntStartDate'));
    this.maxDateRd = new Date(localStorage.getItem('accntEndDate'));
    const sysDate = new Date();
    if (sysDate < this.minDateRd) {
      this.receiptAccountingDate = new DatePipe('en-US').transform(this.minDateRd, 'dd/MM/yyyy');
    }
    else{
      this.receiptAccountingDate = new DatePipe('en-US').transform(sysDate, 'dd/MM/yyyy');
    }
    this.receiptdate.setValue(this.receiptAccountingDate);
  }
  changeVoucherDate() {
    if (this.receiptdate.value) {
      const receiptDate = new Date(this.receiptdate.value);
      this.receiptdate.setValue(this.receiptAccountingDate);
      let showConfirm;
      let modelContent;
      let getConfirm;
      if (receiptDate > this.maxDateRd) {
        showConfirm = true;
        getConfirm = true;
        modelContent = RSAMSGConstants.VOUCHERDATEGREATERTHANACCOUNTINGEND;
      }
      else if(receiptDate < this.minDateRd){
        showConfirm = true;
        getConfirm = false;
        modelContent = RSAMSGConstants.VOUCHERDATELESSERTHANACCOUNTINGEND;
      }
      if(showConfirm){
        this.receiptdate.setValue(this.receiptAccountingDate);
        this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
        this.bsModalRef.content.modelTitle = '';
        this.bsModalRef.content.modelBodyContent = modelContent;
        this.bsModalRef.content.cancelBtn = getConfirm ? RSAMSGConstants.NOTEXT : null;
        this.bsModalRef.content.actionBtn = getConfirm ? RSAMSGConstants.YESTEXT : RSAMSGConstants.OKTEXT;
        this.bsModalRef.content.valueChange.subscribe((data) => {
          if (data.toString().trim() === 'YES') {
            this.receiptAccountingDate = new DatePipe('en-US').transform(receiptDate, 'dd/MM/yyyy');
            this.receiptdate.setValue(this.receiptAccountingDate);
          }
          this.bsModalRef.hide();
        });
      }
      else{
        this.receiptAccountingDate = new DatePipe('en-US').transform(receiptDate, 'dd/MM/yyyy');
        this.receiptdate.setValue(this.receiptAccountingDate);
      }
    }
  }
  setTerminal(val: any) {
    const currentTerminalID = this.terminals.filter(item => item.UserID == val);
    this.receiptForm.get('TerminalID').setValue(currentTerminalID[0].TerminalID);
  }
}
