import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpHeaders, HttpErrorResponse, HttpClient, HttpParams, } from '@angular/common/http';
import { catchError, map, shareReplay } from 'rxjs/operators';
import { RSAENDPOINTConstants } from 'src/app/core/constants/rsa.api.end.points';
import { handleErrorObservable } from 'src/app/shared/utilites/helper';


@Injectable({ providedIn: 'root' })
export class CreateService {
  private cachedMasterData: Observable<any>;
  private cachedMasterData2: Observable<any>;
  
  constructor(private http: HttpClient) { }
  
  createReceipt(param: any) {
    console.log(param, 'param');
    return this.http.post<any>(RSAENDPOINTConstants.RECEIPTPREVIEWSAVE, param).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('createReceipt')));
  }

  cancelReceipt(param) {
    let body = JSON.stringify(param);
    console.log(body, "body");
    return this.http.post(RSAENDPOINTConstants.RECEIPTCANCEL, body).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('cancelReceipt')));
  }
  saveReceipt(param) {
    let body = JSON.stringify({ "receiptNo": param });
      let url = RSAENDPOINTConstants.SAVERECEIPT + param;
    console.log(url, 'url');
    return this.http.put<any>(url, {}).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('saveReceipt')));
  }
  saveReceiptUnApproved(param) {
    let body = JSON.stringify({ 'VoucherNo': param });
    let url = RSAENDPOINTConstants.FINIALIZEORREJECTED;
    console.log(url, 'url');
    return this.http.put<any>(url, body).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('saveReceiptUnApproved')));
  }
  saveCreditNote(param) {
    let body = JSON.stringify({ "CreditNote": param });
    let url = RSAENDPOINTConstants.SAVECREDITNOTE + param;
    console.log(url, 'url');
    return this.http.put<any>(url, {}).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('saveReceipt')));
  }

  saveCreditNoteUnApproved(param) {
    let body = JSON.stringify({ 'VoucherNo': param });
    let url = RSAENDPOINTConstants.FINIALIZEORREJECTED;
    console.log(url, 'url');
    return this.http.put<any>(url, body).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('saveReceipt')));
  }
  saveDebitNote(param) {
    let body = JSON.stringify({ "DebitNote": param });
    let url = RSAENDPOINTConstants.SAVEDEBITNOTE + param;
    console.log(url, 'url');
    return this.http.put<any>(url, {}).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('saveReceipt')));
  }

  saveDebitNoteUnapproved(param) {
    let body = JSON.stringify({ 'VoucherNo': param });
    let url = RSAENDPOINTConstants.FINIALIZEORREJECTED;
    console.log(url, 'url');
    return this.http.put<any>(url, body).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('saveReceipt')));
  }

  sendEmail(param) {
    console.log(param, "paramsssss...");
    let body = JSON.stringify(param);
    let url = RSAENDPOINTConstants.RECEIPTEMAIL;
    console.log(url, 'url');
    return this.http.post<any>(url, body).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('saveReceipt')));
  }

  // saveJv(voucherNo, isdraft?) {
  //   //let body = JSON.stringify({ "JV": param });
  //   let param = 'voucherNo=' + voucherNo + '&draft=' + isdraft;
  //   let url = RSAENDPOINTConstants.SAVEJV + param;
  //   console.log(url, 'url123');
  //   //let url = RSAENDPOINTConstants.SAVEJV;
  //   return this.http.post<any>(url).pipe(
  //     map(res => res),
  //     catchError(handleErrorObservable<any>('saveReceipt')));
  // }

  // saveJvUnapproved(param) {
  //   let body = JSON.stringify({ 'VoucherNo': param });
  //   let url = RSAENDPOINTConstants.FINIALIZEORREJECTED;
  //   console.log(url, 'url');
  //   //let url = RSAENDPOINTConstants.SAVEJV;
  //   return this.http.put<any>(url, body).pipe(
  //     map(res => res),
  //     catchError(handleErrorObservable<any>('saveReceipt')));
  // }

  saveJv(param){
    // debugger;
    console.log(param, 'approverlist');
     return this.http.post<any>(RSAENDPOINTConstants.SAVEJV, param).pipe(
        map(res => res),
        catchError(handleErrorObservable<any>('createJv')));
  }

  saveJvUnapproved(param){
    // debugger;
    console.log(param, 'approverlist');
     return this.http.post<any>(RSAENDPOINTConstants.SAVEJV, param).pipe(
        map(res => res),
        catchError(handleErrorObservable<any>('createJv')));
  }
  

}