import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SearchModule } from './search/search.module';
import { SharedModule } from '../shared/shared.module';
import { FinanceRoutingModule } from './finance-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ModalModule } from 'ngx-bootstrap/modal';


import { PaymentsComponent } from './payments/payments.component';
import { GeneralComponent } from './general/general.component';
import { ChequeComponent } from './cheque/cheque.component';
import { JournalsComponent } from './journals/journals.component';
import { EntitiesComponent } from './entities/entities.component';
import { MonthendComponent } from './monthend/monthend.component';
import { DialogComponent } from './dialog/dialog.component';
import { CreateReceiptComponent } from './receipts/create-receipt/create-receipt.component';
import { CreateAgentComponent } from './entities/create-entitie/agent/create-agent.component';
import { CreateAdvocateComponent } from './entities/create-entitie/advocate/create-advocate.component';
import { CreateBrokerComponent } from './entities/create-entitie/broker/create-broker.component';
import { CreateCustomerComponent } from './entities/create-entitie/customer/create-customer.component';
import { CreateCompanyComponent } from './entities/create-entitie/company/create-company.component';
import { CreatePoliceStationComponent } from './entities/create-entitie/police-station/create-police-station.component';
import { CreateRecoveryAgentComponent } from './entities/create-entitie/recovery-agent/create-recovery-agent.component';
import { CreateSurveyorComponent } from './entities/create-entitie/surveyor/create-surveyor.component';
import { CreateRepairerComponent } from './entities/create-entitie/repairer/create-repairer.component';
import { CreatePaymentComponent } from './payments/create-payment/create-payment.component';
import { ReceiptpreviewComponent } from 'src/app/finance/preview/uae/receiptpreview/receiptpreview.component';
import { ReceiptCancelComponent } from './receipts/receipt-cancel/receipt-cancel.component';
import { SharedService } from 'src/app/finance/services/shared.service';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { AgGridModule } from 'ag-grid-angular';
import 'ag-grid-enterprise';
import { BasevoucherComponent } from 'src/app/finance/basevoucher/basevoucher.component';
import { PaymentpreviewComponent } from './preview/uae/paymentpreview/paymentpreview.component';
import { CreateCreditnotesComponent } from 'src/app/finance/creditnotes/create-creditnotes/create-creditnotes.component';
import { CreateDebitnotesComponent } from 'src/app/finance/debitnotes/create-debitnotes/create-debitnotes.component';
import { CnpreviewComponent } from 'src/app/finance/preview/uae/cnpreview/cnpreview.component';
import { TaxinvoicepreviewComponent } from 'src/app/finance/preview/uae/taxinvoicepreview/taxinvoicepreview.component';
import { DraftsResultsComponent } from './drfats/drafts-results/drafts-results.component';
import { ReceiptDraftsComponent } from './drfats/drafts-results/receipt-drafts/receipt-drafts.component';
import { CreateDraftReceiptComponent } from './drfats/drafts-results/create-draft-receipt/create-draft-receipt.component';
import { CurrencyRendererComponent } from 'src/app/shared/datatable/services/currency-renderer.component';
import { ChequePrintComponent } from 'src/app/finance/payments/cheque-print/cheque-print.component';
import { ChequePrintDialogComponent } from 'src/app/finance/payments/cheque-print-model/cheque-print-model.component';
import { DraftGridComponent } from './drfats/drafts-results/draft-grid/draft-grid.component';
import { DraftEditViewButtonComponent } from './drfats/drafts-results/draft-edit-view-button/draft-edit-view-button.component';
import { CancelPaymentComponent } from './payments/cancel-payment/cancel-payment.component';
import { CreatejvComponent } from './createjv/createjv.component';
import { JvpreviewComponent } from './preview/uae/jvpreview/jvpreview.component';
import { PdfViewerModule } from 'ng2-pdf-viewer';

import { CreditnoteDraftsComponent } from './drfats/drafts-results/creditnote-drafts/creditnote-drafts.component';
import { DebitnoteDraftsComponent } from './drfats/drafts-results/debitnote-drafts/debitnote-drafts.component';
import { JournalDraftsComponent } from './drfats/drafts-results/journal-drafts/journal-drafts.component';
import { PaymentDraftsComponent } from './drfats/drafts-results/payment-drafts/payment-drafts.component';

import { CreateDraftCreditnoteComponent } from './drfats/drafts-results/create-draft-creditnote/create-draft-creditnote.component';
import { CreateDraftDebitnoteComponent } from './drfats/drafts-results/create-draft-debitnote/create-draft-debitnote.component';
import { CreateDraftJournalComponent } from './drfats/drafts-results/create-draft-journal/create-draft-journal.component';
import { CreateDraftPaymentComponent } from './drfats/drafts-results/create-draft-payment/create-draft-payment.component';
import { CreateZerojvComponent } from './createjv/create-zerojv/create-zerojv.component';
import { CreateReversejvComponent } from './createjv/create-reversejv/create-reversejv.component';
import { NgxCurrencyModule } from 'ngx-currency';
import { customCurrencyMaskConfig } from '../shared/utilites/helper';
import { CURRENCY_MASK_CONFIG } from 'ngx-currency/src/currency-mask.config';
import { DraftsHeaderComponent } from './drfats/drafts-header/drafts-header.component';

import { PendingApprovalsResultsComponent } from './pending-approvals/pending-approvals-results.component';
import { ReceiptPendingApprovalsComponent } from './pending-approvals/receipt-pending-approvals/receipt-pending-approvals.component';
import { PendingApprovalGridComponent } from './pending-approvals/pending-approval-grid/pending-approval-grid.component';
import { PendingApprovalEditViewButtonComponent } from './pending-approvals/pending-approval-edit-view-button/pending-approval-edit-view-button.component';
import { PaymentPendingApprovalsComponent } from './pending-approvals/payment-pending-approvals/payment-pending-approvals.component';
import { CreditnotePendingApprovalsComponent } from './pending-approvals/creditnote-pending-approvals/creditnote-pending-approvals.component';
import { DebitnotePendingApprovalsComponent } from './pending-approvals/debitnote-pending-approvals/debitnote-pending-approvals.component';
import { JournalPendingApprovalsComponent } from './pending-approvals/journal-pending-approvals/journal-pending-approvals.component';
import { UnApprovalsResultsComponent } from './un-approved/un-approvals-results/un-approvals-results.component';
import { ReceiptUnApprovalsComponent } from './un-approved/un-approvals-results/receipt-un-approvals/receipt-un-approvals.component';
import { UnApprovalGridComponent } from './un-approved/un-approvals-results/un-approval-grid/un-approval-grid.component';
import { UnApprovalEditViewButtonComponent } from './un-approved/un-approvals-results/un-approval-edit-view-button/un-approval-edit-view-button.component';
import { DebitnoteUnApprovalsComponent } from './un-approved/un-approvals-results/debitnote-un-approvals/debitnote-un-approvals.component';
import { CreditnoteUnApprovalsComponent } from './un-approved/un-approvals-results/creditnote-un-approvals/creditnote-un-approvals.component';
import { JournalUnApprovalsComponent } from './un-approved/un-approvals-results/journal-un-approvals/journal-un-approvals.component';
import { PaymentUnApprovalsComponent } from './un-approved/un-approvals-results/payment-un-approvals/payment-un-approvals.component';
import { PendingApprovalHeaderComponent } from './pending-approvals/pending-approval-header/pending-approval-header.component';
import { ApprovedRejectDailogComponent } from './pending-approvals/approved-reject-dailog/approved-reject-dailog.component';
import { UnApprovalHeaderComponent } from './un-approved/un-approvals-results/un-approved-header/un-approval-header.component'; 
import { ReportsModule } from './reports/reports.module';
import { CustomereditComponent } from './entities/create-entitie/customer/customeredit/customeredit.component';
import { RepairereditComponent } from './entities/create-entitie/repairer/repaireredit/repaireredit.component';
import { EntityViewComponent } from './entities/view-entity/entityview.component';
import { AgenteditComponent } from './entities/create-entitie/agent/agentedit/agentedit.component';
import { RecoveryeditComponent } from './entities/create-entitie/recovery-agent/recoveryedit/recoveryedit.component';
import { PolicestationeditComponent } from './entities/create-entitie/police-station/policestationedit/policestationedit.component';
import { EditBrokerComponent } from './entities/create-entitie/broker/edit-broker/edit-broker.component';
import { EditAdvocateComponent } from './entities/create-entitie/advocate/edit-advocate/edit-advocate.component';
import { EditSurveyorComponent } from './entities/create-entitie/surveyor/edit-surveyor/edit-surveyor.component';
import { CompanyeditComponent } from './entities/create-entitie/company/companyedit/companyedit.component';
import { ConfirmSetDateComponent} from '../finance/monthend/confirm-set-date/confirm-set-date.component';
import { AgCustomDateComponent } from '../shared/ag-custom-date/ag-custom-date.component';
import {AgCustomSelectComponent} from '../shared/ag-custom-select/ag-custom-select.component';
import {AgCustomHeaderComponent} from '../shared/ag-custom-header/ag-custom-header.component';

/* end */

@NgModule({
  imports: [
    CommonModule,
    SearchModule,
    SharedModule,
    FinanceRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    PdfViewerModule,
    ReportsModule,
    NgxCurrencyModule.forRoot(customCurrencyMaskConfig),
    AgGridModule.withComponents([
      CurrencyRendererComponent,
      DraftEditViewButtonComponent,
      PendingApprovalEditViewButtonComponent,
      UnApprovalEditViewButtonComponent,
      AgCustomDateComponent,
      AgCustomSelectComponent,
      AgCustomHeaderComponent
    ]),

    // SharedCreateEntitieModule,
    ModalModule.forRoot()
  ],
  declarations: [

    PaymentsComponent,
    GeneralComponent,
    ChequeComponent,
    JournalsComponent,
    CreateDebitnotesComponent,
    CreateDebitnotesComponent,
    EntitiesComponent,
    MonthendComponent,
    DialogComponent,
    CreateReceiptComponent,
    CreateAgentComponent,
    CreateAdvocateComponent,
    CreateBrokerComponent,
    CreateCustomerComponent,
    CreateCompanyComponent,
    CreatePoliceStationComponent,
    CreateRecoveryAgentComponent,
    CreateSurveyorComponent,
    CreateRepairerComponent,
    CreatePaymentComponent,
    ReceiptpreviewComponent,
    ReceiptCancelComponent,
    BasevoucherComponent,
    PaymentpreviewComponent,
    CreateDebitnotesComponent,
    CreateCreditnotesComponent,
    CnpreviewComponent,
    TaxinvoicepreviewComponent,
    DraftsResultsComponent,
    ReceiptDraftsComponent,
    CreateDraftReceiptComponent,
    ChequePrintComponent,
    ChequePrintDialogComponent,
    DraftGridComponent,
    DraftEditViewButtonComponent,
    CancelPaymentComponent,
    CreatejvComponent,
    JvpreviewComponent,
    PaymentDraftsComponent,
    CreditnoteDraftsComponent,
    DebitnoteDraftsComponent,
    JournalDraftsComponent,
    CreateDraftCreditnoteComponent,
    CreateDraftDebitnoteComponent,
    CreateDraftJournalComponent,
    CreateDraftPaymentComponent,
    CreateZerojvComponent,
    CreateReversejvComponent,
    DraftsHeaderComponent,
    PendingApprovalsResultsComponent,
    ReceiptPendingApprovalsComponent,
    PendingApprovalGridComponent,
    PendingApprovalEditViewButtonComponent,
    PaymentPendingApprovalsComponent,
    CreditnotePendingApprovalsComponent,
    DebitnotePendingApprovalsComponent,
    JournalPendingApprovalsComponent,
    UnApprovalsResultsComponent,
    ReceiptUnApprovalsComponent,
    UnApprovalGridComponent,
    UnApprovalEditViewButtonComponent,
    DebitnoteUnApprovalsComponent,
    CreditnoteUnApprovalsComponent,
    JournalUnApprovalsComponent,
    PaymentUnApprovalsComponent,
    PendingApprovalHeaderComponent,
    ApprovedRejectDailogComponent,
    UnApprovalHeaderComponent,
    EntityViewComponent,
    CustomereditComponent,
      RepairereditComponent,
      AgenteditComponent,
      RecoveryeditComponent,
      PolicestationeditComponent,
      EditBrokerComponent,
      EditAdvocateComponent,
      EditSurveyorComponent,
      CompanyeditComponent,
      ConfirmSetDateComponent
  ],
  entryComponents: [
    CreateReceiptComponent,
    CreatePaymentComponent,
    ReceiptpreviewComponent,
    PaymentpreviewComponent,
    ReceiptCancelComponent,
    CancelPaymentComponent,
    CreateDebitnotesComponent,
    CreateCreditnotesComponent,
    CnpreviewComponent,
    TaxinvoicepreviewComponent,
    CreateDraftReceiptComponent,
    ChequePrintDialogComponent,
    CreatejvComponent,
    JvpreviewComponent,
    CreateDraftCreditnoteComponent,
    CreateDraftDebitnoteComponent,
    CreateDraftJournalComponent,
    CreateDraftPaymentComponent,
    CreateZerojvComponent,
    CreateReversejvComponent,
    ApprovedRejectDailogComponent,
    ConfirmSetDateComponent
  ],
  providers: [
    SharedService,
    BsModalRef,
    { provide: CURRENCY_MASK_CONFIG, useValue: customCurrencyMaskConfig }

  ]
})
export class FinanceModule { }

