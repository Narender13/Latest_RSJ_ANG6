import { Injectable } from '@angular/core';
import { HttpParams, HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { RSAENDPOINTConstants } from 'src/app/core/constants/rsa.api.end.points';
import { map, catchError } from 'rxjs/operators';
import { handleErrorObservable } from 'src/app/shared/utilites/helper';

@Injectable({
    providedIn: 'root'
})

export class UnApprovalsService {

  constructor(private http: HttpClient) { }
    
    getUnApprovalsReceipts(param): Observable<any> {
         let  Url = RSAENDPOINTConstants.PENDINGAPPROVAL_UNAPPROVED_RECEIPT_API  + param;
         return this.http.get(Url).pipe(
          map(res => res),
          catchError(handleErrorObservable<any>('getUnApprovalsReceipt')));
    }

    getUnApprovalDebitnotes(param): Observable<any> {
    
        return this.http.get(RSAENDPOINTConstants.PENDINGAPPROVAL_UNAPPROVED_DN_API + param).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getUnApprovalsDns')));
    }

    getUnApprovalCreditnotes(param): Observable<any> {
    
        return this.http.get(RSAENDPOINTConstants.PENDINGAPPROVAL_UNAPPROVED_CN_API + param).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getUnApprovalsCns')));
    }
    getUnApprovalPayments(param): Observable<any> {
        let Url = RSAENDPOINTConstants.PENDINGAPPROVAL_UNAPPROVED_PAYMENT_API + param;
        console.log('Url22',Url);
        return this.http.get(RSAENDPOINTConstants.PENDINGAPPROVAL_UNAPPROVED_PAYMENT_API + param).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getUnApprovalsPayments')));
    }
    getUnApprovalJournals(param): Observable<any> {
    
        return this.http.get(RSAENDPOINTConstants.PENDINGAPPROVAL_UNAPPROVED_JV_API + param).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getUnApprovalsCns')));
    }

        
        

}

