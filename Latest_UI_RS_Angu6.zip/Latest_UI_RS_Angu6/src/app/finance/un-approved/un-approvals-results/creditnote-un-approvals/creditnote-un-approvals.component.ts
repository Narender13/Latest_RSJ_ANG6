import { Component, OnInit, Input } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap';
//import { CreateDraftReceiptComponent } from 'src/app/finance/drfats/drafts-results/create-draft-receipt/create-draft-receipt.component';
//import { ReceiptpreviewComponent } from 'src/app/finance/preview/uae/receiptpreview/receiptpreview.component';

@Component({
  selector: 'rsa-creditnote-un-approvals',
  templateUrl: './creditnote-un-approvals.component.html',
  styleUrls: ['./creditnote-un-approvals.component.scss']
})
export class CreditnoteUnApprovalsComponent implements OnInit {

  @Input() creditnoteUnApprovalData: any = [];
  @Input() VName:string;
  constructor(private modalService: BsModalService) { }
  
  ngOnInit() {
    console.log(this.creditnoteUnApprovalData, 'creditnoteUnApprovalData-cpomp');
  
  }
  

}

