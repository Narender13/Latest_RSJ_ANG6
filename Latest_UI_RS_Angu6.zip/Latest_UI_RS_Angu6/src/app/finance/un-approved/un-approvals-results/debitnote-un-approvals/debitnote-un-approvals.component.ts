import { Component, OnInit, Input } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap';
//import { CreateDraftReceiptComponent } from 'src/app/finance/drfats/drafts-results/create-draft-receipt/create-draft-receipt.component';
//import { ReceiptpreviewComponent } from 'src/app/finance/preview/uae/receiptpreview/receiptpreview.component';

@Component({
  selector: 'rsa-debitnote-un-approvals',
  templateUrl: './debitnote-un-approvals.component.html',
  styleUrls: ['./debitnote-un-approvals.component.scss']
})
export class DebitnoteUnApprovalsComponent implements OnInit {

  @Input() debitnoteUnApprovalData: any = [];
  @Input() VName:string;
  constructor(private modalService: BsModalService) { }
  
  ngOnInit() {
    console.log(this.debitnoteUnApprovalData, 'debitnoteUnApprovalData-cpomp');
  
  }
  
}

  