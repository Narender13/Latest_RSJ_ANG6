import { Component, OnInit } from '@angular/core';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { CreateService } from 'src/app/finance/receipts/create-receipt/service/create.service';
import { ActivatedRoute } from '@angular/router';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { SharedService } from 'src/app/finance/services/shared.service';
import { validateEmail, multipleEmailValidation } from 'src/app/shared/utilites/helper';
import { PreviewpdfService } from '../service/previewpdf.service';
import printJS from 'print-js';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'rsa-cnpreview',
  templateUrl: './cnpreview.component.html',
  styleUrls: ['./cnpreview.component.scss']
})
export class CnpreviewComponent implements OnInit {


  constructor(private modalService: BsModalService, public bsModalRef: BsModalRef, private createservice: CreateService,
    private route: ActivatedRoute, private alertService: AlertService, private sharedService: SharedService, private previewpdfService: PreviewpdfService) { }
  data: any;
  symbol: string;
  returnValue: any;
  errorMsg: string;
  previewScreenFlag = true;
  approval = false;
  approverlist = '';
  emailVoucher = false;
  emailAddress;
  logourl;
  isUAE;
  isKSA;
  isOman;
  isBahrain;
  successmsg;
  invalidEmailAddress = true;
  checkcorrectEmail = true;
  totalAmount;
  fromCategory: any = null;
  isSingleReceipient: boolean;
  CreditNoteNo;
  LocationCode;
  Cnpdfsrc;
  isLoadingPdf = true;
  unApproved = false;
  isView;
  sendReceiptByEmail;
  currentDate;

  ngOnInit() {
    setTimeout(() => {
      this.data = this.bsModalRef.content.data || this.data;
      this.totalAmount = this.bsModalRef.content.totalAmount;
      this.unApproved = this.bsModalRef.content.unApproved || false;
      console.log(this.data, 'data');
      this.getCreditnotePdfViewr(this.data);
    }, 100);
    this.currentDate= new DatePipe('en-US').transform(new Date(), 'dd MMM yyyy');
    this.symbol = (localStorage.getItem('symbol'));
    this.logourl = localStorage.getItem('logourl') || 'assets/images/logo_rsa.svg';
    this.isUAE = (localStorage.getItem('regioncode') == '2');
    this.isKSA = (localStorage.getItem('regioncode') == '1');
    this.isOman = (localStorage.getItem('regioncode') == '3');
    this.isBahrain = (localStorage.getItem('regioncode') == '5');


  }
  // print() {
  //   window.print();
  // }

  print(CreditNoteNo, isdraft) {
    this.Cnpdfsrc = this.previewpdfService.getCreditnotePdfViewr(CreditNoteNo, isdraft);
    //  console.log(this.pdfsrc,"pdfViewurl");
    printJS({
      type: 'pdf',
      printable: this.Cnpdfsrc,
      showModal: true,
      modalMessage: 'retrieving...',
    })
  }

  onProgress(event) {
    console.log(event);
    const total = event.total;
    if (total !== undefined || total !== '') {
      setTimeout(() => {
        this.isLoadingPdf = false;
      }, 2000);
    }
  }

  saveCreditNote(CreditNoteNo) {
    this.previewScreenFlag = false;
    if (!this.unApproved) {
      this.createservice.saveCreditNote(CreditNoteNo).subscribe(
        dataReturn => {
          this.returnValue = dataReturn;
          console.log(this.returnValue + '/' + this.data, 'saveCreditNote - - this.returnValue');
          this.approval = (this.data.approverlist != null && this.data.approverlist != NaN);
          this.sharedService.sendMessage({
            voucherName: 'Credit Note',
            message: 'save-voucher'
          });

        },
        errorRturn => {
          this.errorMsg = errorRturn;
        }
      );
    } else {
      this.createservice.saveCreditNoteUnApproved(CreditNoteNo).subscribe(
        dataReturn => {
          this.returnValue = dataReturn;
          console.log(this.returnValue + '/' + this.data, 'saveCreditNote - - this.returnValue');
          this.approval = (this.data.approverlist != null && this.data.approverlist != NaN);
          this.sharedService.sendMessage({
            voucherName: 'Credit Note',
            message: 'save-voucher'
          });

        },
        errorRturn => {
          this.errorMsg = errorRturn;
        }
      );
    }

  }

  previous() {
    this.bsModalRef.hide();
    this.sharedService.sendMessage("previous");
    this.sharedService.sendMessage(
      {
        id: this.data.CreditNoteNo,
        data: this.data.CreditNoteDetail
      }
    );
  }
  close() {
    this.bsModalRef.hide();
    this.modalService.hide(1);
    this.sharedService.sendMessage("close");
    this.sharedService.sendMessage('close-preview');
  }

  sendEmail(receiptnumber) {
    this.isSingleReceipient = false;
    this.invalidEmailAddress = (this.emailAddress !== undefined && this.emailAddress !== '' && this.emailAddress.length > 0);
    this.checkcorrectEmail = multipleEmailValidation(this.emailAddress);
    if (this.checkCommaSpeartedString() && !this.emailVoucher) {
      this.isSingleReceipient = true;
      return false;
    }
    this.sendReceiptByEmail = this.emailVoucher;
    if (this.invalidEmailAddress && this.checkcorrectEmail && this.sendReceiptByEmail) {
      const param = {
        ToEmailID: this.emailAddress,
        LoggedInUserID: 181,
        VoucherType: 3,
        VoucherNo: receiptnumber
      };

      this.createservice.sendEmail(param).subscribe((data) => {
        // this.bsModalRef.hide();
        this.successmsg = data;
        this.alertService.success(data);
        console.log(data, 'data sucessfully');
      },
        errorRturn => {
          this.errorMsg = errorRturn;
        });
    }

  }


  getCreditnotePdfViewr(res) {
    this.CreditNoteNo = res.CreditNoteNo;
    this.Cnpdfsrc = this.previewpdfService.getCreditnotePdfViewr(this.CreditNoteNo, 0);
    console.log(this.Cnpdfsrc, "this is pdf-viewer url");
  }

  checkCommaSpeartedString(): boolean {
    const str = this.emailAddress;
    if (str.indexOf(',') > -1) {
      return true;
    } else {
      return false;
    }
  }


}


