import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpHeaders, HttpErrorResponse, HttpClient, HttpParams, } from '@angular/common/http';
import { catchError, map, shareReplay } from 'rxjs/operators';
import { RSAENDPOINTConstants } from 'src/app/core/constants/rsa.api.end.points';
import { handleErrorObservable } from 'src/app/shared/utilites/helper';

@Injectable({
  providedIn: 'root'
})
export class PreviewpdfService {

  private cachedMasterData: Observable<any>;
  private cachedMasterData2: Observable<any>;
  
  constructor(private http: HttpClient) { }

  getJvPdfViewr(voucherNo, locationCode, isdraft?) {
    let param = 'voucherNo=' + voucherNo + '&locationCode=' + locationCode + '&draft=' + isdraft;
    let previewJv_url = RSAENDPOINTConstants.PREVIEWJV + param;
    return previewJv_url;
  }

  getReceiptPdfViewr(ReceiptNo, isdraft?) {

    let param = 'receiptNo=' + ReceiptNo + '&locCode=' + localStorage.getItem('locationcode') + '&draft=' + isdraft;
    let Receiptview_url = RSAENDPOINTConstants.PREVIEWRECEIPT + param;
    return Receiptview_url;
  }

  getCreditnotePdfViewr(CreditNoteNo, isdraft?) {
    let param = 'creditNoteNo=' + CreditNoteNo + '&locCode=' + localStorage.getItem('locationcode') + '&draft=' + isdraft;
    let Creditpreview_url = RSAENDPOINTConstants.PREVIEWCREDITNOTE + param;
    return Creditpreview_url;
  }

  getDebitnotePdfViewr(DebitNoteNo, isdraft?) {
    let param = 'debitNoteNo=' + DebitNoteNo + '&locCode=' + localStorage.getItem('locationcode') + '&draft=' + isdraft;
    let Debitpreview_url = RSAENDPOINTConstants.PREVIEWDEBITNOTE + param;
    return Debitpreview_url;
  }
  getPaymentPdfViewr(VoucherNo, isdraft?) {
    let param = 'voucherNo=' + VoucherNo + '&locCode=' + localStorage.getItem('locationcode') + '&draft=' + isdraft;
    let Paymentpreview_url = RSAENDPOINTConstants.PREVIEWPAYMENT + param;
    return Paymentpreview_url;

  }

  getClaimPaymentPdfViewr(VoucherNo, isdraft?) {
    let param = 'voucherNo=' + VoucherNo + '&locCode=' + localStorage.getItem('locationcode') + '&draft=' + isdraft;
    let Paymentpreview_url = RSAENDPOINTConstants.PREVIEWCLAIMPAYMENT + param;
    return Paymentpreview_url;

  }




}
