import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'rsa-bank-upload',
  templateUrl: './bank-upload.component.html',
  styleUrls: ['./bank-upload.component.scss']
})
export class BankUploadComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
