import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportExpenseAnalysisComponent } from './report-expense-analysis.component';

describe('ReportExpenseAnalysisComponent', () => {
  let component: ReportExpenseAnalysisComponent;
  let fixture: ComponentFixture<ReportExpenseAnalysisComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReportExpenseAnalysisComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReportExpenseAnalysisComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
