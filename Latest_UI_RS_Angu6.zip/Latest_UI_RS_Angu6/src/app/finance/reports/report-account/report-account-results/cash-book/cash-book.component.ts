import { Component, OnInit, Input } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ReportService } from '../../../service/reports.service';
import { Observable } from 'rxjs';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { formatDate, DatePipe } from '@angular/common';
import { ViewAccountComponent } from '../view-account/view-account.component';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { SendEmailComponent } from '../send-email/send-email.component';
import { DownloadAccountDeatilsComponent } from '../download-account-deatils/download-account-deatils.component';
import printJS from 'print-js';

@Component({
  selector: 'rsa-cash-book',
  templateUrl: './cash-book.component.html',
  styleUrls: ['./cash-book.component.scss']
})
export class CashBookComponent implements OnInit {
  cashBookForm: FormGroup;
  @Input() branchdata;
  @Input() totallingacc;
  locationcode: string;
  headerList: any;
  toggleFilter = false;
  frommonth = new Date();
  tomonth = new Date();
  fromyear = new Date();
  toyear = new Date();
  templateList = [];
  selectedTemplateId: number;
  tbReortsData: any;
  paramsForCB;
  fromdate: string;
  todate: string;
  fromYear: string;
  toYear: string;
  paramsForCBDownload;
  totallingAccCode;
  maxDate: any;
  bankList: any[];
  docType: any;
  paymentType = [
    { 'type': 'Others', 'id': 1 },
    { 'type': 'Claims', 'id': 2 }
  ];
  docTypeList = [
    { 'type': 'Receipts', 'id': 1 },
    { 'type': 'Payments', 'id': 2 },
    { 'type': 'Journals', 'id': 3 }
  ];
  printCheck = [
    { 'type': 'Printed', 'id': 1 },
    { 'type': 'Not Printed', 'id': 0 }
  ];
  constructor(private reportService: ReportService, private fb: FormBuilder,
    private alertService: AlertService, private modalService: BsModalService, public bsModalRef: BsModalRef) { }

  ngOnInit() {
    this.locationcode = localStorage.getItem('locationcode');
    console.log(this.locationcode, 'locationcode');
    this.createTbForm();
    this.getHeadersForReports();
    // this.getSavedTemplate();
    this.setMaxDate();
  }

  createTbForm(): void {
    this.cashBookForm = this.fb.group({
      BankName: [null, Validators.required],
      PayType: [null, Validators.required],
      DateRange: [null, Validators.required],
      // FromMonth: [null, Validators.required],
      // ToMonth: [null, Validators.required],
      // FromYear: [null, Validators.required],
      // ToYear: [null, Validators.required],
      Document: [null, Validators.required],
      CheckType: [null, Validators.required],
      Template: [null, Validators.required]
    });
  }

  setMaxDate() {
    this.maxDate = new Date();
    this.maxDate.setDate(this.maxDate.getDate() - 1);
  }
  getHeadersForReports() {
    this.reportService.getReportHeadersCB().subscribe((data) => {
      this.headerList = data;
      console.log(data, 'headerList');
    });
  }

  getBankNameCB(event): void {
    const bankName = this.cashBookForm.get('BankName');
    bankName.setValue(null);
    this.docType = event.srcElement.value;
    if (this.docType && this.docType !== null && this.docType != '3') {
      bankName.setValidators([Validators.required]);
      bankName.updateValueAndValidity();
      const queryParam = 'cashDocumentType=' + this.docType;
      this.reportService.getBankNameCB(queryParam).subscribe((data) => {
        this.bankList = data;
        console.log(data, 'bankList');
      });
    } else {
      bankName.clearValidators();
      bankName.updateValueAndValidity();
    }
  }
  setTotalAccCode(code: any): void {
    const bankData = this.bankList.filter((item) => item.BankCode == code);
    console.log(bankData);
    if (bankData.length) {
      this.totallingAccCode = bankData[0].Tot_Acc_Code;
    }
    console.log(this.totallingAccCode);
  }
  getParams() {
    const locale = 'en-US';
    const date = this.cashBookForm.controls['DateRange'].value;
    // this.docType = this.cashBookForm.controls['DateRange'].value;
    console.log(date);
    this.fromdate = new DatePipe('en-US').transform(date[0], 'dd/MM/yyyy');
    this.todate = new DatePipe('en-US').transform(date[1], 'dd/MM/yyyy');
    let bankcode = this.cashBookForm.controls['BankName'].value;
    const printStatus = this.cashBookForm.controls['CheckType'].value;
    if (this.docType == '3') {
      bankcode = this.totallingAccCode = 0;
    }
    this.paramsForCB = 'reportId=' + '217' + '&reportType=' + '2' +
      '&fromdate=' + this.fromdate + '&todate=' + this.todate + '&bankcode=' + bankcode + '&totacccode=' + this.totallingAccCode +
      '&printstatus=' + printStatus + '&templateId=' + this.selectedTemplateId + '&download=' + '0';
    console.log(this.paramsForCB, 'params');

  }


  getSavedTemplate(value: any) {
    console.log(value);
    const docType = this.cashBookForm.controls['Document'].value;
    if (docType == null || docType == undefined) {
      this.alertService.error('Document Type is required.');
      this.cashBookForm.get('PayType').reset();
      return false;
    }
    const param = '&docType=' + docType + '&payType=' + value;
    this.reportService.generateSavedTemplateCB(param).subscribe((data) => {
      this.templateList = data;
      console.log(data, 'templateList');
    });
  }


  downloadTbReport() {
    this.getParams();
    const initialState = {
      backdrop: true,
      ignoreBackdropClick: false,
      reportName: 'cashbook',
      paramsForDownload: this.paramsForCB,
      customerName: this.totallingAccCode,
    };
    this.bsModalRef = this.modalService.show(DownloadAccountDeatilsComponent,
      { class: 'preview-modal-dailog-send-email', initialState, backdrop: 'static', keyboard: false });
  }


  sendEmail() {
    //  this.getParams();
    const initialState = {
      backdrop: true,
      ignoreBackdropClick: false,
      reportType: 10,
      reportName: 'cashbook',
      //  totallingAccCode: this.totallingAccCode,
      customerName: this.totallingAccCode,
      paramsForEmail: this.paramsForCB,
    };
    this.bsModalRef = this.modalService.show(SendEmailComponent,
      { class: 'preview-modal-dailog-send-email', initialState, backdrop: 'static', keyboard: false });
  }


  changeTemplate(event) {
    console.log(event.srcElement.value, 'item');
    this.selectedTemplateId = Number(event.srcElement.value);
    console.log(this.selectedTemplateId, 'item');
  }
  onSubmit() {
    this.getParams();
    this.reportService.getReportCB(this.paramsForCB).subscribe((data) => {
      console.log(data, 'data');
      // this.paramsForCB = data;
      if (data !== null && data.SelectedCashBookDetail !== null) {
        const initialState = {
          backdrop: true,
          ignoreBackdropClick: false,
          reportsdata: data,
          reportType: 7,
          reportName: 'cashbook',
          paramsForDownload: this.paramsForCB,
          customerName: this.totallingAccCode,
        };
        this.bsModalRef = this.modalService.show(ViewAccountComponent,
          { class: 'user-reports-model', initialState, ignoreBackdropClick: true, keyboard: false });
      } else {
        this.alertService.info('No data found for curerent search');
      }

    });
  }

  onOpenCalendarForMonth(container) {
    container.monthSelectHandler = (event: any): void => {
      console.log(event);
      if (!event.isDisabled) {
        container._store.dispatch(container._actions.select(event.date));
      }
    };
    container.setViewMode('month');
  }

  onOpenCalendarForYear(container) {

    container.yearSelectHandler = (event: any): void => {
      if (!event.isDisabled) {
        container._store.dispatch(container._actions.select(event.date));
      }
    };

    container.setViewMode('year');
    // container.setMaxDate(this.maxDate);
  }
  toggleFilterF() {
    this.toggleFilter = !this.toggleFilter;
  }

  printTb() {
    console.log('print clicked');
    printJS({
      type: 'pdf',
      printable: 'null',
      showModal: true,
      modalMessage: 'retrieving...',

    });

  }

}
