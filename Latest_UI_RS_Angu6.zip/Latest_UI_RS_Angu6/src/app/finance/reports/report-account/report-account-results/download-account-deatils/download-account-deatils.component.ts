import { Component, OnInit } from '@angular/core';
import { BsModalService, BsModalRef } from 'ngx-bootstrap';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { ReportService } from '../../../service/reports.service';
import { saveAs as importedSaveAs } from 'file-saver';
import { DownloadFile } from 'src/app/shared/utilites/helper';


@Component({
  selector: 'rsa-download-account-deatils',
  templateUrl: './download-account-deatils.component.html',
  styleUrls: ['./download-account-deatils.component.scss']
})
export class DownloadAccountDeatilsComponent implements OnInit {
  modalRef: BsModalRef;
  downloadForm: FormGroup;
  paramsForDownload;
  customerName;
  reportName;
  invalidfileDataType = 'application/json';
  constructor(private fb: FormBuilder, private modalService: BsModalService,
    private reportService: ReportService, private alertService: AlertService, public bsModalRef: BsModalRef) { }

  ngOnInit() {
    this.downloadForm = this.fb.group({
      downloadFormat: [null, Validators.required],
    });
    console.log(this.paramsForDownload, 'paramsForDownload');
    console.log(this.reportName, 'reportName');
  }

  close() {
    this.bsModalRef.hide();
  }

  downloadAccount() {
    // this.setdownloadFileName();
    console.log(this.downloadForm.value, 'this.downloadForm');
    const downlaodFromat = +(this.downloadForm.controls['downloadFormat'].value);
    console.log(downlaodFromat, 'downlaodFromat');
    if (this.reportName === 'expenseAnalysis') {
      let exportExcel = downlaodFromat === 1 ? true : false;
      let exportText = downlaodFromat === 3 ? true : false;
      let exportPdf = downlaodFromat === 2 ? true : false;
      this.reportService.downloadExpenseAnalysis(exportExcel, exportText, exportPdf).subscribe(
        (dataReturn) => {
          console.log(dataReturn);
          if (downlaodFromat === 1) {
            DownloadFile(dataReturn['body'], 'ExpenseAnalysis', '.csv');
          }
          if (downlaodFromat === 2) {
            DownloadFile(dataReturn['body'], 'ExpenseAnalysis', '.pdf');
          }
          if (downlaodFromat === 3) {
            DownloadFile(dataReturn['body'], 'ExpenseAnalysis', '.txt');
          }
        },
        errorRturn => {
          console.log(errorRturn);
        }
      );
    } else {
      if (downlaodFromat == 1) {
        this.reportService.exportExcel(this.paramsForDownload, this.reportName).subscribe((res) => {
          console.log(res, 'blob');
          console.log(res['body'].type, 'typeeeeeeeeeeee');
          if (res['body'].type == this.invalidfileDataType) {
            this.alertService.info('No Data Found for current search.Cannot generate file');
            return false;
          }
          DownloadFile(res['body'], this.customerName, '.csv');
        });
      }
      if (downlaodFromat == 2) {
        this.reportService.exportPdf(this.paramsForDownload, this.reportName).subscribe((res) => {
          if (res['body'].type == this.invalidfileDataType) {
            this.alertService.info('No Data Found for current search.Cannot generate file');
            return false;
          }
          DownloadFile(res['body'], this.customerName, '.pdf');
          console.log(res, 'blob');
        });
      }

      if (downlaodFromat == 3) {
        this.reportService.exportText(this.paramsForDownload, this.reportName).subscribe((res) => {
          if (res['body'].type == this.invalidfileDataType) {
            this.alertService.info('No Data Found for current search.Cannot generate file');
            return false;
          }
          DownloadFile(res['body'], this.customerName, '.txt');
          console.log(res, 'blob');
        });
      }
    }

  }
}
