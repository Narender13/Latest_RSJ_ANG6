import { Component, TemplateRef, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, FormArray, Validators } from '@angular/forms';
import { trigger, state, style, animate, transition } from '@angular/animations';
import { ActivatedRoute, Router, Params } from '@angular/router';

import { Observable } from 'rxjs';
import { ReportService } from '../../../service/reports.service';
import { BsModalRef, BsModalService, TypeaheadMatch, TypeaheadOptions } from 'ngx-bootstrap';
import { ViewAccountComponent } from '../view-account/view-account.component';
import { formatDate } from '@angular/common';
import { getShortDate } from 'src/app/shared/utilites/helper';
import { RSAENDPOINTConstants } from 'src/app/core/constants/rsa.api.end.points';
import { forEach } from '@angular/router/src/utils/collection';

@Component({
  selector: 'rsa-report-user',
  templateUrl: './report-user.component.html',
  styleUrls: ['./report-user.component.scss']
})
export class ReportUserComponent implements OnInit {
  modalRef: BsModalRef;
  userReportsForm: FormGroup;
  selectedReport;
  cobData = [];
  branchData = [];
  reportsName = [];
  entityType = [];
  entitysearchlist = [];
  headerList = [];
  savedTemplate = [];
  policeyType = [];
  toggleFilter = false;
  noentiti = false;
  entitySerachItem: any;
  entitySerachType: any;
  entitySerachGLCode: any;
  reportName: string;
  coInsurenceDiscountText = 'Co-Insurance';
  coInsurenceDiscountTextPlaceholder = 'Select Co-Insurance';
  regionCode;
  selectedClass;
  templateList = [];
  recoveryAgent;
  locationCode;
  selectedClassDesc: any;
  classId;
  policyTypeSelected;
  policyId;
  policyName;
  entityTypeS;
  entityTypeId;
  reportCode;
  userReportUrl;
  urlTest;
  reportType;
  agentPayeeName = [];
  dummayurl: any;
  convertedDate: any;
  convertedFromDate: any;
  convertedToDate: any;
  statusPayableReport = [];
  agentorPayeeCode: any;
  agentorPayeeType: any;
  recoveryType;
  statusPayableTB;
  viewForm = false;
  statusPayableReportD = true;
  minDateRd: any;
  maxDateRd: any;
  categary: number;
  searchval: string;
  toDateValue: Date;
  constructor(private fb: FormBuilder,
    private route: ActivatedRoute,
    private reportService: ReportService,
    private router: Router,
    public bsModalRef: BsModalRef,
    private modalService: BsModalService
  ) { }

  ngOnInit() {
    this.getCob();
    this.getBranches();
    this.createUserReportForm();
    this.locationCode = localStorage.getItem('locationcode');
    this.regionCode = localStorage.getItem('regioncode');

    this.statusPayableReport = [
      { id: 1, value: 'NOTIFICATION' },
      { id: 2, value: 'SETTLED' },
      { id: 3, value: 'ALL' },
    ];

    this.statusPayableTB = [
      { id: 1, value: 'OUTSTANDING' },
      { id: 2, value: 'SETTLED' },
      { id: 3, value: 'FULLY SETTLED' },
      { id: 4, value: 'ALL' },
    ];

    this.recoveryType = [
      { id: 1, value: 'TP REC' },
      { id: 2, value: 'COINS REC' },
    ];

    this.minDateRd = new Date();
    this.maxDateRd = new Date();
    this.minDateRd.setDate(this.minDateRd.getDate() - 0);
    this.maxDateRd.setDate(this.maxDateRd.getDate() - 0);
    console.log(this.regionCode, ' this.regionCode');
  }

  createUserReportForm(): void {
    this.userReportsForm = this.fb.group({
      Business: [null, Validators.required],
      Branch: [this.locationCode],
      EntityType: [null, Validators.required],
      reportEntityName: [null, Validators.required],
      RepDate: [null, Validators.required],
      FromDate: [null, Validators.required],
      ToDate: [null, Validators.required],
      PolicyType: [null, Validators.required],
      CoInsurance: [null, Validators.required],
      Template: [null, Validators.required],
      RecoveryAgent: [null, Validators.required],
      StatusAgent: [null, Validators.required],
      RecoveryType: [null, Validators.required],
      TypeMarine: [null]
    });
  }

  getHeadersForReports() {
    const param = 'reportId=' + this.reportCode + '&reportType=' + this.reportType;
    this.reportService.getReportHeaders(param).subscribe((data) => {
      this.headerList = data;
      console.log(data, 'headerList');
    });
  }

  getSavedTemplate() {
    const param = 'userReportId=' + this.reportCode;
    this.reportService.getSavedTemplates(param).subscribe((data) => {
      this.templateList = data;
      console.log(data, 'templateList');
    });
  }

  statusPayableReportChange(ev) {
    const value = ev.target.value;
    const CoIns = this.userReportsForm.get('CoInsurance');
    CoIns.setValue(null);
    if (value === 'SETTLED') {
      this.statusPayableReportD = false;
      CoIns.setValidators([Validators.required]);
      CoIns.updateValueAndValidity();
    } else {
      this.statusPayableReportD = true;
    }
  }

  updateTemplateValidator() {
    const Template = this.userReportsForm.get('Template');
    Template.setValidators([Validators.required]);
    Template.updateValueAndValidity();
  }

  ifSgbReqClaimFinaYearclearValidator() {
    const CoIns = this.userReportsForm.get('CoInsurance');
    CoIns.clearValidators();
    CoIns.updateValueAndValidity();
  }

  clearValidatorTP() {
    const CoIns = this.userReportsForm.get('CoInsurance');
    CoIns.clearValidators();
    CoIns.updateValueAndValidity();
    const Business = this.userReportsForm.get('Business');
    Business.clearValidators();
    Business.updateValueAndValidity();
    const Branch = this.userReportsForm.get('Branch');
    Branch.clearValidators();
    Branch.updateValueAndValidity();
    const EntityType = this.userReportsForm.get('EntityType');
    EntityType.clearValidators();
    EntityType.updateValueAndValidity();
    const reportEntityName = this.userReportsForm.get('reportEntityName');
    reportEntityName.clearValidators();
    reportEntityName.updateValueAndValidity();
    const PolicyType = this.userReportsForm.get('PolicyType');
    PolicyType.clearValidators();
    PolicyType.updateValueAndValidity();
    const FromDate = this.userReportsForm.get('FromDate');
    FromDate.clearValidators();
    FromDate.updateValueAndValidity();
    const ToDate = this.userReportsForm.get('ToDate');
    ToDate.clearValidators();
    ToDate.updateValueAndValidity();
  }

  clearValidatorRepDate() {
    const RepDate = this.userReportsForm.get('RepDate');
    RepDate.clearValidators();
    RepDate.updateValueAndValidity();
  }

  updateValidatorRepDate() {
    const RepDate = this.userReportsForm.get('RepDate');
    RepDate.setValidators([Validators.required]);
    RepDate.updateValueAndValidity();
  }

  updateValidatorRecoverAgent() {
    const RecoveryAgent = this.userReportsForm.get('RecoveryAgent');
    RecoveryAgent.setValidators([Validators.required]);
    RecoveryAgent.updateValueAndValidity();
    const statusAgent = this.userReportsForm.get('StatusAgent');
    statusAgent.setValidators([Validators.required]);
    statusAgent.updateValueAndValidity();
    if (this.reportCode === 26 && this.reportType === 3) {
      const recoveryType = this.userReportsForm.get('RecoveryType');
      recoveryType.setValidators([Validators.required]);
      recoveryType.updateValueAndValidity();
    }

  }

  clearValidatorRecoverAgent() {
    const RecoveryAgent = this.userReportsForm.get('RecoveryAgent');
    RecoveryAgent.clearValidators();
    RecoveryAgent.updateValueAndValidity();
    const statusAgent = this.userReportsForm.get('StatusAgent');
    statusAgent.clearValidators();
    statusAgent.updateValueAndValidity();
    const recoveryType = this.userReportsForm.get('RecoveryType');
    recoveryType.clearValidators();
    recoveryType.updateValueAndValidity();
  }

  clearValidateCompositePreimumReg() {
    const RepDate = this.userReportsForm.get('RepDate');
    RepDate.clearValidators();
    RepDate.updateValueAndValidity();
    const RecoveryAgent = this.userReportsForm.get('RecoveryAgent');
    RecoveryAgent.clearValidators();
    RecoveryAgent.updateValueAndValidity();
    const statusAgent = this.userReportsForm.get('StatusAgent');
    statusAgent.clearValidators();
    statusAgent.updateValueAndValidity();
    const recoveryType = this.userReportsForm.get('RecoveryType');
    recoveryType.clearValidators();
    recoveryType.updateValueAndValidity();
  }


  reportChangeO(reportDetails) {
    console.log(reportDetails.reportCode, 'reportDetails');
    this.viewForm = true;
    this.reportName = reportDetails.reportDesc;
    this.reportCode = +(reportDetails.reportCode);
    this.reportType = +(reportDetails.reportType);
    const paramE = 'repCode=' + this.reportCode + '&repType=' + this.reportType;
    this.getEntityType(paramE);
    const params = 'reportCode=' + reportDetails.reportCode;
    this.getSavedTemplates(params);
    if (this.reportCode === 215 && this.reportType === 3 && this.regionCode == 3) {
      this.coInsurenceDiscountText = 'Sbg Discount';
      this.coInsurenceDiscountTextPlaceholder = 'Select Sbg discount';
      const CoIns = this.userReportsForm.get('CoInsurance');
      CoIns.setValidators([Validators.required]);
      CoIns.updateValueAndValidity();
    }

    if (this.reportCode === 215 && this.reportType === 3 && this.regionCode !== 3) {
      this.ifSgbReqClaimFinaYearclearValidator();
    }

    if (this.reportCode === 2 && this.reportType === 3) {
      this.coInsurenceDiscountText = 'Co-Insurance';
      this.coInsurenceDiscountTextPlaceholder = 'Select Co-Insurance';
    }

    if (this.reportCode === 27 && this.reportType === 3 || this.reportCode === 26 && this.reportType === 3) {
      this.coInsurenceDiscountText = 'Net Balance Zero';
      this.coInsurenceDiscountTextPlaceholder = 'Select Net Balance Zero';
      this.getAgentOrPayeeName();
      this.clearValidatorTP();
      this.updateValidatorRecoverAgent();
    }
    if ((this.reportCode === 2 && this.reportType === 3) || (this.reportCode === 50 && this.reportType === 3) ||
      (this.reportCode === 27 && this.reportType === 3) || (this.reportCode === 26 && this.reportType === 3)) {
      this.updateValidatorRepDate();
      this.clearValidatorDate();
      this.clearValidatorRecoverAgent();
    }
    if (this.reportCode === 9 && this.reportType === 3) {
      this.setCreditDebitReportCriteria();
    }

    if (this.reportCode === 10 && this.reportType === 3) {
      this.setCreditDebitReportCriteria();
    }

    if ((this.reportCode === 8 || this.reportCode === 24 || this.reportCode === 215) && this.reportType === 3) {
      this.setClaimsPaidRegCriteria();
    }

    if (this.reportCode === 216 && this.reportType === 3) {
      this.clearFinianicalYearMarineValidator();
    }


    if ((this.reportCode === 11 || this.reportCode === 12) && this.reportType === 3) {
      this.setCreditDebitCustomerCriteria();
    }

    if ((this.reportCode === 13 || this.reportCode === 14) && this.reportType === 3) {
      this.setCreditDebitGlCriteria();
    }
    if (this.reportCode === 10 && this.reportType === 1) {
      this.clearValidateCompositePreimumReg();
    }

    this.userReportsForm.reset();
    this.userReportsForm.reset({
      PolicyType: null,
      EntityType: null,
      Branch: this.locationCode
    });
    // this.userReportsForm.markAsPristine();
    // this.userReportsForm.markAsUntouched();
    this.userReportsForm.updateValueAndValidity();
  }



  clearValidatorDate() {
    const FromDate = this.userReportsForm.get('FromDate');
    FromDate.clearValidators();
    FromDate.updateValueAndValidity();
    const ToDate = this.userReportsForm.get('ToDate');
    ToDate.clearValidators();
    ToDate.updateValueAndValidity();
  }

  changeRecoveryAgent(data) {
    console.log(this.recoveryAgent, 'recoveryAgent');
    this.agentorPayeeCode = this.recoveryAgent.AgentorPayeeCode;
    this.agentorPayeeType = this.recoveryAgent.AgentorPayeeType;
  }

  updateValidatorDate() {
    const FromDate = this.userReportsForm.get('FromDate');
    FromDate.setValidators([Validators.required]);
    FromDate.updateValueAndValidity();
    const ToDate = this.userReportsForm.get('ToDate');
    ToDate.setValidators([Validators.required]);
    ToDate.updateValueAndValidity();

  }

  getAgentOrPayeeName() {
    this.reportService.getAgentOrPayeeName().subscribe((data) => {
      this.agentPayeeName = data;
      console.log(this.agentPayeeName, 'agentPayeeName');
    });
  }

  toggleFilterF() {
    this.toggleFilter = !this.toggleFilter;
    if (this.toggleFilter) {
      this.getHeadersForReports();
      this.getSavedTemplate();
    }
  }

  getCob() {
    this.reportService.getCob().subscribe((data) => {
      this.cobData = data;
      console.log(this.cobData, 'cobdata');
    });
  }

  getBranches() {
    this.reportService.getBranches().subscribe((data) => {
      this.branchData = data;
      console.log(this.branchData, 'branchData');
    });
  }


  getEntityType(params) {
    this.reportService.getEntityType(params).subscribe((data) => {
      this.entityType = data;
      console.log(this.entityType, 'entityType');
    });
  }

  changeEntityType(data) {
    const EntityType = this.userReportsForm.get('reportEntityName');
    this.entityTypeId = this.entityTypeS.EntityTypeCode;
    // console.log(this.entityTypeId);
    if ((this.entityTypeId == '0' || this.entityTypeId == '2') && (this.reportCode === 10 && this.reportType === 1)) {
      this.entityTypeId = null;
    }
      const param = 'entityCode=' + this.entityTypeS.EntityTypeDesc;
      this.searchval = '';
      this.getEntitName(param);
  }

  getEntitName(params) {
    this.reportService.getEntityName(params).subscribe((data) => {
      this.entitysearchlist = data;
      console.log(this.entitysearchlist, 'entitysearchlist');
    });
  }

  getSavedTemplates(params) {
    this.reportService.getUserReportTemplates(params).subscribe((data) => {
      this.savedTemplate = data;
      console.log(this.savedTemplate, 'savedTemplate');
    });
  }

  getPolicyType(params) {
    this.reportService.getPolicyType(params).subscribe((data) => {
      this.policeyType = data;
      console.log(this.policeyType, 'policeyType');
    });
  }

  changePolicyType() {
    this.policyId = this.policyTypeSelected.PolicyTypeCode;
    this.policyName = this.policyTypeSelected.PolicyEnglishDescription;
  }

  classofBusinessChange() {
    console.log(this.selectedClass, 'selectedClass');
    this.selectedClassDesc = this.selectedClass.COBEnglishDescription;
    this.classId = +(this.selectedClass.COBCode);
    const id = this.selectedClass.COBCode;
    const param = 'cl_code=' + id;
    this.getPolicyType(param);
  }

  // getHeadersForReports() {
  //   this.categary = this.isAllorUnmatched === true ? 0 : 1;
  //   const param = 'reportId=5&reportType=2' + '&category=' + this.categary;
  //   this.reportService.getReportHeaders(param).subscribe((data) => {
  //     this.headerList = data;
  //     console.log(data, 'headerList');
  //   });
  // }

  typeaheadOnSelect(typeheadobj: TypeaheadMatch): void {
    console.log('Selected value: ', typeheadobj);
    this.entitySerachGLCode = typeheadobj.item.GLCode;
    this.entitySerachType = typeheadobj.item.EntityId;
    this.entitySerachItem = typeheadobj.item.EntityName;
  }

  typeaheadNoResults(event: boolean): void {
    console.log(event, 'event');
    this.noentiti = event;
  }

  get ifFromDateAndToDate(): boolean {
    return this.reportType === 3 && (this.reportCode === 8 || this.reportCode === 24 ||
      this.reportCode === 215 || this.reportCode === 216 || this.reportCode === 20 || this.reportCode === 10) ||
      (this.reportCode === 10 && this.reportType === 1) || (this.reportCode === 10 && this.reportType === 1) ||
      (this.reportCode === 12 && this.reportType === 3) || (this.reportCode === 14 && this.reportType === 3) ||
      (this.reportCode === 9 && this.reportType === 3) || (this.reportCode === 11 && this.reportType === 3) ||
      (this.reportCode === 13 && this.reportType === 3);
  }


  get ifTpRecoveryAgent(): boolean {
    return this.reportCode === 27 || this.reportCode === 26;
  }

  get ifCreditDebitRegister(): boolean {
    return (this.reportCode === 10 || this.reportCode === 9) && this.reportType === 3;
  }

  get ifCreditDebitCusReg(): boolean {
    return (this.reportCode === 11 || this.reportCode === 12) && this.reportType === 3;
  }


  get ifFincalYearMarine(): boolean {
    return this.reportCode === 216 && this.reportType === 3;
  }


  get ifCreditDebitGlWiseReg(): boolean {
    return (this.reportCode === 13 || this.reportCode === 14) && this.reportType === 3;
  }

  get ifSgbReqClaimFinaYear(): boolean {
    return (this.reportCode === 215 && this.reportType === 3) && this.regionCode !== 3;
  }

  onSubmit() {
    const fromDate = this.userReportsForm.controls['FromDate'].value;
    const toDate = this.userReportsForm.controls['ToDate'].value;
    const repDate = this.userReportsForm.controls['RepDate'].value;
    const recoveryType = this.userReportsForm.controls['RecoveryType'].value;
    const customerName = this.userReportsForm.controls['reportEntityName'].value;
    const tempCode = +(this.userReportsForm.controls['Template'].value);
    const coinss = this.userReportsForm.controls['CoInsurance'].value || null;
    const statusAgent = this.userReportsForm.controls['StatusAgent'].value;
    console.log(statusAgent, 'statusAgent>>>>>>>>>>>>>>>>>>>>');
    const paramCollapsedString = '&rc:Parameters=Collapsed';
    const Embeded = '&rs:Command=Render&rs:Embed=true';


    if ((this.reportCode === 2 && this.reportType === 3) || (this.reportCode === 50 && this.reportType === 3) ||
      (this.reportCode === 27 && this.reportType === 3) || (this.reportCode === 26 && this.reportType === 3)) {
      this.convertedDate = getShortDate(repDate);
    }

    if (this.reportType === 3 && (this.reportCode === 8 || this.reportCode === 24 ||
      this.reportCode === 215 || this.reportCode === 216 || this.reportCode === 20 || this.reportCode === 10) ||
      this.reportCode === 10 && this.reportType === 1 || this.reportCode === 10 && this.reportType === 3 ||
      this.reportCode === 12 && this.reportType === 3 || this.reportCode === 14 && this.reportType === 3 ||
      this.reportCode === 9 && this.reportType === 3 || this.reportCode === 11 && this.reportType === 3 ||
      this.reportCode === 13 && this.reportType === 3) {
      this.convertedFromDate = getShortDate(fromDate);
      this.convertedToDate = getShortDate(toDate);
    }

    if ((this.reportCode === 2 && this.reportType === 3) || (this.reportCode === 50 && this.reportType === 3)) {
      this.userReportUrl = this.reportName + paramCollapsedString + '&class=' + this.classId + '&reg_code=' + this.regionCode +
        '&location=' + this.locationCode + '&policy_type=' + this.policyId + '&rep_date=' + this.convertedDate + '&print_flag=' +
        this.entityTypeId + '&range_id=' + this.entitySerachType + '&class_alias=' + this.selectedClassDesc + '&Policy_type_alias='
        + this.policyName + '&customer_alias=' + customerName + '&Tem_Code=' + tempCode + '&Co_Insurance=' + coinss;
    }
    if ((this.reportCode === 8 && this.reportType === 3) || (this.reportCode === 24 && this.reportType === 3)) {
      this.userReportUrl = this.reportName + paramCollapsedString + '&class=' + this.classId + '&reg_code=' + this.regionCode +
        '&location=' + this.locationCode + '&print_flag=' + this.entityTypeId + '&range_id=' + this.entitySerachType
        + '&pol_type=' + this.policyId + '&from_date=' + this.convertedFromDate + '&to_date=' + this.convertedToDate
        + '&Policy_type_alias=' + this.policyName + '&Customer_alias=' + customerName + '&Class_alias='
        + this.selectedClassDesc + '&Tem_Code=' + tempCode;
    }

    if (this.reportCode === 215 && this.reportType === 3) {
      this.userReportUrl = this.reportName + paramCollapsedString + '&class=' + this.classId +
        '&location=' + this.locationCode + '&from_date=' + this.convertedFromDate + '&to_date=' + this.convertedToDate
        + '&Customer_alias=' + customerName + '&Class_alias=' + this.selectedClassDesc + '&Tem_Code=' + tempCode
        + '&cust_id=' + this.entitySerachType + '&cust_flag=' + this.entityTypeId + '&policy_no=0' + '&loc_code=' + this.locationCode
        + '&Sbg_discount=' + coinss || null;
    }

    if (this.reportCode === 216 && this.reportType === 3) {
      this.userReportUrl = this.reportName + paramCollapsedString + '&location=' + this.locationCode + '&from_date='
        + this.convertedFromDate + '&to_date=' + this.convertedToDate
        + '&Customer_alias=' + customerName + '&Tem_Code=' + tempCode
        + '&cust_id=' + this.entitySerachType + '&loc_code=' + this.locationCode;
    }

    if (this.reportCode === 20 && this.reportType === 3) {
      this.userReportUrl = this.reportName + paramCollapsedString +
        '&location=' + this.locationCode + '&from_date=' + this.convertedFromDate + '&to_date=' + this.convertedToDate
        + '&Customer_alias=' + customerName + '&Tem_Code=' + tempCode + '&class_alias=' + this.selectedClassDesc
        + '&cust_id=' + this.entitySerachType + '&cust_flag=' + this.entityTypeId + '&policy_no=0' + '&loc_code=' + this.locationCode
        + '&class=' + this.classId;
    }

    if (this.reportCode === 10 && this.reportType === 1) {
      const reportName = this.reportName.replace(new RegExp('/', 'g'), '-');
      this.userReportUrl = reportName + paramCollapsedString + '&class=' + this.classId +
        '&location=' + this.locationCode + '&print_flag=' + 0 + '&range_id=' + this.entitySerachType +
        '&pol_type=' + this.policyId + '&from_date=' + this.convertedFromDate + '&to_date=' + this.convertedToDate +
        '&Policy_type_alias=' + this.policyName + '&Customer_alias=' + customerName + '&Class_alias=' + this.selectedClassDesc +
        '&Tem_Code=' + tempCode + '&Co_Insurance=' + coinss + '&entity_flag=' + this.entityTypeId;
    }

    if (this.reportCode === 10 && this.reportType === 3) {
      this.userReportUrl = this.reportName + paramCollapsedString +
        '&location=' + this.locationCode + '&from_date=' + this.convertedFromDate + '&to_date=' + this.convertedToDate +
        '&loc_code=' + this.locationCode + '&Tem_Code=' + tempCode;
    }

    if (this.reportCode === 12 && this.reportType === 3) {
      const reportName = this.reportName.replace(new RegExp('/', 'g'), '-');
      this.userReportUrl = reportName + paramCollapsedString +
        '&location=' + this.locationCode + '&from_date=' + this.convertedFromDate + '&to_date=' + this.convertedToDate +
        '&Customer_alias=' + customerName + '&loc_code=' + this.locationCode + '&cust_id=' + this.entitySerachType +
        '&Tem_Code=' + tempCode + '&print_flag=' + this.entityTypeId;
    }

    if (this.reportCode === 14 && this.reportType === 3) {
      this.userReportUrl = this.reportName + paramCollapsedString + '&class=' + this.classId +
        '&location=' + this.locationCode + '&pol_type=' + this.policyId + '&from_date=' + this.convertedFromDate +
        '&to_date=' + this.convertedToDate + '&loc_code=' + this.locationCode +
        '&Tem_Code=' + tempCode + '&cust_id=' + this.entitySerachType + '&class_alias='
        + this.selectedClassDesc;
    }

    if (this.reportCode === 9 && this.reportType === 3) {
      this.userReportUrl = this.reportName + paramCollapsedString + '&from_date=' + this.convertedFromDate +
        '&to_date=' + this.convertedToDate + '&loc_code=' + this.locationCode +
        '&Tem_Code=' + tempCode + '&location=' + this.locationCode;
    }

    if (this.reportCode === 11 && this.reportType === 3) {
      const reportName = this.reportName.replace(new RegExp('/', 'g'), '-');
      this.userReportUrl = reportName + paramCollapsedString + '&location=' + this.locationCode + '&from_date=' +
        this.convertedFromDate + '&to_date=' + this.convertedToDate + '&Customer_alias=' + customerName + '&loc_code=' + this.locationCode +
        '&cust_id=' + this.entitySerachType + '&Tem_Code=' + tempCode + '&print_flag=' + this.entityTypeId;
    }

    if (this.reportCode === 13 && this.reportType === 3) {
      this.userReportUrl = this.reportName + paramCollapsedString + '&class=' + this.classId + '&location=' + this.locationCode +
        '&poltype=' + this.policyId + '&from_date=' + this.convertedFromDate + '&to_date=' + this.convertedToDate +
        '&loc_code=' + this.locationCode + '&Tem_Code=' + tempCode + '&Policy_type_alias=' + this.policyName + '&class_alias='
        + this.selectedClassDesc;
    }

    if (this.reportCode === 26 && this.reportType === 3) {
      this.userReportUrl = this.reportName + paramCollapsedString + '&location=' + this.locationCode +
        '&Tem_Code=' + tempCode + '&loc_code=' + this.locationCode + '&reag_code=' + this.agentorPayeeCode +
        '&tran_date=' + this.convertedDate + '&Recovery_type=' + recoveryType + '&NetBalZero_checked=' + coinss +
        '&Status=' + statusAgent;
    }


    if (this.reportCode === 27 && this.reportType === 3) {
      this.userReportUrl = this.reportName + paramCollapsedString + '&location=' + this.locationCode +
        '&Tem_Code=' + tempCode + '&loc_code=' + this.locationCode + '&reag_code=' + this.agentorPayeeCode +
        '&tran_date=' + this.convertedDate + '&NetBalZero_checked=' + coinss + '&Status=' + statusAgent;
    }
    console.log(statusAgent, 'statusAgent');
    console.log(this.userReportUrl, 'userReportUrl');
    const userReportUrl = RSAENDPOINTConstants.REPORTSUSER + this.userReportUrl + Embeded;

    const initialState = {
      backdrop: true,
      ignoreBackdropClick: false,
      reportsDataUrl: userReportUrl,
      reportType: 'userreports'
    };
    this.bsModalRef = this.modalService.show(ViewAccountComponent,
      { class: 'user-reports-model', initialState, ignoreBackdropClick: true, keyboard: false });

  }

  setCreditDebitReportCriteria() {
    const EntityType = this.userReportsForm.get('EntityType');
    EntityType.clearValidators();
    EntityType.updateValueAndValidity();
    const reportEntityName = this.userReportsForm.get('reportEntityName');
    reportEntityName.clearValidators();
    reportEntityName.updateValueAndValidity();
    const PolicyType = this.userReportsForm.get('PolicyType');
    PolicyType.clearValidators();
    PolicyType.updateValueAndValidity();
    const CoInsurance = this.userReportsForm.get('CoInsurance');
    CoInsurance.clearValidators();
    CoInsurance.updateValueAndValidity();
    const RecoveryAgent = this.userReportsForm.get('RecoveryAgent');
    RecoveryAgent.clearValidators();
    RecoveryAgent.updateValueAndValidity();
    const StatusAgent = this.userReportsForm.get('StatusAgent');
    StatusAgent.clearValidators();
    StatusAgent.updateValueAndValidity();
    const RecoveryType = this.userReportsForm.get('RecoveryType');
    RecoveryType.clearValidators();
    RecoveryType.updateValueAndValidity();
    const Business = this.userReportsForm.get('Business');
    Business.clearValidators();
    Business.updateValueAndValidity();
    const RepDate = this.userReportsForm.get('RepDate');
    RepDate.clearValidators();
    RepDate.updateValueAndValidity();
  }

  setCreditDebitCustomerCriteria() {
    const PolicyType = this.userReportsForm.get('PolicyType');
    PolicyType.clearValidators();
    PolicyType.updateValueAndValidity();
    const CoInsurance = this.userReportsForm.get('CoInsurance');
    CoInsurance.clearValidators();
    CoInsurance.updateValueAndValidity();
    const RecoveryAgent = this.userReportsForm.get('RecoveryAgent');
    RecoveryAgent.clearValidators();
    RecoveryAgent.updateValueAndValidity();
    const StatusAgent = this.userReportsForm.get('StatusAgent');
    StatusAgent.clearValidators();
    StatusAgent.updateValueAndValidity();
    const RecoveryType = this.userReportsForm.get('RecoveryType');
    RecoveryType.clearValidators();
    RecoveryType.updateValueAndValidity();
    const Business = this.userReportsForm.get('Business');
    Business.clearValidators();
    Business.updateValueAndValidity();
    const RepDate = this.userReportsForm.get('RepDate');
    RepDate.clearValidators();
    RepDate.updateValueAndValidity();
  }

  setCreditDebitGlCriteria() {
    const EntityType = this.userReportsForm.get('EntityType');
    EntityType.clearValidators();
    EntityType.updateValueAndValidity();
    const reportEntityName = this.userReportsForm.get('reportEntityName');
    reportEntityName.clearValidators();
    reportEntityName.updateValueAndValidity();
    const CoInsurance = this.userReportsForm.get('CoInsurance');
    CoInsurance.clearValidators();
    CoInsurance.updateValueAndValidity();
    const RecoveryAgent = this.userReportsForm.get('RecoveryAgent');
    RecoveryAgent.clearValidators();
    RecoveryAgent.updateValueAndValidity();
    const StatusAgent = this.userReportsForm.get('StatusAgent');
    StatusAgent.clearValidators();
    StatusAgent.updateValueAndValidity();
    const RecoveryType = this.userReportsForm.get('RecoveryType');
    RecoveryType.clearValidators();
    RecoveryType.updateValueAndValidity();
    const RepDate = this.userReportsForm.get('RepDate');
    RepDate.clearValidators();
    RepDate.updateValueAndValidity();
  }

  setClaimsPaidRegCriteria() {
    const CoInsurance = this.userReportsForm.get('CoInsurance');
    CoInsurance.clearValidators();
    CoInsurance.updateValueAndValidity();
    const RecoveryAgent = this.userReportsForm.get('RecoveryAgent');
    RecoveryAgent.clearValidators();
    RecoveryAgent.updateValueAndValidity();
    const StatusAgent = this.userReportsForm.get('StatusAgent');
    StatusAgent.clearValidators();
    StatusAgent.updateValueAndValidity();
    const RecoveryType = this.userReportsForm.get('RecoveryType');
    RecoveryType.clearValidators();
    RecoveryType.updateValueAndValidity();
    const RepDate = this.userReportsForm.get('RepDate');
    RepDate.clearValidators();
    RepDate.updateValueAndValidity();
  }

  clearFinianicalYearMarineValidator() {
    const CoInsurance = this.userReportsForm.get('CoInsurance');
    CoInsurance.clearValidators();
    CoInsurance.updateValueAndValidity();
    const RecoveryAgent = this.userReportsForm.get('RecoveryAgent');
    RecoveryAgent.clearValidators();
    RecoveryAgent.updateValueAndValidity();
    const StatusAgent = this.userReportsForm.get('StatusAgent');
    StatusAgent.clearValidators();
    StatusAgent.updateValueAndValidity();
    const RecoveryType = this.userReportsForm.get('RecoveryType');
    RecoveryType.clearValidators();
    RecoveryType.updateValueAndValidity();
    const RepDate = this.userReportsForm.get('RepDate');
    RepDate.clearValidators();
    RepDate.updateValueAndValidity();
    const Business = this.userReportsForm.get('Business');
    Business.clearValidators();
    Business.updateValueAndValidity();
    const PolicyType = this.userReportsForm.get('PolicyType');
    PolicyType.clearValidators();
    PolicyType.updateValueAndValidity();
  }

  onFromdateValueChange(date) {
    console.log(date, 'date');
    if (date) {
      this.toDateValue = date < new Date() ? date : new Date();
    }
  }
}

