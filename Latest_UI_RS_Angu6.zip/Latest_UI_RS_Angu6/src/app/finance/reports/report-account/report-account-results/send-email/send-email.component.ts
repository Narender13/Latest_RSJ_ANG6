import { Component, OnInit } from '@angular/core';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { ActivatedRoute } from '@angular/router';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { validateEmail, multipleEmailValidation, DownloadFile } from 'src/app/shared/utilites/helper';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { ReportService } from '../../../service/reports.service';
@Component({
    selector: 'rsa-send-email',
    templateUrl: './send-email.component.html',
    styleUrls: ['./send-email.component.scss']
})
export class SendEmailComponent implements OnInit {
    emailform: FormGroup;
    modalRef: BsModalRef;
    reportType;
    reportName;
    invalidEmailAddress = true;
    checkcorrectEmail = true;
    customerName;
    paramsForEmail;
    validFileMgs = 'File generated successfully';
    // totallingAccCode;
    constructor(private fb: FormBuilder, private modalService: BsModalService,
        public bsModalRef: BsModalRef, private reportService: ReportService, private alertService: AlertService) { }

    ngOnInit() {
        this.emailform = this.fb.group({
            emailFormat: [null, Validators.required],
            email: [null, Validators.required]
        });
        console.log(this.reportType, 'reportype');
        // console.log(this.totallingAccCode, 'totallingAccCode');
        console.log(this.reportName, 'reportname');
    }
    close() {
        this.bsModalRef.hide();
    }

    downloadFormat(value) {
        console.log(value);
        const downlaodFromat = value;
        if (downlaodFromat == 1) {
            this.reportService.exportExcelEmail(this.paramsForEmail, this.reportName).subscribe((res) => {
                if (res.Message != undefined && res.Message != this.validFileMgs) {
                    this.alertService.info('No Data Found for current search.Cannot generate file');
                    this.emailform.reset();
                }
                console.log(res, 'res');
            });
        }
        if (downlaodFromat == 2) {
            this.reportService.exportPdfEamil(this.paramsForEmail, this.reportName).subscribe((res) => {
                if (res.Message != undefined && res.Message != this.validFileMgs) {
                    this.alertService.info('No Data Found for current search.Cannot generate file');
                    this.emailform.reset();
                }
                console.log(res, 'res');
            });
        }

        if (downlaodFromat == 3) {
            this.reportService.exportTextEamil(this.paramsForEmail, this.reportName).subscribe((res) => {
                if (res.Message != undefined && res.Message != this.validFileMgs) {
                    this.alertService.info('No Data Found for current search.Cannot generate file');
                    this.emailform.reset();
                }
                console.log(res, 'res');
            });
        }
    }



    sendEmail() {
        console.log(this.emailform.value);
        const emailAddress = this.emailform.controls['email'].value;
        const emailFormat = +(this.emailform.controls['emailFormat'].value);
        console.log(emailAddress, emailFormat);
        this.checkcorrectEmail = multipleEmailValidation(emailAddress);
        if (this.checkcorrectEmail) {
            const param = {
                ToEmailID: emailAddress,
                LoggedInUserID: 181,
                VoucherType: this.reportType,
                DownloadType: emailFormat,
                ReportId: this.customerName
            };
            if (this.reportName == 'tb' || this.reportName == 'gl') {
                param['ReportId'] = String(this.customerName);
            }
            console.log(param, 'param');
            this.reportService.sendEmail(param).subscribe((data) => {
                console.log(data, 'data');
                this.alertService.success(data);
                this.emailform.reset();
                // console.log(data, 'data sucessfully');
            });
        }
    }


}
