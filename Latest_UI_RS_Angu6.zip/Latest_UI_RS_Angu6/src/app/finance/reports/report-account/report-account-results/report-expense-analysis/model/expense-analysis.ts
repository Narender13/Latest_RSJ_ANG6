export class ExpenseAnalysis {
    AnalysisCode: number;
    ACEngDesc: string;
    StartDate: Date;
    EndDate: Date;
    success: boolean;
    errors: any;
    result: any;
}
