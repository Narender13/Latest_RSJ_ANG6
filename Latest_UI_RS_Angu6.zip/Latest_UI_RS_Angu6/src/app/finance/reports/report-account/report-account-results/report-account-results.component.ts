import { Component, Input, OnInit, Output, TemplateRef, EventEmitter } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { SendEmailComponent } from './send-email/send-email.component';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { ViewAccountComponent } from './view-account/view-account.component';
import { DownloadAccountDeatilsComponent } from './download-account-deatils/download-account-deatils.component';
import { MasterDataService } from 'src/app/finance/services/finance.masterdata.service';
import { ReportService } from './../../service/reports.service';


@Component({
  selector: 'rsa-report-account-results',
  templateUrl: './report-account-results.component.html',
  styleUrls: ['./report-account-results.component.scss']
})
export class ReportAccountResultsComponent implements OnInit {
  serachReportForm: FormGroup;
  modalRef: BsModalRef;
  emailform: FormGroup;
  @Input() toggleFilter = true;
  totallingacc: any[];
  reportType: string;
  isDisabled = true;
  @Output()
  searchReport: EventEmitter<any> = new EventEmitter<any>();
  branchdata = [];

  constructor(private fb: FormBuilder,
    private modalService: BsModalService,
    public bsModalRef: BsModalRef,
    private route: ActivatedRoute,
    private router: Router,
    private masterDataService: MasterDataService,
    private reportService: ReportService
  ) { }

  ngOnInit() {
    this.getBranchData();
    this.route.params.subscribe(params => {
      this.reportType = params['reportName'];
    });
    this.getTotalingAccountList();
  }

  sendEmail() {
    this.bsModalRef = this.modalService.show(SendEmailComponent,
      { class: 'preview-modal-dailog-send-email', backdrop: 'static', keyboard: false });
  }

  downloadAccount() {
    this.bsModalRef = this.modalService.show(DownloadAccountDeatilsComponent,
      { class: 'preview-modal-dailog-send-email', backdrop: 'static', keyboard: false });
  }

  getBranchData() {
    const countroyCode = localStorage.getItem('countrycode');
    const regionCode = localStorage.getItem('regioncode');
    const param = 'countryCode=' + countroyCode + '&regionCode=' + regionCode;
    this.reportService.getBranchesReports(param).subscribe(
      dataReturn => {
        this.branchdata = dataReturn;
        console.log(this.branchdata, 'branchdata');
      });
  }

  getTotalingAccountList() {
    const ccentre = 11;
    const param = 'ccCode=' + ccentre;
    this.masterDataService.getDetailTotallingAccount(param).subscribe(
      dataReturn => {
        this.totallingacc = dataReturn;
        console.log(this.totallingacc, 'cndnac');
      });
  }


  onSubmit(reportType) {
    const initialState = {
      backdrop: true,
      ignoreBackdropClick: false,
    };
    this.bsModalRef = this.modalService.show(ViewAccountComponent,
      { class: 'preview-modal-dailog', initialState, ignoreBackdropClick: true, keyboard: false });
  }
}
