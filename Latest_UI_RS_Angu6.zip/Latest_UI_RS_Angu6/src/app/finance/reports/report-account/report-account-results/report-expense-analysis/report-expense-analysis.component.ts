import { Component, OnInit, ViewChild, AfterViewInit, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { DatePipe, formatDate } from '@angular/common';
import { ExpenseAnalysis } from './model/expense-analysis'
import { ReportService } from '../../../service/reports.service'
import { AgGridNg2 } from 'ag-grid-angular';
import { GridOptions } from 'ag-grid-community/dist/lib/entities/gridOptions';
import { AgGridEditViewButtonComponent } from '../ag-grid-edit-view-button/ag-grid-edit-view-button.component';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { DownloadFile } from 'src/app/shared/utilites/helper';
import { DownloadAccountDeatilsComponent } from '../download-account-deatils/download-account-deatils.component';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { ConfirmationDialogComponent } from 'src/app/shared/custom-model/custom-model.component';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';
import {AgCustomTextComponent} from 'src/app/shared/ag-custom-text/ag-custom-text.component';
import {AgCustomDateComponent} from 'src/app/shared/ag-custom-date/ag-custom-date.component';

@Component({
    selector: 'rsa-report-expense-analysis',
    templateUrl: './report-expense-analysis.component.html',
    styleUrls: ['./report-expense-analysis.component.scss']
})
export class ReportExpenseAnalysisComponent implements OnInit, AfterViewInit {
    @ViewChild('agGrid') agGrid: AgGridNg2;
    gridApi;
    gridColumnApi;
    paginationOptions: TextValuePair[] = [];
    selectedData;
    expAnalysisForm: FormGroup;
    expAnalysis: ExpenseAnalysis = new ExpenseAnalysis();
    rowData: any[] = [];
    columnDefs: Array<object> = [];
    domLayout;
    detailRowHeight;
    detailCellRendererParams;
    gridConfiguration: GridOptions = {};
    //components;
    viewExpAnalysis = true;
    updateExpAnalysis = true;
    editingRowIndex: number;
    suppressClickEdit;
    currentEditRow;
    isRowEditing: boolean = false;
    endDateMinValue: Date;
    //endDateMaxValue = new Date();
    frameworkComponents;
    constructor(private expAnalysisService: ReportService, private fb: FormBuilder,
        public datepipe: DatePipe, private alertService: AlertService, private modalService: BsModalService, public bsModalRef: BsModalRef) {
        this.domLayout = 'autoHeight';
    }

    ngOnInit() {
        this.createExpAnalysisForm();
        this.getAsyncAllExpenseAnalysis();
        this.columnDefs = [
            {
                headerName: 'Analysis Code', field: 'AnalysisCode',
                filter: 'agTextColumnFilter',
                filterParams: { selectAllOnMiniFilter: true, cellHeight: 30, }, editable: false,
            },
            {
                headerName: 'Project Indicator', field: 'ACEngDesc', filter: 'agTextColumnFilter', editable: true,
            cellEditor: 'agInputText', maxLength: 50 },
            {
                headerName: 'Start Date', field: 'StartDate', filter: 'agDateColumnFilter', editable: true,
                valueFormatter: (data) => {
                    return this.datepipe.transform(data.value, 'dd/MM/yyyy');
                }, cellEditor: "agInputDate",
                filterParams: {
                    comparator: filterByDate,
                    inRangeInclusive: true,
                    browserDatePicker: true
                }
            },
            {
                headerName: 'End Date', field: 'EndDate', filter: 'agDateColumnFilter', editable: true,
                valueFormatter: (data) => {
                    return this.datepipe.transform(data.value, 'dd/MM/yyyy');
                }, cellEditor: "agInputDate", page: 'expAnalysis',
                filterParams: {
                    comparator: filterByDate,
                    inRangeInclusive: true,
                    browserDatePicker: true
                }
            },
            {
                headerName: 'Action',
                field: 'value',
                cellRendererFramework: AgGridEditViewButtonComponent,
                cellRendererParams: {
                    inActoionLink: 'expAnalysis'
                },
                colId: 'editSaveBtn',
                filter: 'none',
                headerClass: 'hidefilter'
            }
        ];
        this.frameworkComponents = { agInputDate: AgCustomDateComponent, agInputText: AgCustomTextComponent };
        this.GetcolumnDefs();
        this.suppressClickEdit = true;
    }

    GetcolumnDefs() {
        this.gridConfiguration = <GridOptions>{
            columnDefs: this.columnDefs,
            postProcessPopup: function (params) {
                const ePopup = params.ePopup;
                ePopup.style.top = '14.9838px';
            },
            rowData: this.rowData,
            rowHeight: 40,
            headerHeight: 40,
            pagination: true,
            floatingFiltersHeight: 40,
            paginationPageSize: 20,
            enableRangeSelection: true,
            rowSelection: 'single',
            rowMultiSelectWithClick: true,
            animateRows: true,
            enableColResize: true,
            enableFilter: true,
            suppressContextMenu: true,
            enableSorting: true,
            editType: 'cel',
            defaultColDef: {
                enableRowGroup: false,
                enableValue: true,
                suppressMovable: true,
                minWidth: 100,
                menuTabs: ['filterMenuTab', '', '']
            },
            context: {
                componentParent: this
            },
        };
    }

    createExpAnalysisForm(): void {
        this.expAnalysisForm = this.fb.group({
            AnalysisCode: [null, Validators.required],
            ACEngDesc: [null, Validators.required],
            StartDate: [null, Validators.required],
            EndDate: [null, Validators.required]
        });
    }


    onParentCancel(rowIndex) {
        this.gridApi.stopEditing();
        this.currentEditRow.editMode = false;
        this.rowData[rowIndex] = this.currentEditRow;
        this.gridConfiguration.api.setRowData(this.rowData);
        this.suppressClickEdit = true;
        this.isRowEditing = false;
    }

    getAsyncAllExpenseAnalysis(): any {
        this.expAnalysisService.getAllExpenseAnalysis().subscribe((data) => {
            this.rowData = data;
            console.log(data, this.rowData);
        });
    }

    validateData(currentData) {
        if (currentData.AnalysisCode === "") {
            this.alertService.error('Analysis Code is empty');
            return 'AnalysisCode';
        }
        if (currentData.ACEngDesc === "") {
            this.alertService.error('Project Indicator is empty');
            return 'ACEngDesc';
        }
        if (currentData.EndDate === "") {
            this.alertService.error('End date is empty');
            return 'EndDate';
        }
        if (currentData.StartDate === "") {
            this.alertService.error('Start date is empty');
            return 'StartDate';
        }
        let endDate = typeof currentData.EndDate === 'string' ? new Date(currentData.EndDate) : currentData.EndDate;
        let startDate = typeof currentData.StartDate === 'string' ? new Date(currentData.StartDate) : currentData.StartDate;
        if (startDate > endDate) {
            this.alertService.error('End date should be greater than Start date');
            return 'EndDate';
        }
        return '';
    }

    saveExpAnalysis(): any {
        if (!this.expAnalysisForm.valid) {
            return false;
        }
        const startdate = Date.parse(this.expAnalysisForm.controls['StartDate'].value);
        const enddate = Date.parse(this.expAnalysisForm.controls['EndDate'].value);
        console.log(startdate, enddate);
        if (startdate > enddate) {
            this.alertService.error('End date should  be greater than Start date');
            return false;
        }
        this.expAnalysisForm.value.EndDate = this.convertDateToString(this.expAnalysisForm.value.EndDate, 'yyyy-MM-ddTHH:mm:ss');
        this.expAnalysisForm.value.StartDate = this.convertDateToString(this.expAnalysisForm.value.StartDate, 'yyyy-MM-ddTHH:mm:ss');
            this.expAnalysisService.addExpenseAnalysis(this.expAnalysisForm.value).subscribe(  
        dataReturn => {
                console.log(dataReturn);
                if (dataReturn.success) {
                    this.expAnalysisForm.reset();
                    this.alertService.success('Data saved successfully.');
                    this.getAsyncAllExpenseAnalysis();
                } else {
                    dataReturn.errors.forEach(element => {
                        this.alertService.error(element);
                    });
                }
            },
            errorRturn => {
                this.alertService.error('something went wrong');
            }
        );
    }

    downloadExpAnalysis() {
       const initialState = {
        backdrop: true,
        ignoreBackdropClick: false,
        reportName: 'expenseAnalysis',
        paramsForDownload: '',
        customerName: ''
      };
      this.bsModalRef = this.modalService.show(DownloadAccountDeatilsComponent,
        { class: 'preview-modal-dailog-send-email', initialState, backdrop: 'static', keyboard: false });
    }

    setAutoHeight() {
        setTimeout(() => {
            this.gridApi.setDomLayout('autoHeight');
        }, 200);

    }

    ngAfterViewInit() {
        this.fitToCoulmn();
        this.setAutoHeight();
    }

    fitToCoulmn() {
        setTimeout(() => {
            this.gridApi.sizeColumnsToFit();
        }, 200);
    }

    onStartDateValueChange($event){
        if($event){
          this.endDateMinValue = $event > new Date() ? $event : new Date();
        }
      }

    onGridReady(params) {
        console.log(params, 'params');
        this.gridApi = params.api;
        this.gridColumnApi = params.columnApi;
        this.gridConfiguration.api.setRowData(this.rowData);
        params.api.paginationGoToPage(0);
        this.fitToCoulmn();
    }

    getRowData(){
        return this.rowData;
     }

    editRowData(rowIndex, column) {
        this.gridApi.startEditingCell({
            rowIndex: rowIndex,
            colKey: column
        });
        this.isRowEditing = true;
    }

    convertDateToString(dateValue, format){
        return this.datepipe.transform(dateValue, format);
    }

    onCellDoubleClicked($event){
        let rowIndex = $event.rowIndex !== null ? $event.rowIndex : null;
        let colId = $event.column ? $event.column.colId : null;
        if(rowIndex && colId)
            this.allowEditing(rowIndex, colId);
    }

    onCellClicked($event) {
        let rowIndex = $event.rowIndex !== null ? $event.rowIndex : null;
        let colId = $event.column ? $event.column.colId : null;
        if(rowIndex && colId)
            this.allowEditing(rowIndex, colId);
    }

    onCellFocused($event){
        let rowIndex = $event.rowIndex !== null ? $event.rowIndex : null;
        let colId = $event.column ? $event.column.colId : null;
        if(rowIndex && colId)
            this.allowEditing(rowIndex, colId);
    }

    allowEditing(rowIndex, colId){
        if(this.isRowEditing){
            if(rowIndex !== this.editingRowIndex){
                this.suppressClickEdit = true;
                this.gridApi.stopEditing();
            }
            else{
                this.suppressClickEdit = false;
                this.editRowData(rowIndex, colId);
            }
        }
    }

    onParentEditClicked(rowIndex) {
        const editedData = this.rowData.filter(data => data.editMode === true);
        if(editedData.length === 0){
            this.suppressClickEdit = false;
            this.editingRowIndex = rowIndex;
            let currentEditData = this.rowData[rowIndex];
            currentEditData.editMode = true;
            this.currentEditRow = Object.assign({}, currentEditData);
            this.editRowData(rowIndex, 'ACEngDesc');
            return true;
        }
        else{
            this.alertService.warn('Please save/cancel the data which already modifed.');
            return false;
        }
        
    }

    onParentSaveClicked(id, rowIndex) {
        console.log(this.rowData);
        this.gridApi.stopEditing();
        let updatedData = this.rowData.filter(data => data.AnalysisCode === id);
        console.log(updatedData, 'updatedata');
        if (updatedData.length > 0) {
            let validate = this.validateData(updatedData[0]);
            if (validate === '') {
                updatedData[0].EndDate = this.convertDateToString(updatedData[0].EndDate, 'yyyy-MM-ddTHH:mm:ss');
                updatedData[0].StartDate = this.convertDateToString(updatedData[0].StartDate, 'yyyy-MM-ddTHH:mm:ss');
                this.expAnalysisService.updateExpenseAnalysis(updatedData[0]).subscribe(  
               dataReturn => {
                        if (!dataReturn.success) {
                            dataReturn.errors.forEach(element => {
                                this.alertService.error(element);
                            });
                            this.editRowData(rowIndex, 'ACEngDesc');
                            return false;
                        }
                        else {
                            this.suppressClickEdit = true;
                            this.alertService.success('Data saved successfully.');
                            updatedData[0].editMode = false;
                            this.isRowEditing = false;
                            this.getAsyncAllExpenseAnalysis();
                            return true;
                        }
                    },
                    errorRturn => {
                        this.alertService.error('something went wrong');
                        this.editRowData(rowIndex, 'ACEngDesc');
                        return false;
                    }
                );
            }
            else {
                this.editRowData(rowIndex, validate);
                return false;
            }
        }
    }

    onParentDeleteClicked(id, rowIndex) {
        this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
        this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
        this.bsModalRef.content.modelBodyContent = RSAMSGConstants.DELETEMSGRECEIPTL;
        this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
        this.bsModalRef.content.actionBtn = RSAMSGConstants.BTNPROCEED;
        this.bsModalRef.content.valueChange.subscribe((data) => {
            if (data = RSAMSGConstants.BTNPROCEED) {
                this.expAnalysisService.removeExpenseAnalysis(id).subscribe(
                    dataReturn => {
                        if (!dataReturn.success) {
                            dataReturn.errors.forEach(element => {
                                this.alertService.error(element);
                            });
                        }
                        else {
                            this.alertService.success('Data deleted successfully.');
                            this.getAsyncAllExpenseAnalysis();
                        }
                    },
                    errorRturn => {
                        this.alertService.error('Something went wrong');
                    }
                );
            }
        });
        
    }
}

interface TextValuePair {
    id: number;
    value: string;
}

function filterByDate (filterLocalDateAtMidnight, cellValue) {
    const dateValue = cellValue;
    if (dateValue == null) {
        return -1;
    }
    let dateParts;
    if(typeof dateValue === 'string'){
        dateParts = dateValue.split('T')[0].split('-');
    }
    else{
        dateParts = new Date(new Date(Number(dateValue.getFullYear()), Number(dateValue.getMonth()), Number(dateValue.getDate())));
    }   
    const cellDate = new Date(new Date(Number(dateParts[0]), Number(dateParts[1]) - 1, Number(dateParts[2])));
    const filterDate = new Date(new Date(Number(filterLocalDateAtMidnight.getFullYear()), Number(filterLocalDateAtMidnight.getMonth()), Number(filterLocalDateAtMidnight.getDate())));
    if (filterDate.getTime() == cellDate.getTime()) {
        return 0;
    }
    if (cellDate < filterDate) {
        return -1;
    }
    if (cellDate > filterDate) {
        return 1;
    }
}