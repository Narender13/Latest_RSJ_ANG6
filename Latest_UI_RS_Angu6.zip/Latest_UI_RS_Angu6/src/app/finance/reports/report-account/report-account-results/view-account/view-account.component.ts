import { Component, OnInit } from '@angular/core';
import { SendEmailComponent } from '../send-email/send-email.component';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { DownloadAccountDeatilsComponent } from '../download-account-deatils/download-account-deatils.component';
import { filter } from 'rxjs/operators';
import { ReportService } from '../../../service/reports.service';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';

@Component({
  selector: 'rsa-view-account',
  templateUrl: './view-account.component.html',
  styleUrls: ['./view-account.component.scss']
})
export class ViewAccountComponent implements OnInit {
  modalRef: BsModalRef;
  filterArrayvalues: any[];
  filterArraykeys: any[];
  constructor(private modalService: BsModalService,
    public bsModalRef: BsModalRef, private reportService: ReportService, private alertService: AlertService) { }
  reportsdata;
  reportsDataUrl;
  reportType;
  cureentDate = new Date();
  soaDeatils: any;
  tbDeatils: any;
  templateHeader: any;
  filterArray = [];
  paramsForDownload;
  customerName;
  ageAnalysis;
  isUnmathed;
  reportName;
  voucherType;
  locationName;
  invalidfileDataType = 'application/json';
  // totallingAccCode;
  ngOnInit() {
    console.log(this.reportName, 'reportType');
    console.log(this.reportsdata, 'reportsdata');
    console.log(this.paramsForDownload, 'paramsForDownload');
    console.log(this.isUnmathed, 'isUnmathed');
    console.log(this.locationName, 'locationName');

    if (this.reportName == 'soa') {
      this.soaDeatils = this.reportsdata.SOADetail;
      this.templateHeader = this.reportsdata.TemplateHeader;
      this.ageAnalysis = this.reportsdata.AgeAnalysis[0];
      console.log(this.ageAnalysis, 'ageanalysis');
    }
    if (this.reportName == 'tb') {
      // this.soaDeatils = this.reportsdata.SOADetail;
      // this.templateHeader = this.reportsdata.TemplateHeader;
    }


    console.log(this.reportsDataUrl, 'reportsDataUrl');

  }
  sendEmail() {
    const initialState = {
      backdrop: true,
      ignoreBackdropClick: false,
      reportType: this.reportType,
      reportName: this.reportName,
      customerName: this.customerName,
      paramsForEmail: this.paramsForDownload
    };
    this.bsModalRef = this.modalService.show(SendEmailComponent,
      { class: 'preview-modal-dailog-send-email', initialState, backdrop: 'static', keyboard: false });
  }
  download() {
    // if (this.reportName == 'soa') {
    const initialState = {
      backdrop: true,
      ignoreBackdropClick: false,
      reportName: this.reportName,
      paramsForDownload: this.paramsForDownload,
      customerName: this.customerName
    };
    this.bsModalRef = this.modalService.show(DownloadAccountDeatilsComponent,
      { class: 'preview-modal-dailog-send-email', initialState, backdrop: 'static', keyboard: false });
  }
  // if (this.reportName == 'tb') {
  //   this.downloadTb();
  // }
  //  }
  // downloadTb() {
  //   const initialState = {
  //     backdrop: true,
  //     ignoreBackdropClick: false,
  //     reportName: 'tb',
  //     paramsForDownload: this.paramsForDownload,
  //     customerName: this.customerName
  //   };
  //   this.bsModalRef = this.modalService.show(DownloadAccountDeatilsComponent,
  //     { class: 'preview-modal-dailog-send-email', initialState, backdrop: 'static', keyboard: false });
  // }

  close() {
    this.modalService.hide(1);
  }
  print() {
    // this.getParams();
    this.reportService.exportPdf(this.paramsForDownload, this.reportName).subscribe((res) => {
      console.log(res, 'res');
      if (res['body'].type == this.invalidfileDataType) {
        this.alertService.info('No Data Found for current search.Cannot print file');
        return false;
      }
      const blob = new Blob([res['body']], { type: 'application/pdf;base64' });
      const blobUrl = URL.createObjectURL(blob);
      const iframe = document.createElement('iframe');
      iframe.style.display = 'none';
      iframe.src = blobUrl;
      document.body.appendChild(iframe);
      iframe.contentWindow.print();
    });
  }

}
