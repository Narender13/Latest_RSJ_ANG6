import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportSoaComponent } from './report-soa.component';

describe('ReportSoaComponent', () => {
  let component: ReportSoaComponent;
  let fixture: ComponentFixture<ReportSoaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReportSoaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReportSoaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
