import { Component, OnInit, Input } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ReportService } from '../../../service/reports.service';
import { Observable } from 'rxjs';
import { TypeaheadMatch } from 'ngx-bootstrap';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { formatDate, DatePipe } from '@angular/common';
import { ViewAccountComponent } from '../view-account/view-account.component';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { SendEmailComponent } from '../send-email/send-email.component';
import { DownloadAccountDeatilsComponent } from '../download-account-deatils/download-account-deatils.component';
import { DownloadFile } from 'src/app/shared/utilites/helper';
import printJS from 'print-js';

@Component({
  selector: 'rsa-general-ledger',
  templateUrl: './general-ledger.component.html',
  styleUrls: ['./general-ledger.component.scss']
})
export class GeneralLedgerComponent implements OnInit {

  @Input() branchdata;
  glForm: FormGroup;
  locationcode: string;
  accountList: any[] = [];
  headerList: any;
  toggleFilter = false;
  frommonth = new Date();
  tomonth = new Date();
  fromyear = new Date();
  toyear = new Date();
  templateList = [];
  selectedTemplateId: number;
  glReortsData: any;
  paramsForgl;
  fromMonth: string;
  toMonth: string;
  fromYear: string;
  toYear: string;
  paramsForGlDownload;
  maxDate: any;
  GLCodeDesc: string;
  invalidfileDataType = 'application/json';
  constructor(private reportService: ReportService, private fb: FormBuilder,
    private alertService: AlertService, private modalService: BsModalService, public bsModalRef: BsModalRef) { }

  ngOnInit() {
    this.locationcode = localStorage.getItem('locationcode');
    console.log(this.locationcode, 'locationcode');
    this.getReportHeadersGL();
    this.createGlForm();
    this.getAccountListGL();
    this.generateSavedTemplateGL();
    this.setMaxDate();
  }
  getAccountListGL() {
    const param = 'userId=' + '181' + '&locationCode=' + this.locationcode;
    this.reportService.getAccountListGL(param).subscribe((data) => {
      this.accountList = data;
      console.log(data, 'accountList');
    });
  }
  setMaxDate() {
    this.maxDate = new Date();
    this.maxDate.setDate(this.maxDate.getDate() - 1);
  }

  setGLCodeDesc(glName: string) {
    const glData = this.accountList.filter((item) => item.GLName == glName);
    console.log(glData);
    if (glData.length) {
      this.GLCodeDesc = glData[0].GLCodeDesc;
    }
    console.log(this.GLCodeDesc);
  }
  createGlForm(): void {
    this.glForm = this.fb.group({
      Account: [null, Validators.required],
      Branch: [this.locationcode, Validators.required],
      DateRange: [null, Validators.required],
      // FromMonth: [null, Validators.required],
      // ToMonth: [null, Validators.required],
      // FromYear: [null, Validators.required],
      // ToYear: [null, Validators.required],
      Template: [null, Validators.required]
    });
  }


  getReportHeadersGL() {
    this.reportService.getReportHeadersGL().subscribe((data) => {
      this.headerList = data;
      console.log(data, 'headerList');
    });
  }

  generateSavedTemplateGL() {
    this.reportService.generateSavedTemplateGL().subscribe((data) => {
      this.templateList = data;
      console.log(data, 'templateList');
    });
  }

  changeTemplate(event) {
    console.log(event.srcElement.value, 'item');
    this.selectedTemplateId = Number(event.srcElement.value);
    console.log(this.selectedTemplateId, 'item');
  }

  getParams() {
    const formatMonth = 'MM';
    const formatYear = 'yyyy';
    const locale = 'en-US';
    const loccode = this.glForm.controls['Branch'].value;
    const dateRange = this.glForm.controls['DateRange'].value;
    this.fromMonth = formatDate(dateRange[0], formatMonth, locale);
    this.toMonth = formatDate(dateRange[1], formatMonth, locale);
    this.fromYear = formatDate(dateRange[0], formatYear, locale);
    this.toYear = formatDate(dateRange[1], formatYear, locale);
    const glName = this.glForm.controls['Account'].value;
    console.log("fromMonth", this.fromMonth);
    console.log("toMonth", this.toMonth);
    console.log("fromYear", this.fromYear);
    console.log("toYear", this.toYear);
    this.paramsForgl = 'glName=' + glName + '&userId=' + '181' + '&locationCode=' + loccode + '&templateId=' + this.selectedTemplateId +
      '&fromYear=' + this.fromYear + '&toYear=' + this.toYear + '&fromMonth=' + this.fromMonth + '&toMonth=' + this.toMonth;
    console.log(this.paramsForgl, 'params');
  }
  onSubmit() {
    this.getParams();
    this.reportService.generateGLReport(this.paramsForgl).subscribe((data) => {
      console.log(data, 'report data');
      this.glReortsData = data;
      if (data !== null && data.SelectedGLDetail.length) {
        const initialState = {
          backdrop: true,
          ignoreBackdropClick: false,
          reportsdata: this.glReortsData,
          reportName: 'gl',
          reportType: 9,
          customerName: this.GLCodeDesc,
          paramsForDownload: this.paramsForgl,
        };
        this.bsModalRef = this.modalService.show(ViewAccountComponent,
          { class: 'user-reports-model', initialState, ignoreBackdropClick: true, keyboard: false });
      } else {
        this.alertService.info('No data found for curerent search');
      }

    });
  }

  toggleFilterF() {
    this.toggleFilter = !this.toggleFilter;
  }

  sendEmail() {
    this.getParams();
    const initialState = {
      backdrop: true,
      ignoreBackdropClick: false,
      reportType: 9,
      reportName: 'gl',
      customerName: this.GLCodeDesc,
      paramsForEmail: this.paramsForgl,
    };
    this.bsModalRef = this.modalService.show(SendEmailComponent,
      { class: 'preview-modal-dailog-send-email', initialState, backdrop: 'static', keyboard: false });
  }

  downloadGlReport() {
    this.getParams();
    const initialState = {
      backdrop: true,
      ignoreBackdropClick: false,
      reportName: 'gl',
      paramsForDownload: this.paramsForgl,
      customerName: this.GLCodeDesc
    };
    this.bsModalRef = this.modalService.show(DownloadAccountDeatilsComponent,
      { class: 'preview-modal-dailog-send-email', initialState, backdrop: 'static', keyboard: false });
  }

  printGl() {
    this.getParams();
    this.reportService.exportPdf(this.paramsForgl, 'gl').subscribe((res) => {
      console.log(res, 'res');
      if (res['body'].type == this.invalidfileDataType) {
        this.alertService.info('No Data Found for current search.Cannot print file');
        return false;
      }
      const blob = new Blob([res['body']], { type: 'application/pdf;base64' });
      const blobUrl = URL.createObjectURL(blob);
      const iframe = document.createElement('iframe');
      iframe.style.display = 'none';
      iframe.src = blobUrl;
      document.body.appendChild(iframe);
      iframe.contentWindow.print();
    });

  }




}
