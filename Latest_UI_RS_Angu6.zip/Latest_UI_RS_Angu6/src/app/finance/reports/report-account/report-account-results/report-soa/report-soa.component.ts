import { Component, OnInit, Input } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ReportService } from '../../../service/reports.service';
import { Observable } from 'rxjs';
import { TypeaheadMatch } from 'ngx-bootstrap';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { formatDate, DatePipe } from '@angular/common';
import { ViewAccountComponent } from '../view-account/view-account.component';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { SendEmailComponent } from '../send-email/send-email.component';
import { DownloadAccountDeatilsComponent } from '../download-account-deatils/download-account-deatils.component';
import { DownloadFile } from 'src/app/shared/utilites/helper';
import printJS from 'print-js';
@Component({
  selector: 'rsa-report-soa',
  templateUrl: './report-soa.component.html',
  styleUrls: ['./report-soa.component.scss']
})
export class ReportSoaComponent implements OnInit {
  @Input() branchdata;
  soaForm: FormGroup;
  locationcode: string;
  entitysearchlist: any[] = [];
  searchval;
  entitySerachItem: any;
  entitySerachType: any;
  entitySerachGLCode: any;
  noentiti = true;
  headerList: any;
  ageingList: Array<any>;
  toggleFilter = false;
  frommonth = new Date();
  tomonth = new Date();
  fromyear = new Date();
  toyear = new Date();
  templateList = [];
  selectedTemplateId: number;
  isAllorUnmatched = false;
  invalidsearch = true;
  soaReortsData: any;
  paramsForSoa;
  fromMonth: string;
  toMonth: string;
  fromYear: string;
  toYear: string;
  categary: number;
  paramsForSoaDownload;
  maxDate: any;
  invalidfileDataType = 'application/json';
  constructor(private reportService: ReportService, private fb: FormBuilder,
    private alertService: AlertService, private modalService: BsModalService, public bsModalRef: BsModalRef) { }

  ngOnInit() {
    this.locationcode = localStorage.getItem('locationcode');
    console.log(this.locationcode, 'locationcode');
    this.getAsyncDataEntitysearchlist();
    this.ageingList = this.reportService.ageing;
    this.createSoaForm();
    this.getSavedTemplate();
    this.formControlClearValidator();
    this.setMaxDate();
  }

  setMaxDate() {
    this.maxDate = new Date();
    this.maxDate.setDate(this.maxDate.getDate() - 1);
  }
  createSoaForm(): void {
    this.soaForm = this.fb.group({
      Branch: [this.locationcode, Validators.required],
      Entitiename: [null, Validators.required],
      // FromMonth: [null, Validators.required],
      // ToMonth: [null, Validators.required],
      // FromYear: [null, Validators.required],
      // ToYear: [null, Validators.required],
      DateRange: [null, Validators.required],
      Template: [null, Validators.required]
    });
  }

  onOpenCalendarForMonth(container) {
    container.monthSelectHandler = (event: any): void => {
      container._store.dispatch(container._actions.select(event.date));
    };
    container.setViewMode('month');
  }

  onOpenCalendarForYear(container) {
    container.yearSelectHandler = (event: any): void => {
      container._store.dispatch(container._actions.select(event.date));
    };
    container.setViewMode('year');
  }

  formControlClearValidator() {
    const DateRange = this.soaForm.get('DateRange');
    DateRange.clearValidators();
    DateRange.updateValueAndValidity();
    // const fromMonth = this.soaForm.get('FromMonth');
    // fromMonth.clearValidators();
    // fromMonth.updateValueAndValidity();
    // const toMonth = this.soaForm.get('ToMonth');
    // toMonth.clearValidators();
    // toMonth.updateValueAndValidity();
    // const fromYear = this.soaForm.get('FromYear');
    // fromYear.clearValidators();
    // fromYear.updateValueAndValidity();
    // const toYear = this.soaForm.get('ToYear');
    // toYear.clearValidators();
    // toYear.updateValueAndValidity();
  }

  formControlAddValidator() {
    // const fromMonth = this.soaForm.get('FromMonth');
    const DateRange = this.soaForm.get('DateRange');
    DateRange.setValidators([Validators.required]);
    DateRange.updateValueAndValidity();
    // fromMonth.setValidators([Validators.required]);
    // fromMonth.updateValueAndValidity();
    // const toMonth = this.soaForm.get('ToMonth');
    // toMonth.setValidators([Validators.required]);
    // toMonth.updateValueAndValidity();
    // const fromYear = this.soaForm.get('FromYear');
    // fromYear.setValidators([Validators.required]);
    // fromYear.updateValueAndValidity();
    // const toYear = this.soaForm.get('ToYear');
    // toYear.setValidators([Validators.required]);
    // toYear.updateValueAndValidity();
  }

  getHeadersForReports() {
    this.categary = this.isAllorUnmatched === true ? 0 : 1;
    const param = 'reportId=5&reportType=2' + '&category=' + this.categary;
    this.reportService.getReportHeaders(param).subscribe((data) => {
      this.headerList = data;
      console.log(data, 'headerList');
    });
  }

  getSavedTemplate() {
    this.categary = this.isAllorUnmatched === true ? 0 : 1;
    const param = '&category=' + this.categary;
    console.log(param, 'param');
    this.reportService.generateSavedTemplateSoa(param).subscribe((data) => {
      this.templateList = data;
      console.log(data, 'templateList');
    });
  }
  typeaheadOnSelect(typeheadobj: TypeaheadMatch): void {
    console.log('Selected value: ', typeheadobj);
    this.entitySerachGLCode = typeheadobj.item.GLCode;
    this.entitySerachType = typeheadobj.item.EntityId;
    this.entitySerachItem = typeheadobj.item.EntityName;
    this.noentiti = true;
  }

  typeaheadNoResults(event: boolean): void {
    this.noentiti = event;
  }

  isAllorUnmatchedF(ev) {
    this.isAllorUnmatched = ev;
    this.getSavedTemplate();
    this.getHeadersForReports();
    if (this.isAllorUnmatched === false) {
      this.formControlClearValidator();
    } else {
      this.formControlAddValidator();
    }
  }

  changeTemplate(event) {
    console.log(event.srcElement.value, 'item');
    this.selectedTemplateId = Number(event.srcElement.value);
    console.log(this.selectedTemplateId, 'item');
  }

  getParams() {
    console.log(this.soaForm.controls['Branch'].value, 'formvalue');
    const loccode = this.soaForm.controls['Branch'].value;
    const formatMonth = 'MM';
    const formatYear = 'yyyy';
    const locale = 'en-US';
    // this.fromMonth = formatDate(this.soaForm.controls['FromMonth'].value, formatMonth, locale);
    // this.toMonth = formatDate(this.soaForm.controls['ToMonth'].value, formatMonth, locale);
    // this.fromYear = formatDate(this.soaForm.controls['FromYear'].value, formatYear, locale);
    // this.toYear = formatDate(this.soaForm.controls['ToYear'].value, formatYear, locale);
    const dateRange = this.soaForm.controls['DateRange'].value;

    if (dateRange != null && dateRange.length) {
      this.fromMonth = formatDate(dateRange[0], formatMonth, locale);
      this.toMonth = formatDate(dateRange[1], formatMonth, locale);
      this.fromYear = formatDate(dateRange[0], formatYear, locale);
      this.toYear = formatDate(dateRange[1], formatYear, locale);
    }
    this.categary = this.isAllorUnmatched === true ? 0 : 1;

    this.paramsForSoa = 'locationCode=' + loccode + '&category=' + this.categary + '&glCode=' + this.entitySerachGLCode
      + '&entityType=' + this.entitySerachType + '&fromMonth=' + this.fromMonth + '&toMonth=' + this.toMonth +
      '&fromYear=' + this.fromYear + '&toYear=' + this.toYear + '&reportId=5&reportType=2' + '&templateId=' + this.selectedTemplateId;
    console.log(this.paramsForSoa, 'params');

    this.paramsForSoaDownload = 'locationCode=' + loccode + '&category=' + this.categary + '&locCode=' +
      this.locationcode + '&glCode=' + this.entitySerachGLCode
      + '&entityType=' + this.entitySerachType + '&fromMonth=' + this.fromMonth + '&toMonth=' + this.toMonth +
      '&fromYear=' + this.fromYear + '&toYear=' + this.toYear + '&templateId=' + this.selectedTemplateId;

    console.log(this.paramsForSoa, 'params');
  }
  onSubmit() {
    this.getParams();
    this.reportService.generateSoaReport(this.paramsForSoa).subscribe((data) => {
      console.log(data, 'data');
      this.soaReortsData = data;
      if (data != null && data.SelectedSOADetail.length) {
        const initialState = {
          backdrop: true,
          ignoreBackdropClick: false,
          reportsdata: this.soaReortsData,
          reportName: 'soa',
          reportType: 8,
          paramsForDownload: this.paramsForSoaDownload,
          customerName: this.entitySerachGLCode,
          isUnmathed: this.isAllorUnmatched
        };
        this.bsModalRef = this.modalService.show(ViewAccountComponent,
          { class: 'user-reports-model', initialState, ignoreBackdropClick: true, keyboard: false });
      } else {
        this.alertService.info('No data found for curerent search');
      }

    });
  }

  toggleFilterF() {
    this.toggleFilter = !this.toggleFilter;
    if (this.toggleFilter) {
      this.getHeadersForReports();
      this.getSavedTemplate();
    }

  }



  sendEmail() {
    this.getParams();
    const initialState = {
      backdrop: true,
      ignoreBackdropClick: false,
      reportType: 8,
      reportName: 'soa',
      customerName: this.entitySerachGLCode,
      paramsForEmail: this.paramsForSoaDownload,
    };
    this.bsModalRef = this.modalService.show(SendEmailComponent,
      { class: 'preview-modal-dailog-send-email', initialState, backdrop: 'static', keyboard: false });
  }

  downloadSoaReport() {
    this.getParams();
    const initialState = {
      backdrop: true,
      ignoreBackdropClick: false,
      reportName: 'soa',
      paramsForDownload: this.paramsForSoaDownload,
      customerName: this.entitySerachItem
    };
    this.bsModalRef = this.modalService.show(DownloadAccountDeatilsComponent,
      { class: 'preview-modal-dailog-send-email', initialState, backdrop: 'static', keyboard: false });
  }

  printSoa() {
    this.getParams();
    this.reportService.exportPdf(this.paramsForSoaDownload, 'soa').subscribe((res) => {
      console.log(res, 'res');
      if (res['body'].type == this.invalidfileDataType) {
        this.alertService.info('No Data Found for current search.Cannot print file');
        return false;
      }
      const blob = new Blob([res['body']], { type: 'application/pdf;base64' });
      const blobUrl = URL.createObjectURL(blob);
      const iframe = document.createElement('iframe');
      iframe.style.display = 'none';
      iframe.src = blobUrl;
      document.body.appendChild(iframe);
      iframe.contentWindow.print();
    });

  }

  getAsyncDataEntitysearchlist() {
    this.entitysearchlist = Observable.create((observer: any) => {
      const userId = localStorage.getItem('LoggedInUserId');
      const locationcode = localStorage.getItem('locationcode');
      const params = 'userId=' + 1 + '&serachName=' + this.searchval + '&locationCode=' + locationcode;
      console.log(this.searchval.length, 'this.searchval');
      this.reportService.getEntitySearchListData(params)
        .subscribe((searchlistdata) => {
          this.invalidsearch = true;
          if (searchlistdata) {
            console.log(searchlistdata, 'serass-obser');
            const data = searchlistdata.sort((one, two) => (one.entityType < two.entityType ? -1 : 1));
            observer.next(data);
          } else {
            this.entitysearchlist = [];
          }
        });
    });
  }

}
