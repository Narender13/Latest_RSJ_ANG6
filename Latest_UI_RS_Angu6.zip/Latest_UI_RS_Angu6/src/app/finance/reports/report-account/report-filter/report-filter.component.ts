import { Component, Input, OnInit, Output, EventEmitter, OnChanges } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import {
  trigger, state, style, transition,
  animate, group, query, stagger, keyframes
} from '@angular/animations';
import { timingSafeEqual } from 'crypto';
import { ReportService } from '../../service/reports.service';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { ReportsRoutingModule } from '../../reports-routing.module';
import { flattenStyles } from '@angular/platform-browser/src/dom/dom_renderer';

@Component({
  selector: 'rsa-report-filter',
  templateUrl: './report-filter.component.html',
  styleUrls: ['./report-filter.component.scss']
})
export class ReportFilterComponent implements OnChanges, OnInit {
  @Output()
  displayfilterReport: EventEmitter<any> = new EventEmitter<any>();
  @Input() toggleFilter = false;
  @Input() headersList: any[] = [];
  reportType: string;
  @Input() selectedHeadersList = [];
  @Input() isAllorUnmatched;
  @Input() sortByHeadersList = [];
  @Input() ageingList: any[] = [];
  @Input() reportCode;
  @Input() reportType1;
  selectedItems = [];
  resetHeadersList: any[] = [];
  selectedReceiptItems = [];
  selectedValue = 'ASC';
  selectedOrder = 'ASC';
  selectedTemplate;
  ageingListClone = [];
  selectedTemplateId;
  templateDetailArray = [];
  updatedAgevalues = [];
  selectedTemplateName;
  @Input() templateList = [];
  isEditTemplate = false;
  sortByOptions: any[] = [
    { 'id': 'ASC', 'item': 'ASC' },
    { 'id': 'DESC', 'item': 'DESC' }];
  removeduplicte: boolean;
  categary: number;
  // hoveredIndex: any;
  showEditInput = false;
  constructor(private fb: FormBuilder,
    private route: ActivatedRoute,
    private reportService: ReportService,
    private alertService: AlertService,
    private router: Router) { }

  ngOnInit() {
    this.route.params.subscribe(params => {
      this.reportType = params['reportName'];
    });
    console.log(this.reportType1, 'this.reportType1');
    console.log(this.reportCode, 'this.reportCode');
  }
  ngOnChanges() {
    if (this.ageingList) {
      this.ageingListClone = this.ageingList.map(item => Object.assign({}, item));
    }
    console.log(this.ageingListClone, 'ageingListClone>>>>>>');
  }


  removeDuplicates(arr, prop): any {
    const obj = {};
    for (let i = 0, len = arr.length; i < len; i++) {
      if (!obj[arr[i][prop]]) {
        obj[arr[i][prop]] = arr[i];
      }
    }
    const newArr = [];
    for (let key in obj) {
      newArr.push(obj[key]);
    };

    return newArr;
  } ''

  onDrop(currentObj, arr) {
    console.log(currentObj);
    const item = currentObj['item'];
    if (arr.length) {
      for (let i = 0; i < arr.length; i++) {
        if (arr[i].Name === item.Name) {
          arr.splice(i, 1);
          return false;
        }
      }
    }
    return true;
  }

  resetHeaderList(): void {
    this.selectedHeadersList = [];
    this.templateDetailArray = [];
    this.sortByHeadersList = [];
  }
  get FilterHeaders(): any {
    const filterHeaders = {} as any;
    filterHeaders.sortByHeadersList = this.sortByHeadersList;
    filterHeaders.selectedHeadersList = this.selectedHeadersList;
    return filterHeaders;
  }

  resetAllHeadersData() {
    this.selectedHeadersList = [];
    this.templateDetailArray = [];
    this.sortByHeadersList = [];
  }

  viewfilterReport() {
    const filterHeaders = this.FilterHeaders;
    this.displayfilterReport.emit(filterHeaders);
  }

  changeOrder(data) {
    console.log(data.item.id, 'data');
    const id = data.item.id;
    this.selectedOrder = id;
    console.log(this.selectedOrder, 'selectedorder');
    if (id == 'ASC') {
      this.sortByHeadersList.sort((a, b) => (a.Name > b.Name) ? 1 : -1);
    } else {
      this.sortByHeadersList.sort((a, b) => (a.Name < b.Name) ? 1 : -1);

    }
  }


  uselectedAge(i, ev) {
    this.selectedItems = [];
    this.ageingList.map((ele, index) => {
      if (this.selectedReceiptItems[index]) {
        this.selectedItems.push(ele);
      }
    });
    console.log(this.selectedItems, 'item');
  }

  editAge(): void {
    this.showEditInput = !this.showEditInput;

  }
  updateToAge(item, val, index): void {
    console.log(item, val, index);
    if (this.updatedAgevalues.length) {
      this.updatedAgevalues.map((obj, i) => {
        if (obj['indexForval'] == index) {
          this.updatedAgevalues.splice(i, 1);
        }
      });
      this.updatedAgevalues.push(
        {
          'toAge': val,
          'indexForval': index
        }
      );
    } else {
      this.updatedAgevalues.push(
        {
          'toAge': val,
          'indexForval': index
        }
      );
    }
    console.log(this.updatedAgevalues);
    // this.updatedAgevalues = this.removeDuplicates(this.updatedAgevalues, 'indexForval');
  }

  saveToAge(): void {
    console.log(this.updatedAgevalues);
    if (this.updatedAgevalues.length) {
      this.updatedAgevalues.some((item) => {
        console.log(this.ageingList[item.indexForval].FromAgeing, item.toAge);
        if (this.ageingList[item.indexForval].FromAgeing > item.toAge) {
          this.alertService.warn('From age should less then to Age at index ' + item.indexForval);
          return true;
        } else {
          if (item.indexForval != 5) {
            this.ageingList[item.indexForval + 1].FromAgeing = Number(item.toAge) + 1;
          }
          this.ageingList[item.indexForval].ToAgeing = Number(item.toAge);
          this.showEditInput = false;
          console.log(this.updatedAgevalues);
          this.updatedAgevalues = [];
          this.ageingListClone = this.ageingList.map(data => Object.assign({}, data));
        }
      });
    } else {
      this.showEditInput = false;
    }
    console.log(this.updatedAgevalues);
  }
  resetAgeing() {
    this.ageingList = this.ageingListClone;
    this.showEditInput = !this.showEditInput;

  }


  changeTemplate(item) {
    console.log(item, 'item');
    this.selectedTemplateId = Number(item.Id);
    this.selectedTemplate = item;
    this.selectedTemplateName = item.Name;
    console.log(item, 'item');
    this.categary = this.isAllorUnmatched === true ? 0 : 1;
    let param = '&templateId=' + this.selectedTemplateId + '&category=' + this.categary;
    if (this.reportType == 'tb' || this.reportType == 'gl' || this.reportType == 'cashbook') {
      param = '&templateId=' + this.selectedTemplateId;
    }
    if (this.reportType == 'userreports') {
      param = '?reportId=' + this.reportCode + '&reportType=' + this.reportType1 + '&templateId=' + this.selectedTemplateId;
    }
    const reportType = this.reportType;
    this.reportService.getSavedTemplate(param, reportType).subscribe((data) => {
      console.log(data, 'data');
      if (data && data.SelectedName != null) {
        this.selectedHeadersList = data.SelectedName;
        this.sortByHeadersList = data.SortingDetails;
        this.selectedValue = data.SortingDetails[0].SortType;
      } else {
        this.alertService.info(`no previous data found for Template ${this.selectedTemplateId}`);
      }

    });
  }

  formatedTemplateDetail() {
    console.log(this.selectedHeadersList, 'selectedheaderlist before format');
    this.templateDetailArray = [];
    this.selectedHeadersList.map((ele) => {
      this.templateDetailArray.push({ 'ColumnID': ele.Id, 'SelectedColumn': ele.Id, 'SortedColumn': null, 'SortType': null });
    });
    console.log(this.templateDetailArray, 'After format');
    this.sortByHeadersList.map((ele, index) => {
      if (this.templateDetailArray.length >= (index + 1)) {
        this.templateDetailArray[index].SortedColumn = ele.Id;
        this.templateDetailArray[index].SortType = this.selectedOrder;
      } else {
        this.templateDetailArray.push({ 'ColumnID': null, 'SelectedColumn': null, 'SortedColumn': ele.Id, 'SortType': this.selectedOrder });
      }
    });
    console.log(this.templateDetailArray, ' this.templateDetailArray');
    console.log(this.templateDetailArray, ' this.templateDetailArrayafter');

  }

  deleteParticularSelectedHeader(index) {
    this.selectedHeadersList.splice(index, 1);
    console.log(this.selectedHeadersList, 'this.selectedHeadersList');
  }

  deleteParticularSortHeader(index) {
    this.sortByHeadersList.splice(index, 1);
    console.log(this.deleteParticularSortHeader, 'this.selectedHeadersList');
  }

  editTemplate(item) {
    this.isEditTemplate = true;
    this.selectedTemplate = item;
  }

  closeEdit() {
    this.isEditTemplate = false;
  }

  saveEditedtemplate(temName, tempId) {
    const objIndex = this.templateList.findIndex((obj => obj.Id == tempId));
    if (!this.checkDuplicateTemplateName(temName)) {
      this.templateList[objIndex].Name = temName;
      this.selectedTemplateName = temName;
      this.isEditTemplate = false;
    } else {
      this.alertService.info(`template name ${temName} already exits`);
    }

  }

  applyConfigurator() {
    console.log(this.selectedHeadersList);
    const selectedHeaderArray = this.selectedHeadersList.length < 0;
    const selectedSortArray = this.sortByHeadersList.length < 0;
    const selectedTeamplate = this.selectedTemplate;
    if (!selectedHeaderArray && !selectedSortArray && (selectedTeamplate == null || undefined)) {
      this.alertService.warn('please select all the fields');
      return false;
    }
    if (this.selectedHeadersList.length == 0) {
      this.alertService.warn('Selected headers field can not  be blank');
      return false;
    }
    this.formatedTemplateDetail();
    const params = {
      'ReportId': 5,
      'ReportType': 2,
      'TemplateID': this.selectedTemplateId,
      'TemplateName': this.selectedTemplateName,
      'UserId': 181,
      'TemplateDetail': this.removeDuplicates(this.templateDetailArray, 'ColumnID'),
    };
    if (this.reportType == 'tb') {
      params['ReportId'] = 8;
    }
    if (this.reportType == 'gl') {
      params['ReportId'] = 7;
    }
    if (this.reportType == 'soa') {
      params['AgeingDetails'] = this.selectedItems;
    }

    if (this.reportType == 'userreports') {
      params['ReportId'] = this.reportCode;
      params['ReportType'] = this.reportType1;
    }
    console.log(JSON.stringify(params), 'params');
    console.log(this.templateDetailArray, ' this.templateDetailArrayafter');

    if (this.reportType === 'userreports') {
      this.reportService.saveUserConfiguratorReports(JSON.stringify(params)).subscribe((data) => {
        if (data) {
          this.alertService.success('Sucessfully Created template');
          // this.resetAllHeadersData();
        } else {
          this.templateDetailArray = [];
        }
      });
    } else {
      this.reportService.saveConfiguratorReports(JSON.stringify(params)).subscribe((data) => {
        if (data) {
          this.alertService.success('Sucessfully Created template');
          // this.resetAllHeadersData();
        } else {
          this.templateDetailArray = [];
        }
      });
    }

  }

  checkDuplicateTemplateName(tempName): boolean {
    console.log(tempName);
    let duplicateTempName = false;
    this.templateList.forEach((item) => {
      if (tempName.trim() === item.Name.trim()) {
        duplicateTempName = true;
      }
    });
    return duplicateTempName;
  }

}


