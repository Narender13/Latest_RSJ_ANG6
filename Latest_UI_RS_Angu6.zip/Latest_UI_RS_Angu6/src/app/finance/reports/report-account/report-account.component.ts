import { Component, TemplateRef, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, FormArray, Validators } from '@angular/forms';
import { trigger, state, style, animate, transition } from '@angular/animations';
import { ActivatedRoute, Router } from '@angular/router';

import { Observable } from 'rxjs';
import { ReportService } from '../service/reports.service';


@Component({
  selector: 'rsa-report-account',
  templateUrl: './report-account.component.html',
  styleUrls: ['./report-account.component.scss'],
  animations: [
    trigger('slide', [
      state('down', style({
        'margin-top': '20px'
      })),
      state('up', style({
        'margin-top': '0px'
      })),
      transition('*=>down', animate('500ms')),
      transition('*=>up', animate('500ms'))
    ])
  ]
})

export class ReportAccountComponent implements OnInit {
  toggleFilter = true;
  reportType: string;
  reportList: Observable<any[]>;
  headerList: any;
  currentState = 'down';
  ageingList: Array<any>;
  isAllorUnmatched = true;
  constructor(private fb: FormBuilder,
    private route: ActivatedRoute,
    private _service: ReportService,
    private router: Router
  ) { }

  ngOnInit() {
    this.route.params.subscribe(params => {
      this.reportType = params['reportName'];
      console.log(this.reportType, 'reporttype');
    });
    this.getReportList();
    this.ageingList = this._service.ageing;

  }
  switchTemplate(): void {
    this.currentState = this.currentState === 'down' ? 'up' : 'down';
    this.toggleFilter = !this.toggleFilter;

  }
  isAllorUnmatchedF(ev) {
    this.isAllorUnmatched = !this.isAllorUnmatched;
    console.log(this.isAllorUnmatched, 'isAllorUnmatched');
  }

  getReportList() {
    this._service.getReportsList().subscribe((data) => {
      this.reportList = data;
    });
  }

  loadReport(e: any) {
    if (e.target.value) {
      const reportName = e.target.value;
      this.router.navigate(['/finance/Reports', reportName]);
      this.ngOnInit();
    }
  }
  getReport($event) {
    console.log($event);
  }
  getfilterHeaders(filterHeaders) {
    console.warn(filterHeaders);
  }

}
