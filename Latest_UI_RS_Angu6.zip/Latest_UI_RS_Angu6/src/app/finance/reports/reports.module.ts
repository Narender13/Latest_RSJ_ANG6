import { filter } from '@angular-devkit/schematics';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../../shared/shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ReportsRoutingModule } from './reports-routing.module';
import { ReportFilterComponent } from './report-account/report-filter/report-filter.component';
import { ReportAccountResultsComponent } from './report-account/report-account-results/report-account-results.component';
import { ReportSoaComponent } from './report-account/report-account-results/report-soa/report-soa.component';
import { UiSwitchModule } from 'ngx-toggle-switch';
import { DndListModule } from 'ngx-drag-and-drop-lists';
import { ReportTbComponent } from './report-account/report-account-results/report-tb/report-tb.component';
import { ReportAccountComponent } from './report-account/report-account.component';
import { SendEmailComponent } from './report-account/report-account-results/send-email/send-email.component';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { ReportsHomeComponent } from './reports-home.component';
import { ReportService } from './service/reports.service';
import { ViewAccountComponent } from './report-account/report-account-results/view-account/view-account.component';
import { DownloadAccountDeatilsComponent } from './report-account/report-account-results/download-account-deatils/download-account-deatils.component';
import { ReportUserComponent } from './report-account/report-account-results/report-user/report-user.component';
import { ReportHeaderComponent } from './report-account/report-account-results/report-header/report-header-component';
import { ChartOfAccountsComponent } from './report-account/report-account-results/chart-of-accounts/chart-of-accounts.component';
import { CashBookComponent } from './report-account/report-account-results/cash-book/cash-book.component';
import { GeneralLedgerComponent } from './report-account/report-account-results/general-ledger/general-ledger.component';
import { BankUploadComponent } from './report-account/report-account-results/bank-upload/bank-upload.component';
import { HoConsldComponent } from './report-account/report-account-results/ho-consld/ho-consld.component';
import { BatchPrintComponent } from './report-account/report-account-results/batch-print/batch-print.component';
import { ReportExpenseAnalysisComponent } from './report-account/report-account-results/report-expense-analysis/report-expense-analysis.component';
import { AgGridModule } from 'ag-grid-angular';
import 'ag-grid-enterprise';
import { AgGridEditViewButtonComponent } from './report-account/report-account-results/ag-grid-edit-view-button/ag-grid-edit-view-button.component';
import {AgCustomTextComponent} from '../../shared/ag-custom-text/ag-custom-text.component';
@NgModule({
  imports: [
    CommonModule,
    UiSwitchModule,
    ReportsRoutingModule,
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
    DndListModule,
    AgGridModule.withComponents([
      AgGridEditViewButtonComponent,
      AgCustomTextComponent
    ])
  ],
  declarations: [ReportsHomeComponent,
    ReportFilterComponent,
    ReportAccountResultsComponent,
    ReportSoaComponent,
    ReportTbComponent,
    ReportAccountComponent,
    SendEmailComponent,
    ViewAccountComponent,
    DownloadAccountDeatilsComponent,
    ReportUserComponent,
    ReportHeaderComponent,
    ChartOfAccountsComponent,
    CashBookComponent,
    GeneralLedgerComponent,
    BankUploadComponent,
    HoConsldComponent,
    BatchPrintComponent,
    ReportExpenseAnalysisComponent,
    AgGridEditViewButtonComponent
  ],
  providers: [
    ReportService,
    BsModalRef,
  ],
  entryComponents: [SendEmailComponent, ViewAccountComponent, DownloadAccountDeatilsComponent]
})
export class ReportsModule { }
