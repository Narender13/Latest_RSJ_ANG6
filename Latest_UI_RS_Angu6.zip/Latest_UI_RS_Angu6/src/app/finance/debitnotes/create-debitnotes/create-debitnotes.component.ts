import { Component, OnInit, ViewChild } from '@angular/core';
import { SharedService } from '../../services/shared.service';
import { FormBuilder, FormControl, FormGroup, FormArray, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';
import { ConfirmationDialogComponent } from 'src/app/shared/custom-model/custom-model.component';
import { BsModalService } from 'ngx-bootstrap/modal';
import { TabsetComponent } from 'ngx-bootstrap/tabs';
import { CreateReceipt } from '../../search/model/create-receipt';
import { UtilityClass } from 'src/app/shared/utilites/helper-class';
import { MasterDataService } from 'src/app/finance/services/finance.masterdata.service';
import { CreateDebitNotes } from 'src/app/finance/debitnotes/create-debitnotes/model/create-dn';
import { BasevoucherComponent } from 'src/app/finance/basevoucher/basevoucher.component';
import { CreateDebitnotesService } from 'src/app/finance/debitnotes/create-debitnotes/service/create-debitnotes.service';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { ReceiptpreviewComponent } from 'src/app/finance/preview/uae/receiptpreview/receiptpreview.component';
import { TaxinvoicepreviewComponent } from 'src/app/finance/preview/uae/taxinvoicepreview/taxinvoicepreview.component';
import { RSAConstants } from 'src/app/core/constants/rsaconstant';

@Component({
  selector: 'rsa-create-debitnotes',
  templateUrl: './create-debitnotes.component.html',
  styleUrls: ['./create-debitnotes.component.scss']
})
export class CreateDebitnotesComponent extends BasevoucherComponent implements OnInit {
  title = 'Tax Invoice';
  currency = 'AED';
  errorpayee: boolean;
  errordetail: boolean;
  errorglCode: boolean;
  /* form error-feilds */
  errorbankcodeCheque: boolean;
  level: any = 2;
  errorbankcodeBanktransfer: boolean;
  errorpaayeebanknameCheque: boolean;
  errorpaayeebanknameBanktransfer: boolean;
  errorchequedateCheque: boolean;
  errorchequedateBankT: boolean;
  errorchequedateCreditCard: boolean;
  errorchequenoCheque: boolean;
  errorchequenoCreditCard: boolean;
  errorterminalID: boolean;
  errorexpirydate: boolean;
  errorvoucherdate: boolean;
  matchedRecords = [];
  isUploadUnmatched;
  returnValue: any;
  usersReq;
  symbol;
  glAcountHeader: any = [];
  createDebitNotes: CreateDebitNotes;
  clonedDebitNotes: CreateDebitNotes;
  animatedClass = true;
  selectedRowItem: any = [];
  toggleValueCredit = [];
  customerName: string = "";
  ondemandFlag: boolean = true;
  ondemandFlagClaim = true;
  formArray: any;
  headerDescription: string = "";
  dnVATFlag = false;
  dnClaimsFlag: any;
  @ViewChild('tabset') tabset: TabsetComponent;
  ifnewlyAddedRow = false;
  isStateClosed: boolean = false;
  accountingCode;
  receiptAccountingDate: any;
  constructor(
    protected sharedService: SharedService,
    private fb: FormBuilder,
    protected modalService: BsModalService,
    protected bsModalRef: BsModalRef,
    protected masterDataService: MasterDataService,
    protected utilityClass: UtilityClass,
    protected createPaymentService: CreateDebitnotesService,
    private alertService: AlertService,
  ) {
    super(masterDataService, sharedService, modalService, utilityClass, bsModalRef);
    //super.setMinMaxDate();
  }


  ngOnInit() {
    /* super with method is calling from BasevoucherComponent */
    this.createVoucherForm(this.paymentMode);
    this.isClaimFlag = this.dnClaimsFlag;
    this.isVATFlag = this.dnVATFlag;
    this.rowClaimData = this.selectedRowItem;
    super.getAllBranchData();
    super.getAllCostCenterData({ ev: null, index: 0, flag: true });
    super.getAllTotallingData(true);
    super.getAllProjData();
    super.getAllDeptData();
    super.getAllMasterData2();
    this.fieldStatusChanges();
    super.closeModel();
    super.getAllTranData();
    this.symbol = (localStorage.getItem('symbol'));
    //super.setMinMaxDate();
    super.GetAccountingDates();
    this.getGlAccountHeader();
    this.getDetailsArrayFormGroup();
    super.getModelPreviousClose();
    super.getAllgetLookupBanksData();
    super.getTotalingHeaderDataCnDn();
    const totcode = this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.value;
    super.getGlAccountHeaderDataCnDn(totcode);
    this.setTotAccTransCreCredit();
    if (this.headerDescription != null && this.headerDescription != undefined && this.headerDescription != '')
      this.setHeaderDescription(this.headerDescription);
    /*mutiple GL Code*/
    this.updateFromSession();
    this.sharedService.getMessage().subscribe(val => {
      if (val == 'ClearState' || val == 'close') {
        if (localStorage.getItem('EntityCDStateExists') != null) {
          localStorage.setItem('EntityCDStateExists', 'false');
          this.isStateClosed = true
        }
      }
    });
  }
  ngOnDestroy() {
    if (!this.isStateClosed) {
      this.addToSession();
    }
  }

  addToSession() {
    if (this.mainVoucherForm.dirty || this.mainVoucherForm.touched) {
      let voucherDate = this.mainVoucherForm['controls'].VoucherDate.value;
      let totallingAccCode = this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.value;
      let glCode = this.mainVoucherForm.controls.accountInfo['controls'].GLCode.value;
      let description = this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription.value;
      let payeeName = this.mainVoucherForm.controls.detailInfo['controls'].PayeeName.value;
      var commonData = { VoucherDate: voucherDate, TotallingAccCode: totallingAccCode, GLCode: glCode, Description: description, PayeeName: payeeName }
      localStorage.setItem('EntityDNData', JSON.stringify(commonData));
      localStorage.setItem('EntityCDStateExists', 'true');
    }
  }
  updateFromSession() {
    let entityCDStateExists = localStorage.getItem('EntityCDStateExists');
    if (entityCDStateExists == 'true') {
      let itemDetail = localStorage.getItem('EntityDNData');
      if (itemDetail) {
        this.mainVoucherForm.markAsDirty();
        let commonData = JSON.parse(itemDetail);
        // if(commonData.VoucherDate) this.mainVoucherForm['controls'].VoucherDate.setValue(new DatePipe('en-US').transform(new Date(commonData.VoucherDate), 'dd/MM/yyyy'));
        if (commonData.TotallingAccCode) {
          this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.setValue(commonData.TotallingAccCode);
          setTimeout(() => {
            super.getGlAccountHeaderDataCnDn(commonData.TotallingAccCode);

          }, 500);
          if (commonData.GLCode) this.mainVoucherForm.controls.accountInfo['controls'].GLCode.setValue(commonData.GLCode);
        }
        if (commonData.Description) this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription.setValue(commonData.Description);
        if (commonData.PayeeName) this.mainVoucherForm.controls.detailInfo['controls'].PayeeName.setValue(commonData.PayeeName);
      }
    }

  }
  checkIsformDirtyCD() {
    this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
    this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
    this.bsModalRef.content.modelBodyContent = RSAMSGConstants.DIRTYFLAGMSGRECIPT;
    this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
    this.bsModalRef.content.actionBtn = RSAMSGConstants.BTNPROCEED;
    this.bsModalRef.content.valueChange.subscribe((data) => {
      if (data = 'Proceed') {
        this.modalService.hide(1);
        this.sharedService.sendMessage('close');
        this.isStateClosed = true;
      }
    });
  }
  /*end*/
  /* create entiti form */
  createVoucherForm(param): void {
    this.mainVoucherForm = null;
    //let tranDate = localStorage.getItem('tranAccntMnthStrtDate') ? new Date(localStorage.getItem('tranAccntMnthStrtDate')) : new Date();
    this.mainVoucherForm = this.fb.group({
      VoucherDate: [new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy')],
      ApprovedBy: [1],
      ArabicDescription: [],
      Amount: [''],
      CountryCode: [1],
      CustomerID: [],
      CustCode: [],
      ModifiedBy: [],
      ModifiedDate: [],
      PreparedBy: [localStorage.getItem(RSAConstants.LoggedInUserId)],
      PreparedDate: [],
      ReprintNo: [],
      PrintDate: [],
      RefreshDate: [],
      PostedDate: [],
      PreprintNo: [],
      Title: [],
      RegionCode: [localStorage.getItem('regioncode')],
      Approvers: this.fb.array([]),
      detailInfo: this.fb.group({
        PayeeName: [this.customerName, Validators.required],
        EnglishDescription: ['', Validators.required],
      }),
      accountInfo: this.fb.group({
        LocationCode: [localStorage.getItem('locationcode')],
        CostCenterCode: [localStorage.getItem('costcentre')],
        TotallingAccCode: [1110],
        GLCode: [4, Validators.required],
      }),
      VoucherDetails: this.fb.array([])
    });
  }
  setHeaderDescription(desc) {
    this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription.setValue(desc);
  }

  get voucherDate() { return this.mainVoucherForm.get('VoucherDate'); }
  getDetailsArrayFormGroup() {

    console.log(this.selectedRowItem, this.ondemandFlag + 'this.selectedRowItem');
    let control = <FormArray>this.mainVoucherForm.controls['VoucherDetails'];
    if (!this.ondemandFlag) {
      console.log('this.selectedRowItem[0].CustomerID', this.selectedRowItem[0].CustomerID);
      this.mainVoucherForm.controls['CustomerID'].setValue(this.selectedRowItem[0].CustomerID);
      this.mainVoucherForm.controls['CustCode'].setValue(this.selectedRowItem[0].CustCode);

      this.selectedRowItem.map((index, item) => {

        let group = this.createDetailsArrayGroup();
        item['IsDebitEntry'] = (item.Amount < 0) ? false : true;
        group.patchValue(item.item);
        console.log('group.get("Amount").value:', group.get("Amount").value)
        console.log("test:::", ((parseFloat(group.get("Amount").value) < 0) ? false : true));
        // group.get('IsDebitEntry').setValue((parseFloat(group.get("Amount").value) < 0) ? false : true);

        group.get("newAddedRow").setValue(false);
        control.push(group);
      });
    } if (!this.ondemandFlagClaim) {
      this.mainVoucherForm.controls['CustomerID'].setValue(this.selectedRowItem[0].CustomerID);
      this.mainVoucherForm.controls['CustCode'].setValue(this.selectedRowItem[0].CustCode);
      /* defect Id  - 2932 fixes Narender */
      this.mainVoucherForm.controls['accountInfo'].get('TotallingAccCode').setValue(this.selectedRowItem[0].DNTotallingAcc);
      this.mainVoucherForm.controls['accountInfo'].get('GLCode').setValue(this.selectedRowItem[0].DNGLCode);

      this.selectedRowItem.map((item, index) => {
        let group = this.createDetailsArrayGroup();
        if (this.dnClaimsFlag) {
          group.addControl('EntryTypeCode', new FormControl());
        }
        item['IsDebitEntry'] = (item.Amount < 0) ? false : true;
        if ((index % 2 === 0)) {
          this.toggleValueCredit[index] = item.Amount < 0 ? false : true;
          console.log(this.toggleValueCredit, 'this.toggleValueCredit');
        }
        group.patchValue(item);
        console.log("Debit Patch After",item);
        console.log('group.get("Amount").value:', group.get("Amount").value)
        console.log("test:::", ((parseFloat(group.get("Amount").value) < 0) ? false : true));
        //group.get('IsDebitEntry').setValue((parseFloat(group.get("Amount").value) < 0) ? false : true);

        group.get("newAddedRow").setValue(false);

        if ((index % 2) !== 0) {
          if (item.DNVATAmount !== 0) {
           // this.toggleValueCredit[index] = item.Amount < 0 ? false : true;
            control.push(group);
          }
        }
        if ((index % 2) == 0) {
          //this.toggleValueCredit[index] = item.Amount < 0 ? false : true;
          control.push(group);
        }
        const ctrl = <FormArray>this.mainVoucherForm.controls['VoucherDetails'];
        ctrl.controls.forEach((val, i) => {
       const amount = val.get('Amount').value;
       this.toggleValueCredit[i] = amount < 0 ? false : true;
     });

        /* please let me know [Ankappa] before enable */
        // (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls[index].get('Amount').setValue(item.Amount);
        // if (item.Amount > 0) {
        //   (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls[index].get('IsDebitEntry').setValue(true);
        // }
        // else {
        //   (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls[index].get('IsDebitEntry').setValue(false);
        // }
        // // if (this.dnClaimsFlag) {
        // //   (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls[index].get('IsDebitEntry').setValue(true);
        // // }
      });
    } else {
      control.push(this.createDetailsArrayGroup());
    }
  }


  getGLdataCnDn(ev) {
    const totcode = ev.ev;
    console.log(totcode, 'totcode');
    super.getGlAccountHeaderDataCnDn(totcode);
    /* set first value as default */
    if (this.glaccountCnDnHeader.length > 0) {
      this.mainVoucherForm.controls.accountInfo['controls'].GLCode.setValue(this.glaccountCnDnHeader.GLCode);
    }
  }

  /* form array for recept details */
  createDetailsArrayGroup(): FormGroup {
    return this.fb.group({
      Amount: [0, Validators.required],
      AnalysisCode: [],
      CostCenterCode: [localStorage.getItem('costcentre')],
      ClaimID: [],
      ClassCode: [],
      CauseOfLossCode: [],
      CounterPartyRef: [],
      CountryCode: [1],
      Description: [],
      DocumentCode: [],
      EntityID: [],
      GLCode: [4, Validators.required],
      GLCodeDesc: ['4-HSBC BANK MIDDLE EAST - Deira', Validators.required],
      LocationCode: [localStorage.getItem('locationcode')],
      LocationDesc: ['Dubai'],
      ModifiedBy: [],
      ModifiedDate: [],
      NatureOfLossCode: [],
      PolicyID: [],
      PolicyYear: [],
      PreparedBy: [localStorage.getItem(RSAConstants.LoggedInUserId)],
      PreparedDate: [],
      RefTransactionID: [],
      RefTransactionSerialNo: [],
      RefTransactionType: [11],
      RegionCode: [localStorage.getItem('regioncode')],
      TotallingAccCode: [1110],
      PolicyType: [],
      newAddedRow: true,
      IsDebitEntry: [false],
      VoucherNo: [],
      SerialNo: [],
      Department: [],
      DepartmentCode: [],
    });
  }

  /* set receipt mode and set default values   */
  setReceiptMode(val, paymentname) {
    this.mainVoucherForm.controls['PaymentMode'].setValue(val);
    this.paymentMode = val;
    this.paymentname = paymentname;
    this.createVoucherForm(this.paymentMode);
    this.receiverdataBankName = this.cachedReceiverBankData;
    this.totallingacc = this.cachedTotAcc;
    this.payeedataBankName = this.cachedPayeeBankData;
    if (this.paymentMode == 1) {
      this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.setValue('1210');
    } else {
      this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.setValue('1110');
      this.mainVoucherForm.controls.accountInfo['controls'].RecevierBankCode.setValue('14');
    }
    this.setdefaultHeaderData();
    this.fieldStatusChanges();
    super.GetAccountingDates();
  }


  setTotAccTransCreCredit() {
    // getTotallingDetailData
    if (this.selectedRowItem.length) {
      this.selectedRowItem.map((item, index) => {
        super.getTotallingDetailData({ index: index, flag: true });
      });
    }
  }

  /* using req fields and update status  */
  fieldStatusChanges() {
    this.clearerrors();
    this.cshpayeename.statusChanges.subscribe(
      status => {
        this.errorpayee = (status === 'INVALID');
        console.log(this.errorpayee, 'his.errorpayee');
      }
    );
    this.cshdetails.statusChanges.subscribe(
      status => {
        this.errordetail = (status === 'INVALID');
      }
    );
    this.cshvoucherdate.statusChanges.subscribe(
      status => {
        this.errorvoucherdate = (status === 'INVALID');
      }
    );

    // this.glCodeValue.statusChanges.subscribe(
    //   status => {
    //     this.errorglCode = (status === 'INVALID');
    //   }
    // );

  }

  /* clear all errors after reset   */
  clearerrors() {
    this.errorpayee = false;
    this.errordetail = false;
    //this.errorglCode = false;
  }

  /* get the controls of each fields   */
  get cshpayeename() { return this.mainVoucherForm.controls.detailInfo['controls'].PayeeName; }
  get cshdetails() { return this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription; }
  get cshvoucherdate() { return this.mainVoucherForm['controls'].VoucherDate; }
  // get glCodeValue() { return this.mainVoucherForm.controls.detailInfo['controls'].GLCode; }


  /* set Description in receptdetails desc   */
  setDescription() {
    (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls[0].get('Description').setValue(this.cshdetails.value);
  }

  getActualAmountSum(processFlag) {
    let total = 0;
    let amt = 0;
    let actualamt = 0;
    let flagtoggle = false;
    (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls.forEach((element, index) => {

      if (this.getFromFormArrayControlVal("Amount", index) != undefined
        && this.getFromFormArrayControlVal("Amount", index) != null) {
        flagtoggle = this.getFromFormArrayControlVal("IsDebitEntry", index);
        console.log(flagtoggle, 'flagtoggle');
        const Camt = parseFloat(this.getFromFormArrayControlVal("Amount", index));
        amt = Math.abs(Camt);
        if (processFlag == 'DN') {
          actualamt = (flagtoggle) ? amt : (amt * -1);
        }
        console.log('flagtoggle:' + flagtoggle + ",amt:" + amt + ",actualamt:" + actualamt);
        total = total + actualamt;
      }

    });
    this.totalAmount = total;
  }
  setCreditEntryDn(ev) {

    console.log(ev.event.target.checked, '<<<<key');
    const actualData = Number(ev.data.controls['Amount'].value);
    //const curdata = -(ev.data.controls['Amount'].value);
    // ev.data.controls['Amount'].patchValue(curdata);

    if (actualData === 0 || actualData === undefined) {
      this.displayAlertModal({
        'title': RSAMSGConstants.MODELTITLE,
        'txt': RSAMSGConstants.EMPTYAMOUNTCHECK,
        'btnaction': RSAMSGConstants.OKTEXT
      });
      ev.event.target.checked = false;

    }
    //console.log(ev.event.target.checked, 'ev.event.target.checked');
    // (<FormArray>this.mainVoucherForm.controls['VoucherDetails'])
    //   .controls[ev.index].get(ev.iscredit).setValue(ev.event.target.checked);
    this.setFormArrayCTRLDefaultValue(ev.iscredit, ev.index, ev.event.target.checked);
    this.getActualAmountSum('DN');
    if (this.totalAmount > 0) {
      ev.event.target.checked = false;
      this.setFormArrayCTRLDefaultValue(ev.iscredit, ev.index, false);
      this.displayAlertModal({
        'title': RSAMSGConstants.MODELTITLE,
        'txt': RSAMSGConstants.CREDITEXCEEDMSG,
        'btnaction': RSAMSGConstants.OKTEXT
      });
    }
    this.getActualAmountSum('DN');
  }

  /* add receipt in review screen */
  addReceipt(len) {
    this.ifnewlyAddedRow = (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls[len - 1].get('newAddedRow').value;
    console.log(this.ifnewlyAddedRow, 'ifnewlyAddedRow');
    const control = <FormArray>this.mainVoucherForm.controls['VoucherDetails'];
    const CurrentAmount = Math.abs((<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls[len - 1].get('Amount').value);
    // const toggleFlag = (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls[len - 1].get('IsDebitEntry').value;
    // let totalAmount = (!toggleFlag)?CurrentAmount * -1:CurrentAmount;
    if (CurrentAmount != null && CurrentAmount != 0 && CurrentAmount != undefined) {
      control.push(this.createDetailsArrayGroup());
      this.setFormArrayCTRLDefaultValue('GLCode', len, 4);
      this.setFormArrayCTRLDefaultValue('GLCodeDesc', len, '4-HSBC BANK MIDDLE EAST - Deira');
      super.getTotallingDetailData({ index: len, flag: true });
      this.dtltotallingacc[len] = this.cachedDtlTot;
      this.glaccount[len] = this.cachedGL;
    } else {
      this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
      this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
      this.bsModalRef.content.modelBodyContent = RSAMSGConstants.AMOUNTVALIDATIONMSG;
      this.bsModalRef.content.cancelBtn = RSAMSGConstants.OKTEXT;
      return false;
    }
  }

  reSetForm(params) {
    const param = params.defaultParam;
    /*set default value here and reset */
    if (param == 1) {
      super.validateAllFormFields(this.mainVoucherForm);
      this.mainVoucherForm.controls.VoucherDate.setValue([new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy')]);
      this.mainVoucherForm.controls.GLCode.setValue(4);
      this.mainVoucherForm.controls.GLCodeDesc.setValue('4-HSBC BANK MIDDLE EAST - Deira');
      this.clearerrors();
    } else if (param == 2) {
      this.mainVoucherForm.controls['VoucherDetails'].reset();
      (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls.map(item => {
        item.get('LocationCode').setValue([localStorage.getItem('locationcode')]);
        item.get('CostCenterCode').setValue([localStorage.getItem('costcentre')]);
        item.get('RefTransactionType').setValue(3);
        item.get('TotallingAccCode').setValue(1110);
        item.get('GLCode').setValue(4);
        item.get('GLCodeDesc').setValue('4-HSBC BANK MIDDLE EAST - Deira');
      });
      this.getActualAmountSum('DN');
    }
    super.GetAccountingDates();
  }

  /* update  form values to create-receipt objects*/
  createCNFormValues() {
    this.createDebitNotes = new CreateDebitNotes();
    const mainFormFieldArray = ['VoucherDate', 'ApprovedBy', 'ArabicDescription',
      'CountryCode', 'CustomerID', 'CustCode', 'ModifiedDate', 'ModifiedBy', 'PostedDate',
      'PreparedBy', 'PreparedDate', 'PreprintNo', 'PrintDate', 'RefreshDate', 'RegionCode', 'Title',
      'Approvers'];
    mainFormFieldArray.forEach(item => {
      console.log('this.item****', item);
      this.createDebitNotes[item] = this.mainVoucherForm.controls[item].value;
    });
    this.createDebitNotes.PreparedDate = this.mainVoucherForm.controls['VoucherDate'].value;
    this.createDebitNotes.LocationCode = this.mainVoucherForm.controls.accountInfo['controls'].LocationCode.value;
    this.createDebitNotes.CostCenterCode = this.mainVoucherForm.controls.accountInfo['controls'].CostCenterCode.value;
    this.createDebitNotes.TotallingAccCode = this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.value;
    this.createDebitNotes.GLCode = this.mainVoucherForm.controls.accountInfo['controls'].GLCode.value;

    this.createDebitNotes.PayeeName = this.mainVoucherForm.controls.detailInfo['controls'].PayeeName.value;
    this.createDebitNotes.EnglishDescription = this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription.value;
    this.createDebitNotes.DebitNoteDetail = this.mainVoucherForm.controls['VoucherDetails'].value;
    console.log('this.createCreditNotes****', this.createDebitNotes);

  }
  preSubmission(precessFlag) {
    let flagtoggle: boolean = false;
    let amt: number = 0;
    this.clonedDebitNotes = Object.assign({}, this.createDebitNotes);
    this.clonedDebitNotes.DebitNoteDetail.forEach((element, index) => {
      flagtoggle = element.IsDebitEntry;
      if (!flagtoggle && precessFlag == 'DN') {
        element.Amount = (Math.abs(element.Amount)) * -1;
      }
      if (this.dnVATFlag && !this.ifnewlyAddedRow) {
        if ((index % 2) !== 0) {
          console.log(element, 'element');
          element.DNVATAmount = element.Amount;
          element.Amount = element.Amount;
        }
        element['CNVATflag'] = true;
      }
    });
    console.log('this.clonedDebitNotes', this.clonedDebitNotes);
  }
  /* create-receipt form*/
  submitForm() {
    super.validateDetailInfo();
    this.errorpayee = this.cshpayeename.invalid;
    this.errordetail = this.cshdetails.invalid;
    this.errorvoucherdate = this.cshvoucherdate.invalid;
    // zero amount warning
    if (this.amountZeroCheck > 0) {
      this.alertService.warn(RSAMSGConstants.AMOUNTZEROCHECK);
      return false;
    }
    if (!(!this.errorpayee && !this.errordetail && !this.errorvoucherdate && !this.errorglCode)) {
      return false;
    }
    if (this.amountLimitCheck > 0) {
      this.alertService.warn(RSAMSGConstants.AMOUNTEXCEEDMSG);
      return false;
    }
    if (this.glerrorcount > 0) {
      return false;
    }

    this.usersReq = (this.approverusers !== undefined && this.approverusers !== '' &&
      this.approverusers.length > 0);
    if (this.totalAmount < 0) {
      // UAE Approver is not needed for country=3
      if (!(localStorage.getItem('country') == '3')) {
        if (this.totalAmount < -99999 && !this.usersReq) {
          return false;
        }
      }

      this.createCNFormValues();

      console.log(this.createDebitNotes, ' this.createCreditNotes');
      if (this.prevPreviewID == null || this.prevPreviewID == undefined)
        this.prevPreviewID = 0;
      this.createDebitNotes["DebitNoteNo"] = this.prevPreviewID;
      this.preSubmission('DN');
      //this.clonedDebitNotes["DebitNoteNo"] = this.prevPreviewID;

      if (this.dnVATFlag) {
        this.clonedDebitNotes['dnVATFlag'] = true;
      }

      console.log('this.prevPreviewID', this.prevPreviewID);
      this.createPaymentService.createDebitNote(JSON.stringify(this.clonedDebitNotes)).subscribe(
        dataReturn => {
          this.returnValue = dataReturn;
          this.returnValue['approverlist'] = this.approverusers;
          this.returnValue['ondemand'] = true;
          this.previewFlag = true;
          // tslint:disable-next-line:max-line-length
          this.bsModalRef = this.modalService.show(TaxinvoicepreviewComponent, { class: 'preview-modal-dailog', ignoreBackdropClick: true });
          this.bsModalRef.content.data = this.returnValue;
          this.bsModalRef.content.totalAmount = this.totalAmount;
          this.bsModalRef.content.backdrop = true;
        },
        errorRturn => {
          this.errorMsg = errorRturn;
        }
      );
    }
    if (this.totalAmount >= 0) {
      this.alertService.warn(RSAMSGConstants.AMOUNTTEXTREQ);
    }
  }


  getGlAccountHeader() {
    const param = 'totAccCode=1110' +
      '&ccCode=' + localStorage.getItem('costcentre');
    this.masterDataService.getDetailGlAccount(param).subscribe(data => {
      this.glAcountHeader = data;
      console.log('gldata', data);
    })
  }

  setGLHdrHiddenValue(ev) {
    console.log(ev);
    this.mainVoucherForm.controls.detailInfo['controls'].GLCode.setValue(ev.item.Code);
  }
  clearHdrGLCode(ev) {
    this.mainVoucherForm.controls.detailInfo['controls'].GLCode.setValue('');
    this.mainVoucherForm.controls.detailInfo['controls'].GLCodeDesc.setValue('');
  }

}