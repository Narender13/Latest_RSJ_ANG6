import { Component, OnInit, Input } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap';
import { PendingApprovalsService } from '../services/pendingapprovals.service';
import { SharedService } from '../../services/shared.service';


@Component({
  selector: 'rsa-receipt-pending-approvals',
  templateUrl: './receipt-pending-approvals.component.html',
  styleUrls: ['./receipt-pending-approvals.component.scss']
})
export class ReceiptPendingApprovalsComponent implements OnInit {

  @Input() receiptPendingApprovalData: any = [];
  @Input() VName: string;
  constructor(private modalService: BsModalService,
    private sharedService: SharedService, private pendingApprovalService: PendingApprovalsService) { }

  ngOnInit() {
    console.log(this.receiptPendingApprovalData, 'receiptPendingApprovalData-cpomp');
  }





}

