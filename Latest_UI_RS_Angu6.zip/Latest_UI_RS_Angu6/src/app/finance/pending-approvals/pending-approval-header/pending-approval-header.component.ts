import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { PendingApprovalsResultsComponent } from '../pending-approvals-results.component';
import { ActivatedRoute, Router } from '@angular/router';
import { PendingApprovalsService } from '../services/pendingapprovals.service';

@Component({
  selector: 'rsa-pending-approval-header',
  templateUrl: './pending-approval-header.component.html',
  styleUrls: ['./pending-approval-header.component.scss']
})
export class PendingApprovalHeaderComponent implements OnInit {
  @Input() catid: number;
  @Output() getPaymentVocherO = new EventEmitter();
  constructor(protected route: ActivatedRoute,
    protected pendingApprovalService: PendingApprovalsService, private router: Router) {

  }

  ngOnInit() {
  }

  getVoucherType(vochername) {
    const params = {
      'voucherName': vochername,
    };
    this.router.navigate(['home/search/pendingapproval'], {
      queryParams: params
    });
  }


}

