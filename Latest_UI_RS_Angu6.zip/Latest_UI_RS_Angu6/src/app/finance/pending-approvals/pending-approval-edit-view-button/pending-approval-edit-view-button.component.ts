import { Component, OnInit } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';
import { BsModalRef, BsModalService } from 'ngx-bootstrap';
import { ReceiptpreviewComponent } from 'src/app/finance/preview/uae/receiptpreview/receiptpreview.component';
import { CreateDraftReceiptComponent } from 'src/app/finance/drfats/drafts-results/create-draft-receipt/create-draft-receipt.component';
import { TaxinvoicepreviewComponent } from 'src/app/finance/preview/uae/taxinvoicepreview/taxinvoicepreview.component';
import { CreateDraftDebitnoteComponent } from '../../drfats/drafts-results/create-draft-debitnote/create-draft-debitnote.component';
import { CnpreviewComponent } from 'src/app/finance/preview/uae/cnpreview/cnpreview.component';
import { CreateDraftCreditnoteComponent } from '../../drfats/drafts-results/create-draft-creditnote/create-draft-creditnote.component';
import { PaymentpreviewComponent } from 'src/app/finance/preview/uae/paymentpreview/paymentpreview.component';
import { CreateDraftPaymentComponent } from '../../drfats/drafts-results/create-draft-payment/create-draft-payment.component';
import { JvpreviewComponent } from 'src/app/finance/preview/uae/jvpreview/jvpreview.component';
import { CreateDraftJournalComponent } from 'src/app/finance/drfats/drafts-results/create-draft-journal/create-draft-journal.component';

import { PendingApprovalsService } from 'src/app/finance/pending-approvals/services/pendingapprovals.service';
import { DrfatService } from 'src/app/finance/drfats/drafts-results/services/drafts.service';


@Component({
  selector: 'rsa-pending-approval-edit-view-button',
  templateUrl: './pending-approval-edit-view-button.component.html',
  styleUrls: ['./pending-approval-edit-view-button.component.scss']
})
export class PendingApprovalEditViewButtonComponent implements ICellRendererAngularComp {
  public params: any;
  bsModalRef: BsModalRef;
  receiptData: any;
  debitenoteData: any;
  creditnoteData: any;
  paymentData: any;
  jvData: any;

  receiptNo;
  debitNoteNo;
  creditNoteNo;
  paymentNo;
  VoucherNo;
  receiptDetailData: any = [];
  debitenoteDetailData: any = [];
  creditnoteDetailData: any = [];
  paymentDetailData: any = [];
  jvDetailData: any = [];
  voucherName:string;
  constructor(private modalService: BsModalService, private drfatService: DrfatService) { }

  agInit(params: any): void {
    this.params = params;
    this.receiptNo = this.params.context.componentParent.methodFromParent(this.params.data.ReceiptNo);
    this.debitNoteNo = this.params.context.componentParent.methodFromParent(this.params.data.DebitNoteNo);
    this.creditNoteNo = this.params.context.componentParent.methodFromParent(this.params.data.CreditNoteNo);
    this.paymentNo = this.params.context.componentParent.methodFromParent(this.params.data.PaymentNo);
    this.VoucherNo = this.params.context.componentParent.methodFromParent(this.params.data.VoucherNo);
    this.voucherName = params.inActoionLink;

}


  viewReceipt() {
    //console.log(this.receiptNo,"sdssss");
      this.receiptNo = 576498;
    this.drfatService.getDraftReceipt(this.receiptNo).subscribe((data) => {
      this.receiptDetailData = data;
      this.receiptDetailData['fromDraftView'] = 'true';
      console.log(data, 'detaildata');
      this.bsModalRef = this.modalService.show(ReceiptpreviewComponent, { class: 'preview-modal-dailog', ignoreBackdropClick: true });
      this.bsModalRef.content.data = this.receiptDetailData;
      this.bsModalRef.content.totalAmount = this.params.data.TotalAmount;
      this.bsModalRef.content.backdrop = true;
    });
  }

  editReceipt() {
   // this.receiptNo = 576498;
    this.drfatService.getDraftReceipt(this.receiptNo).subscribe((data) => {
      this.receiptDetailData = data;
      const initialState = {
        backdrop: true,
        ignoreBackdropClick: false,
        receiptEditData: this.receiptDetailData,
      };
      console.log('initialState:', initialState);
      this.bsModalRef = this.modalService.show(CreateDraftReceiptComponent, { class: 'create-modal-dailog', initialState });
    });

  }

  viewDebitNote() {
      //this.debitNoteNo = 1422960;
      this.drfatService.getDrfatsDebitnote(this.debitNoteNo).subscribe((data) => {
      this.debitenoteDetailData = data;
      this.debitenoteDetailData['fromDraftView'] = 'true';
      console.log(data, 'detaildata');
      this.bsModalRef = this.modalService.show(TaxinvoicepreviewComponent, { class: 'preview-modal-dailog', ignoreBackdropClick: true });
      this.bsModalRef.content.data = this.debitenoteDetailData;
      this.bsModalRef.content.totalAmount = this.params.data.TotalAmount;
      this.bsModalRef.content.backdrop = true;
    });
  }

  editDebitNote() {
   // this.debitNoteNo = 1422960;
    this.drfatService.getDrfatsDebitnote(this.debitNoteNo).subscribe((data) => {
      this.debitenoteDetailData = data;
      const initialState = {
        backdrop: true,
        ignoreBackdropClick: false,
        debitnoteEditData: this.debitenoteDetailData,
      };
      console.log('initialState:', initialState);
      this.bsModalRef = this.modalService.show(CreateDraftDebitnoteComponent, { class: 'create-modal-dailog', initialState });
    });

  }


  viewCreditNote() {
    this.drfatService.getDrfatsCreditnote(this.creditNoteNo).subscribe((data) => {
    this.creditnoteDetailData = data;
    this.creditnoteDetailData['fromDraftView'] = 'true';
    console.log(data, 'detaildata');
    this.bsModalRef = this.modalService.show(CnpreviewComponent, { class: 'preview-modal-dailog', ignoreBackdropClick: true });
    this.bsModalRef.content.data = this.creditnoteDetailData;
    this.bsModalRef.content.totalAmount = this.params.data.TotalAmount;
    this.bsModalRef.content.backdrop = true;
  });
}

editCreditNote() {
  this.drfatService.getDrfatsCreditnote(this.creditNoteNo).subscribe((data) => {
    this.creditnoteDetailData = data;
    const initialState = {
      backdrop: true,
      ignoreBackdropClick: false,
      creditnoteEditData: this.creditnoteDetailData,
    };
    console.log('initialState:', initialState);
    this.bsModalRef = this.modalService.show(CreateDraftCreditnoteComponent, { class: 'create-modal-dailog', initialState });
  });
}

viewPayment() {
  //console.log(this.paymentNo,"dsfadf");
  this.drfatService.getDrfatsPayment(this.paymentNo).subscribe((data) => {
  this.paymentDetailData = data;
  this.paymentDetailData['fromDraftView'] = 'true';
  console.log(data, 'detaildata');
  this.bsModalRef = this.modalService.show(PaymentpreviewComponent, { class: 'preview-modal-dailog', ignoreBackdropClick: true });
  this.bsModalRef.content.data = this.paymentDetailData;
  this.bsModalRef.content.totalAmount = this.params.data.TotalAmount;
  this.bsModalRef.content.backdrop = true;
});
}

editPayment() {
this.drfatService.getDrfatsPayment(this.paymentNo).subscribe((data) => {
  this.paymentDetailData = data;
  const initialState = {
    backdrop: true,
    ignoreBackdropClick: false,
    paymentEditData: this.paymentDetailData,
  };
  console.log('initialState:', initialState);
  this.bsModalRef = this.modalService.show(CreateDraftPaymentComponent, { class: 'create-modal-dailog', initialState });
});
}

viewJv() {
 // this.VoucherNo = 34447;
  this.drfatService.getDrfatsJournal(this.VoucherNo).subscribe((data) => {
  this.paymentDetailData = data;
  this.paymentDetailData['fromDraftView'] = 'true';
  console.log(data, 'detaildata');
  this.bsModalRef = this.modalService.show(JvpreviewComponent, { class: 'preview-modal-dailog', ignoreBackdropClick: true });
  this.bsModalRef.content.data = this.paymentDetailData;
  this.bsModalRef.content.totalAmount = this.params.data.TotalAmount;
  this.bsModalRef.content.backdrop = true;
});
}

editJv() {
  //this.VoucherNo = 34447;
this.drfatService.getDrfatsJournal(this.VoucherNo).subscribe((data) => {
  this.jvDetailData = data;
  const initialState = {
    backdrop: true,
    ignoreBackdropClick: false,
    jvEditData: this.jvDetailData,
  };
  console.log('initialState:', initialState);
  this.bsModalRef = this.modalService.show(CreateDraftJournalComponent, { class: 'create-modal-dailog', initialState });
});
}

refresh(): boolean {
    return false;
  }

}
