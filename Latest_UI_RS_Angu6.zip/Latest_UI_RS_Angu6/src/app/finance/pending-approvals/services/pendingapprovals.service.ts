import { Injectable } from '@angular/core';
import { HttpParams, HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { RSAENDPOINTConstants } from 'src/app/core/constants/rsa.api.end.points';
import { map, catchError } from 'rxjs/operators';
import { handleErrorObservable } from 'src/app/shared/utilites/helper';

@Injectable({
    providedIn: 'root'
})

export class PendingApprovalsService {
    pendingRejectResults: any = [];
    constructor(private http: HttpClient) { }
    
    getPendingApprovalsReceipts(param): Observable<any> {
        let Url = RSAENDPOINTConstants.PENDINGAPPROVAL_UNAPPROVED_RECEIPT_API + param;
        return this.http.get(Url).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getpendingApprovalReceipt')));
    }

    getPendingApprovalDebitnotes(param): Observable<any> {

        return this.http.get(RSAENDPOINTConstants.PENDINGAPPROVAL_UNAPPROVED_DN_API + param).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getPENDINGAPPROVALDns')));
    }

    getPendingApprovalCreditnotes(param): Observable<any> {

        return this.http.get(RSAENDPOINTConstants.PENDINGAPPROVAL_UNAPPROVED_CN_API + param).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getPENDINGAPPROVALCns')));
    }
    getPendingApprovalPayments(param): Observable<any> {

        return this.http.get(RSAENDPOINTConstants.PENDINGAPPROVAL_UNAPPROVED_PAYMENT_API + param).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getPENDINGAPPROVALPayments')));
    }
    getPendingApprovalJournals(param): Observable<any> {

        return this.http.get(RSAENDPOINTConstants.PENDINGAPPROVAL_UNAPPROVED_JV_API + param).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getPENDINGAPPROVALCns')));
    }

    pendingRejectApprovalReceipt(param): Observable<any> {
        // const body = JSON.stringify(param);
        // console.log(body, 'body');
        this.pendingRejectResults = [];
        this.pendingRejectResults.push(param);
        console.log(this.pendingRejectResults, 'body');
        return this.http.put(RSAENDPOINTConstants.UPDATERECEIPTSSTATUS, this.pendingRejectResults).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('UPDATERECEIPTSSTATUS')));
    }


    pendingRejectApprovalPayment(param): Observable<any> {
        // const body = JSON.stringify(param);
        // console.log(body, 'body');
        this.pendingRejectResults = [];
        this.pendingRejectResults.push(param);
        console.log(this.pendingRejectResults, 'body');
        return this.http.put(RSAENDPOINTConstants.UPDATEPAYMENTSTATUS, this.pendingRejectResults).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('UPDATEPAYMENTSTATUS')));
    }

    pendingRejectApprovalCreditNote(param): Observable<any> {
        // const body = JSON.stringify(param);
        // console.log(body, 'body');
        this.pendingRejectResults = [];
        this.pendingRejectResults.push(param);
        console.log(this.pendingRejectResults, 'body');
        return this.http.put(RSAENDPOINTConstants.UPDATECREDITSTATUS, this.pendingRejectResults).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('UPDATECREDITSTATUS')));
    }

    pendingRejectApprovalDebitNote(param): Observable<any> {
        // const body = JSON.stringify(param);
        // console.log(body, 'body');
        this.pendingRejectResults = [];
        this.pendingRejectResults.push(param);
        console.log(this.pendingRejectResults, 'body');
        return this.http.put(RSAENDPOINTConstants.UPDATEDEBITSSTATUS, this.pendingRejectResults).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('UPDATEDEBITSSTATUS')));
    }

    pendingRejectApprovalJv(param): Observable<any> {
        // const body = JSON.stringify(param);
        // console.log(body, 'body');
        this.pendingRejectResults = [];
        this.pendingRejectResults.push(param);
        console.log(this.pendingRejectResults, 'body');
        return this.http.put(RSAENDPOINTConstants.UPDATEJVSTATUS, this.pendingRejectResults).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('UPDATEJVSTATUS')));
    }



}

