
import { Component, OnInit, ViewChild, AfterViewInit, Input, Output, EventEmitter } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { AgGridNg2 } from 'ag-grid-angular';
import { GridOptions } from 'ag-grid-community/dist/lib/entities/gridOptions';
import { GridService } from 'src/app/shared/datatable/services/grid-service';
import { Entitie } from 'src/app/shared/datatable/model/entitie';
import { MatchUnMatchService } from 'src/app/finance/search/service/match-unmatch.service';
import { GridApiService } from 'src/app/shared/datatable/services/grid-api-service';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { PendingapprovalsAgridService } from 'src/app/finance/pending-approvals/services/pendingapprovals.grid.service';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { ApprovedRejectDailogComponent } from '../approved-reject-dailog/approved-reject-dailog.component';
import { SharedService } from '../../services/shared.service';
import { UserAutherizationService } from 'src/app/core/authorization/userauth.service';

@Component({
  selector: 'rsa-pending-approval-grid',
  templateUrl: './pending-approval-grid.component.html',
  styleUrls: ['./pending-approval-grid.component.scss']
})
export class PendingApprovalGridComponent implements OnInit, AfterViewInit {
  @ViewChild('agGrid') agGrid: AgGridNg2;
  gridApi;
  gridColumnApi;
  paginationOptions: TextValuePair[] = [];
  selectedData;
  showSnackbar = false;
  masterData = {};
  @Input() detailRowHeight;
  @Input() detailCellRendererParams;
  @Input() gridConfiguration: GridOptions = {};
  @Input('rowData') rowData: Entitie[] = [];
  @Output() selectedRowDetails = new EventEmitter();
  @Output() deSelectCheckbox = new EventEmitter();
  entityMatch: TextValuePair[] = [];
  columnDefs = [];
  gridDataselectedRows = [];
  uncheck;
  totalRecepitAmount;
  ifMatched;
  frameworkComponents;
  domLayout;
  buttonName;
  @Input() vouName: string;
  @Input() myTaskDraftFlag: boolean;
  @Input() myTaskPAFlag: boolean;
  bsModalRef: BsModalRef;
  currRowSelectionData: any;
  private selectedTransactionType: string;

  constructor(private http: HttpClient, private pendingApprovalsAgridService: PendingapprovalsAgridService,
    private matchunmatchservice: MatchUnMatchService, private gridApiService: GridApiService, private modalService: BsModalService,
    private alertService: AlertService, private sharedService: SharedService,private allowAccess: UserAutherizationService) {
    console.log(this.rowData, 'rowData');
    this.paginationOptions = [
      { id: 2, value: '20' },
      { id: 2, value: '100' },
      { id: 3, value: '500' },
      { id: 4, value: '1000' }
    ];

    this.entityMatch = [
      { id: 0, value: 'UnMatched' },
      { id: 1, value: 'Matched' },
    ];

  }

  unSelectedCheckBox() {
    this.sharedService.getMessage().subscribe(data => {
      if (data = 'close-approve-rejected-window') {
        this.gridApiService.unCheck();
      }
    });
  }

  ngOnInit() {
    console.log(this.vouName, 'this.vouName');
    this.GetcolumnDefs(this.vouName);
    this.detailRowHeight = 220;
    const _currentInstance = this;
    this.detailCellRendererParams = {
      getDetailRowData: function (params) {
        params.successCallback(params.data);
        this.fitToCoulmn();
      },
      onFirstDataRendered(params) {
        params.api.sizeColumnsToFit();
      },

      template: (params) => {
        return _currentInstance.pendingApprovalsAgridService.getMasterData(params, this.vouName);
      }
    };
    this.domLayout = 'autoHeight';
    this.gridApiService.isUnCheck().subscribe(() => {
      this.gridConfiguration.api.deselectAll();
    });
    this.unSelectedCheckBox();
  }

  // noinspection JSMethodCanBeStatic
  public methodFromParent(cell) {
    return cell;
  }


  setAutoHeight() {
    setTimeout(() => {
      this.gridApi.setDomLayout('autoHeight');
      //(<HTMLElement>document.querySelector('#myGrid')).style.height = '';
    }, 200);

  }

  ngAfterViewInit() {
    this.fitToCoulmn();
    this.setAutoHeight();
  }

  onGridReady(params) {
    console.log(params, 'params');
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridConfiguration.api.setRowData(this.rowData);
    params.api.paginationGoToPage(0);
    this.fitToCoulmn();
  }

  fitToCoulmn() {
    setTimeout(() => {
      this.gridApi.sizeColumnsToFit();
    }, 200);
  }

  rowGroupOpened(params) {
    if (params.node.expanded) {
      params.api.forEachNode(function (node) {
        if (node.expanded && node.id !== params.node.id && node.uiLevel === params.node.uiLevel) {
          node.setExpanded(false);
        }
      });
    }
  }

  onPageSizeChanged(newPageSize: HTMLSelectElement) {
    const value = +(newPageSize.srcElement.value);
    this.gridApi.paginationSetPageSize(value);
    this.gridApi.sizeColumnsToFit();
  }


  GetcolumnDefs(vouName) {
    this.gridConfiguration = <GridOptions>{
      columnDefs: this.pendingApprovalsAgridService.getEntityColumnHeaderPropertyNames(vouName),
      postProcessPopup: function (params) {
        const ePopup = params.ePopup;
        ePopup.style.top = '14.9838px';
      },
      rowData: this.rowData,
      rowHeight: 40,
      headerHeight: 40,
      pagination: true,
      floatingFiltersHeight: 40,
      paginationPageSize: 20,
      enableRangeSelection: true,
      rowSelection: 'single',
      rowMultiSelectWithClick: true,
      animateRows: true,
      enableColResize: true,
      enableFilter: true,
      suppressContextMenu: true,
      enableSorting: true,
      // masterDetail: true,
      defaultColDef: {
        enableRowGroup: false,
        enableValue: true,
        suppressMovable: true,
        minWidth: 100,
        menuTabs: ['filterMenuTab', '', '']
      },
      context: {
        componentParent: this
      },
    };
  }
  createButton(buttonNames) {
    this.buttonName = buttonNames;
  }

  onRowSelected(params) {
    console.log(params, 'selectedRows');
    /* based on transactiontype create option */
    const isSelect = params.node.isSelected();
    const selectedRows = this.gridApi.getSelectedRows();
    console.log(selectedRows, 'selectedRows');
    this.currRowSelectionData = params.data;
    console.log(this.currRowSelectionData, 'currRowSelectionData');
    if (selectedRows.length) {
      this.showSnackbar = true;
      this.createButton([
        { id: '1', name: 'Approved', access: this.accessItem(262) },
        { id: '2', name: 'Rejected',access: this.accessItem(262) },
      ]);
    } else {
      this.showSnackbar = false;
    }
  }

  isApprovedOrReject(e) {
    console.log(this.currRowSelectionData.ReceiptNo, 'ReceiptNo');
    console.log(this.currRowSelectionData.PreparedByName, 'PreparedByName');
    const voucherNo = this.currRowSelectionData.ReceiptNo || this.currRowSelectionData.PaymentNo
      || this.currRowSelectionData.VoucherNo || this.currRowSelectionData.CreditNoteNo || this.currRowSelectionData.DebitNoteNo;
    console.log(voucherNo, 'voucherNo');
    if (e == '1') {
      this.showSnackbar = false;
      const initialState = {
        isApproved: true,
        voucherNo: voucherNo,
        voucherName: this.vouName,
        PreparedByName: this.currRowSelectionData.PreparedByName
      };
      this.bsModalRef = this.modalService.show(ApprovedRejectDailogComponent, {
        class: 'receipt-cancel-model',
        initialState,
        ignoreBackdropClick: true
      });
    }

    if (e == '2') {
      this.showSnackbar = false;
      const initialState = {
        isApproved: false,
        voucherNo: voucherNo,
        voucherName: this.vouName,
        PreparedByName: this.currRowSelectionData.PreparedByName
      };
      this.bsModalRef = this.modalService.show(ApprovedRejectDailogComponent, {
        class: 'receipt-cancel-model',
        initialState,
        ignoreBackdropClick: true
      });
    }

  }

  hideSnackBar() {
    this.unSelectCheckbox();
    this.showSnackbar = false;
  }
  unSelectCheckbox() {
    this.gridApiService.unCheck();
  }

  accessItem(functionid){
    return this.allowAccess.isAllowed(functionid)
  }

}


interface TextValuePair {
  id: number;
  value: string;
}





