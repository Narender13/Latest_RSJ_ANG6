
export class MatchUnMatch {
    value: string;
}

