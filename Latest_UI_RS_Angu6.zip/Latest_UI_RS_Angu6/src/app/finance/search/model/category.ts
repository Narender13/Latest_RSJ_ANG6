
export class CategoryType {
    id: number;
    item: string;
}

