import { NgModule } from '@angular/core';
import { SharedModule } from '../../shared/shared.module';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SearchRoutingModule } from './search-routing.module';

import { SearchResultsComponent } from './search-results/search-results.component';
import { ReceiptComponent } from './search-results/receipt/receipt.component';
import { EntityComponent } from './search-results/entity/entity.component';
import { ClaimComponent } from './search-results/claim/claim.component';
import { EndorsementnumberComponent } from './search-results/endorsement-number/endorsement-number.component';
import { QuotationnumberComponent } from './search-results/quotation-number/quotation-number.component';
import { PayeenameComponent } from './search-results/payee-name/payee-name.component';
import { ChequeComponent } from './search-results/cheque/cheque.component';
import { PolicyComponent } from './search-results/policy/policy.component';
import { PaymentComponent } from './search-results/payment/payment.component';
import { CreditnoteComponent } from './search-results/credit-note/credit-note.component';
import { JournalComponent } from './search-results/journal/journal.component';
import { TaxComponent } from './search-results/tax/tax.component';

import { SearchService } from './service/search.service';
import { ApprovalCodeComponent } from './search-results/approval-code/approval-code.component';
import { BaseSearchComponent } from './search-results/basesearch/basesearch.component';
import { NoresultsmsgComponent } from './search-results/noresultsmsg/noresultsmsg.component';
import { SettingsComponent } from './search-results/settings/settings.component';
import { AgGridModule } from 'ag-grid-angular';
import 'ag-grid-enterprise';
import { DatatableComponent } from 'src/app/shared/datatable/datatable.component';
import { CreateReceiptEntitiComponent } from 'src/app/finance/search/search-results/entity/create-receipt-entiti/create-receipt-entiti.component';
import { CreateReceiptEntitiRowSelectionComponent } from 'src/app/finance/search/search-results/entity/create-receipt-entiti-row-selection/create-receipt-entiti-row-selection.component';
import { CreateClaimReceiptComponent } from 'src/app/finance/search/search-results/claim/create-claim-receipt/create-claim-receipt.component';
import { CurrencyRendererComponent } from 'src/app/shared/datatable/services/currency-renderer.component';
import { CreatePaymentEntityComponent } from 'src/app/finance/search/search-results/entity/create-payment-entity/create-payment-entity.component';
import { CreatePaymentNewComponent } from './search-results/entity/create-payment-new/create-payment-new.component';
import { CreatePolicyReceiptComponent } from 'src/app/finance/search/search-results/policy/receipt/create-receipt.component';
import { CreateDebitNoteReceiptComponent } from './search-results/tax/receipt/create-receipt.component';
import { NgxCurrencyModule } from 'ngx-currency';
import { customCurrencyMaskConfig } from 'src/app/shared/utilites/helper';
import { CURRENCY_MASK_CONFIG } from 'ngx-currency/src/currency-mask.config';

@NgModule({
  imports: [
    SearchRoutingModule,
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
    NgxCurrencyModule.forRoot(customCurrencyMaskConfig),
    AgGridModule.withComponents([CurrencyRendererComponent]),

  ],
  exports: [],
  declarations: [
    SearchResultsComponent,
    ReceiptComponent,
    EntityComponent,
    ClaimComponent,
    EndorsementnumberComponent,
    QuotationnumberComponent,
    PayeenameComponent,
    ChequeComponent,
    PolicyComponent,
    PaymentComponent,
    CreditnoteComponent,
    JournalComponent,
    TaxComponent,
    ApprovalCodeComponent,
    BaseSearchComponent,
    NoresultsmsgComponent,
    SettingsComponent,
    DatatableComponent,
    CreateReceiptEntitiComponent,
    CreateReceiptEntitiRowSelectionComponent,
    CreateClaimReceiptComponent,
    CreatePaymentEntityComponent,
    CreatePaymentNewComponent,
    CreatePolicyReceiptComponent,
    CreateDebitNoteReceiptComponent
  ],
  entryComponents: [CreatePolicyReceiptComponent, CreateDebitNoteReceiptComponent,
    CreateReceiptEntitiComponent, CreatePaymentNewComponent, CreatePaymentEntityComponent,
    CreateReceiptEntitiRowSelectionComponent, CreateClaimReceiptComponent],
  providers: [
    SearchService,
    { provide: CURRENCY_MASK_CONFIG, useValue: customCurrencyMaskConfig }
  ],
})
export class SearchModule { }

