import { Injectable } from '@angular/core';
import { HttpParams, HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { map, catchError, tap, shareReplay, switchMap } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { CreditDebit } from 'src/app/finance/search/model/credit-debit';
import { RSAENDPOINTConstants } from 'src/app/core/constants/rsa.api.end.points';
import { handleErrorObservable } from 'src/app/shared/utilites/helper';
import { CustomHttpParams } from 'src/app/core/interceptor/loader-interceptor';
@Injectable()
export class SearchService {

    constructor(private http: HttpClient) { }

    getSearchResults(param): Observable<any> {
        console.log(param, 'params');
        // const httpHeaders = new HttpHeaders();
        // httpHeaders.append('Accept', 'application/json');
        // httpHeaders.append('Access-Control-Allow-Origin', '*');
        // httpHeaders.append('locCode', localStorage.getItem('locationcode'));
        let params = new HttpParams();
        if (param.categoryType == 4) {
            params = params.append('id', param.id);
            params = params.append('entityType', param.entityType);
            params = params.append('entityUnMatched', param.entityUnMatched);
        } else if (param.category == 8) {
            params = params.append('category', param.category);
            params = params.append('inputData', param.inputData);
            params = params.append('classCode', param.classCode);
        } else {
            params = params.append('category', param.category);
            params = params.append('inputData', param.inputData);
            params = params.append('categoryitem', param.categoryitem);
        }
        // ENTITYSEARCHRESULTS

        const urlstr = `${RSAENDPOINTConstants.SERVERAPI_SEARCHRESULT}`;

        const fakeUrl = `assets/json/${param.category}.json`;
        const under_writer_policy_url = `${RSAENDPOINTConstants.SERVER_API_UNDERWRITING_POLICY}`;
        const endorsement_url = `${RSAENDPOINTConstants.SERVER_API_ENDORSEMENT}`;
        const under_writer_quotation_url = `${RSAENDPOINTConstants.SERVER_API_UNDERWRITING_QUOTATION}`;
        const entity_url = `${RSAENDPOINTConstants.SEARCH_API_ADMIN_ENTITY}`;
        const entity_url_claim = `${RSAENDPOINTConstants.SEARCH_API_ADMIN_ENTITY_CLAIM}`;
        const claimurl = `${RSAENDPOINTConstants.SERVERAPI_SEARCHRESULTCLAIM}`;
        //const claimurl = `assets/json/4.json`;

        const category = param.category;
        let url = '';
        if (category == 1) {
            url = under_writer_policy_url;
            params = params.append('policyNo', param.inputData);
            params = params.append('classCode', param.classCode);
        } else if (category == 8) {
            url = claimurl;
        } else if (category == 9) {
            url = endorsement_url;
            params = params.append('policyNo', param.inputData);
            params = params.append('endNo', param.inputData);
        } else if (category == 10) {
            url = under_writer_quotation_url;
            params = params.append('quoNo', param.inputData);
            params = params.append('classCode', param.classCode);
        } else if (param.categoryType == 4) {
            if (param.entityUnMatched == 0) {
                console.log('cominghere unmatched');
                url = entity_url;
            }
            if (param.entityUnMatched == 1) {
                console.log('cominghere claim');
                url = entity_url_claim;
            }
        } else {
            url = urlstr;
        }
        console.log(params, 'paramsca');
        return this.http.get<any>(url, { params: params }).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getSearchResults')));
    }

    getCoulmnHeaderConfig(headerConfig): Observable<any> {
        return this.http.get<any>(headerConfig).pipe(
            map(res => res));
    }
    getCreditData(): Observable<CreditDebit[]> {
        return this.http.get<CreditDebit[]>(RSAENDPOINTConstants.CREDITJSON).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getCreditData')));
    }
    getPreviewReceipt(receipt: any) {
        let url: string = RSAENDPOINTConstants.GETRECEIPTPREVIEW + receipt;
        return this.http.get<CreditDebit[]>(url).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getPreviewData')));
    }
    getPreviewPayment(receipt: any) {
        let url: string = RSAENDPOINTConstants.GETRECEIPTPREVIEW + receipt;
        return this.http.get<CreditDebit[]>(url).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getPreviewData')));
    }
    // getPredictiveSearchList(param) {
    //     let url: string;
    //     let paramstrquo = 'quoNo=' + param.quoNo + '&classCode=' + param.classCode + '&locCode=' + param.locationcode;
    //     let paramstrpolicy = 'policyNo=' + param.policyNo + '&classCode=' + param.classCode + '&locCode=' + param.locationcode;
    //     if (param.category == 10)
    //         url = RSAENDPOINTConstants.GETQUOTATIONLIST + paramstrquo;
    //     else if (param.category == 1)
    //         url = RSAENDPOINTConstants.GETPOLICYLIST + paramstrpolicy;
    //     console.log("URL>>>>>>", url)
    //     return this.http.get(url, { params: new CustomHttpParams(true) }).pipe(
    //         map(res => res),
    //         catchError(handleErrorObservable<any>('getPredictiveSearchList')));
    // }

    getPredictiveSearchList(param) {
        let url: string;
        const paramstrquo = 'quoNo=' + param.quoNo + '&classCode=' + param.classCode;
        const paramstrpolicy = 'policyNo=' + param.policyNo + '&classCode=' + param.classCode;
        const paramstrclaim = 'claimNo=' + param.claimNo + '&classCode=' + param.classCode;
        const paramstrDN = 'debitNoteNo=' + param.taxInvoiceNo;
        const paramstrPayeeName = 'searchName=' + param.payeeName;
        const paramstrChequeNo = 'chequeNo=' + param.chequeNo;
        const paramtrCreditNoteNo = 'creditNoteNo=' + param.creditNoteNo;
        const paramtrApprovalNo = 'approvalNo=' + param.approvalNo;

        if (param.category == 10) {
            url = RSAENDPOINTConstants.GETQUOTATIONLIST + paramstrquo;
        } else if (param.category == 1) {
            url = RSAENDPOINTConstants.GETPOLICYLIST + paramstrpolicy;
        } else if (param.category == 8) {
            url = RSAENDPOINTConstants.GETCLAIMNUMBERLIST + paramstrclaim;
        } else if (param.category == 6) {
            url = RSAENDPOINTConstants.GETTAXINVOICENUMBERLIST + paramstrDN;
        } else if (param.category == 11) {
            url = RSAENDPOINTConstants.GETPAYEENAMELIST + paramstrPayeeName;
        }
        if (param.category == 12) {
            url = RSAENDPOINTConstants.GETCHEQUENUMBERLIST + paramstrChequeNo;
        } else if (param.category == 5) {
            url = RSAENDPOINTConstants.GETCREDITNOTENUMBERLIST + paramtrCreditNoteNo;
        } else if (param.category == 13) {
            url = RSAENDPOINTConstants.GETAPPROVALCODELIST + paramtrApprovalNo;
        }
        return this.http.get(url, { params: new CustomHttpParams(false) }).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getPredictiveSearchList')));
    }

    checkSearchResult(param): Observable<any> {
        console.log(param, 'params');
        const httpHeaders = new HttpHeaders();
        httpHeaders.append('Accept', 'application/json');
        httpHeaders.append('Access-Control-Allow-Origin', '*');
        let params = new HttpParams();
        params = params.append('category', param.category);
        params = params.append('inputData', param.inputData);
        params = params.append('categoryitem', param.categoryitem);
        // if 404 not - record doen't exists defect 1126
        const url = `${RSAENDPOINTConstants.SERVERAPI_SEARCHRESULT}`;
        return this.http.get<any>(url, { params: params, headers: httpHeaders }).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getPredictiveSearchList')));
    }
}
