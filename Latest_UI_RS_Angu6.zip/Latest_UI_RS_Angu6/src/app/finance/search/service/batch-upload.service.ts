import { Injectable } from '@angular/core';
import { Subject, Observable, BehaviorSubject } from 'rxjs';
import { map, catchError, tap } from 'rxjs/operators';
import { handleErrorObservable } from 'src/app/shared/utilites/helper';
import { RSAENDPOINTConstants } from 'src/app/core/constants/rsa.api.end.points';
import { HttpParams, HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';

@Injectable({
    providedIn: 'root'
})
export class BatchUploadService {

    httpheaders = new HttpHeaders(
        {
            'Content-Disposition': 'form-data',
            'enctype': 'multipart/form-data',
           // 'Content-Type': ''
        });

    constructor(private http: HttpClient) { }

    uploadBatchFile(file: File, param): Observable<any> {
        console.log(param.acc + '----------acc');
        console.log(param.gl + '----------gl');
        const formdata: FormData = new FormData();
        formdata.append('filename', file, file.name);
        formdata.append('GLCode', param.gl);
        formdata.append('AccountCode', param.acc);
        formdata.append('Batch ', 'true');
        return this.http.post<any>(RSAENDPOINTConstants.BULKUPLOAD, formdata, {
            headers: this.httpheaders
        }).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('uploadBatchFile')));
    }
    uploadJvBatchFile(file: File, param: any): Observable<any> {
        const formdata: FormData = new FormData();
        formdata.append('filename', file, file.name);
        formdata.append('VoucherDate', param.VoucherDate);
        formdata.append('Type', param.Type);
        formdata.append('AccountCode  ', param.TotallingAccCode);
        formdata.append('GlCode ', param.GLCode);
        console.log(param);
        console.log(file);
        return this.http.post<any>(RSAENDPOINTConstants.IMPORTJV, formdata, {
            headers: this.httpheaders
        }).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('uploadJvBatchFile')));
    }


    validateUnmatchedRecord(param: any) {
        console.log(param);
        return this.http.post<any>(RSAENDPOINTConstants.VALIDATEUNMAtCHED, param, {
            reportProgress: true
        }).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('validateUnmatchedRecord')));

    }
}
