import { Component, OnInit, Input, ViewChild, ElementRef, AfterViewInit, QueryList } from '@angular/core';
import { BaseSearchComponent } from '../basesearch/basesearch.component';
import { NoresultsmsgComponent } from '../noresultsmsg/noresultsmsg.component'
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { BsModalService } from 'ngx-bootstrap/modal';
import { CreatePolicyReceiptComponent } from 'src/app/finance/search/search-results/policy/receipt/create-receipt.component';
import { SharedService } from 'src/app/finance/services/shared.service';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { Router } from '@angular/router';
import { CreateDebitnotesComponent } from 'src/app/finance/debitnotes/create-debitnotes/create-debitnotes.component';
import { CreateCreditnotesComponent } from 'src/app/finance/creditnotes/create-creditnotes/create-creditnotes.component';
import { CreatePaymentComponent } from 'src/app/finance/payments/create-payment/create-payment.component';
import { UserAutherizationService } from 'src/app/core/authorization/userauth.service';

@Component({
  selector: 'rsa-quotationnumber',
  templateUrl: './quotation-number.component.html',
  styleUrls: ['./quotation-number.component.scss']
})
export class QuotationnumberComponent extends BaseSearchComponent implements OnInit {
  @Input() category;
  @Input('quotationnumber') quotationnumber: any;
  @Input() resultdata;
  @Input() classcode;
  @Input() lobtitle;
  glnumber: string;
  idnumber: number;
  name: string;
  totalAmount = 0;
  totalCount = 0;
  showSnackBar = false;
  bsModalRef: BsModalRef;
  customerName;
  selectedItems = [];
  selectedReceiptItems = [];
  isQuotation:boolean;

  constructor(private allowAccess: UserAutherizationService, private modalService: BsModalService, private sharedService: SharedService, private alertService: AlertService) { super() }

  ngOnInit() {
    this.isQuotation=this.accessItem(237);
    this.customerName = this.resultdata[0].CustomerName;
    super.ngOnInit();
    this.createButton([
      { id: '11', name: 'Receipt',access: this.accessItem(238) },
      //{ id: '12', name: 'Tax Invoice No' },
      //{ id: '13', name: 'Credit Note' },
      { id: '14', name: 'Payment',access: this.accessItem(239) }
    ]);

  }
  accessItem(functionid){
    return this.allowAccess.isAllowed(functionid)
  }
  selectReceiptData(index, ev) {

    this.selectedItems = [];
    this.totalAmount = 0;
    this.totalCount = 0;
    this.resultdata[0].map((ele, index) => {
      ele.RefTranTypeName=ele.RefTranType;
      ele.CostCenter=ele.CostCenterName;
      if (this.selectedReceiptItems[index]) {
        this.selectedItems.push(ele);
        this.totalCount = this.totalCount + 1;
        this.totalAmount = this.totalAmount + ((ele.Amount != null && ele.Amount != undefined) ? parseFloat(ele.Amount) : 0)
      }
    });
    this.showSnackBar = (this.selectedItems.length > 0) ? true : false;
  }

  buttonHandler(e) {
    let flagDisplay = false;
    if (this.totalAmount > 0 && e === '14') {
      this.alertService.warn(RSAMSGConstants.MSGPAYMENTLESSZERO);
      return false;
    }
    else if (this.totalAmount < 0 && e === '11') {
      this.alertService.warn(RSAMSGConstants.CREDITEXCEEDMSG);
      return false;
    }
    if (this.totalAmount < 0 && e === '14') {
      const initialState = {
        backdrop: true,
        ignoreBackdropClick: false,
        selectedRowEntitiDataTable: this.selectedItems,
        customerName: this.customerName,
        totalAmount: this.totalAmount,
        ondemandFlag: false,
      };
      this.showSnackBar = false;
      this.bsModalRef = this.modalService.show(CreatePaymentComponent, {
        class: 'create-modal-dailog',
        initialState
      });
    }
    else if (e === '11' && this.totalAmount > 0) {
      flagDisplay = true;
      this.bsModalRef = this.modalService.show(CreatePolicyReceiptComponent, {
        class: 'create-modal-dailog', backdrop: true,
        ignoreBackdropClick: true
      });
    }
    else if (e === '12') {
      flagDisplay = true;
      this.bsModalRef = this.modalService.show(CreateDebitnotesComponent, {
        class: 'create-modal-dailog', backdrop: true,
        ignoreBackdropClick: false
      });
    }

    else if (e === '13') {
      flagDisplay = true;
      this.bsModalRef = this.modalService.show(CreateCreditnotesComponent, {
        class: 'create-modal-dailog', backdrop: true,
        ignoreBackdropClick: false
      });
    }

    if (e === '12' && e === '13')
      this.bsModalRef.content.ondemandFlag = false;

    if (flagDisplay) {
      this.showSnackBar = false;
      this.bsModalRef.content.totalamount = this.totalAmount;
      this.bsModalRef.content.totalcount = this.totalCount;
      this.bsModalRef.content.selectedRowEntitiDataTable = this.selectedItems;
    }


  }



  hideSnackBar(e) {
    this.showSnackBar = false;
    this.selectedReceiptItems = [];
  }

}
