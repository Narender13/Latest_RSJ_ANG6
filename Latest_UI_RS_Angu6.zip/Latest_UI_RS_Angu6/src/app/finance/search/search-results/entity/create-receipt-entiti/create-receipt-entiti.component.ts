

import { Component, OnInit, ViewChild, TemplateRef, ElementRef } from '@angular/core';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { FormBuilder, FormControl, FormGroup, FormArray, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { BsModalService } from 'ngx-bootstrap/modal';
import { Router } from '@angular/router';
import { ConfirmationDialogComponent } from 'src/app/shared/custom-model/custom-model.component';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';
import { ReceiptpreviewComponent } from 'src/app/finance/preview/uae/receiptpreview/receiptpreview.component';
import { MasterDataService } from 'src/app/finance/services/finance.masterdata.service';
import { CreateService } from 'src/app/finance/receipts/create-receipt/service/create.service';
import { BatchUploadService } from 'src/app/finance/search/service/batch-upload.service';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { TabsetComponent } from 'ngx-bootstrap/tabs';
import { Customvalidators } from 'src/app/shared/validators/customvalidators';
import { SharedService } from 'src/app/finance/services/shared.service';
import { ExcelService } from 'src/app/finance/search/service/excel.service';
import { UtilityClass } from 'src/app/shared/utilites/helper-class';
import { NUMBER_FORMAT_REGEXP } from '@angular/common/src/i18n/format_number';
import { AmtValidator } from 'src/app/shared/utilites/helper';
import { SearchService } from '../../../service/search.service';
import { RSAConstants } from 'src/app/core/constants/rsaconstant';

@Component({
  selector: 'rsa-create-receipt-entiti',
  templateUrl: './create-receipt-entiti.component.html',
  styleUrls: ['./create-receipt-entiti.component.scss']
})
export class CreateReceiptEntitiComponent implements OnInit {
  title = 'Receipt';
  level: any = 1;
  amount: number;
  currency = 'AED';
  collapsetoheader: boolean;
  createReceiptEntitiForm: FormGroup;
  unmatchedForm: FormGroup;
  BankName: any;
  results: any;
  errorMsg: string;
  isMatched = true;
  count;
  value;
  unmatchedRecords = [];
  fileUploadForm: FormGroup;
  matchedRecords = [];
  isUploadUnmatched;
  pjctindicator: any = [];
  department: any = [];
  placeholder: any;
  glaccount: any = [];
  totallingacc: any = [];
  transactiontype: any = [];
  chequeTypeData: any = [];
  private masterdata: any = [];
  private masterdata2: any = [];
  payeedataBankName: any = [];
  receiverdataBankName: any = [];
  clonedReceipts: FormGroup;
  branchdata = [];
  glerrorcount = 0;
  costcentredata = [];
  paymentname = 'CASH';
  errorpayee: boolean;
  errordetail: boolean;
  errorbankcode: boolean;
  errorchequedate: boolean;
  errorinstrumentdate: boolean;
  errorchequeno: boolean;
  errorinstrumentrefno: boolean;
  errorterminalID: boolean;
  // errorexpirydate: boolean;
  errorreceiptdate: boolean;
  errorChequeTypeCheque: boolean;
  errorchequetype: boolean;
  usersReq = true;
  payeeBankDefaultSelect;
  users: any = [];
  arrUser: any = [];
  terminals = [];
  bulkuploadData = [];
  slided;
  returnValue;
  isBatch = false;
  ifUploadSuccess = true;
  isMatchedOrUnmatched = true;
  RcptMode = 2;
  totalAmount = 0;
  dtltotallingacc = [];
  approverusers: string;
  displayApprover = false;
  symbol: string;
  minDateRd;
  maxDateRd;
  currentDate;
  customerName: string;
  currentTbIndex = 0;
  /* added for caching dropdown master data */
  cachedReceiverBankData: any;
  cachedTotAcc: any;
  cachedPayeeBankData: any;
  cachedBranchdata: any;
  cachedCostcentredata: any;
  cachedDtlTot: any;
  cachedGL: any;
  glnumber: any;
  idnumber: any;
  previewFlag = false;
  prevReceipt: any;
  previewDataDtl: any = [];
  newMatchedRecordForm: FormGroup;
  unmatchedDetails = [];
  matchedDetails = [];
  selectedRow: Number;
  isMatchedOrUnmatchedDownload = false;
  totalMatched;
  totalUnMatched;
  brokerCustomerAmount = 0;
  entitydata: any;
  defaultGLCode: any;
  defaultGLCodeDesc: any;
  defaultTotallingAccCode: any;
  validFileContent: boolean;
  BmhId: any;
  IsDebit = true;
  BmdSrNo: any[] = [];
  accountingCode = '1';
  accountingStartDate: any;
  accountingEndDate: any;
  receiptAccountingDate: any;
  isUAE;
  amountZeroCheck;
  amountLimitCheck;
  editReceiptFromPrevious = false;
  defaultUserId;
  defaultTerminalId;

  @ViewChild('tabset') tabset: TabsetComponent;
  @ViewChild('batchTotalAmt') batchTotalAmount: ElementRef;

  constructor(public bsModalRef: BsModalRef,
    private fb: FormBuilder,
    private masterDataService: MasterDataService,
    private createservice: CreateService,
    private modalService: BsModalService,
    private batchUploadService: BatchUploadService,
    private alertService: AlertService,
    private sharedService: SharedService,
    private excelService: ExcelService,
    private router: Router) {
    this.minDateRd = new Date();
    this.maxDateRd = new Date();
    this.minDateRd.setDate(this.minDateRd.getDate() - 0);
    this.maxDateRd.setDate(this.maxDateRd.getDate() - 0);
    this.receiptAccountingDate = new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy');
    this.currentDate = new Date();
  }

  ngOnInit() {
    
    this.getAllMasterData(1110);
    this.getAllMasterData2(true);
    this.createEntitiForm(this.RcptMode);
    this.getTotalAmount();
    this.getPayeeBankData(true);
    this.getTotallingData(true);
    this.getBankData(true);
    this.fieldStatusChanges();
    this.getAllInstrumentTypes();
    this.GetAccountingDates();
    this.isUAE = localStorage.getItem('country') == '3' ? true : false;
    this.symbol = (localStorage.getItem('symbol'));
    setTimeout(() => {
      this.customerName = this.bsModalRef.content.CustomerName;
      this.setPayeName();
    }, 0);
    this.sharedService.getMessage().subscribe(val => {

      if (val == "previous") {
        this.previewFlag = false;
        this.editReceiptFromPrevious = true;
      } else if (val == "close") {
        this.modalService.hide(1);
      }
      console.log(val.id);
      this.prevReceipt = val.id;
      this.BmhId = val.bmhId;
      console.log(val.data);
      if (val.data) {
        this.BmdSrNo = val.data.map((item) => {
          item.BmdSrNo = item.BmdSrNo == null ? 0 : item.BmdSrNo;
          return item.BmdSrNo;
        });
      }
      console.log(`ReceiptNo ${this.prevReceipt} BmhId ${this.BmhId} BmdSrNo ${this.BmdSrNo}`)

      this.previewDataDtl = val.data;
      if (this.previewDataDtl != null || this.previewDataDtl != undefined) {
        this.doPatchRefFields();
      }

    });
    setTimeout(() => {
      this.defaultGLCode = this.entitydata[0].GLCode;
      this.defaultGLCodeDesc = this.entitydata[0].GLCodeDesc;
      this.defaultTotallingAccCode = this.entitydata[0].TotallingAccCode;
    }, 10);

  }

  doPatchRefFields() {
    const formarray = (<FormArray>this.createReceiptEntitiForm.controls['ReceiptDetails']);
    formarray.controls.map((item, index) => {
      item.get('RefTransactionID').setValue(this.previewDataDtl[index].RefTransactionID);
      item.get('RefTransactionSerialNo').setValue(this.previewDataDtl[index].RefTransactionSerialNo);
    });
  }
  clearerrors() {
    this.errorpayee = false;
    this.errordetail = false;
    this.errorbankcode = false;
    this.errorchequedate = false;
    this.errorchequeno = false;
    this.errorinstrumentrefno = false;
    this.errorterminalID = false;
    // this.errorexpirydate = false;
    this.errorreceiptdate = false;
    this.errorinstrumentdate = false;
    this.errorchequetype = false;
  }
  get voucherDetailsLength() {
    return this.createReceiptEntitiForm.controls.ReceiptDetails['controls'].length > 1;
  }
  getTotallingDetailData(index, initFlag) {
    let ccentre = this.getFromFormArrayControlVal('CostCenterCode', index);

    const param = 'paymentMode=' + this.paymentname +
      '&costCenter=' + ccentre;

    this.masterDataService.getTotallingDetailData(param).subscribe(
      dataReturn => {
        this.dtltotallingacc[index] = dataReturn;
        let totcode = this.dtltotallingacc[index][0].TotAccCode;
        if (!initFlag)
          this.setFormArrayCTRLDefaultValue("TotallingAccCode", index, this.defaultTotallingAccCode);
        if (initFlag) {
          this.cachedDtlTot = dataReturn;
          this.setFormArrayCTRLDefaultValue("TotallingAccCode", index, this.defaultTotallingAccCode);
        }
        this.getGLData(index, initFlag, this.defaultGLCode);
      },
      errorRturn => this.errorMsg = errorRturn
    );
  }
  getSum() {
    this.totalAmount = 0;
    const ctrl = <FormArray>this.createReceiptEntitiForm.controls['ReceiptDetails'];
    ctrl.controls.forEach(val => {
      const amt = (val.get('Amount').value == null || isNaN(val.get('Amount').value) ||
        val.get('Amount').value == '') ? 0 : val.get('Amount').value;
      this.totalAmount += parseFloat(amt);
    });
    this.totalAmount = (isNaN(this.totalAmount)) ? 0 : this.totalAmount;
  }
  fieldStatusChanges() {
    this.clearerrors();
    this.cshpayeename.statusChanges.subscribe(
      status => {
        this.errorpayee = (status === 'INVALID');
        console.log(this.errorpayee, 'his.errorpayee');

      }
    );
    this.cshdetails.statusChanges.subscribe(
      status => {
        this.errordetail = (status === 'INVALID');
      }
    );
    if (this.RcptMode == 2) {
      if (this.payeebankcode != null && this.payeebankcode != undefined) {
        this.payeebankcode.statusChanges.subscribe(
          status => {
            this.errorbankcode = (status == 'INVALID');
          }
        );
      }
      if (this.instrumentdate != null && this.instrumentdate != undefined) {
        this.instrumentdate.statusChanges.subscribe(
          status => {
            this.errorinstrumentdate = (status == 'INVALID');
          }
        );
      }
    }
    if (this.chequedate != null && this.chequedate !== undefined) {
      this.chequedate.statusChanges.subscribe(
        status => {
          this.errorchequedate = (status === 'INVALID');
        }
      );
    }
    if (this.chequeno != null && this.chequeno !== undefined) {
      this.chequeno.statusChanges.subscribe(
        status => {
          this.errorchequeno = (status === 'INVALID');
        }
      );
    }
    if (this.receiptdate != null && this.receiptdate !== undefined) {
      this.receiptdate.statusChanges.subscribe(
        status => {
          this.errorreceiptdate = (status === 'INVALID');
        }
      );
    }
    if (this.terminalid != null && this.terminalid !== undefined) {
      this.terminalid.statusChanges.subscribe(
        status => {
          this.errorterminalID = (status === 'INVALID');
        }
      );
    }
    if (this.chequeType != null && this.chequeType != undefined) {
      this.chequeType.statusChanges.subscribe(
        status => {
          this.errorchequetype = (status == 'INVALID');
        }
      );
    }
    if (this.RcptMode == 5) {
      if (this.instrumentrefno != null && this.instrumentrefno !== undefined) {
        this.instrumentrefno.statusChanges.subscribe(
          status => {
            this.errorinstrumentrefno = (status === 'INVALID');
          }
        );
      }
    }

    // if (this.expirydate != null && this.expirydate !== undefined) {
    //   this.expirydate.statusChanges.subscribe(
    //     status => {
    //       this.errorexpirydate = (status === 'INVALID');
    //     }
    //   );
    // }

  }

  setPayeName() {
    this.createReceiptEntitiForm.controls['PayeeName'].setValue(this.customerName);
    this.clearerrors();
  }

  goNext() {
    // this.errorpayee = this.cshpayeename.invalid;
    this.errordetail = this.cshdetails.invalid;
    if (this.isBatch && (!this.totalAmount || this.totalAmount <= 0)) {
      return false;
    }

    if (this.RcptMode == 2) {
      if (this.payeebankcode != null && this.payeebankcode != undefined) {
        this.errorbankcode = this.payeebankcode.invalid;

      }
      if (this.instrumentdate != null && this.instrumentdate !== undefined) {
        this.errorinstrumentdate = this.instrumentdate.invalid;
      }
    }
    if (this.receiptdate != null && this.receiptdate !== undefined) {
      this.errorreceiptdate = this.receiptdate.invalid;
    }

    if (this.chequedate != null && this.chequedate !== undefined) {
      this.errorchequedate = this.chequedate.invalid;
    }

    if (this.chequeno != null && this.chequeno !== undefined) {
      this.errorchequeno = this.chequeno.invalid;
    }
    if (this.chequeType != null && this.chequeType !== undefined) {
      this.errorchequetype = this.chequeType.invalid;
    }

    // if (this.instrumentrefno != null && this.instrumentrefno !== undefined) {
    //   this.errorinstrumentrefno = this.instrumentrefno.invalid;
    // }
    if (this.RcptMode == 5) {
      if (this.instrumentrefno != null && this.instrumentrefno !== undefined) {
        this.errorinstrumentrefno = this.instrumentrefno.invalid;
      }
    }
    if (this.RcptMode == 8) {
      if (this.terminalid != null && this.terminalid !== undefined) {
        this.errorterminalID = this.terminalid.invalid;
      }
    }

    // if (this.expirydate != null && this.expirydate !== undefined) {
    //   this.errorexpirydate = this.expirydate.invalid;
    // }

    if (!this.errorpayee && !this.errordetail && !this.errorchequedate && !this.errorreceiptdate && !this.errorchequeno
      && !this.errorinstrumentrefno
      && !this.errorterminalID && !this.errorbankcode && !this.errorinstrumentdate && !this.errorchequetype) {
      (<FormArray>this.createReceiptEntitiForm.controls['ReceiptDetails']).controls[0].get('Description').setValue(this.cshdetails.value);
      this.getTotallingDetailData(0, true);
      if (this.isBatch && !this.totalAmount) {
        return false;
      }
      this.level = 2;
    }
  }
  onDateValueChange(ev) {
    this.createReceiptEntitiForm.controls['ChequeDateFld'].setValue(new DatePipe('en-US').transform(new Date(ev), 'dd/MM/yyyy'));

  }
  // setting current Tab Index to activiate tab
  setcurrentTbIndex(tab) {
    switch (tab) {
      case 'Cash':
        this.currentTbIndex = 2;
        break;
      case 'Cheque':
        this.currentTbIndex = 0;
        break;
      case 'Credit Card':
        this.currentTbIndex = 1;
        break;
      case 'Bank Transfer':
        this.currentTbIndex = 3;
    }
  }
  // Displaying the  confirmation alert on tab click
  confirmTabSwitch(event) {
    console.log(event.target.tagName);
    const parentElement = event.target.parentElement;
    const target = event.target.parentElement.text;
    if (event.target.tagName === 'SPAN' && !parentElement.classList.contains('active') && parentElement.classList.contains('nav-link')) {
      if (this.createReceiptEntitiForm.dirty) {
        // --- showing popup only you have added or changed something
        this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
        this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
        // Will move the content to RSAMSGConstants once approved // 
        this.bsModalRef.content.modelBodyContent = RSAMSGConstants.PAYMENTMODECHANGEMSG;
        this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
        this.bsModalRef.content.actionBtn = RSAMSGConstants.BTNPROCEED;
        this.bsModalRef.content.valueChange.subscribe((data) => {
          console.log(data);
          // changing the currentTbIndex if user proceed
          if (data = RSAMSGConstants.BTNPROCEED) {
            console.log(this.currentTbIndex);
            setTimeout(() => {
              this.setcurrentTbIndex(target);
            }, 0);
            setTimeout(() => {
              this.tabset.tabs[this.currentTbIndex].active = true;
              if (!this.isBatch) {
                /* Resetting the total amount if greater than  zero whiling changing payment method*/
                // defect 5766-No need to reset review screen and total amount
                if (!this.editReceiptFromPrevious) {
                  this.totalAmount = this.totalAmount > 0 ? 0 : this.totalAmount;
                }
              }
            }, 1);
          }
        });
      } else {
        setTimeout(() => {
          this.setcurrentTbIndex(target);
        }, 0);
        setTimeout(() => {
          this.tabset.tabs[this.currentTbIndex].active = true;
        }, 1);

      }

    }
  }
  clearGLCode(indx, val) {

    this.setFormArrayCTRLDefaultValue('GLCode', indx, '');
    this.setFormArrayCTRLDefaultValue('GLCodeDesc', indx, '');

  }
  changeCostcenter(index, flagInit) {
    let loccode = this.getFromFormArrayControlVal('LocationCode', index);
    this.masterDataService.getCostCenters().subscribe(
      dataReturn => {
        this.costcentredata[index] = dataReturn;
        if (loccode == "20")
          this.setFormArrayCTRLDefaultValue('CostCenterCode', index, 11);
        this.getTotallingDetailData(index, false);
      },
      errorRturn => this.errorMsg = errorRturn
    );
  }

  setReceiptMode(val, paymentname, ev) {
    if (!ev.tabset) return; // fix for tab key resetting all values
    this.createReceiptEntitiForm.controls['ReceiptMode'].setValue(val);
    this.RcptMode = val;
    this.paymentname = paymentname;
    if (!this.editReceiptFromPrevious) {
      this.createEntitiForm(this.RcptMode);
    }
    if (this.editReceiptFromPrevious) {
      const control = <FormArray>this.createReceiptEntitiForm.controls['ReceiptDetails'];
      this.createEntitiForm(this.RcptMode);
      this.createReceiptEntitiForm.controls['ReceiptDetails'] = control;
    }
    this.GetAccountingDates();
    this.receiverdataBankName = this.cachedReceiverBankData;
    this.totallingacc = this.cachedTotAcc;
    this.payeedataBankName = this.cachedPayeeBankData;
    this.createReceiptEntitiForm.controls['TotallingAccCode'].setValue(1110);
    this.createReceiptEntitiForm.controls['RecevierBankCode'].setValue(14);
    // if (this.RcptMode == 1) {
    //   this.createReceiptEntitiForm.controls['TotallingAccCode'].setValue(1210);
    //   this.getBankData(false);
    // }
    // else {
    //   this.createReceiptEntitiForm.controls['TotallingAccCode'].setValue(1110);
    //   this.createReceiptEntitiForm.controls['RecevierBankCode'].setValue(14);
    // }
    if (this.RcptMode == 5) {
      this.createReceiptEntitiForm.controls['PayeeBankCode'].setValue('');
    }
    this.setPayeName();
    this.setdefaultHeaderData();
    this.fieldStatusChanges();
  }
  getPayeeBankData(initFlag) {
    this.masterDataService.getPayeeBankData().subscribe(
      dataReturn => {
        this.payeedataBankName = dataReturn;
        if (this.RcptMode == 2 || this.RcptMode == 5) {
          this.createReceiptEntitiForm.controls['PayeeBankCode'].setValue('');
        }
        this.clearerrors();
        if (initFlag)
          this.cachedPayeeBankData = dataReturn;
      },
      errorRturn => this.errorMsg = errorRturn
    );

  }
  getBankData(flagInit) {
    let ccentre = this.getFormCtrlValue('CostCenterCode');
    let totcode = this.getFormCtrlValue('TotallingAccCode');

    let param = 'totallingAccCode=' + totcode +
      '&costCenter=' + ccentre;
    this.masterDataService.getBankData(param).subscribe(
      dataReturn => {
        this.receiverdataBankName = dataReturn;
        if (!flagInit)
          this.createReceiptEntitiForm.controls['RecevierBankCode'].setValue(this.receiverdataBankName[0].BankCode);
        if (flagInit)
          this.cachedReceiverBankData = dataReturn;
      },
      errorRturn => this.errorMsg = errorRturn
    );
  }
  setBankData(val) {
    this.createReceiptEntitiForm.controls['RecevierBankCode'].setValue('');
    this.getBankData(false);
  }
  setdefaultHeaderData() {
    if(this.terminals!=null && this.terminals.length>0){
      const terminal =this.terminals.filter( x=>x.UserID == localStorage.getItem(RSAConstants.LoggedInUserId));
      this.defaultUserId= terminal!=null&& terminal[0]!=null? terminal[0].UserID:this.terminals[0].UserID;
      this.defaultTerminalId=terminal!=null&& terminal[0]!=null? terminal[0].TerminalID:this.terminals[0].TerminalID;
      }
    if (this.RcptMode == 8) {
      this.createReceiptEntitiForm.controls['TerminalUserID'].setValue(this.defaultUserId ||this.terminals[0].UserID);
      this.createReceiptEntitiForm.controls['TerminalID'].setValue(this.defaultTerminalId || this.terminals[0].TerminalID);
    }
    //this.createReceiptEntitiForm.controls['TerminalID'].setValue('');
    if (this.RcptMode == 2 || this.RcptMode == 5)
      this.createReceiptEntitiForm.controls['PayeeBankCode'].setValue('');

  }
  /* get all instrument types */
  getAllInstrumentTypes() {
    this.masterDataService.getInstrumentTypes().subscribe((data) => {
      this.chequeTypeData = data.filter(c => c.Related_Code == 8);
    },
      errorRturn => this.errorMsg = errorRturn
    );
  }
  getTotallingData(initflag) {
    let ccentre = this.getFormCtrlValue('CostCenterCode');
    const param = 'paymentMode=' + this.paymentname +
      '&costCenter=' + ccentre;

    this.masterDataService.getTotallingData(param).subscribe(
      dataReturn => {
        this.totallingacc = dataReturn;
        if (initflag)
          this.cachedTotAcc = dataReturn;
      },
      errorRturn => this.errorMsg = errorRturn
    );
  }
  setFormArrayCTRLDefaultValue(contrlname, index, val) {
    (<FormArray>this.createReceiptEntitiForm.controls['ReceiptDetails']).controls[index].get(contrlname).setValue(val);
  }
  getFromFormArrayControlVal(contrlname, index) {
    return (<FormArray>this.createReceiptEntitiForm.controls['ReceiptDetails']).controls[index].get(contrlname).value;
  }
  getFormCtrlValue(contrlName) {
    console.log(this.createReceiptEntitiForm.controls, 'this.createReceiptEntitiForm.controls');
    return this.createReceiptEntitiForm.controls[contrlName].value;
  }
  getGLData(index, initFlag, val) {
    let ccentre = this.getFromFormArrayControlVal('CostCenterCode', index);
    let totcode = (initFlag) ? this.getFromFormArrayControlVal('TotallingAccCode', index) : val;

    let param = 'totallingAccCode=' + totcode +
      '&CostCenterCode=' + ccentre;
    console.log('param-GL', param);

    this.masterDataService.getGLData(param).subscribe(
      dataReturn => {
        this.glaccount[index] = dataReturn;
        if (!initFlag) {
          this.setFormArrayCTRLDefaultValue("GLCode", index, this.glaccount[index][0].GLCode);
          this.setFormArrayCTRLDefaultValue("GLCodeDesc", index, this.glaccount[index][0].GLEngDescription);
        } else {
          this.cachedGL = dataReturn;
          this.setFormArrayCTRLDefaultValue("GLCode", index, this.defaultGLCode);
          this.setFormArrayCTRLDefaultValue("GLCodeDesc", index, this.defaultGLCodeDesc);
        }
      },
      errorRturn => this.errorMsg = errorRturn
    );
    if (this.level == 2) {
      (<FormArray>this.createReceiptEntitiForm.controls['ReceiptDetails']).controls.map(item => {
        // item.get('Amount').clearValidators();
        // item.get('GLCode').clearValidators();
        item.get('Amount').updateValueAndValidity();
        item.get('GLCode').updateValueAndValidity();
      });
    }
  }

  getTotalAmount() {
    this.totalAmount = 0;
    const ctrl = <FormArray>this.createReceiptEntitiForm.controls['ReceiptDetails'];
    ctrl.controls.forEach(val => {
      const amt = (val.get('Amount').value == null || isNaN(val.get('Amount').value ||
        val.get('Amount').value === '')) ? 0 : val.get('Amount').value;
      this.totalAmount += parseFloat(amt);
    });

    this.totalAmount = (isNaN(this.totalAmount)) ? 0 : this.totalAmount;
  }



  getAllMasterData(totalacc): void {

    this.masterDataService.getAllMasterData(totalacc).subscribe(
      dataReturn => {
        this.masterdata = dataReturn;
        console.log(dataReturn, ' : master data');
        //this.payeedataBankName = this.masterdata.LoadPayeeBanks;
        this.terminals = this.masterdata.Terminals;
        this.pjctindicator = this.masterdata.ProjectIndicators;
        this.department = this.masterdata.Departments;
        this.transactiontype = this.masterdata.TransactionType;

      },
      errorRturn => this.errorMsg = errorRturn
    );
  }
  getAllMasterData2(initFlag): void {
    this.masterDataService.getAllMasterData2().subscribe(
      dataReturn => {
        this.masterdata2 = dataReturn;
        console.log(dataReturn, ' : master data');
        //this.glaccount = this.masterdata2.GLCodes;
        this.users = this.masterdata2.Users;
        // console.log(this.users, 'USERS');
        this.branchdata = this.masterdata2.Locations;
        this.costcentredata[0] = this.masterdata2.CostCenter;
        if (initFlag) {
          this.cachedBranchdata = this.masterdata2.Locations;
          this.cachedCostcentredata = this.masterdata2.CostCenter;
        }
      },
      errorRturn => this.errorMsg = errorRturn
    );
  }

  onUserChange(userid: string, isChecked: boolean, username: string) {
    const userFormArray = <FormArray>this.createReceiptEntitiForm.controls.Approvers;
    if (isChecked) {
      userFormArray.push(new FormControl(userid));
      this.arrUser.push(username);
    } else {
      const index = userFormArray.controls.findIndex(x => x.value == userid);
      userFormArray.removeAt(index);
      this.arrUser = this.arrUser.filter(v => v !== username);
    }
    this.approverusers = this.arrUser.join();
  }

  createEntitiForm(param): void {
    this.createReceiptEntitiForm = null;
    this.createReceiptEntitiForm = this.fb.group({
      ReceiptDate: [new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy'), Validators.required],
      //Amount: [''],
      ReceiptMode: [this.RcptMode],
      PrintDate: [new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy')],
      ReceiptType: [0],
      PreparedBy: [1],
      ModifiedBy: ['1'],
      Approvers: this.fb.array([]),
      CustomerID: [],
      TerminalID: [],
      TerminalUserID: [],
      TerminalUserName: [],
      CountryCode: [1],
      LocationCode: [localStorage.getItem('locationcode')],
      RegionCode: [localStorage.getItem('regioncode')],
      ReprintNo: [],
      CostCenterCode: [localStorage.getItem('costcentre')],
      ArabicDescription: [],
      TotallingAccCode: [1110],
      RecevierBankCode: [14],
      ChequeDateFld: [''],
      PayeeBankCode: ['', Validators.required],
      PayeeName: [this.customerName, Validators.required],
      EnglishDescription: ['', Validators.required],
      ChequeDate: [new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy'), Validators.required],
      ReceiptDetails: this.fb.array([this.createNewcreateReceiptEntitiFormGroup()])
    });
    switch (param) {
      case 1:
        //this.createReceiptEntitiForm.addControl('Amount', new FormControl(''));
        break;
      case 2:
        this.createReceiptEntitiForm.addControl('ChequeNo', new FormControl('', Validators.required));
        this.createReceiptEntitiForm.controls['ChequeNo'].updateValueAndValidity();
        this.createReceiptEntitiForm.addControl('InstrumentDate', new FormControl('', Validators.required));
        this.createReceiptEntitiForm.controls['InstrumentDate'].updateValueAndValidity();
        this.createReceiptEntitiForm.addControl('PayeeBankCode', new FormControl('', Validators.required));
        this.createReceiptEntitiForm.controls['PayeeBankCode'].updateValueAndValidity();
        this.createReceiptEntitiForm.addControl('PayeeBankName', new FormControl('', Validators.required));
        this.createReceiptEntitiForm.controls['PayeeBankName'].updateValueAndValidity();
        break;
      case 8:
        this.createReceiptEntitiForm.addControl('ChequeNo', new FormControl('', [Validators.required, Customvalidators.creditcardValidator]));
        this.createReceiptEntitiForm.controls['ChequeNo'].updateValueAndValidity();
        this.createReceiptEntitiForm.addControl('InstrumentRefNo', new FormControl(''));
        this.createReceiptEntitiForm.addControl('TransactionNo', new FormControl(''));
        //this.createReceiptEntitiForm.controls['InstrumentRefNo'].updateValueAndValidity();
        this.createReceiptEntitiForm.addControl('ChequeDate', new FormControl('', Validators.required));
        this.createReceiptEntitiForm.controls['ChequeDate'].updateValueAndValidity();
        this.createReceiptEntitiForm.addControl('TerminalUserID', new FormControl('', Validators.required));
        this.createReceiptEntitiForm.controls['TerminalUserID'].updateValueAndValidity();
        //this.createReceiptEntitiForm.addControl('TerminalID', new FormControl('', Validators.required));
        //this.createReceiptEntitiForm.controls['TerminalID'].updateValueAndValidity();
        this.createReceiptEntitiForm.addControl('ChequeType', new FormControl('', Validators.required));
        this.createReceiptEntitiForm.controls['ChequeType'].updateValueAndValidity();
        this.createReceiptEntitiForm.addControl('ExpiryDate', new FormControl('', Validators.required));
        this.createReceiptEntitiForm.controls['ExpiryDate'].updateValueAndValidity();
        break;
      case 5:
        this.createReceiptEntitiForm.addControl('PayeeBankCode', new FormControl(''));
        this.createReceiptEntitiForm.controls['PayeeBankCode'].updateValueAndValidity();
        this.createReceiptEntitiForm.addControl('PayeeBankName', new FormControl('', Validators.required));
        this.createReceiptEntitiForm.controls['PayeeBankName'].updateValueAndValidity();
        this.createReceiptEntitiForm.addControl('ChequeDate', new FormControl('', Validators.required));
        this.createReceiptEntitiForm.controls['ChequeDate'].updateValueAndValidity();
        // defect 3080- make required for bank transfer
        this.createReceiptEntitiForm.addControl('InstrumentRefNo', new FormControl('', [Validators.required]));
        this.createReceiptEntitiForm.controls['InstrumentRefNo'].updateValueAndValidity();

        break;
    }
  }
  createNewcreateReceiptEntitiFormGroup(): FormGroup {
    return this.fb.group({
      CounterPartyRef: [],
      LocationCode: [localStorage.getItem('locationcode')],
      LocationDesc: ['Dubai'],
      CountryCode: [1],
      CostCenterCode: [localStorage.getItem('costcentre')],
      Description: [],
      Amount: ['', Validators.required],
      RefTransactionID: [],
      RefTransactionType: [3],
      // RefTranTypeDesc: ['Receipt'],
      IsCreditEntry: [true],
      PolicyID: [],
      PolicyNumber: [],
      ModifiedBy: ['1'],
      ReceiptDate: [],
      // ProjectIndicator: [],
      AnalysisCode: [],
      DepartmentCode: [],
      Department: [],
      RefTransactionSerialNo: [],
      GLCode: [4, Validators.required],
      GLCodeDesc: ['4-HSBC BANK MIDDLE EAST - Deira', Validators.required],
      //GLCodeDesc: [],
      RegionCode: localStorage.getItem('regioncode'),
      TotallingAccCode: [1110],
      // TotallingAccCodeDesc: ['1110 BANK CURRENT A/C'],
      ClassCode: [],
      PolicyYear: [],
      PolicyType: [],
      SerialNo: [0],
      Endt_ID: []
    });
  }

  setHiddenValue(ev, iter, key, setKey) {
    (<FormArray>this.createReceiptEntitiForm.controls['ReceiptDetails']).controls[iter].get(key).setValue(ev.item[setKey]);
    let glAccntId = parseInt(ev.item[setKey]);
      let selGLAccnt = this.glaccount[iter].filter(data => data.GLCode === glAccntId)[0]; 
      //if(selAccount.length > 0){
        this.setReqValFormArrayControl('AnalysisCode', iter, selGLAccnt.ProjectIndicator ? true : false);
        this.setReqValFormArrayControl('DepartmentName', iter, selGLAccnt.Department ? true : false);
      //}
  }

  setReqValFormArrayControl(contrlname, index, isRequired) {
    //isRequired = true;
    let selCtrl = (<FormArray>this.createReceiptEntitiForm.controls['ReceiptDetails']).controls[index].get(contrlname);
    
    if(contrlname === 'AnalysisCode'){
      this.createReceiptEntitiForm.value.ReceiptDetails[index].isPIRequired = isRequired;
    }
    if(contrlname === 'DepartmentName'){
      this.createReceiptEntitiForm.value.ReceiptDetails[index].isDepRequired = isRequired;
    }
    if(isRequired){
      if(selCtrl.value === null || selCtrl.value === ''){
      selCtrl.setValidators([Validators.required]);
      selCtrl.markAsTouched();
      selCtrl.markAsDirty();
      selCtrl.setErrors({ 'incorrect': true });
      }
      (<FormArray>this.createReceiptEntitiForm.controls['ReceiptDetails']).controls[index].updateValueAndValidity();
    }
    else{
      selCtrl.clearValidators();
    }
  }

  changeDepartment(event, index){
    this.createReceiptEntitiForm.value.ReceiptDetails[index].isDepRequired = false;
  }

  changeProjectIndicator(event, index){
    this.createReceiptEntitiForm.value.ReceiptDetails[index].isPIRequired = false;
  }

  changeNewDepartment(event, index){
    this.newMatchedRecordForm.value.isDepRequired = false;
  }

  changeNewProjectIndicator(event, index){
    this.newMatchedRecordForm.value.isPIRequired = false;
  }

  setCreditEntry(ev, iter, key, data) {
    console.log(iter, 'key');
    const actualData = Number(data.controls['Amount'].value);
    // const curdata = -(data.controls['Amount'].value);
    // data.controls['Amount'].patchValue(curdata);

    if (actualData === 0 || actualData === undefined) {
      this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
      this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
      this.bsModalRef.content.modelBodyContent = RSAMSGConstants.EMPTYAMOUNTCHECK;
      this.bsModalRef.content.cancelBtn = RSAMSGConstants.OKTEXT;
      ev.target.checked = true;

    }
    (<FormArray>this.createReceiptEntitiForm.controls['ReceiptDetails']).controls[iter].get(key).setValue(ev.target.checked);
    this.getActualAmountSum();
    if (this.totalAmount < 0) {
      ev.target.checked = true;
      this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
      this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
      this.bsModalRef.content.modelBodyContent = RSAMSGConstants.CREDITEXCEEDMSG;
      this.bsModalRef.content.cancelBtn = RSAMSGConstants.OKTEXT;
      // data.controls['Amount'].patchValue(-curdata);
      (<FormArray>this.createReceiptEntitiForm.controls['ReceiptDetails']).controls[iter].get(key).setValue(ev.target.checked);

    }
    this.getActualAmountSum();
  }

  setTerminalCode(ev, key, setKey) {
    console.log(ev, 'ev');
    this.createReceiptEntitiForm.controls[key].setValue(ev.item[setKey]);
  }
  setBankCode(ev, iter, key) {
    this.createReceiptEntitiForm.controls[key].setValue(ev.item.BankCode);
  }
  get cshpayeename() { return this.createReceiptEntitiForm.get('PayeeName'); }
  get cshdetails() { return this.createReceiptEntitiForm.get('EnglishDescription'); }
  get payeebankcode() { return this.createReceiptEntitiForm.get('PayeeBankCode'); }
  get chequeType() { return this.createReceiptEntitiForm.get('ChequeType'); }
  get chequedate() { return this.createReceiptEntitiForm.get('ChequeDate'); }
  get instrumentrefno() { return this.createReceiptEntitiForm.get('InstrumentRefNo'); }
  get terminalid() { return this.createReceiptEntitiForm.get('TerminalUserID'); }
  get expirydate() { return this.createReceiptEntitiForm.get('ExpiryDate'); }
  get chequeno() { return this.createReceiptEntitiForm.get('ChequeNo'); }
  get receiptdate() { return this.createReceiptEntitiForm.get('ReceiptDate'); }
  get instrumentdate() { return this.createReceiptEntitiForm.get('InstrumentDate'); }

  addReceipt(len) {
    const control = <FormArray>this.createReceiptEntitiForm.controls['ReceiptDetails'];
    const CurrentAmount = (<FormArray>this.createReceiptEntitiForm.controls['ReceiptDetails']).controls[len - 1].get('Amount').value;
    if (CurrentAmount > 0) {
      control.push(this.createNewcreateReceiptEntitiFormGroup());
      this.dtltotallingacc[len] = this.cachedDtlTot;
      this.glaccount[len] = this.cachedGL;
      this.costcentredata[len] = this.cachedCostcentredata;
      this.setFormArrayCTRLDefaultValue('TotallingAccCode', len, this.defaultTotallingAccCode);
      this.setFormArrayCTRLDefaultValue('GLCode', len, this.defaultGLCode);
      this.setFormArrayCTRLDefaultValue('GLCodeDesc', len, this.defaultGLCodeDesc);

    } else {
      this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
      this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
      this.bsModalRef.content.modelBodyContent = RSAMSGConstants.AMOUNTVALIDATIONMSG;
      this.bsModalRef.content.cancelBtn = RSAMSGConstants.OKTEXT;
      return false;
    }
  }

  reSetForm(param) {
    this.totalAmount = 0;
    /*set default value here and reset */
    if (param == 1) {
      const arrayFields = ['EnglishDescription', 'ChequeNo', 'PayeeBankCode',
        'PayeeBankName', 'ExpiryDate', 'InstrumentRefNo', 'TerminalUserID', 'PayeeName'];
      this.createReceiptEntitiForm.controls['LocationCode'].reset(localStorage.getItem('locationcode'));
      this.createReceiptEntitiForm.controls['CostCenterCode'].reset(localStorage.getItem('costcentre'));
      this.createReceiptEntitiForm.controls['RegionCode'].reset(localStorage.getItem('regioncode'));
      this.createReceiptEntitiForm.controls['TotallingAccCode'].reset(1110);
      this.getBankData(true);
      this.createReceiptEntitiForm.controls['RecevierBankCode'].reset(14);
      this.createReceiptEntitiForm.controls['EnglishDescription'].reset();
      arrayFields.forEach((val) => {
        if (this.createReceiptEntitiForm.controls[val] != null && this.createReceiptEntitiForm.controls[val] != undefined) {
          this.createReceiptEntitiForm.controls[val].reset();
        }
      });
      if (this.RcptMode == 2) {
        this.createReceiptEntitiForm.controls['InstrumentDate'].setValue('');
      }
      if (this.RcptMode == 5) {
        this.createReceiptEntitiForm.controls['PayeeBankCode'].setValue('');
        this.createReceiptEntitiForm.controls['ChequeDate'].setValue('');
      }
      if (this.RcptMode == 8) {
        this.createReceiptEntitiForm.controls['TerminalUserID'].setValue(this.defaultUserId ||this.terminals[0].UserID);
        this.createReceiptEntitiForm.controls['TerminalID'].setValue(this.defaultTerminalId || this.terminals[0].TerminalID);
      }
      this.setPayeName();
      this.clearerrors();
      if (this.isBatch) {
        this.batchTotalAmount.nativeElement.value = '';
      }
    } else if (param === 2) {
      this.createReceiptEntitiForm.controls['ReceiptDetails'].reset();
      (<FormArray>this.createReceiptEntitiForm.controls['ReceiptDetails']).controls.map(item => {
        item.get('LocationCode').setValue(localStorage.getItem('locationcode'));
        item.get('CostCenterCode').setValue(localStorage.getItem('costcentre'));
        item.get('RegionCode').setValue(localStorage.getItem('regioncode'));
        item.get('RefTransactionType').setValue(3);
        item.get('TotallingAccCode').setValue(1110);
        item.get('GLCode').setValue(4);
        item.get('GLCodeDesc').setValue('4-HSBC BANK MIDDLE EAST - Deira');
      });
      this.getActualAmountSum();
    }
    this.GetAccountingDates();
  }

  deleteReceipt(index: number, itemrow) {
    console.log(itemrow, 'itemrow');
    if (index >= 1) {
      this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
      this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
      this.bsModalRef.content.modelBodyContent = RSAMSGConstants.DELETEMSGRECEIPTL;
      this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
      this.bsModalRef.content.actionBtn = RSAMSGConstants.BTNPROCEED;
      this.bsModalRef.content.valueChange.subscribe((data) => {
        if (data = RSAMSGConstants.BTNPROCEED) {
          const control = <FormArray>this.createReceiptEntitiForm.controls['ReceiptDetails'];
          control.removeAt(index);
        }
      });
    } else {
      this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
      this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
      this.bsModalRef.content.modelBodyContent = RSAMSGConstants.CANTDELETEFIRSTROW;
      this.bsModalRef.content.cancelBtn = RSAMSGConstants.OKTEXT;
    }
  }

  get receiptRows() { return <FormArray>this.createReceiptEntitiForm.get('ReceiptDetails'); }

  checkIsformDirty() {
    if (this.createReceiptEntitiForm.dirty || this.createReceiptEntitiForm.touched) {
      console.log('cmg here');
      this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
      this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
      this.bsModalRef.content.modelBodyContent = RSAMSGConstants.DIRTYFLAGMSGRECIPT;
      this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
      this.bsModalRef.content.actionBtn = RSAMSGConstants.BTNPROCEED;
      this.bsModalRef.content.valueChange.subscribe((data) => {
        if (data = 'Proceed') {
          this.modalService.hide(1);
        }
      });

    } else {
      this.modalService.hide(1);
    }
  }

  validateDetailInfo() {
    this.glerrorcount = 0;
    this.amountZeroCheck = 0;
    this.amountLimitCheck = 0;
    (<FormArray>this.createReceiptEntitiForm.controls['ReceiptDetails']).controls.map(item => {
      item.get('Amount').updateValueAndValidity();
      item.get('Amount').markAsTouched();
      item.get('GLCode').updateValueAndValidity();
      item.get('GLCode').markAsTouched();

      if (item.get('GLCode').value == null || item.get('GLCode').value == undefined || item.get('GLCode').value == "") {
        this.glerrorcount = this.glerrorcount + 1;
      }
      if (item.get('Amount').value == null || item.get('Amount').value == 0 || item.get('Amount').value == undefined || item.get('Amount').value == "") {
        this.glerrorcount = this.glerrorcount + 1;
        this.amountZeroCheck = this.amountZeroCheck + 1;
      }

      if (item.get('Amount').value > 999999999.99) {
        this.glerrorcount = this.glerrorcount + 1;
        this.amountLimitCheck = this.amountLimitCheck + 1;
        return false;
      }
    });
  }

  submitForm(bsModalRef, receiptno) {
    if (this.isBatch && this.isMatchedOrUnmatched) {
      this.fileUploadForm.get('fileContent').markAsTouched();
      console.log(this.fileUploadForm.valid);
      if (!this.fileUploadForm.valid) {
        return false;
      }
      if (Math.abs(this.totalMatched) > Math.abs(this.totalAmount)) {
        this.alertService.error('Transactions Amount exceeds the Receipt Amount !!');
        return false;
      } else if (Math.abs(this.totalMatched) !== Math.abs(this.totalAmount)) {
        this.alertService.warn(RSAMSGConstants.AMOUNTNOTMATCHED);
        return false;
      } else if (Number(this.totalMatched) < 0) {
        this.alertService.warn(RSAMSGConstants.CREDITEXCEEDMSG);
        return false;
      } else {
        const formval = this.createReceiptEntitiForm.value;
        formval['Batch'] = true;
        formval['GLCode'] = this.defaultGLCode;
        formval['Filename'] = this.matchedDetails[0].Filename;
        formval['ChequeDate'] = formval['ChequeDateFld'];
        formval['TotallingAccCode'] = this.getFormCtrlValue('TotallingAccCode');
        formval['ReceiptDetails'] = this.matchedDetails;
        // formval['TotallingAccCode'] = this.defaultTotallingAccCode;

        console.log(formval['ReceiptDetails']);
        if (this.prevReceipt == null || this.prevReceipt == undefined) {
          this.prevReceipt = '0';
        }
        if (this.BmhId == null || this.BmhId == undefined) {
          this.BmhId = '0';
        }
        if (this.BmdSrNo == null || this.BmdSrNo == undefined || this.BmdSrNo.length == 0) {
          this.BmdSrNo = [];
        }
        formval['ReceiptNo'] = this.prevReceipt;
        formval['BmhId'] = this.BmhId;
        formval.ReceiptDetails.forEach((item, index) => {
          item.BmdSrNo = this.BmdSrNo[index] || '0';
        });
        //send serialNo in update
        if (this.prevReceipt > 0 && (this.previewDataDtl != null || this.previewDataDtl != undefined)) {
          formval.ReceiptDetails.forEach((element, index) => {
            if (index < this.previewDataDtl.length) {
              element.SerialNo = this.previewDataDtl[index].SerialNo;
            }
          });
        }

        console.log(formval, '>>>>>>>>>.matched preview>>>>>>>>>>');

        this.createservice.createReceipt(JSON.stringify(formval)).subscribe(
          dataReturn => {
            this.returnValue = dataReturn;
            console.log(this.returnValue, 'value');
            this.returnValue['approverlist'] = this.approverusers;
            this.returnValue['ondemand'] = true;
            let newAmountval=0;
            newAmountval=(this.totalAmount*-1);
            const initialState = {
              'brokerCustomerAmount': this.brokerCustomerAmount || 0,
              'isBatch': true,
              'totalReceiptAmount': newAmountval || 0,
              // 'backdrop': 'static',
              //'keyboard': false
            };
            this.previewFlag = true;
            // tslint:disable-next-line:max-line-length
            this.bsModalRef = this.modalService.show(ReceiptpreviewComponent, { class: 'preview-modal-dailog', initialState, backdrop: 'static', keyboard: false });
            this.bsModalRef.content.data = this.returnValue;
            this.bsModalRef.content.totalAmount = this.totalAmount;
            this.bsModalRef.content.isBatch = true;
          },
          errorRturn => {
            this.errorMsg = errorRturn;
          }
        );
      }

    } else {
      // const chequeDate = this.createReceiptEntitiForm.get('ChequeDate').value;
      // this.createReceiptEntitiForm.controls['ChequeDate']
      //   .setValue(getShortDate(new Date(chequeDate)));
      this.validateDetailInfo();
      if (this.amountZeroCheck > 0) {
        this.alertService.warn(RSAMSGConstants.AMOUNTZEROCHECK);
        return false;
      }
      if (this.amountLimitCheck > 0) {
        this.alertService.warn(RSAMSGConstants.AMOUNTEXCEEDMSG);
        return false;
      }
      if (this.glerrorcount > 0) {
        return false;
      }
      this.usersReq = (this.approverusers !== undefined && this.approverusers !== '' &&
        this.approverusers.length > 0);
      const formval = this.createReceiptEntitiForm.value;
      formval["ChequeDate"] = formval["ChequeDateFld"];
      console.log(formval['ReceiptDetails']);
      console.log(formval, 'value');
      if (this.totalAmount > 0) {
        if (!(localStorage.getItem('country') == '3')) {
          if (this.totalAmount > 99999 && !this.usersReq) {
            return false;
          }
        }
        if (this.prevReceipt == null || this.prevReceipt == undefined) {
          this.prevReceipt = 0;
        }
        formval["ReceiptNo"] = this.prevReceipt;
        //send serialNo in update
        if (this.prevReceipt > 0 && (this.previewDataDtl != null || this.previewDataDtl !== undefined)) {
          (<FormArray>this.createReceiptEntitiForm.controls['ReceiptDetails']).value.forEach((element, index) => {
            if (index < this.previewDataDtl.length) {
              element.SerialNo = this.previewDataDtl[index].SerialNo;
            }
          });
        }
        this.preSubmission();
        this.createservice.createReceipt(JSON.stringify(this.clonedReceipts.value)).subscribe(
          dataReturn => {
            this.returnValue = dataReturn;
            console.log(this.returnValue, 'value');
            this.returnValue['approverlist'] = this.approverusers;
            this.returnValue['ondemand'] = true;
            //this.bsModalRef.hide();
            this.previewFlag = true;
            this.bsModalRef = this.modalService.show(ReceiptpreviewComponent, { class: 'preview-modal-dailog', backdrop: 'static', keyboard: false });
            this.bsModalRef.content.data = this.returnValue;
            this.bsModalRef.content.totalAmount = this.totalAmount;
          },
          errorRturn => {
            this.errorMsg = errorRturn;
          }
        );
      }
      if (this.totalAmount <= 0) {
        this.alertService.warn(RSAMSGConstants.AMOUNTTEXTREQ);
      }
    }
  }

  goPrevious() {
    this.level = 1;
  }

  collapseToheader() {
    this.collapsetoheader = !this.collapsetoheader;
    if (this.collapsetoheader) {
      this.sharedService.sendMessage('collapse');
    } else {
      this.sharedService.sendMessage('not-collapse');
    }
  }


  checkSingleOrbatch(e) {
    this.isBatch = !this.isBatch;
    this.totalAmount = 0;
    if (this.isBatch) {
      this.buildFileUploadForm();
      /*Removing ReceiptDetails formarray items if t and come from
     periviuos toggle from Single to Batch - Narender - 15/02/2019 Defect ID 5307  */
      const formarray = (<FormArray>this.createReceiptEntitiForm.controls['ReceiptDetails']);
      this.clearFormArray(formarray);
      formarray.push(this.createNewcreateReceiptEntitiFormGroup());
    }
  }

  clearFormArray(formArray: FormArray) {
    while (formArray.length !== 0) {
      formArray.removeAt(0);
    }
  }
  get checkRecieptCommision(): any {
    let bulkdata = {};
    this.bulkuploadData.map((item) => {
      if (item.Message !== null) {
        bulkdata = {
          commisionValid: false,
          voucherNo: item.VoucherNo,
          policyNo: item.PolicyNumber
        };
        return false;
      }
    });
    return bulkdata;
  }
  buildnewMatchedRecordForm() {
    //let tranDate = localStorage.getItem('tranAccntMnthStrtDate') ? new Date(localStorage.getItem('tranAccntMnthStrtDate')) : new Date();
    this.newMatchedRecordForm = this.fb.group({
      CounterPartyRef: [],
      Amount: ['', [Validators.required, AmtValidator]],
      VoucherNo: ['0'],
      VoucherDate: [new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy')],
      PolicyID: [],
      GLCode: [this.defaultGLCode],
      Commision: [0],
      NetAmount: [],
      PolicyNumber: [null],
      PolicyYear: [],
      DepartmentCode: [],
      DepartmentName: [],
      Description: [''],
      LocationCode: [localStorage.getItem('locationcode')],
      ClassCode: [0],
      CityCode: [],
      PolicyType: [0],
      CountryCode: [1],
      RegionCode: localStorage.getItem('regioncode'),
      CostCenterCode: localStorage.getItem('costcentre'),
      TotallingAccCode: [this.defaultTotallingAccCode],
      GLCodeDesc: [this.defaultGLCodeDesc],
      RefTransactionID: [0],
      RefTransactionType: [3],
      TransactionType: ['RECEIPT'],
      RefTransactionSerialNo: [0],
      ModifiedBy: [],
      SerialNo: [0],
      Filename: [''],
      Cheque_Number: [],
      Cheque_Date: [],
      Customer_Id: [],
      BmdChequeNo: [],
      BmdChequeDate: [new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy')],
      Endt_ID: [0],
      ClaimID: [0],
      newAddedRow: [true]
    });
  }
  calculateNetAmount() {
    const Amt = (this.newMatchedRecordForm.get('Amount').value == null) || (isNaN(this.newMatchedRecordForm.get('Amount').value)) ||
      (this.newMatchedRecordForm.get('Amount').value == '') ? 0 : this.newMatchedRecordForm.get('Amount').value;
    const Comm = (this.newMatchedRecordForm.get('Commision').value == null) || (isNaN(this.newMatchedRecordForm.get('Commision').value)) ||
      (this.newMatchedRecordForm.get('Commision').value == '') ? 0 : this.newMatchedRecordForm.get('Commision').value;
    return Number(Amt) + Number(Comm);

  }
  buildUnmachedForm() {
    this.unmatchedForm = this.fb.group({
      unmatchedList: this.fb.array([
        this.fb.group({
          Amount: [],
          VoucherNo: [],
          VoucherDate: [],
          PolicyID: [],
          GLCode: [this.defaultGLCode],
          Commision: [],
          NetAmount: [],
          PolicyNumber: [],
          PolicyYear: [],
          DepartmentCode: [],
          DepartmentName: [],
          Description: [],
          LocationCode: [localStorage.getItem('locationcode')],
          ClassCode: [],
          CityCode: [],
          PolicyType: [],
          CountryCode: [1],
          RegionCode: localStorage.getItem('regioncode'),
          CostCenterCode: localStorage.getItem('costcentre'),
          TotallingAccCode: this.defaultTotallingAccCode,
          GLCodeDesc: this.defaultGLCodeDesc,
          RefTransactionID: [],
          RefTransactionType: [3],
          TransactionType: ['RECEIPT'],
          RefTransactionSerialNo: [],
          ModifiedBy: [],
          SerialNo: [],
          Filename: [],
          Cheque_Number: [],
          Cheque_Date: [],
          Customer_Id: [],
          BmdChequeNo: [],
          BmdChequeDate: [new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy')],
          Endt_ID: [],
          ClaimID: [],
          // Aaded new formControlName to make row readonly if coming from selection rows
          newAddedRow: [false]
        }),

      ])
    });
  }

  clearXlsFile(e: any) {
    e.target.value = '';
  }
  uploadXlsFile(e) {
    if (e.target.files && e.target.files.length) {
      if (e.target.files[0].name.indexOf('.xlsx') === -1) {
        this.alertService.warn(`Please upload a valid Excel file.`);
        return false;
      } else {
        if (e.target.files[0].name.length > 50) {
          this.alertService.warn(`File name cannot exceed 50 characters.`);
          return false;
        }

      }
    }
    if (e.target.files && e.target.files.length) {
      const selectedFiles = e.target.files;
      console.log(selectedFiles.item(0), 'selectedFiles.item(0)');
      // e.target.value = '';
      this.batchUploadService.uploadBatchFile(selectedFiles.item(0),
        { 'gl': this.defaultGLCode, 'acc': this.defaultTotallingAccCode }).subscribe((data) => {
          this.bulkuploadData = data;
          if (Array.isArray(this.bulkuploadData) && this.bulkuploadData.length) {
            if (this.checkRecieptCommision.commisionValid == false) {
              this.alertService.warn(`Amount and Commission is blank for Voucher No : ${this.checkRecieptCommision.voucherNo}
              and PolicyNo : ${this.checkRecieptCommision.policyNo}!!`);
              return false;
            }
            console.log(data, 'Data from API');
            this.ifUploadSuccess = false;
            this.buildUnmachedForm();
            this.buildnewMatchedRecordForm();
            this.unmatchedRecords = data.filter(item => item.Matched === false) || [];
            this.matchedRecords = data.filter(item => item.Matched !== false) || [];
            console.log(this.unmatchedRecords, 'unMatched Records');
            console.log(this.matchedRecords, 'Matched Records');
            this.setMatchedUnmatched(this.matchedRecords, 'matched');
            this.setMatchedUnmatched(this.unmatchedRecords, 'unmatched');
          } else {
            this.alertService.error('Invalid data from API');

          }
        });
    }
  }

  buildFileUploadForm() {
    this.fileUploadForm = this.fb.group({
      fileContent: ['', Validators.required],
    });
  }


  setMatchedUnmatched(data: any[], matched) {
    if (Array.isArray(data) && data.length) {
      if (matched === 'matched') {
        this.matchedDetails = [];
      } else {
        this.unmatchedDetails = [];

      }
      let receiptDetails = {};
      for (const item of data) {
        receiptDetails = {
          Amount: item.GrossAmount || item.Amount || 0,
          VoucherNo: item.VoucherNo,
          VoucherDate: item.VoucherDate || item.VoucherDateString,
          PolicyID: item.PolicyID || '',
          GLCode: this.defaultGLCode,
          Commision: item.Commision || 0,
          NetAmount: item.NetAmount || Number(item.GrossAmount || item.Amount) + Number(item.Commision),
          PolicyNumber: item.PolicyNumber,
          PolicyYear: item.Policy_Year || '',
          DepartmentCode: '',
          DepartmentName: '',
          Description: item.Description,
          LocationCode: localStorage.getItem('locationcode'),
          ClassCode: item.ClassCode,
          CityCode: item.Cty_Code || null,
          PolicyType: item.Policy_Type || item.PolicyType,
          CountryCode: item.Cty_Code || 1,
          RegionCode: localStorage.getItem('regioncode'),
          CostCenterCode: localStorage.getItem('costcentre'),
          TotallingAccCode: !item.newAddedRow ? this.defaultTotallingAccCode : item.TotallingAccCodes,
          GLCodeDesc: !item.newAddedRow ? this.defaultGLCodeDesc : item.GLCodeDesc,
          RefTransactionID: item.Ref_Tran_Id || '',
          RefTransactionType: item.TransactionTypeId || item.Ref_Tran_Type || item.RefTransactionType,
          TransactionType: item.TransactionType || '',
          RefTransactionSerialNo: item.SerialNo,
          ModifiedBy: item.ModifyBy || '',
          Filename: item.Filename || '',
          Cheque_Number: item.Cheque_Number || null,
          Cheque_Date: item.Cheque_Date || null,
          Customer_Id: item.Customer_Id || null,
          BmdChequeNo: item.BmdChequeNo || null,
          BmdChequeDate: new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy'),
          Endt_ID: item.EndtId,
          ClaimID: item.Claim_Id,
          newAddedRow: item.newAddedRow || false
        };
        if (matched === 'matched') {
          this.totalMatched = 0;
          this.matchedDetails.push(receiptDetails);
          this.totalMatched = this.getMatchedUnmatchedAmtsum(this.matchedDetails);
        } else {
          this.totalUnMatched = 0;
          this.unmatchedDetails.push(receiptDetails);
          this.totalUnMatched = this.getMatchedUnmatchedAmtsum(this.unmatchedDetails);

        }
      }
    }
  }

  exportAsXlsx(): void {
    const unmatchdata = this.unmatchedForm.controls.unmatchedList.value.map((item) => {
      return {
        TransactionType: item.RefTransactionType,
        VoucherNo: item.VoucherNo,
        VoucherDate: item.VoucherDate,
        SNo: item.RefTransactionSerialNo,
        PolicyNo: item.PolicyNumber,
        Gross: item.Amount,
        Comm: item.Commision,
        classcode: item.ClassCode,
      };

    });
    if (unmatchdata.length) {
      this.excelService.exportAsExcelFile(unmatchdata, 'Unmatched');
      this.isUploadUnmatched = true;
    } else {
      this.alertService.warn('No record found');
    }
  }

  checkMatchedOrUnmatched(e) {
    this.isMatchedOrUnmatched = !this.isMatchedOrUnmatched;
    if (!this.isMatchedOrUnmatched) {
      // this.setMatchedUnmatched(this.unmatchedRecords, 'umatched');
      console.log(this.unmatchedRecords);
      console.log(this.unmatchedDetails);
      const list = this.unmatchedDetails.map((item) => {
        return this.fb.group({
          Amount: [item.Amount],
          VoucherNo: [item.VoucherNo],
          VoucherDate: [item.VoucherDate],
          PolicyID: [item.PolicyID],
          GLCode: [item.GLCode],
          Commision: [item.Commision],
          NetAmount: [Number(item.Amount) + Number(item.Commision)],
          PolicyNumber: [item.PolicyNumber],
          PolicyYear: [item.PolicyYear],
          DepartmentCode: [item.DepartmentCode],
          DepartmentName: [item.DepartmentName],
          Description: [item.Description],
          LocationCode: localStorage.getItem('locationcode'),
          ClassCode: [item.ClassCode],
          CityCode: [item.Cty_Code],
          PolicyType: [item.PolicyType],
          CountryCode: [item.CountryCode],
          RegionCode: [item.RegionCode],
          CostCenterCode: [item.CostCenterCode],
          TotallingAccCode: [item.TotallingAccCode],
          GLCodeDesc: this.defaultGLCodeDesc,
          RefTransactionID: [item.RefTransactionID],
          RefTransactionType: [item.RefTransactionType],
          TransactionType: [item.TransactionType],
          RefTransactionSerialNo: [item.RefTransactionSerialNo],
          ModifiedBy: [item.ModifiedBy],
          SerialNo: [item.RefTransactionSerialNo],
          Filename: [item.Filename],
          Cheque_Number: [item.Cheque_Number],
          Cheque_Date: [item.Cheque_Date],
          Customer_Id: [item.Customer_Id],
          BmdChequeNo: [item.BmdChequeNo],
          BmdChequeDate: [item.BmdChequeDate],
          Endt_ID: item.Endt_ID,
          ClaimID: item.ClaimID,
          newAddedRow: [item.newAddedRow]

        });
      });
      const arrayList = this.fb.array(list);
      this.unmatchedForm.setControl('unmatchedList', arrayList);

    }
    // this.isMatched = !this.isMatched;
  }

  setClickedRow(e, index) {
    if (e.srcElement.checked) {
      this.selectedRow = index;
    } else {
      this.selectedRow = undefined;
    }
  }
  deleteMatchedRecord(index, row) {
    this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
    this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
    this.bsModalRef.content.modelBodyContent = RSAMSGConstants.DELETEMSGRECEIPTL;
    this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
    this.bsModalRef.content.actionBtn = RSAMSGConstants.BTNPROCEED;
    this.bsModalRef.content.valueChange.subscribe((data) => {
      if (data = 'Proceed') {
        console.log(index);
        this.matchedDetails.splice(index, 1);
        this.matchedRecords.splice(index, 1);
        this.bulkuploadData.length--;
        // this.setMatchedUnmatched(this.matchedRecords, 'matched');
        this.totalMatched = this.getMatchedUnmatchedAmtsum(this.matchedDetails);

      }
    });

  }
  updateRecord(i, t) {
    const unmatchForm = this.unmatchedForm.get('unmatchedList') as FormArray;
    let amt = unmatchForm.controls[i].get('Amount').value || 0;
    let com = unmatchForm.controls[i].get('Commision').value || 0;
    const checkSign = String(amt).charAt(0);
    if (checkSign == '-') {
      amt = amt;
    } else {
      amt = amt.toString().replace(/-/g, '');
    }
    const checkSigncom = String(com).charAt(0);
    if (checkSigncom == '-') {
      com = com;
    } else {
      com = com.toString().replace(/-/g, '');
    }
    unmatchForm.controls[i].patchValue({ 'Amount': Number(amt) || 0 });
    unmatchForm.controls[i].patchValue({ 'Commision': Number(com) || 0 });
    const comm = unmatchForm.controls[i].get('Commision').value || 0;
    unmatchForm.controls[i].patchValue({ 'NetAmount': Number(amt) + Number(comm) || 0 });
    this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
    this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
    this.bsModalRef.content.modelBodyContent = RSAMSGConstants.MGSMOVEUNMATCHEDTOMATCHED;
    this.bsModalRef.content.cancelBtn = 'NO';
    this.bsModalRef.content.actionBtn = 'Yes';
    this.bsModalRef.content.valueChange.subscribe((data) => {
      if (data = 'Yes') {
        const umatchedData = this.unmatchedRecords[i];
        umatchedData.VoucherNo = unmatchForm.controls[i].get('VoucherNo').value || 0;
        umatchedData.VoucherDate = unmatchForm.controls[i].get('VoucherDate').value instanceof Object ?
          new DatePipe('en-US').transform(unmatchForm.controls[i].get('VoucherDate').value, 'yyyy/MM/dd\'T\'HH:mm:ss') :
          this.getISODateFormat(unmatchForm.controls[i].get('VoucherDate').value);
        umatchedData.GrossAmount = unmatchForm.controls[i].get('Amount').value || 0;
        umatchedData.Commision = unmatchForm.controls[i].get('Commision').value || null;
        umatchedData.NetAmount = unmatchForm.controls[i].get('NetAmount').value || null;
        umatchedData.GLCode = this.defaultGLCode,
          umatchedData.TotAccountCode = this.defaultTotallingAccCode,
          console.log(umatchedData, 'Unmatched data to validate');
        this.batchUploadService.validateUnmatchedRecord(umatchedData).subscribe(
          dataReturn => {
            console.log(dataReturn);
            if (dataReturn.Matched === true) {
              this.matchedRecords.push(dataReturn);
              this.setMatchedUnmatched(this.matchedRecords, 'matched');
              console.log(this.matchedDetails);
              unmatchForm.removeAt(i);
              this.unmatchedDetails.splice(i, 1);
              this.unmatchedRecords.splice(i, 1);
              console.log(this.unmatchedRecords);
              this.setMatchedUnmatched(this.unmatchedRecords, 'unmatched');
              this.alertService.success('Selected transaction moved to matched grid!');
            } else {
              this.alertService.warn('The record could not be matched against the database.');
              return false;
            }

          },
          errorRturn => this.errorMsg = errorRturn
        );
      }
    });

  }

  getISODateFormat(date: string) {
    const dt = date.split('/');
    if (dt[0] && dt[1] && dt[2]) {
      return new Date(dt[2] + '-' + dt[1] + '-' + dt[0]).toISOString().slice(0, 19);
    } else {
      return new Date().toISOString().slice(0, 19);
    }
  }

  getMatchedUnmatchedAmtsum(data: any[]) {
    if (toString.call(data) !== '[object Array]') {
      return false;
    }
    let total = 0;
    let comm = 0;
    for (let i = 0; i < data.length; i++) {
      total += Number(data[i].Amount) || 0;
      comm += Number(data[i].Commision) || 0;
    }
    const net = Number(total) + Number(comm);
    return net.toFixed(2);
  }
  getbatchTotalAmt(val) {
    console.log(val);
    if (this.isBatch) {
      this.totalAmount = val;
    }

  }
  calculateBrokerCustomerAmount() {
    this.brokerCustomerAmount += Number(this.newMatchedRecordForm.get('Amount').value);

  }
  addRowModal(template: TemplateRef<any>) {
    this.resetnewMatchedRecordFormvalues();
    this.bsModalRef = this.modalService.show(
      template,
      { class: 'gray modal-add-new-receipt', backdrop: 'static' });
  }
  addNewMatchedRecord() {
    this.newMatchedRecordForm.get('Amount').markAsTouched();
    if (this.newMatchedRecordForm.valid) {
      const newTransactionDetails = this.newMatchedRecordForm.value;
      newTransactionDetails['SerialNo'] = newTransactionDetails['SerialNo'] || 0;
      // this.newMatchedRecordForm.patchValue({ NetAmount: this.calculateNetAmount() });
      if (!this.IsDebit) {
        newTransactionDetails['Amount'] = -Math.abs(newTransactionDetails['Amount']);
      }
      newTransactionDetails['NetAmount'] = Number(newTransactionDetails['Amount']
        || 0) + Number(newTransactionDetails['Commision'] || 0) || 0;
      console.log(newTransactionDetails);
      this.matchedDetails.push(newTransactionDetails);
      this.totalMatched = 0;
      this.totalMatched = this.getMatchedUnmatchedAmtsum(this.matchedDetails);
      console.log(this.matchedDetails);
      // this.setMatchedUnmatched(this.matchedRecords, 'matched');
      this.calculateBrokerCustomerAmount();
      this.resetnewMatchedRecordFormvalues();
      this.IsDebit = true;
      this.bulkuploadData.length++;
      this.bsModalRef.hide();
    }

  }

  resetnewMatchedRecordFormvalues() {
    this.newMatchedRecordForm.controls.Amount.reset('');
    this.newMatchedRecordForm.controls.Description.reset('');
    this.newMatchedRecordForm.controls.RefTransactionID.reset('');
    this.newMatchedRecordForm.controls.SerialNo.reset('');
    this.newMatchedRecordForm.controls.CounterPartyRef.reset('');
  }
  updateCostcenter(flagInit) {
    const loccode = this.newMatchedRecordForm.get('LocationCode').value;
    this.masterDataService.getCostCenters().subscribe(
      dataReturn => {
        this.costcentredata[0] = dataReturn;
        if (loccode == '20') {
          this.newMatchedRecordForm.get('CostCenterCode').setValue(11);
        }
        this.updateTotallingDetailData(false);
      },
      errorRturn => this.errorMsg = errorRturn
    );
  }
  updateTotallingDetailData(initFlag) {
    const ccentre = this.newMatchedRecordForm.get('CostCenterCode').value;

    const param = 'paymentMode=' + this.paymentname +
      '&costCenter=' + ccentre;

    this.masterDataService.getTotallingDetailData(param).subscribe(
      dataReturn => {
        this.dtltotallingacc[0] = dataReturn;
        const totcode = this.dtltotallingacc[0][0].TotAccCode;
        if (!initFlag) {
          this.newMatchedRecordForm.get('TotallingAccCode').setValue(this.defaultTotallingAccCode);
        }
        this.upadteGLData(initFlag, totcode);
      },
      errorRturn => this.errorMsg = errorRturn
    );
  }
  upadteGLData(initFlag, val) {
    const ccentre = this.newMatchedRecordForm.get('CostCenterCode').value;
    const totcode = val;

    let param = 'totallingAccCode=' + totcode +
      '&CostCenterCode=' + ccentre;
    console.log('param-GL', param);

    this.masterDataService.getGLData(param).subscribe(
      dataReturn => {
        this.glaccount[0] = dataReturn;
        console.log(this.glaccount[0][0].GLCode, this.glaccount[0][0].GLEngDescription);
        if (!initFlag) {
          this.newMatchedRecordForm.get('GLCode').setValue(this.glaccount[0][0].GLCode);
          this.newMatchedRecordForm.get('GLCodeDesc').setValue(this.glaccount[0][0].GLEngDescription);
        }
      },
      errorRturn => this.errorMsg = errorRturn
    );
  }

  setTransactiontypeDesc(e: any) {

    const transaction: any = this.transactiontype.filter((data) => data.RefTransactionID == e.srcElement.value);
    this.newMatchedRecordForm.patchValue({
      TransactionType: transaction[0].RefTranEngDescription
    });

  }
  setBulkCreditEntry(e: any) {
    console.log(e.target.checked);
    if (e.target.checked) {
      this.IsDebit = false;
    } else {
      this.IsDebit = true;
    }
  }


  updateHiddenValue(event: any) {
    const ev = event.item.GLCode;
    console.log(ev);
    this.newMatchedRecordForm.get('GLCode').setValue(ev);
  }


  clearGLCodeBulk() {
    const list = ['GLCode', 'GLCodeDesc'];
    list.forEach((item) => {
      this.newMatchedRecordForm.get(item).setValue('');
    });
  }

  preSubmission() {

    let flagtoggle: boolean = false;
    let amt: number = 0;
    this.clonedReceipts = Object.assign({}, this.createReceiptEntitiForm);
    // console.log('this.clonedReceipts',this.clonedReceipts);
    this.clonedReceipts.value.ReceiptDetails = this.clonedReceipts.controls['ReceiptDetails'].value;
    (<FormArray>this.clonedReceipts.controls["ReceiptDetails"]).value.forEach((element, index) => {
      flagtoggle = element.IsCreditEntry;

      if (!flagtoggle)
        element.Amount = (Math.abs(parseFloat(element.Amount)) * -1);
      console.log('flagtoggle:::::' + Math.abs(parseFloat(element.Amount)) * -1, flagtoggle);
      console.log(element.Amount);

    });
    console.log('this.clonedReceipts', this.clonedReceipts);
  }
  getActualAmountSum() {
    let total: number = 0;
    let amt: number = 0;
    let actualamt: number = 0;
    let flagtoggle: boolean = false;
    (<FormArray>this.createReceiptEntitiForm.controls['ReceiptDetails']).controls.forEach((element, index) => {

      if (this.getFromFormArrayControlVal("Amount", index) != undefined
        && this.getFromFormArrayControlVal("Amount", index) != null) {
        flagtoggle = this.getFromFormArrayControlVal("IsCreditEntry", index);
        amt = parseFloat(this.getFromFormArrayControlVal("Amount", index));
        amt = Math.abs(amt || 0);
        actualamt = (flagtoggle) ? amt : (amt * -1);
        console.log('flagtoggle:' + flagtoggle + ",amt:" + amt + ",actualamt:" + actualamt);
        total = total + actualamt;
      }

    });

    this.totalAmount = (total == null || total == undefined || isNaN(total)) ? 0.00 : total;
  }
  GetAccountingDates() {
    this.minDateRd = new Date(localStorage.getItem('accntStartDate'));
    this.maxDateRd = new Date(localStorage.getItem('accntEndDate'));
    const sysDate = new Date();
    if (sysDate < this.minDateRd) {
      this.receiptAccountingDate = new DatePipe('en-US').transform(this.minDateRd, 'dd/MM/yyyy');
    }
    else{
      this.receiptAccountingDate = new DatePipe('en-US').transform(sysDate, 'dd/MM/yyyy');
    }
    this.receiptdate.setValue(this.receiptAccountingDate);
  }
  changeVoucherDate() {
    if (this.receiptdate.value) {
      const receiptDate = new Date(this.receiptdate.value);
      this.receiptdate.setValue(this.receiptAccountingDate);
      let showConfirm;
      let modelContent;
      let getConfirm;
      if (receiptDate > this.maxDateRd) {
        showConfirm = true;
        getConfirm = true;
        modelContent = RSAMSGConstants.VOUCHERDATEGREATERTHANACCOUNTINGEND;
      }
      else if(receiptDate < this.minDateRd){
        showConfirm = true;
        getConfirm = false;
        modelContent = RSAMSGConstants.VOUCHERDATELESSERTHANACCOUNTINGEND;
      }
      if(showConfirm){
        this.receiptdate.setValue(this.receiptAccountingDate);
        this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
        this.bsModalRef.content.modelTitle = '';
        this.bsModalRef.content.modelBodyContent = modelContent;
        this.bsModalRef.content.cancelBtn = getConfirm ? RSAMSGConstants.NOTEXT : null;
        this.bsModalRef.content.actionBtn = getConfirm ? RSAMSGConstants.YESTEXT : RSAMSGConstants.OKTEXT;
        this.bsModalRef.content.valueChange.subscribe((data) => {
          if (data.toString().trim() === 'YES') {
            this.receiptAccountingDate = new DatePipe('en-US').transform(receiptDate, 'dd/MM/yyyy');
            this.receiptdate.setValue(this.receiptAccountingDate);
          }
          this.bsModalRef.hide();
        });
      }
      else{
        this.receiptAccountingDate = new DatePipe('en-US').transform(receiptDate, 'dd/MM/yyyy');
        this.receiptdate.setValue(this.receiptAccountingDate);
      }
    }
  }
  setTerminal(val: any) {
    const currentTerminalID = this.terminals.filter(item => item.UserID == val);
    this.createReceiptEntitiForm.get('TerminalID').setValue(currentTerminalID[0].TerminalID);
  }
}
