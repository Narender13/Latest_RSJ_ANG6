import { Router, NavigationExtras } from '@angular/router';
import { Component, OnInit, OnDestroy, Input, AfterViewInit, ViewChild, OnChanges, SimpleChanges } from '@angular/core';
import { NgXDonutChartSlice } from 'ngx-donutchart/ngx-donutchart.type';
import { BaseSearchComponent } from '../basesearch/basesearch.component';
import { SearchService } from 'src/app/finance/search/service/search.service';
import { CreditDebit } from 'src/app/finance/search/model/credit-debit';
import { GridOptions } from 'ag-grid-community/dist/lib/entities/gridOptions';
import { GridApiService } from 'src/app/shared/datatable/services/grid-api-service';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { CreateReceiptEntitiComponent } from 'src/app/finance/search/search-results/entity/create-receipt-entiti/create-receipt-entiti.component';
import { CreateReceiptEntitiRowSelectionComponent } from 'src/app/finance/search/search-results/entity/create-receipt-entiti-row-selection/create-receipt-entiti-row-selection.component';
import { MatchUnMatchService } from 'src/app/finance/search/service/match-unmatch.service';
import { CreatePaymentEntityComponent } from './create-payment-entity/create-payment-entity.component';
import { CreatePaymentNewComponent } from 'src/app/finance/search/search-results/entity/create-payment-new/create-payment-new.component';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';
import { CreatePaymentComponent } from 'src/app/finance/payments/create-payment/create-payment.component';
import { CreateCreditnotesComponent } from 'src/app/finance/creditnotes/create-creditnotes/create-creditnotes.component';
import { CreateDebitnotesComponent } from 'src/app/finance/debitnotes/create-debitnotes/create-debitnotes.component';
import { SharedService } from 'src/app/finance/services/shared.service';
import { ActivatedRoute } from '@angular/router';
import { CreatejvComponent } from 'src/app/finance/createjv/createjv.component';
import { UserAutherizationService } from 'src/app/core/authorization/userauth.service';
import { CreateClaimReceiptComponent } from '../claim/create-claim-receipt/create-claim-receipt.component';

@Component({
  selector: 'rsa-entity',
  templateUrl: './entity.component.html',
  styleUrls: ['./entity.component.scss']
})
export class EntityComponent extends BaseSearchComponent implements OnInit, OnDestroy, OnChanges {
  @Input('resultdata') resultdata: any = [];
  @Input('entityNo') entityNo: any;
  @Input('category') category: any;
  @Input('filtercolumndata') filtercolumndata: any;
  @Input('propertyNames') propertyNames: any;
  @Input('userdata') userdata: any;
  @Input('searchedname') searchedname: string;
  @Input('glnumber') glnumber = [];
  @Input('entityType') entityType: any;
  rowopen = true;
  size = 90;
  innerRadius = 30;
  slices: NgXDonutChartSlice[] | any[];
  creditlimit: number;
  donutdropdata: any;
  idnumber: number;
  amountCorrForClaimrecipt = [];
  name: string;
  creditData: CreditDebit[] = [];
  creditLimitDetails: CreditDebit[] = [];
  selectedValue = 'All';
  debitlimit: number;
  total: number;
  showSnackbar = false;
  totalVoucherAmount: any = 0;
  totalVoucherCount = 0;
  gridOptions: GridOptions;
  isRecepit;
  selectedRowEntitiDataTable;
  newSelectedRowEntitiDataTable;
  bsModalRef: BsModalRef;
  isMatched;
  showCreateReceiptForm;
  entitydata: any;
  gridHasData: boolean;
  isRowPaymentEntity = false;
  unMatchFlag: boolean = true;
  public rowsSelected: string[] = [];
  isClicked: boolean = false;
  canReceipt: boolean;
  details: any;
  receiptClaims: any;
  rowData = [];
  dnClaims = [];
  selectedRowItemWithVATDebit = [];
  cnClaims = [];
  selectedRowItemWithVATCredit = [];
  selectedClaimboxLists = [];
  chkboxIndex;
  paymentClaims = [];
  selectedRowItemWithVATPayment = [];

  constructor(private allowAccess: UserAutherizationService, private sharedService: SharedService, private searchService: SearchService,
    private router: Router, private gridApiService: GridApiService, private modalService: BsModalService,
    private matchUnMatchService: MatchUnMatchService, private alertService: AlertService, private route: ActivatedRoute, ) {
    super();
  }

  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      this.getCreditData();
      this.canReceipt = this.accessItem(203);
      this.idnumber = 201838683;
      this.name = this.searchedname;
      console.log(this.searchedname, 'name');
      const unique = (value, index, self) => {
        return self.indexOf(value) === index;
      };

      if (Array.isArray(this.resultdata[0]) && this.resultdata[0].length > 0) {
        this.gridHasData = true;
      } else {
        this.gridHasData = false;
      }
      this.donutdropdata = [
        { item: 'All' },
        { item: 'pl' },
        { item: 'cl' },
        { item: 'sme/spl' }
      ];
      if (params.isFromHome == 'true') {
        this.clearSnackBar();
      }
      this.sharedService.getMessage().subscribe(val => {
        console.log(val, 'value shared message');
        if (val) {
          this.formatedEntityData();
        }
        if (val == 'close' || val == true || val == undefined) {
          this.clearSnackBar();
        }
        if (val == 'close' || val == true || val == undefined) {
          this.clearSnackBar();
        }
        if (val === 'close-cliam' || 'close') {
          //this.unSelectCheckbox();
          this.selectedRowItemWithVATDebit = [];
          this.dnClaims = [];
          this.cnClaims = [];
          this.receiptClaims = [];
          this.selectedRowItemWithVATCredit = [];
          this.amountCorrForClaimrecipt = [];
          //this.selectedRowEntitiDataTable = [];
          this.selectedClaimboxLists = [];
          this.paymentClaims = [];
          this.selectedRowItemWithVATPayment = [];
        }
      });
      this.getPreviousRows();
    });
    console.log(this.resultdata, 'this.resultdata[0]');
    this.rowData = this.resultdata[0];
  }

  ngOnChanges(changes: SimpleChanges) {
    if (this.resultdata) {
      this.rowData = this.resultdata[0];
      console.log(changes.resultdata.currentValue, 'currentValue');
      console.log(this.resultdata[0], 'resultdata');
    }
  }

  ngOnDestroy() {
    this.showSnackbar = false;
  }
  updateSelectedRows() {
    if (this.totalVoucherCount > 0) {
      localStorage.setItem('SnackbarAdded', 'true');
      let voucherDetail = { ButtonNames: this.buttonName, SelectedRowEntitiDataTable: this.selectedRowEntitiDataTable };
      localStorage.setItem('VoucherDetail', JSON.stringify(voucherDetail));
    }
    else {
      localStorage.setItem('SnackbarAdded', 'false');
      localStorage.removeItem('VoucherDetail');
      this.selectedRowEntitiDataTable = [];
      this.buttonName = [];
      let voucherDetail = { ButtonNames: this.buttonName, SelectedRowEntitiDataTable: this.selectedRowEntitiDataTable };
      localStorage.setItem('VoucherDetail', JSON.stringify(voucherDetail));
    }
  }
  getPreviousRows() {
    let SnackbarAdded = localStorage.getItem('SnackbarAdded');
    if (SnackbarAdded == 'true') {
      let voucherDetail = JSON.parse(localStorage.getItem('VoucherDetail'));
      this.buttonName = voucherDetail.ButtonNames;
      this.selectedRowEntitiDataTable = voucherDetail.SelectedRowEntitiDataTable;
      this.selectedRowEntitiDataTable.forEach(row => {
        if (row.SrNO) {
          this.rowsSelected.push(row.SrNO);
        }
        else {
          this.rowsSelected.push(row.SerialNumber);
        }
      });
      this.updateVoucherAmount();
    }
  }
  updateVoucherAmount() {
    this.totalVoucherCount = 0;
    this.totalVoucherAmount = 0;
    this.showSnackbar = false;
    if (this.selectedRowEntitiDataTable.length > 0) {
      this.selectedRowEntitiDataTable.forEach(row => {
        this.totalVoucherCount++;
        this.totalVoucherAmount += row.Amount;
      });
      this.showSnackbar = true;
    }
  }

  fillSlicerData(debit, total) {
    this.slices = [
      {
        value: debit,
        color: '#00b5d5',
        message: ''
      },
      {
        value: total,
        color: '#ef5ba1',
        message: 'Payment Due(>90 Days)'
      },

    ];
  }


  getCreditData(): void {
    this.searchService.getCreditData().subscribe((data) => {
      this.creditData = data;
      if (this.selectedValue === 'All') {
        this.creditLimitDetails = this.creditData.filter(i => i.name === this.selectedValue);
        console.log(this.creditLimitDetails);
        this.debitlimit = this.creditLimitDetails[0].debitlimit;
        this.total = this.creditLimitDetails[0].total;
        this.fillSlicerData(this.debitlimit, this.total);
      }
    });
  }

  getDountDropdownData(e) {
    console.log(e);
    this.selectedValue = e.item.item;
    this.creditLimitDetails = this.creditData.filter(i => i.name === e.item.item);
    this.debitlimit = this.creditLimitDetails[0].debitlimit;
    this.total = this.creditLimitDetails[0].total;
    this.fillSlicerData(this.debitlimit, this.total);
  }

  createNewRecepit(obj) {
    this.entitydata = obj;
    this.totalVoucherAmount = 0.00;
    this.totalVoucherCount = null;
    this.createButton([
      { id: '1', name: 'receipt', access: this.accessItem(205) },
      { id: '4', name: 'payment', access: this.accessItem(206) },
      { id: '15', name: 'Tax Invoice', access: this.accessItem(209) },
      { id: '16', name: 'Credit note', access: this.accessItem(210) },
    ]);
    this.unSelectCheckbox();
    setTimeout(() => {
      this.showSnackbar = true;
    }, 200);

  }

  buttonHandler(e) {
    let payeeName: String;
    if (this.resultdata !== null && this.resultdata[0].length > 0) {
      payeeName = this.resultdata[0][0].CustomerName;
    }
    else {
      payeeName = this.searchedname;
    }
    const config = {
      backdrop: true,
      ignoreBackdropClick: false,
      class: 'create-modal-dailog'
    };

    if (e == '15') {
      this.showSnackbar = false;
      const initialState = {
        customerName: payeeName,
        ondemandFlag: true
      };
      this.bsModalRef = this.modalService.show(CreateDebitnotesComponent, {
        class: 'create-modal-dailog',
        initialState, keyboard: false, ignoreBackdropClick: true,
      });
    }

    if (e == '16') {
      this.showSnackbar = false;
      const initialState = {
        customerName: payeeName,
        ondemandFlag: true
      };
      this.bsModalRef = this.modalService.show(CreateCreditnotesComponent, {
        class: 'create-modal-dailog', initialState, keyboard: false,
        ignoreBackdropClick: true,
      });
    }

    if (e == '1') {
      this.showSnackbar = false;

      const initialState = {
        'glnumber': this.glnumber,
        'idnumber': this.idnumber,
        'entitydata': this.entitydata,
        'CustomerName': payeeName
      };
      this.bsModalRef = this.modalService.show(CreateReceiptEntitiComponent, {
        class: 'create-modal-dailog', initialState,
        backdrop: 'static',
        keyboard: false,
        ignoreBackdropClick: true,
      });
      this.bsModalRef.content.CustomerName = payeeName;
    }
    if (e == '4') {
      this.showSnackbar = false;
      this.bsModalRef = this.modalService.show(CreatePaymentComponent, { class: 'create-modal-dailog', ignoreBackdropClick: true, });
      this.bsModalRef.content.CustomerName = payeeName;
      this.bsModalRef.content.entitydata = this.entitydata[0];
      this.bsModalRef.content.isPaymentFromEntity = true;
    }
    if (e == '3' && (this.totalVoucherAmount < 0 || !this.unMatchFlag)) {

      if (this.selectedRowEntitiDataTable.filter(i => i.ClaimID == 0 || i.ClaimID == null).length != this.selectedRowEntitiDataTable.length
        && (this.selectedRowEntitiDataTable.filter(i => i.ClaimID > 0) == this.selectedRowEntitiDataTable.length)) {
        this.alertService.warn(' Do not Select Both Claim and Generic Transactions.Select approriate transactions');
        return false;
      }
      console.log(this.newSelectedRowEntitiDataTable, 'newSelectedRowEntitiDataTable');
      const IsclaimPayment = this.selectedRowEntitiDataTable.filter(i => i.ClaimID > 0).length > 0 ? true : false;
      let initialState;
      if (IsclaimPayment) {
        this.formatedAmountDataForCalim();
        this.paymentClaims = this.amountCorrForClaimrecipt.map(x => Object.assign({}, x));
        /* VAT Implemation changes start */

        this.paymentClaims.map((item) => {
          const copyItem = Object.assign({}, item);
          this.selectedRowItemWithVATPayment.push(item);
          this.selectedRowItemWithVATPayment.push(copyItem);
        });
        console.log(this.selectedRowItemWithVATPayment, 'selectedRowItemWithVATPayment');
        this.selectedRowItemWithVATPayment.map((item, index) => {
          console.log(index, 'index ouside if');
          if ((index % 2) !== 0) {
            console.log(index, 'indexinsideif');
            item.Amount = item.VATAmount || 0;
            item.Description = item.Description + '' + ' included With VAT Amount';
            item.TotallingAccCode = 1110;
            item.CostCenterCode = 11;
            item.GLCode = 4;
          }
        });
        console.log(this.selectedRowItemWithVATPayment, 'after-conversion-selectedRowItemWithVATCredit');
        const totalAmount = this.amountCorrForClaimrecipt.reduce((prevVal, elem) => prevVal + elem.Amount, 0);
        const totalVatAmount = this.amountCorrForClaimrecipt.reduce((prevVal, elem) => prevVal + elem.VATAmount, 0);
        const totalAmountWithVat = (totalAmount + totalVatAmount);
        this.setDetails();
        initialState = {
          selectedRowEntitiDataTable: this.selectedRowItemWithVATPayment,
          customerName: this.selectedRowItemWithVATPayment[0].PayeeName,
          totalAmount: totalAmountWithVat,
          title: 'Claim Payment',
          claimPayment: true,
          paymentVATFlag: true,
          ondemandFlag: false,
          paymentClaimDetails: this.details,
          isRowPaymentEntityClaim: true,
        };
      }
      else {
        this.formatedEntityData();
        console.log(this.newSelectedRowEntitiDataTable, 'this.newSelectedRowEntitiDataTable');
        const totalAmount = this.newSelectedRowEntitiDataTable.reduce((prevVal, elem) => prevVal + elem.Amount, 0);
        console.log(totalAmount, 'toatlamount');
        initialState = {
          selectedRowEntitiDataTable: this.newSelectedRowEntitiDataTable,
          totalAmount: totalAmount,
          ondemandFlag: false,
          customerName: payeeName,
          paymentClaimDetails: this.details,
          isRowPaymentEntity: true,
          isRowPaymentEntityClaim: true,
          title: this.selectedRowEntitiDataTable.filter(i => i.ClaimID > 0).length > 0 ? 'Claim Payment' : 'Payment',
          claimPayment: IsclaimPayment,
        };
      }
      this.bsModalRef = this.modalService.show(CreatePaymentComponent, {
        initialState,
        keyboard: false,
        class: 'create-modal-dailog',
        ignoreBackdropClick: true,
      });
    }
    if (e === '22') {
      this.cnClaims = this.selectedRowEntitiDataTable.map(x => Object.assign({}, x));
      /* VAT Implemation changes start */
      this.cnClaims.map((item) => {
        const copyItem = Object.assign({}, item);
        this.selectedRowItemWithVATCredit.push(item);
        this.selectedRowItemWithVATCredit.push(copyItem);
      });

      this.selectedRowItemWithVATCredit.map((item, index) => {
        const claimcode = item.EntryTypeCode;
        const glcode = (claimcode === 1 || claimcode === 2) ? 154 : 151;
        console.log(index, 'index ouside if');
        if ((index % 2) !== 0) {
          console.log(index, 'indexinsideif');
          item.Amount = item.DNVATAmount || 0;
          item.Description = item.Description + '' + ' included With VAT Amount';
          item.DNTotallingAcc = 2230;
          item.CostCenterCode = 11;
          item.DNGLCode = glcode;
          item.TotallingAccCode = 2230;
          item.CostCenterCode = 11;
          item.GLCode = glcode;
        }
      });
      this.selectedRowItemWithVATCredit.map((item, index) => {
        item.Amount = item.TypeCode == 2 ? (item.Amount) * -1 : item.Amount;
        item.CNVATAmount = item.TypeCode == 2 ? (item.CNVATAmount) * -1 : item.CNVATAmount;
      });
      console.log(this.selectedRowItemWithVATCredit, 'Salvage / Recovery-selectedRowItemWithVATDebit');
      const totalAmount = this.cnClaims.reduce((prevVal, elem) => prevVal + elem.Amount, 0);
      const totalVatAmount = this.cnClaims.reduce((prevVal, elem) => prevVal + elem.CNVATAmount, 0);
      const totalAmountWithVat = (totalAmount + totalVatAmount);

      const initialState = {
        selectedRowItem: this.selectedRowItemWithVATCredit,
        totalAmount: totalAmountWithVat,
        customerName: payeeName,
        ondemandFlagClaim: false,
        cnVATFlag: true,
        cnClaimsFlag: true
      };
      this.bsModalRef = this.modalService.show(CreateCreditnotesComponent, {
        class: 'create-modal-dailog', initialState,
        keyboard: false, ignoreBackdropClick: true,
      });
      this.bsModalRef.content.title = 'Credit Note';

    }

    if (e === '99') {

      this.dnClaims = this.selectedRowEntitiDataTable.map(x => Object.assign({}, x));
      /* VAT Implemation changes start */
      this.dnClaims.map((item) => {
        const copyItem = Object.assign({}, item);
        this.selectedRowItemWithVATDebit.push(item);
        this.selectedRowItemWithVATDebit.push(copyItem);
      });
      this.selectedRowItemWithVATDebit.map((item, index) => {
        const claimcode = item.EntryTypeCode;
        const glcode = (claimcode === 1 || claimcode === 2) ? 151 : 154;
        console.log(index, 'index ouside if');
        if ((index % 2) !== 0) {
          console.log(index, 'indexinsideif');
          item.Amount = item.DNVATAmount || 0;
          item.Description = item.Description + '' + ' included With VAT Amount';
          item.DNTotallingAcc = 2230;
          item.CostCenterCode = 11;
          item.DNGLCode = glcode;
          item.TotallingAccCode = 2230;
          item.CostCenterCode = 11;
          item.GLCode = glcode;
        }
      });
      this.selectedRowItemWithVATDebit.map((item, index) => {
        item.Amount = item.TypeCode == 2 ? (item.Amount) * -1 : item.Amount;
        item.DNVATAmount = item.TypeCode == 2 ? (item.DNVATAmount) * -1 : item.DNVATAmount;
      });
      console.log(this.selectedRowItemWithVATDebit, 'Salvage / Recovery-selectedRowItemWithVATDebit');
      const totalAmount = this.dnClaims.reduce((prevVal, elem) => prevVal + elem.Amount, 0);
      const totalVatAmount = this.dnClaims.reduce((prevVal, elem) => prevVal + elem.DNVATAmount, 0);
      const totalAmountWithVat = (totalAmount + totalVatAmount);

      const initialState = {
        selectedRowItem: this.selectedRowItemWithVATDebit,
        totalAmount: totalAmountWithVat,
        customerName: this.name,
        ondemandFlagClaim: false,
        dnVATFlag: true,
        dnClaimsFlag: true
      };
      this.bsModalRef = this.modalService.show(CreateDebitnotesComponent, {
        class: 'create-modal-dailog', initialState,
        keyboard: false, ignoreBackdropClick: true
      });
      this.bsModalRef.content.title = 'Tax Invoice';

    }
    if (e === '32') {
      const initialState = {
        selectedRowItem: this.selectedRowEntitiDataTable,
        //totalAmount: this.totalVoucherAmount,
        customerName: this.name,
        ondemandFlagClaim: false,
        isRowPaymentEntity: true
      };
      this.bsModalRef = this.modalService.show(CreatejvComponent, {
        class: 'create-modal-dailog', initialState, keyboard: false,
        ignoreBackdropClick: true,
      });
      this.bsModalRef.content.title = 'JV';
      this.bsModalRef.content.selectedRowEntitiDataTable = this.selectedRowEntitiDataTable;
    }

    if (e === '21') {
      this.showSnackbar = false;
      const initialState = {
        selectedRowItem: this.selectedRowEntitiDataTable,
        totalAmount: this.totalVoucherAmount,
        customerName: payeeName,
        ondemandFlagClaim: false
      };
      this.bsModalRef = this.modalService.show(CreateDebitnotesComponent, {
        class: 'create-modal-dailog', initialState,
        keyboard: false, ignoreBackdropClick: true,
      });
      this.bsModalRef.content.title = 'Tax Invoice';

    }

    if (this.unMatchFlag) {
      if ((e === '3' && this.totalVoucherAmount > 0)) {
        this.alertService.warn(RSAMSGConstants.MSGPAYMENTLESSZERO);
      }
    }

    if (this.totalVoucherAmount > 0 && e === '2') {
      //this.showSnackbar = false;
      this.bsModalRef = this.modalService.show(CreateReceiptEntitiRowSelectionComponent, config);
      this.bsModalRef.content.totalamount = this.totalVoucherAmount;
      this.bsModalRef.content.totalcount = this.totalVoucherCount;
      this.bsModalRef.content.selectedRowEntitiDataTable = this.selectedRowEntitiDataTable;
    }
    if (this.totalVoucherAmount < 0 && e === '2') {
      this.alertService.warn(RSAMSGConstants.CREDITEXCEEDMSG);
    }

    if (e === '200') {
      this.formatedAmountDataForCalim();
      console.log(this.amountCorrForClaimrecipt, 'this.amountCorrForClaimrecipt');
      this.receiptClaims = this.amountCorrForClaimrecipt.map(x => Object.assign({}, x));
      const receiptClaims = this.receiptClaims.map(x => Object.assign({}, x));
      console.log(receiptClaims, 'receiptClaims');
      const totalAmount = receiptClaims.reduce((prevVal, elem) => prevVal + elem.Amount, 0);
      const totalVatAmount = receiptClaims.reduce((prevVal, elem) => prevVal + elem.VATAmount, 0);
      const totalAmountWithVat = (totalAmount + totalVatAmount);
      receiptClaims.map((item, index) => {
        item.RefTranTypeDesc = item.RefTranType;
      });
      console.log(this.receiptClaims, 'this.receiptClaims');
      const initialState = {
        backdrop: true,
        ignoreBackdropClick: false,
        selectedClaimboxLists: receiptClaims,
        CustomerName: this.resultdata[0][0].CustomerName,
        totalAmount: totalAmountWithVat,
        receiptVATFlag: true,
      };
      this.bsModalRef = this.modalService.show(CreateClaimReceiptComponent,
        { class: 'create-modal-dailog', initialState, keyboard: false, ignoreBackdropClick: true, });
    }

  }

  formatedEntityData() {
    this.newSelectedRowEntitiDataTable = [];
    const selectedItems = this.selectedRowEntitiDataTable.map(item => Object.assign({}, item));
    for (let i = 0, l = selectedItems.length; i < l; i++) {
      const item = selectedItems[i];
      item.Amount = !this.unMatchFlag ? (item.TypeCode === 2 ? -(item.Amount) : item.Amount) : -(item.Amount);
      item.VATAmount = !this.unMatchFlag ? (item.TypeCode === 2 ? -(item.VATAmount) : item.VATAmount) : -(item.VATAmount);
      item.amt = (item.Amount);
      this.newSelectedRowEntitiDataTable[i] = item;
    }
    console.log(this.newSelectedRowEntitiDataTable, 'newSelectedRowEntitiDataTablefunct');
  }


  formatedAmountDataForCalim() {
    const amountCorrForClaimP = this.selectedRowEntitiDataTable.map(x => Object.assign({}, x));
    this.amountCorrForClaimrecipt = [];
    for (let i = 0, l = amountCorrForClaimP.length; i < l; i++) {
      const item = amountCorrForClaimP[i];
      item.Amount = item.TypeCode == 2 ? -(item.Amount) : item.Amount;
      item.VATAmount = item.TypeCode == 2 ? -(item.VATAmount) : item.VATAmount;
      this.amountCorrForClaimrecipt[i] = item;
      console.log(this.amountCorrForClaimrecipt, 'amountCorrForClaimPayment');
    }

  }


  onlyUnique(value, index, self) {
    return self.indexOf(value) === index;
  }
  setDetails() {
    if (this.newSelectedRowEntitiDataTable.length > 0) {
      console.log(this.newSelectedRowEntitiDataTable[0] + 'setEntityDetails');
      const topRecord = this.newSelectedRowEntitiDataTable[0];
      // TransactionType: "Expenses"
      const typecode = topRecord.TypeCode;
      let selectedIDs: any;
      if (typecode === 1) {
        selectedIDs = this.newSelectedRowEntitiDataTable.map(({ PolicyNumber }) => PolicyNumber);
        this.details = "POL No's " + selectedIDs.filter(this.onlyUnique);
      }
      if (typecode === 2) {
        selectedIDs = this.newSelectedRowEntitiDataTable.map(({ PolicyNumber }) => PolicyNumber);
        this.details = "SAL POL No's " + selectedIDs.filter(this.onlyUnique);
      }
      if (typecode === 3) {
        selectedIDs = this.newSelectedRowEntitiDataTable.map(({ ClaimNumber }) => ClaimNumber);
        this.details = "Exp CL No's " + selectedIDs.filter(this.onlyUnique);
      }

    }
  }
  setErorrMsgForTotalAmount() {
    this.alertService.warn(RSAMSGConstants.CREDITEXCEEDMSG);
  }
  selectedRowDetails(event) {
    const e = event.vocherEmitedDetails;
    console.log(event, 'e.isMatched');
    const isUnmatched = e.ifUnMatched;
    this.unMatchFlag = isUnmatched;
    if (e.count) {
      if (isUnmatched) {
        this.createButton([
          { id: '2', name: 'receipt', access: this.accessItem(205) },
          { id: '3', name: 'payment', access: this.accessItem(206) },
          { id: '32', name: 'Journal', access: this.accessItem(207) },
        ]);
      }
      if (!isUnmatched) {
        const selected = e.currentRowData;
        let typecode = selected.TypeCode;
        if (e.isChecked) {
          if (!this.selectedClaimboxLists[typecode]) {
            this.selectedClaimboxLists[typecode] = [];
          }
          this.selectedClaimboxLists[typecode].push(selected);
          let salvage = (this.selectedClaimboxLists[2] == null || this.selectedClaimboxLists[2] == undefined || this.selectedClaimboxLists[2] == []) ? 0 : this.selectedClaimboxLists[2].length;
          let claim = (this.selectedClaimboxLists[1] == null || this.selectedClaimboxLists[1] == undefined || this.selectedClaimboxLists[1] == []) ? 0 : this.selectedClaimboxLists[1].length;
          let expenses = (this.selectedClaimboxLists[3] == null || this.selectedClaimboxLists[3] == undefined || this.selectedClaimboxLists[3] == []) ? 0 : this.selectedClaimboxLists[3].length;

          console.log(salvage, claim, expenses);

          if ((salvage >= 0 && claim <= 0 && expenses <= 0)) {
            this.createButton([
              { id: '200', name: 'receipt', access: this.accessItem(205) },
              { id: '3', name: 'Claim Payment', access: this.accessItem(206) },
              { id: '32', name: 'Journal', access: this.accessItem(207) },
              { id: '99', name: 'Tax Invoice', access: this.accessItem(209) },
              { id: '22', name: 'credit note', access: this.accessItem(208) }
            ]);
          }
          else {
            this.createButton([
              { id: '3', name: 'Claim Payment', access: this.accessItem(206) },
              { id: '32', name: 'Journal', access: this.accessItem(207) },
              { id: '99', name: 'Tax Invoice', access: this.accessItem(209) },
              { id: '22', name: 'credit note', access: this.accessItem(208) }
            ]);
          }
        }
        else {
          if (this.selectedClaimboxLists[typecode] !== undefined) {
            this.selectedClaimboxLists[typecode].filter((element, i) => {
              if (element === selected) { this.chkboxIndex = i; }
            });
            this.selectedClaimboxLists[typecode].splice(this.chkboxIndex, 1);
          }
        }
        let salvage = (this.selectedClaimboxLists[2] == null || this.selectedClaimboxLists[2] == undefined || this.selectedClaimboxLists[2] == []) ? 0 : this.selectedClaimboxLists[2].length;
        let claim = (this.selectedClaimboxLists[1] == null || this.selectedClaimboxLists[1] == undefined || this.selectedClaimboxLists[1] == []) ? 0 : this.selectedClaimboxLists[1].length;
        let expenses = (this.selectedClaimboxLists[3] == null || this.selectedClaimboxLists[3] == undefined || this.selectedClaimboxLists[3] == []) ? 0 : this.selectedClaimboxLists[3].length;
        if ((salvage >= 0 && claim <= 0 && expenses <= 0)) {
          this.createButton([
            { id: '200', name: 'receipt', access: this.accessItem(205) },
            { id: '99', name: 'Tax Invoice', access: this.accessItem(209) },
            { id: '22', name: 'credit note', access: this.accessItem(208) },
            { id: '3', name: 'Claim Payment', access: this.accessItem(206) },
            { id: '32', name: 'Journal', access: this.accessItem(207) },
          ]);
        }
        else {
          this.createButton([
            { id: '3', name: 'Claim Payment', access: this.accessItem(206) },
            { id: '99', name: 'Tax Invoice', access: this.accessItem(209) },
            { id: '22', name: 'credit note', access: this.accessItem(208) },
            { id: '32', name: 'Journal', access: this.accessItem(207) },
          ]);
        }
      }
      if (e.transactionType === 'DEBIT') {
        this.createButton([
          { id: '2', name: 'receipt', access: this.accessItem(205) },
          { id: '32', name: 'Journal', access: this.accessItem(207) }
        ]);
      } else if (e.transactionType === 'CREDIT') {
        this.createButton([
          { id: '3', name: 'payment', access: this.accessItem(206) },
          { id: '32', name: 'Journal', access: this.accessItem(207) }
        ]);
      }
    } else {
      // alert('amount should ne gretaherthan zero');
      // this.showSnackbar = false;
    }
    let rowsSelected = e.currentRowData;
    // If already rows selected add row or remove row depending on check box value.
    if (this.selectedRowEntitiDataTable) {
      if (isUnmatched) {
        //If row does not exist means check box is checked then add the row to list.if exists check box is unchecked then remove the row from list.
        if ((this.selectedRowEntitiDataTable.filter(x => x.SrNO == rowsSelected.SrNO).length == 0) && e.isChecked) {
          this.selectedRowEntitiDataTable.push(rowsSelected);
          this.rowsSelected.push(rowsSelected.SrNO);
        }
        else {
          if (!e.isChecked) {
            this.selectedRowEntitiDataTable = this.selectedRowEntitiDataTable.filter(x => x.SrNO != rowsSelected.SrNO);
            this.rowsSelected = this.rowsSelected.filter(x => x != rowsSelected.SrNO);
          }
        }
      }
      //For claims
      else {
        //If row does not exist means check box is checked then add the row to list.if exists check box is unchecked then remove the row from list.
        let rowId = rowsSelected.ClaimID + '-' + rowsSelected.TypeCode + '-' + rowsSelected.SerialNumber;
        if ((this.selectedRowEntitiDataTable.filter(x =>
          (x.ClaimID == rowsSelected.ClaimID && x.TypeCode == rowsSelected.TypeCode && x.SerialNumber == rowsSelected.SerialNumber)).length == 0) && e.isChecked) {
          this.selectedRowEntitiDataTable.push(rowsSelected);
          this.rowsSelected.push(rowId);
        }
        else {
          if (!e.isChecked) {
            this.selectedRowEntitiDataTable = this.selectedRowEntitiDataTable.filter(x => !(x.ClaimID == rowsSelected.ClaimID && x.TypeCode == rowsSelected.TypeCode && x.SerialNumber == rowsSelected.SerialNumber));
            this.rowsSelected = this.rowsSelected.filter(x => x != rowId);
          }
        }
      }

    }
    else {
      if (e.isChecked) {
        this.selectedRowEntitiDataTable = e.selectedrow;
        if (isUnmatched) {
          this.rowsSelected.push(rowsSelected.SrNO);
        }
        else {
          let rowId = rowsSelected.ClaimID + '-' + rowsSelected.TypeCode + '-' + rowsSelected.SerialNumber;
          this.rowsSelected.push(rowId);
        }
      }
    }
    this.updateVoucherAmount();
    this.updateSelectedRows();
    console.log(this.selectedRowEntitiDataTable, 'this.selectedRowEntitiDataTable');
  }

  hideSnackBar(e) {
    this.clearSnackBar();
  }
  clearSnackBar() {
    this.totalVoucherCount = 0;
    this.totalVoucherAmount = 0;
    localStorage.setItem('SnackbarAdded', 'false');
    this.selectedRowEntitiDataTable = [];
    this.buttonName = [];
    this.rowsSelected = [];
    let voucherDetail = { ButtonNames: this.buttonName, SelectedRowEntitiDataTable: this.selectedRowEntitiDataTable };
    localStorage.setItem('VoucherDetail', JSON.stringify(voucherDetail));
    this.unSelectCheckbox();
    this.showSnackbar = false;
    this.sharedService.sendMessage("ClearState");
    if (localStorage.getItem('ERStateExists') != null) {
      localStorage.setItem('ERStateExists', 'false');
    }
  }
  hideSnackBarDataT(ev) {
    if (ev === 1) {
      console.log(ev);
      this.showSnackbar = false;
    }
  }

  unSelectCheckbox() {
    this.gridApiService.unCheck();
  }
  accessItem(functionid) {
    return this.allowAccess.isAllowed(functionid)
  }
}

