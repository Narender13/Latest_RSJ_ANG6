
import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, FormArray, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';
import { ConfirmationDialogComponent } from 'src/app/shared/custom-model/custom-model.component';
import { BsModalService } from 'ngx-bootstrap/modal';
import { TabsetComponent } from 'ngx-bootstrap/tabs';
import { SharedService } from 'src/app/finance/services/shared.service';
import { CreateReceipt } from '../../../model/create-receipt';
import { MasterDataService } from 'src/app/finance/services/finance.masterdata.service';
import { UtilityClass } from 'src/app/shared/utilites/helper-class';
import { CreatePayment } from 'src/app/finance/search/model/create-payment';
import { CreatePaymentService } from 'src/app/finance/payments/create-payment/service/create-payment.service';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { BasevoucherComponent } from 'src/app/finance/basevoucher/basevoucher.component';
import { PaymentpreviewComponent } from 'src/app/finance/preview/uae/paymentpreview/paymentpreview.component';

@Component({
  selector: 'rsa-create-payment-entity',
  templateUrl: './create-payment-entity.component.html',
  styleUrls: ['./create-payment-entity.component.scss']
})
export class CreatePaymentEntityComponent extends BasevoucherComponent implements OnInit {
  title = 'Payment';
  currency = 'AED';
  errorpayee: boolean;
  errordetail: boolean;
  /* form error-feilds */
  errorbankcodeCheque: boolean;
  errorbankcodeBanktransfer: boolean;
  errorpaayeebanknameCheque: boolean;
  errorpaayeebanknameBanktransfer: boolean;
  errorchequedateCheque: boolean;
  errorchequedateBankT: boolean;
  errorchequedateCreditCard: boolean;
  errorchequenoCheque: boolean;
  errorchequenoCreditCard: boolean;
  errorterminalID: boolean;
  errorexpirydate: boolean;
  matchedRecords = [];
  isUploadUnmatched;
  returnValue: any;
  usersReq;
  isEntityPaymentFeildReq = true;
  symbol;
  isBatch = false;
  createPayment: CreatePayment;
  animatedClass = true;
  selectedRowEntitiDataTable: any = [];
  bulkuploadData: any = [];
  @ViewChild('tabset') tabset: TabsetComponent;
  setPayeeName;

  constructor(
    protected sharedService: SharedService,
    private fb: FormBuilder,
    protected modalService: BsModalService,
    protected bsModalRef: BsModalRef,
    protected masterDataService: MasterDataService,
    protected utilityClass: UtilityClass,
    protected createPaymentService: CreatePaymentService,
    private alertService: AlertService,
  ) {
    super(masterDataService, sharedService, modalService, utilityClass, bsModalRef);
    //super.setMinMaxDate();
  }


  ngOnInit() {
    /* super with method is calling from BasevoucherComponent */
    this.createPaymentForm(this.paymentMode);
    super.getAllBranchData();
    super.getAllCostCenterData({ ev: null, index: 0, flag: true });
    super.getAllTotallingData(true);
    super.getAllgetLookupBanksData();
    super.getAllPayeeBankData(true);
    super.getAllDeptData();
    super.getAllProjData();
    super.getAllMasterData2();
    this.fieldStatusChanges();
    super.getBankData(true);
    super.getModelPreviousClose();
    super.closeModel();
    super.getAllTranData();
    this.symbol = (localStorage.getItem('symbol'));
    //super.setMinMaxDate();
    super.GetAccountingDates();
    this.getTotalAmount();
    this.getSelectedRowData();
  }


  getTotalAmount() {
    setTimeout(() => {
      this.totalAmount = this.bsModalRef.content.totalamount;
      console.log(this.totalAmount, 'totalamount');
    }, 100);
  }

  getSelectedRowData() {
    setTimeout(() => {
      this.selectedRowEntitiDataTable = this.bsModalRef.content.selectedRowEntitiDataTable;
      this.selectedRowEntitiDataTable.map((item, index) => this.addReceipt(item, (index + 1), false));
      console.log(this.selectedRowEntitiDataTable, 'selectedRowEntitiDataTable');
      this.setPayeeName = this.selectedRowEntitiDataTable[0].CustomerName;
      this.setPayeName();
    }, 0);
  }

  setPayeName() {
    this.mainVoucherForm.controls.detailInfo['controls'].PayeeName.setValue(this.setPayeeName);
  }

  /* create entiti form */
  createPaymentForm(param): void {
    this.mainVoucherForm = null;
    //let tranDate = localStorage.getItem('tranAccntMnthStrtDate') ? new Date(localStorage.getItem('tranAccntMnthStrtDate')) : new Date();
    this.mainVoucherForm = this.fb.group({
      VoucherDate: [new DatePipe('en-US').transform(new Date(), 'MM/dd/yyyy')],
      Amount: [''],
      PaymentMode: [this.paymentMode],
      PrintDate: [new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy')],
      ReceiptType: [0],
      PreparedBy: [1],
      ModifiedBy: ['1'],
      Approvers: this.fb.array([]),
      ApprovedBy: [1],
      CustomerID: [],
      TerminalID: [],
      TerminalUserID: [20],
      TerminalUserName: [],
      CountryCode: [1],
      ChequeDateFld: [],
      LocationCode: [localStorage.getItem('locationcode')],
      RegionCode: [localStorage.getItem('regioncode')],
      ReprintNo: [],
      CostCenterCode: [localStorage.getItem('costcentre')],
      ArabicDescription: [],
      TotallingAccCode: [1110],
      RecevierBankCode: [14],
      chequeInfo: this.fb.group({
        ChequeNo: [''],
        ChequeDate: [new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy'), Validators.required],
        PayeeBankCode: [122, Validators.required],
        PayeeBankName: ['dd', Validators.required],
      }),
      bankTransfer: this.fb.group({
        InstrumentRefNo: [''],
        ChequeDate: [new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy'), Validators.required],
        PayeeBankCode: [, Validators.required],
        PayeeBankName: [''],
        BeneficiaryBank: [''],
        BeneficiaryBankCurrency: [''],
        BeneficiaryAccNo: [''],
        BeneficiarySwiftCode: [''],
        BeneficiarySortCode: [''],
        CorrespondentBank: [''],
        IBAN: [''],
        CorrespondentAccNo: [''],
        CorrespondentBankSwiftCode: [''],
      }),
      detailInfo: this.fb.group({
        PayeeName: ['', Validators.required],
        EnglishDescription: ['', Validators.required],
      }),
      accountInfo: this.fb.group({
        LocationCode: [localStorage.getItem('locationcode')],
        CostCenterCode: [localStorage.getItem('costcentre')],
        TotallingAccCode: [1110],
        RecevierBankCode: [14],
      }),

      VoucherDetails: this.fb.array(this.selectedRowEntitiDataTable.map(item => {
        console.log(item, 'item');
        const group = this.createPaymentArrayGroup();
        group.patchValue(item);
        return group;
      }))
    });
  }


  /* form array for recept details */
  createPaymentArrayGroup(): FormGroup {
    return this.fb.group({
      CounterPartyReferenceNo: [],
      LocationCode: [localStorage.getItem('locationcode')],
      BranchCode: [localStorage.getItem('locationcode')],
      LocationDesc: [],
      CountryCode: [],
      CostCenterCode: [localStorage.getItem('costcentre')],
      CounterPartyRef: [],
      Class: [],
      Description: [],
      Amount: ['', Validators.required],
      Amt: [],
      BranchName: [],
      RefTransactionID: [],
      IsDebitEntry: [true],
      RefTransactionType: [5],
      RefTranTypeDesc: [],
      RefTranType: [],
      PolicyID: [],
      PolicyNumber: [],
      PolicyYear: [],
      PolicyType: [],
      ModifiedBy: [],
      ReceiptDate: [],
      AnalysisCode: [],
      DepartmentCode: [],
      DepartmentName: [],
      Department: [],
      RefTransactionSerialNo: [],
      TotallingAccName: [],
      PlaceHolderCode: [],
      GLCode: [4, Validators.required],
      GLCodeDesc: ['4-HSBC BANK MIDDLE EAST - Deira', Validators.required],
      GLAccountName: [],
      GLAccount: [],
      RegionCode: [localStorage.getItem('regioncode')],
      TotallingAccCode: [1110],
      ClassCode: [localStorage.getItem('costcentre')],
      ClaimID: [],
      VoucherType: [],
      TransactionNo: [],
      VoucherNo: [],
      // Aaded new formControlName to make row readonly if coming from selection rows
      newAddedRow: false
    });
  }

  /* set receipt mode and set default values   */
  setReceiptMode(val, paymentname) {
    this.mainVoucherForm.controls['PaymentMode'].setValue(val);
    this.paymentMode = val;
    this.paymentname = paymentname;
    if (!this.editPaymentFromPrevious) {
      this.createPaymentForm(this.paymentMode);
    }
    super.GetAccountingDates();
    this.receiverdataBankName = this.cachedReceiverBankData;
    this.totallingacc = this.cachedTotAcc;
    this.payeedataBankName = this.cachedPayeeBankData;
    if (this.paymentMode == 1) {
      this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.setValue('1210');
    } else {
      this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.setValue('1110');
      this.mainVoucherForm.controls.accountInfo['controls'].RecevierBankCode.setValue('14');
    }
    this.setdefaultHeaderData();
    this.fieldStatusChanges();
    this.setPayeName();
  }

  /* using req fields and update status  */
  fieldStatusChanges() {
    this.clearerrors();
    this.cshpayeename.statusChanges.subscribe(
      status => {
        this.errorpayee = (status === 'INVALID');
        console.log(this.errorpayee, 'his.errorpayee');
      }
    );
    this.cshdetails.statusChanges.subscribe(
      status => {
        this.errordetail = (status === 'INVALID');
      }
    );
    /* for cheque */
    if (this.payeebankcodeCheque != null && this.payeebankcodeCheque !== undefined) {
      this.payeebankcodeCheque.statusChanges.subscribe(
        status => {
          this.errorbankcodeCheque = (status === 'INVALID');
        }
      );
    }

    if (this.chequedateCheque != null && this.chequedateCheque !== undefined) {
      this.chequedateCheque.statusChanges.subscribe(
        status => {
          this.errorchequedateCheque = (status === 'INVALID');
        }
      );
    }


    if (this.chequeno != null && this.chequeno !== undefined) {
      this.chequeno.statusChanges.subscribe(
        status => {
          this.errorchequenoCheque = (status === 'INVALID');
        }
      );
    }

    if (this.payeebanknameCheque != null && this.payeebanknameCheque !== undefined) {
      this.payeebanknameCheque.statusChanges.subscribe(
        status => {
          this.errorpaayeebanknameCheque = (status === 'INVALID');
        }
      );
    }


    /* for banktransfer */

    if (this.chequedateBankT != null && this.chequedateBankT !== undefined) {
      this.chequedateBankT.statusChanges.subscribe(
        status => {
          this.errorchequedateBankT = (status === 'INVALID');
        }
      );
    }


    if (this.payeebankcodeBankt != null && this.payeebankcodeBankt !== undefined) {
      this.payeebankcodeBankt.statusChanges.subscribe(
        status => {
          this.errorbankcodeBanktransfer = (status === 'INVALID');
        }
      );
    }

    if (this.payeebanknameBankt != null && this.payeebanknameBankt !== undefined) {
      this.payeebanknameBankt.statusChanges.subscribe(
        status => {
          this.errorpaayeebanknameBanktransfer = (status === 'INVALID');
        }
      );
    }


    if (this.expirydate != null && this.expirydate !== undefined) {
      this.expirydate.statusChanges.subscribe(
        status => {
          this.errorexpirydate = (status === 'INVALID');
        }
      );
    }

  }

  /* clear all errors after reset   */
  clearerrors() {
    this.errorpayee = false;
    this.errordetail = false;
    this.errorbankcodeCheque = false;
    this.errorbankcodeBanktransfer = false;
    this.errorpaayeebanknameCheque = false;
    this.errorpaayeebanknameBanktransfer = false;
    this.errorchequedateCheque = false;
    this.errorchequedateBankT = false;
    this.errorchequedateCreditCard = false;
    this.errorchequenoCheque = false;
    this.errorexpirydate = false;
  }

  /* get the controls of each fields   */
  get cshpayeename() { return this.mainVoucherForm.controls.detailInfo['controls'].PayeeName; }
  get cshdetails() { return this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription; }
  get payeebankcodeCheque() {
    return this.mainVoucherForm.controls.chequeInfo['controls'].PayeeBankCode;
  }
  get payeebankcodeBankt() {
    return this.mainVoucherForm.controls.bankTransfer['controls'].PayeeBankCode;
  }

  get payeebanknameCheque() {
    return this.mainVoucherForm.controls.chequeInfo['controls'].PayeeBankName;
  }
  get payeebanknameBankt() {
    return this.mainVoucherForm.controls.bankTransfer['controls'].PayeeBankName;
  }
  get chequedateCheque() {
    return (this.mainVoucherForm.controls.chequeInfo['controls'].ChequeDate);
  }
  get chequedateBankT() {
    return (this.mainVoucherForm.controls.bankTransfer['controls'].ChequeDate);
  }

  get instrumentrefnoBankT() {
    return (this.mainVoucherForm.controls.bankTransfer['controls'].InstrumentRefNo);
  }


  get expirydate() { return this.mainVoucherForm.get('ExpiryDate'); }

  get chequeno() {
    return this.mainVoucherForm.controls.chequeInfo['controls'].ChequeNo;
  }


  /* set Description in receptdetails desc   */
  setDescription() {
    (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls[0].get('Description').setValue(this.cshdetails.value);

  }


  /* go next valiadtion depending on receipt mode   */
  goNext() {
    if (this.paymentMode == 1) {
      this.errorpayee = this.cshpayeename.invalid;
      console.log(this.errorpayee);
      this.errordetail = this.cshdetails.invalid;
      if (!this.errorpayee && !this.errordetail) {
        this.level = 2;
        this.setDescription();
        super.getTotallingDetailData({ index: 0, flag: true });
      }
    }

    if (this.paymentMode == 2) {
      this.errorpayee = this.cshpayeename.invalid;
      console.log(this.errorpayee);
      this.errordetail = this.cshdetails.invalid;

      if (this.payeebankcodeCheque != null && this.payeebankcodeCheque !== undefined) {
        this.errorbankcodeCheque = this.payeebankcodeCheque.invalid;
        console.log(this.payeebankcodeCheque.invalid, 'this.payeebankcode.invalid');
      }

      if (this.chequedateCheque != null && this.chequedateCheque !== undefined) {
        this.errorchequedateCheque = this.chequedateCheque.invalid;
      }

      if (this.chequeno != null && this.chequeno !== undefined) {
        this.errorchequenoCheque = this.chequeno.invalid;
      }
      if (!this.errorpayee && !this.errordetail && !this.errorbankcodeCheque &&
        !this.errorchequedateCheque && !this.errorchequenoCheque) {
        this.level = 2;
        this.setDescription();
        super.getTotallingDetailData({ index: 0, flag: true });
      }
    }

    if (this.paymentMode == 5) {
      this.errorpayee = this.cshpayeename.invalid;
      this.errordetail = this.cshdetails.invalid;

      if (this.chequedateBankT != null && this.chequedateBankT !== undefined) {
        this.errorchequedateBankT = this.chequedateBankT.invalid;

      }

      if (this.payeebankcodeBankt != null && this.payeebankcodeBankt !== undefined) {
        this.errorbankcodeBanktransfer = this.payeebankcodeBankt.invalid;
        console.log(this.errorbankcodeBanktransfer, 'errorbankcodeBanktransfer');
      }

      if (!this.errorpayee && !this.errordetail && !this.errorchequedateBankT &&
        !this.errorbankcodeBanktransfer) {
        this.level = 2;
        this.setDescription();
        super.getTotallingDetailData({ index: 0, flag: true });

      }
    }

  }


  addReceipt(item, len?, newAdded?) {
    const control = <FormArray>this.mainVoucherForm.controls['VoucherDetails'];
    console.log(control);
    console.log(item);
    const newRow = this.createPaymentArrayGroup();
    newRow.patchValue(item);
    control.push(newRow);
    if (newAdded) {
      this.setFormArrayCTRLDefaultValue('GLCode', len, 4);
      this.setFormArrayCTRLDefaultValue('GLCodeDesc', len, '4-HSBC BANK MIDDLE EAST - Deira');
      newRow.patchValue({ 'newAddedRow': true });
      this.dtltotallingacc[len] = this.cachedDtlTot;
      this.glaccount[len] = this.cachedGL;
      // this.getTotallingDetailData({ index: len, flag: true });

    }
    const CurrentAmount = (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls[len - 1].get('Amount').value;
    // if (CurrentAmount > 0) {

    //   //   this.getTotallingDetailData({ index: len, flag: false });
    //   // (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls[len].get('Amount').value;
    // } else {
    //   this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
    //   this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
    //   this.bsModalRef.content.modelBodyContent = RSAMSGConstants.AMOUNTVALIDATIONMSG;
    //   this.bsModalRef.content.cancelBtn = RSAMSGConstants.OKTEXT;
    //   control.removeAt(len);
    //   return false;
    // }
  }



  reSetForm(params) {
    const param = params.defaultParam;
    /*set default value here and reset */
    if (param == 1) {
      this.validateAllFormFields(this.mainVoucherForm);
      this.mainVoucherForm.controls.accountInfo['controls'].LocationCode.reset([localStorage.getItem('locationcode')]);
      this.mainVoucherForm.controls.accountInfo['controls'].CostCenterCode.reset([localStorage.getItem('costcentre')]);
      this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.reset([1110]);
      this.mainVoucherForm.controls.accountInfo['controls'].RecevierBankCode.reset([14]);
      this.mainVoucherForm.controls.ReceiptDate.setValue([new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy')]);

      this.clearerrors();
    } else if (param == 2) {
      this.mainVoucherForm.controls['VoucherDetails'].reset();
      (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls.map(item => {
        item.get('LocationCode').setValue([localStorage.getItem('locationcode')]);
        item.get('CostCenterCode').setValue([localStorage.getItem('costcentre')]);
        item.get('RefTransactionType').setValue(3);
        item.get('TotallingAccCode').setValue(1110);
        item.get('GLCode').setValue(4);
        item.get('GLCodeDesc').setValue('4-HSBC BANK MIDDLE EAST - Deira');
      });
      this.getSum();
    }
    super.GetAccountingDates();
  }


  /* update  form values to create-receipt objects*/
  upDateCreatePaymentValues() {
    this.createPayment = new CreatePayment();
    this.createPayment = new CreatePayment();
    const mainFormFieldArray = ['VoucherDate', 'Amount', 'PaymentMode', 'PrintDate', 'ReceiptType',
      'PreparedBy', 'ModifiedBy', 'CustomerID', 'TerminalUserID', 'TerminalUserName',
      'CountryCode', 'ArabicDescription', 'Approvers', 'ApprovedBy'];
    mainFormFieldArray.forEach(item => {
      this.createPayment[item] = this.mainVoucherForm.controls[item].value;
    });
    this.createPayment.LocationCode = this.mainVoucherForm.controls.accountInfo['controls'].LocationCode.value;
    this.createPayment.CostCenterCode = this.mainVoucherForm.controls.accountInfo['controls'].CostCenterCode.value;
    this.createPayment.TotallingAccCode = this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.value;
    this.createPayment.RecevierBankCode = this.mainVoucherForm.controls.accountInfo['controls'].RecevierBankCode.value;
    this.createPayment.Name = this.mainVoucherForm.controls.detailInfo['controls'].PayeeName.value;
    this.createPayment.E_Desc = this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription.value;
    this.createPayment.PmtDetails = this.mainVoucherForm.controls['VoucherDetails'].value;
    if (this.paymentMode == 2) {
      this.createPayment.ChequeNo = this.mainVoucherForm.controls.chequeInfo['controls'].ChequeNo.value;
      this.createPayment.ChequeDate = this.mainVoucherForm.controls.ChequeDateFld.value;
      this.createPayment.PayeeBankCode = this.mainVoucherForm.controls.chequeInfo['controls'].PayeeBankCode.value;
      this.createPayment.PayeeBankName = this.mainVoucherForm.controls.chequeInfo['controls'].PayeeBankName.value;
    }

    if (this.paymentMode == 5) {
      this.createPayment.InstrumentRefNo = this.mainVoucherForm.controls.bankTransfer['controls'].InstrumentRefNo.value;
      this.createPayment.ChequeNo = this.mainVoucherForm.controls.bankTransfer['controls'].InstrumentRefNo.value;
      this.createPayment.ChequeDate = this.mainVoucherForm.controls.ChequeDateFld.value;
      this.createPayment.PayeeBankCode = this.mainVoucherForm.controls.bankTransfer['controls'].PayeeBankCode.value;
      this.createPayment.BeneficiaryBank = this.mainVoucherForm.controls.bankTransfer['controls'].BeneficiaryBank.value;
      this.createPayment.BeneficiaryBankCurrency = this.mainVoucherForm.controls.bankTransfer['controls'].BeneficiaryBankCurrency.value;
      this.createPayment.BeneficiaryAccNo = this.mainVoucherForm.controls.bankTransfer['controls'].BeneficiaryAccNo.value;
      this.createPayment.BeneficiarySwiftCode = this.mainVoucherForm.controls.bankTransfer['controls'].BeneficiarySwiftCode.value;
      this.createPayment.BeneficiarySortCode = this.mainVoucherForm.controls.bankTransfer['controls'].BeneficiarySortCode.value;
      this.createPayment.CorrespondentBank = this.mainVoucherForm.controls.bankTransfer['controls'].CorrespondentBank.value;
      this.createPayment.IBAN = this.mainVoucherForm.controls.bankTransfer['controls'].IBAN.value;
      this.createPayment.CorrespondentAccNo = this.mainVoucherForm.controls.bankTransfer['controls'].CorrespondentAccNo.value;
      this.createPayment.CorrespondentBankSwiftCode = this.mainVoucherForm.controls.bankTransfer['controls'].CorrespondentBankSwiftCode.value;
      this.createPayment.ChequeNo = this.mainVoucherForm.controls.bankTransfer['controls'].InstrumentRefNo.value;
      this.createPayment.CorrespondentBankSortCode = this.mainVoucherForm.controls.bankTransfer['controls'].CorrespondentBankSortCode.value;
    }
  }

  /* create-receipt form*/
  submitForm() {
    super.validateDetailInfo();
    this.upDateCreatePaymentValues();
    console.log(this.createPayment, ' this.createPayment');
    if (this.glerrorcount > 0) {
      return false;
    }
    this.usersReq = (this.approverusers !== undefined && this.approverusers !== '' &&
      this.approverusers.length > 0);
    if (this.totalAmount > 0) {
      if (this.totalAmount > 99999 && !this.usersReq) {
        return false;
      }

      if (this.prevPreviewID == null || this.prevPreviewID == undefined) {
        this.prevPreviewID = 0;
        this.createPayment['VoucherNo'] = this.prevPreviewID;
      }


      this.createPaymentService.createPayment(JSON.stringify(this.createPayment)).subscribe(
        dataReturn => {
          this.returnValue = dataReturn;
          this.returnValue['approverlist'] = this.approverusers;
          this.returnValue['ondemand'] = true;
          console.log(this.returnValue, 'this.returnValue');
          this.previewFlag = true;
          this.bsModalRef = this.modalService.show(PaymentpreviewComponent, { class: 'preview-modal-dailog', ignoreBackdropClick: true });
          this.bsModalRef.content.data = this.returnValue;
          this.bsModalRef.content.totalAmount = this.totalAmount;
          this.bsModalRef.content.backdrop = true;
        },
        errorRturn => {
          this.errorMsg = errorRturn;
        }
      );
    }
    if (this.totalAmount <= 0) {
      this.alertService.warn(RSAMSGConstants.AMOUNTTEXTREQ);
    }
  }



  /* check single or batch upload */
  checkSingleOrbatch(e) {
    this.isBatch = !this.isBatch;
    console.log(this.isBatch);
  }

}

