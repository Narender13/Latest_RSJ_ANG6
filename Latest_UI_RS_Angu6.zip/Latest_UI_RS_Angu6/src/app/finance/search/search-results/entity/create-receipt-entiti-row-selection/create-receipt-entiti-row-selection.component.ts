import { Component, OnInit, ChangeDetectorRef, ViewChild ,OnDestroy} from '@angular/core';
import { FormBuilder, FormControl, FormGroup, FormArray, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { MasterDataService } from 'src/app/finance/services/finance.masterdata.service';
import { CreateService } from 'src/app/finance/receipts/create-receipt/service/create.service';
import { getShortDate, getShortDateCreditCard } from 'src/app/shared/utilites/helper';
import { ConfirmationDialogComponent } from 'src/app/shared/custom-model/custom-model.component';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';
import { Router } from '@angular/router';
import { ReceiptpreviewComponent } from 'src/app/finance/preview/uae/receiptpreview/receiptpreview.component';
import { GridApiService } from 'src/app/shared/datatable/services/grid-api-service';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { TabsetComponent } from 'ngx-bootstrap/tabs';
import { Customvalidators } from 'src/app/shared/validators/customvalidators';
import { SharedService } from 'src/app/finance/services/shared.service';
import { SearchService } from '../../../service/search.service';
import { RSAConstants } from 'src/app/core/constants/rsaconstant';
@Component({
  selector: 'rsa-create-receipt-entiti-row-selection',
  templateUrl: './create-receipt-entiti-row-selection.component.html',
  styleUrls: ['./create-receipt-entiti-row-selection.component.scss']
})
export class CreateReceiptEntitiRowSelectionComponent implements OnInit, OnDestroy {
  title = 'Receipt';
  level: any = 1;
  amount;
  currency = 'AED';
  collapsetoheader: boolean;
  entitiRowSelectionForm: FormGroup;
  BankName: any;
  results: any;
  errorMsg;
  terminals;
  slided;
  returnValue;
  count;
  branchdata: any = [];
  users: any = [];
  RcptMode = 2;
  selectedRowEntitiDataTable = [];
  getbankterminaldetails = {};
  payeedataBankName: any = [];
  receiverdataBankName: any = [];
  pjctindicator: any = [];
  department: any = [];
  placeholder: any;
  glaccount: any = [];
  totallingacc: any = [];
  transactiontype: any = [];
  chequeTypeData: any = [];
  private masterdata: any = [];
  private masterdata2: any = [];
  costcentredata: any = [];
  displayApprover = false;
  approverusers: string;
  totalAmount = 0;
  glerrorcount = 0;
  setcredit = true;
  totalSum = 0;
  dtltotallingacc = [];
  symbol: string;
  arrUser: any = [];
  paymentname = 'CASH';
  usersReq = true;
  errorpayee: boolean;
  errordetail: boolean;
  errorbankcode: boolean;
  errorchequedate: boolean;
  errorinstrumentdate: boolean;
  errorchequeno: boolean;
  errorinstrumentrefno: boolean;
  errorterminalID: boolean;
  // errorexpirydate: boolean;
  errorreceiptdate: boolean;
  errorChequeTypeCheque: boolean;
  errorchequetype: boolean;
  minDate;
  totalAmountc;
  minDateRd;
  maxDateRd;
  isDisabled = true;
  setPayeeName;
  currentTbIndex = 0;
  currentTbName;
  previewFlag: boolean = false;
  cachedPayeeBankData: any;
  cachedDtlTot: any;
  cachedGL;
  prevReceipt: any;
  previewDataDtl: any = [];
  cachedReceiverBankData: any;
  cachedCostcentredata: any;
  cachedTotAcc: any;
  isUAE;
  amountZeroCheck;
  amountLimitCheck;
  currentDate;
  concatDescription = [];
  accountingCode = '1';
  accountingStartDate: any;
  accountingEndDate: any;
  receiptAccountingDate: any;
  isStateExist:boolean;
  isStateClosed:boolean=false;
  editReceiptFromPrevious = false;
  defaultUserId;
  defaultTerminalId;

  @ViewChild('tabset') tabset: TabsetComponent;
  constructor(
    private ref: ChangeDetectorRef,
    public bsModalRef: BsModalRef,
    private fb: FormBuilder,
    private createservice: CreateService,
    private masterDataService: MasterDataService,
    private modalService: BsModalService,
    private gridApiService: GridApiService,
    private alertService: AlertService,
    private sharedService: SharedService,
    private router: Router) {
    this.minDateRd = new Date();
    this.maxDateRd = new Date();
    this.minDateRd.setDate(this.minDateRd.getDate() - 0);
    this.maxDateRd.setDate(this.maxDateRd.getDate() - 0);
    this.receiptAccountingDate = new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy');
    this.currentDate = new Date();
  }


  ngOnInit() {
    
    this.createReceiptEntitiRowSForm(this.RcptMode);
    this.getSelectedRowData();
    this.getAllMasterData(1110);
    this.getAllMasterData2();
    this.getTotalAmount();
    this.getPayeeBankData(true);
    this.getTotallingData(localStorage.getItem('costcentre'));
    this.getBankData(true);
    this.getAllInstrumentTypes();
    this.symbol = (localStorage.getItem('symbol'));
    console.log(this.bsModalRef, 'this.bsModalRef');
    this.fieldStatusChanges();
    this.getModalFromPrevious();
    this.isUAE = localStorage.getItem('country') == '3' ? true : false;
      this.isStateExist=false;
    this.updateFromSession();
    if(this.currentTbIndex==0 && this.isStateExist){
      this.updateTabValues();
    }
    this.GetAccountingDates();
  }
  /*region for mantaining session for multiple search */
  ngOnDestroy() {
    if(!this.isStateClosed){
      this.addToSession();
    }
   }
   addToSession(){
     if(this.entitiRowSelectionForm.dirty || this.entitiRowSelectionForm.touched){
      let receiptDate = this.getDateClrlValue('ReceiptDate');
      let totallingAccCode = this.getFormCtrlValue('TotallingAccCode');
      let recevierBankCode = this.getFormCtrlValue('RecevierBankCode');
      let description = this.getFormCtrlValue('EnglishDescription');//PayeeName
      let payeeName = this.getFormCtrlValue('PayeeName')
       var commonData={ReceiptDate:receiptDate,CurrentTabIndex:this.currentTbIndex ,TotallingAccCode:totallingAccCode,RecevierBankCode:recevierBankCode,Description:description,PayeeName:payeeName}
      localStorage.setItem('CommonData',JSON.stringify(commonData));
      let contentData=this.getContentData();
      localStorage.setItem('ContentData',JSON.stringify(contentData));
      localStorage.setItem('PaymentContentData',JSON.stringify(contentData));
      localStorage.setItem('ERStateExists','true');
     }
  }
   getDateClrlValue(contrlName:string){
    if(this.entitiRowSelectionForm.controls[contrlName].dirty || this.entitiRowSelectionForm.controls[contrlName].touched){
      return this.entitiRowSelectionForm.controls[contrlName].value;
    }
    else{
      return null;
    }
   }
   getContentData(){
     var contentData:any;
     if(this.currentTbIndex==0){
      let payeeBankCode = this.getFormCtrlValue('PayeeBankCode');
      let instrumentDate = this.getDateClrlValue('InstrumentDate');
      let chequeNo = this.getFormCtrlValue('ChequeNo');
      contentData={PayeeBankCode:payeeBankCode,InstrumentDate:instrumentDate,ChequeNo:chequeNo}
     }
     if(this.currentTbIndex==1){
      let instrumentRefNo = this.getFormCtrlValue('InstrumentRefNo');
      let chequeDate = this.getDateClrlValue('ChequeDate');
      let chequeNo = this.getFormCtrlValue('ChequeNo');
      contentData={InstrumentRefNo:instrumentRefNo,ChequeDate:chequeDate,ChequeNo:chequeNo}
     }
     if(this.currentTbIndex==3){
      let payeeBankCode = this.getFormCtrlValue('PayeeBankCode');
      let chequeDate = this.getDateClrlValue('ChequeDate');
      let instrumentRefNo = this.getFormCtrlValue('InstrumentRefNo');
      contentData={InstrumentRefNo:instrumentRefNo,ChequeDate:chequeDate,PayeeBankCode:payeeBankCode}
     }
     return contentData;
   }
   updateContentData(){
    let itemDetail=localStorage.getItem('ContentData');
    if(itemDetail){
      this.entitiRowSelectionForm.markAsDirty();
      let contentData=JSON.parse(itemDetail);
      if(this.currentTbIndex==0){
       if(contentData.PayeeBankCode) this.setControlValue('PayeeBankCode',contentData.PayeeBankCode);
       if(contentData.InstrumentDate)this.setControlValue('InstrumentDate',this.getDateFormat(contentData.InstrumentDate));
       if(contentData.ChequeNo)this.setControlValue('ChequeNo',contentData.ChequeNo);
      }
      if(this.currentTbIndex==1){
        if(contentData.InstrumentRefNo) this.setControlValue('InstrumentRefNo',contentData.InstrumentRefNo);
        if(contentData.ChequeDate) this.setControlValue('ChequeDate',this.getDateFormat(contentData.ChequeDate));
        if(contentData.ChequeNo) this.setControlValue('ChequeNo',contentData.ChequeNo);
      }
      if(this.currentTbIndex==3){
        if(contentData.PayeeBankCode) this.setControlValue('PayeeBankCode',contentData.PayeeBankCode);
        if(contentData.ChequeDate) this.setControlValue('ChequeDate',this.getDateFormat(contentData.ChequeDate));
        if(contentData.InstrumentRefNo) this.setControlValue('InstrumentRefNo',contentData.InstrumentRefNo);
      }
    }
   }
   updateFromSession(){
    let erStateExists=localStorage.getItem('ERStateExists');
    if(erStateExists=='true'){
      let itemDetail=localStorage.getItem('CommonData')
      if(itemDetail){
       this.isStateExist=true;
       let commonData=JSON.parse(itemDetail);
       this.currentTbIndex=commonData.CurrentTabIndex;
       setTimeout(() => {
          this.tabset.tabs[this.currentTbIndex].active=true;
         
        }, 1);
      }
    }
     
   }
   updateTabValues(){
    let erStateExists=localStorage.getItem('ERStateExists');
    if(erStateExists=='true'){
      let itemDetail=localStorage.getItem('CommonData')
      if(itemDetail){
       this.isStateExist=true;
       let commonData=JSON.parse(itemDetail);
       if(commonData.ReceiptDate) this.setControlValue('ReceiptDate',this.getDateFormat(commonData.ReceiptDate));
       if(commonData.TotallingAccCode) this.setControlValue('TotallingAccCode',commonData.TotallingAccCode);
       if(commonData.Description) this.setControlValue('EnglishDescription',commonData.Description);
       if(commonData.PayeeName) this.setControlValue('PayeeName',commonData.PayeeName);
       setTimeout(() => {
        this.getBankData(true);
       
      }, 500);
       setTimeout(() => {
        this.tabset.tabs[this.currentTbIndex].active=true;
        this.setControlValue('RecevierBankCode',commonData.RecevierBankCode);
      }, 500);
      this.updateContentData();
     }
    }
    
  }
  setControlValue(controlName:any,val:any){
    if(val){
      this.entitiRowSelectionForm.controls[controlName].setValue(val);
    }
     
  }
  getDateFormat(val:any){
    return new DatePipe('en-US').transform(new Date(val), 'dd/MM/yyyy')
  }
  /*end region*/
  doPatchRefFields() {
    let formarray = (<FormArray>this.entitiRowSelectionForm.controls['ReceiptDetails']);
    formarray.controls.map((item, index) => {
      item.get("RefTransactionID").setValue(this.previewDataDtl[index].RefTransactionID);
      item.get("RefTransactionSerialNo").setValue(this.previewDataDtl[index].RefTransactionSerialNo);
    });
  }
  getModalFromPrevious() {
    this.sharedService.getMessage().subscribe(val => {
      if (val === 'previous') {
        this.previewFlag = false;
        this.editReceiptFromPrevious = true;
      } else if (val === 'close') {
        this.modalService.hide(1);
      }
      this.prevReceipt = val.id;
      console.log(this.prevReceipt, 'this.prevReceipt');
      this.previewDataDtl = val.data;
      if (this.previewDataDtl != null || this.previewDataDtl != undefined) {
        this.doPatchRefFields();
      }
    });
  }
  clearerrors() {
    this.errorpayee = false;
    this.errordetail = false;
    this.errorbankcode = false;
    this.errorchequedate = false;
    this.errorchequeno = false;
    this.errorchequetype = false;
    this.errorinstrumentrefno = false;
    this.errorterminalID = false;
    // this.errorexpirydate = false;
    this.errorreceiptdate = false;
    this.errorinstrumentdate = false;
  }

  getPayeeBankData(initFlag) {
    const param = this.getFormCtrlValue('LocationCode');
    this.masterDataService.getPayeeBankData().subscribe(
      dataReturn => {
        this.payeedataBankName = dataReturn;
        //this.clearPayeeBankCode();


        if (initFlag) {
          this.cachedPayeeBankData = dataReturn;
          //this.clearPayeeBankCode();
        }



        this.clearerrors();
      },
      errorRturn => this.errorMsg = errorRturn
    );
  }

  clearPayeeBankCode() {
    if (this.RcptMode == 2 || this.RcptMode == 5) {
      this.entitiRowSelectionForm.controls['PayeeBankCode'].setValue('');
    }
    this.clearerrors();
  }

  setFormArrayCTRLDefaultValue(contrlname, index, val) {
    (<FormArray>this.entitiRowSelectionForm.controls['ReceiptDetails']).controls[index].get(contrlname).setValue(val);
  }
  getFromFormArrayControlVal(contrlname, index) {
    return (<FormArray>this.entitiRowSelectionForm.controls['ReceiptDetails']).controls[index].get(contrlname).value;
  }
  getFormCtrlValue(contrlName) {
    console.log(this.entitiRowSelectionForm.controls, 'this.receiptForm.controls');
    return this.entitiRowSelectionForm.controls[contrlName].value;
  }


  getTotallingDetailData(index, initFlag) {

    let loccode = (initFlag == true) ? 20 : this.getFromFormArrayControlVal('BranchCode', index);
    let ccentre = (initFlag == true) ? 11 : this.getFromFormArrayControlVal('CostCenterCode', index);

    const param = 'paymentMode=' + this.paymentname +
      '&costCenter=' + ccentre;
    console.log(param, param);
    this.masterDataService.getTotallingDetailData(param).subscribe(
      dataReturn => {
        this.dtltotallingacc[index] = dataReturn;
        let totcode = (initFlag == true) ? 1110 : this.dtltotallingacc[index][0].TotAccCode;
        if (!initFlag) {
          this.setFormArrayCTRLDefaultValue("TotallingAccCode", index, totcode);
        }
        if (initFlag) {
          this.cachedDtlTot = dataReturn;
        }
        this.getGLData(index, initFlag, totcode);
      },
      errorRturn => this.errorMsg = errorRturn
    );
  }
  get voucherDetailsLength() {
    return this.entitiRowSelectionForm.controls.ReceiptDetails['controls'].length > 1;
  }
  fieldStatusChanges() {
    this.clearerrors();
    this.cshpayeename.statusChanges.subscribe(
      status => {
        this.errorpayee = (status === 'INVALID');
        console.log(this.errorpayee, 'his.errorpayee');
      }
    );
    this.cshdetails.statusChanges.subscribe(
      status => {
        this.errordetail = (status === 'INVALID');
      }
    );
    if (this.RcptMode == 2) {
      if (this.payeebankcode != null && this.payeebankcode != undefined) {
        this.payeebankcode.statusChanges.subscribe(
          status => {
            this.errorbankcode = (status == 'INVALID');
          }
        );
      }
      if (this.instrumentdate != null && this.instrumentdate != undefined) {
        this.instrumentdate.statusChanges.subscribe(
          status => {
            this.errorinstrumentdate = (status == 'INVALID');
          }
        );
      }
    }
    if (this.RcptMode == 5) {
      if (this.payeebankcode != null && this.payeebankcode != undefined && this.payeebankcode.value != '') {
        this.payeebankcode.statusChanges.subscribe(
          status => {
            this.errorbankcode = (status == 'INVALID');
          }
        );
      }
      if (this.instrumentrefno != null && this.instrumentrefno !== undefined) {
        this.instrumentrefno.statusChanges.subscribe(
          status => {
            this.errorinstrumentrefno = (status === 'INVALID');
          }
        );
      }
    }
    if (this.chequedate != null && this.chequedate !== undefined) {
      this.chequedate.statusChanges.subscribe(
        status => {
          this.errorchequedate = (status === 'INVALID');
        }
      );
    }
    if (this.chequeno != null && this.chequeno !== undefined) {
      this.chequeno.statusChanges.subscribe(
        status => {
          this.errorchequeno = (status === 'INVALID');
        }
      );
    }
    if (this.receiptdate != null && this.receiptdate !== undefined) {
      this.receiptdate.statusChanges.subscribe(
        status => {
          this.errorreceiptdate = (status === 'INVALID');
        }
      );
    }
    if (this.terminalid != null && this.terminalid !== undefined) {
      this.terminalid.statusChanges.subscribe(
        status => {
          this.errorterminalID = (status === 'INVALID');
        }
      );
    }
    if (this.chequeType != null && this.chequeType != undefined) {
      this.chequeType.statusChanges.subscribe(
        status => {
          this.errorchequetype = (status == 'INVALID');
        }
      );
    }

  }

  goNext() {
    this.errorpayee = this.cshpayeename.invalid;
    this.errordetail = this.cshdetails.invalid;

    if (this.RcptMode == 2) {
      if (this.payeebankcode != null && this.payeebankcode != undefined) {
        this.errorbankcode = this.payeebankcode.invalid;
      }
      if (this.instrumentdate != null && this.instrumentdate !== undefined) {
        this.errorinstrumentdate = this.instrumentdate.invalid;
      }
    }


    if (this.chequedate != null && this.chequedate !== undefined) {
      this.errorchequedate = this.chequedate.invalid;
    }

    if (this.chequeno != null && this.chequeno !== undefined) {
      this.errorchequeno = this.chequeno.invalid;
    }
    if (this.chequeType != null && this.chequeType !== undefined) {
      this.errorchequetype = this.chequeType.invalid;
    }

    if (this.receiptdate != null && this.receiptdate !== undefined) {
      this.errorreceiptdate = this.receiptdate.invalid;
    }

    if (this.RcptMode == 5) {
      if (this.instrumentrefno != null && this.instrumentrefno !== undefined) {
        this.errorinstrumentrefno = this.instrumentrefno.invalid;
      }
    }
    if (this.RcptMode == 8) {
      if (this.terminalid != null && this.terminalid !== undefined) {
        this.errorterminalID = this.terminalid.invalid;
      }
    }
    if (!this.errorpayee && !this.errordetail && !this.errorchequedate && !this.errorreceiptdate && !this.errorchequeno
      && !this.errorinstrumentrefno && !this.errorterminalID && !this.errorbankcode && !this.errorinstrumentdate && !this.errorchequetype) {

      this.getTotallingDetailData(this.getVoucherDetailsLength(), true);
      this.getDescription();
      this.level = 2;
    }
  }
  doPatchDescrption() {
    const formarray = (<FormArray>this.entitiRowSelectionForm.controls['ReceiptDetails']);
    formarray.controls.map((item, index) => {
      item.get('Description').setValue(this.concatDescription[index].Description);
    });
  }

  getDescription() {
    const paramResultArray = this.selectedRowEntitiDataTable.map((item, index) =>
      ({
        PolicyId: item.PolicyID,
        EndId: item.Endt_ID,
        ClassCode: item.ClassCode,
        ClaimId: item.ClaimID,
        Description: item.Description
      }));
    console.log(paramResultArray, 'resultarray');

    this.masterDataService.getDescription(paramResultArray).subscribe(data => {
      this.concatDescription = data;
      console.log(this.concatDescription, 'this.concatDescription');
      this.doPatchDescrption();

    });
  }
  getTotalAmount() {
    setTimeout(() => {
      this.totalAmount = this.bsModalRef.content.totalamount;
      console.log(this.totalAmount, 'totalamount');
    }, 100);
  }

  getSelectedRowData() {
    setTimeout(() => {
      this.selectedRowEntitiDataTable = this.bsModalRef.content.selectedRowEntitiDataTable;
      this.selectedRowEntitiDataTable.map((item, index) => this.addReceipt(item, (index + 1), false));
      console.log(this.selectedRowEntitiDataTable, 'selectedRowEntitiDataTable');
      this.setPayeeName = this.selectedRowEntitiDataTable[0].CustomerName;
      this.setPayeName();
    }, 0);


  }

  setPayeName() {
    this.entitiRowSelectionForm.controls['PayeeName'].setValue(this.setPayeeName);
  }

  setReceiptMode(val, paymentname, ev) {
    if (!ev.tabset) return; // fix for tab key resetting all values
    this.entitiRowSelectionForm.controls['ReceiptMode'].setValue(val);
    this.RcptMode = val;
    this.paymentname = paymentname;
    console.log(this.RcptMode, 'set');
    if (!this.editReceiptFromPrevious) {
      this.createReceiptEntitiRowSForm(this.RcptMode);
    }
    if (this.editReceiptFromPrevious) {
      const control = <FormArray>this.entitiRowSelectionForm.controls['ReceiptDetails'];
      this.createReceiptEntitiRowSForm(this.RcptMode);
      this.entitiRowSelectionForm.controls['ReceiptDetails'] = control;
    }
    this.GetAccountingDates();
    this.payeedataBankName = this.cachedPayeeBankData;

    this.receiverdataBankName = this.cachedReceiverBankData;
    this.totallingacc = this.cachedTotAcc;
    this.entitiRowSelectionForm.controls['TotallingAccCode'].setValue(1110);
    this.entitiRowSelectionForm.controls['RecevierBankCode'].setValue(14);
    this.clearPayeeBankCode();
     if(this.terminals!=null && this.terminals.length>0 ){
      const terminal =this.terminals.filter( x=>x.UserID == localStorage.getItem(RSAConstants.LoggedInUserId));
      this.defaultUserId= terminal!=null&& terminal[0]!=null? terminal[0].UserID:this.terminals[0].UserID;
      this.defaultTerminalId=terminal!=null&& terminal[0]!=null? terminal[0].TerminalID:this.terminals[0].TerminalID;
      }
    if (this.RcptMode == 5) {
      this.entitiRowSelectionForm.controls['PayeeBankCode'].setValue('');
    }

    if (this.RcptMode == 8) {
      this.entitiRowSelectionForm.controls['TerminalUserID'].setValue(this.defaultUserId || this.terminals[0].UserID);
      this.entitiRowSelectionForm.controls['TerminalID'].setValue(this.defaultTerminalId || this.terminals[0].TerminalID);
    }
    this.setPayeName();
    this.fieldStatusChanges();
    if(this.isStateExist){
      this.updateTabValues();
    }
  }

  getSum() {
    this.totalAmount = 0;
    const ctrl = <FormArray>this.entitiRowSelectionForm.controls['ReceiptDetails'];
    ctrl.controls.forEach(val => {
      const amt = (val.get('Amount').value == null || isNaN(val.get('Amount').value) ||
        val.get('Amount').value == '') ? 0 : val.get('Amount').value;
      this.totalAmount += parseFloat(amt);
    });

    this.totalAmount = (isNaN(this.totalAmount)) ? 0 : this.totalAmount;

  }
  getGLData(index, initFlag, val) {
    let loccode = (initFlag == true) ? 20 : this.getFromFormArrayControlVal('BranchCode', index);
    let ccentre = (initFlag == true) ? 11 : this.getFromFormArrayControlVal('CostCenterCode', index);
    let totcode = val;

    let param = 'totallingAccCode=' + totcode +
      '&CostCenterCode=' + ccentre;
    console.log('param-GL', param);

    this.masterDataService.getGLData(param).subscribe(
      dataReturn => {
        this.glaccount[index] = dataReturn;
        console.log(this.glaccount, 'glacount');
        if (!initFlag) {
          this.setFormArrayCTRLDefaultValue("GLCode", index, this.glaccount[index][0].GLCode);
          this.setFormArrayCTRLDefaultValue("GLCodeDesc", index, this.glaccount[index][0].GLEngDescription);
        }
        if (initFlag) this.cachedGL = dataReturn;
        console.log(this.cachedGL, 'cachedGL');
      },
      errorRturn => this.errorMsg = errorRturn
    );
    if (this.level == 2) {
      (<FormArray>this.entitiRowSelectionForm.controls['ReceiptDetails']).controls.map(item => {
        item.get('Amount').updateValueAndValidity();
        item.get('GLCode').updateValueAndValidity();
      });
    }
  }
  changeCostcenter(index, flagInit) {
    let loccode = this.getFromFormArrayControlVal('BranchCode', index);
    this.masterDataService.getCostCenters().subscribe(
      dataReturn => {
        this.costcentredata[index] = dataReturn;
        if (loccode == "20")
          this.setFormArrayCTRLDefaultValue('CostCenterCode', index, 11);
        this.getTotallingDetailData(index, false);
      },
      errorRturn => this.errorMsg = errorRturn
    );
  }

  setBankData(val) {

    this.getBankData(false);

  }

  getBankData(flagInit) {
    let ccentre = this.getFormCtrlValue('CostCenterCode');
    let totcode = this.getFormCtrlValue('TotallingAccCode');

    let param = 'totallingAccCode=' + totcode +
      '&costCenter=' + ccentre;
    this.masterDataService.getBankData(param).subscribe(
      dataReturn => {
        this.receiverdataBankName = dataReturn;
        if (!flagInit)
          this.entitiRowSelectionForm.controls['RecevierBankCode'].setValue(this.receiverdataBankName[0].BankCode);
        if (flagInit)
          this.cachedReceiverBankData = dataReturn;
      },
      errorRturn => this.errorMsg = errorRturn
    );
  }
  getTotallingData(initflag) {
    let ccentre = this.getFormCtrlValue('CostCenterCode');
    const param = 'paymentMode=' + this.paymentname +
      '&costCenter=' + ccentre;

    this.masterDataService.getTotallingData(param).subscribe(
      dataReturn => {
        this.totallingacc = dataReturn;
        if (initflag)
          this.cachedTotAcc = dataReturn;
        //this.clearPayeeBankCode();  

      },
      errorRturn => this.errorMsg = errorRturn
    );
  }
  /* get all instrument types */
  getAllInstrumentTypes() {
    this.masterDataService.getInstrumentTypes().subscribe((data) => {
      this.chequeTypeData = data.filter(c => c.Related_Code == 8);
    },
      errorRturn => this.errorMsg = errorRturn
    );
  }

  getAllMasterData(totalacc): void {
    this.masterDataService.getAllMasterData(totalacc).subscribe(
      dataReturn => {
        this.masterdata = dataReturn;
        console.log(dataReturn, ' : master data');
        this.payeedataBankName = this.masterdata.LoadPayeeBanks;
        this.terminals = this.masterdata.Terminals;
        this.pjctindicator = this.masterdata.ProjectIndicators;
        this.department = this.masterdata.Departments;
        console.log(this.department, 'd');
        console.log(this.pjctindicator, 'p');
        console.log(this.terminals, 't');
        this.transactiontype = this.masterdata.TransactionType;

      },
      errorRturn => this.errorMsg = errorRturn
    );
  }
  getAllMasterData2(): void {
    this.masterDataService.getAllMasterData2().subscribe(
      dataReturn => {
        this.masterdata2 = dataReturn;
        console.log(dataReturn, ' : master data');
        this.glaccount = this.masterdata2.GLCodes;
        this.users = this.masterdata2.Users;
        this.branchdata = this.masterdata2.Locations;
        this.cachedCostcentredata = this.masterdata2.CostCenter;
        this.costcentredata[0] = this.masterdata2.CostCenter;
      },
      errorRturn => this.errorMsg = errorRturn
    );
  }

  onUserChange(userid: string, isChecked: boolean, username: string) {
    const userFormArray = <FormArray>this.entitiRowSelectionForm.controls.Approvers;
    if (isChecked) {
      userFormArray.push(new FormControl(userid));
      this.arrUser.push(username);
    } else {
      const index = userFormArray.controls.findIndex(x => x.value === userid);
      userFormArray.removeAt(index);
      this.arrUser = this.arrUser.filter(v => v !== username);
    }
    this.approverusers = this.arrUser.join();
    console.log(this.approverusers);
  }

  onDateValueChange(ev) {
    this.entitiRowSelectionForm.controls['ChequeDateFld'].setValue(new DatePipe('en-US').transform(new Date(ev), 'dd/MM/yyyy'));
  }
  createReceiptEntitiRowSForm(param): void {
    this.entitiRowSelectionForm = null;
    //let tranDate = localStorage.getItem('tranAccntMnthStrtDate') ? new Date(localStorage.getItem('tranAccntMnthStrtDate')) : new Date();
    this.entitiRowSelectionForm = this.fb.group({
      ReceiptDate: [new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy')],
      ReceiptMode: [this.RcptMode],
      PrintDate: [new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy')],
      ReceiptType: [],
      PreparedBy: [1],
      ModifiedBy: ['1'],
      Approvers: this.fb.array([]),
      CustomerID: [],
      TerminalID: [],
      TerminalUserID: [],
      TerminalUserName: [],
      CountryCode: [1],
      LocationCode: [localStorage.getItem('locationcode')],
      RegionCode: [localStorage.getItem('regioncode')],
      ReprintNo: [],
      CostCenterCode: [localStorage.getItem('costcentre')],
      ArabicDescription: [],
      TotallingAccCode: [1110],
      RecevierBankCode: [14],
      ChequeDateFld: [''],
      PayeeName: ['', Validators.required],
      EnglishDescription: ['', Validators.required],
      ChequeDate: [new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy'), Validators.required],
      ReceiptDetails: this.fb.array(this.selectedRowEntitiDataTable.map(item => {
        console.log(item, 'item');
        const group = this.entitiRowSelectionFormGroup();
        group.patchValue(item);
        return group;
      }))
    });
    switch (param) {
      case 1:
        break;
      case 2:
        this.entitiRowSelectionForm.addControl('ChequeNo', new FormControl('', Validators.required));
        this.entitiRowSelectionForm.controls['ChequeNo'].updateValueAndValidity();
        this.entitiRowSelectionForm.addControl('InstrumentDate', new FormControl(new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy'), Validators.required));
        this.entitiRowSelectionForm.controls['InstrumentDate'].updateValueAndValidity();
        this.entitiRowSelectionForm.addControl('PayeeBankCode', new FormControl('', Validators.required));
        this.entitiRowSelectionForm.controls['PayeeBankCode'].updateValueAndValidity();
        this.entitiRowSelectionForm.addControl('PayeeBankName', new FormControl('', Validators.required));
        this.entitiRowSelectionForm.controls['PayeeBankName'].updateValueAndValidity();
        break;
      case 8:
        this.entitiRowSelectionForm.addControl('ChequeNo', new FormControl('', [Validators.required, Customvalidators.creditcardValidator]));
        this.entitiRowSelectionForm.controls['ChequeNo'].updateValueAndValidity();
        this.entitiRowSelectionForm.addControl('InstrumentRefNo', new FormControl(''));
        this.entitiRowSelectionForm.addControl('TransactionNo', new FormControl(''));
        //this.entitiRowSelectionForm.controls['InstrumentRefNo'].updateValueAndValidity();
        this.entitiRowSelectionForm.addControl('ChequeDate', new FormControl('', Validators.required));
        this.entitiRowSelectionForm.controls['ChequeDate'].updateValueAndValidity();
        this.entitiRowSelectionForm.addControl('TerminalUserID', new FormControl('', Validators.required));
        this.entitiRowSelectionForm.controls['TerminalUserID'].updateValueAndValidity();
        this.entitiRowSelectionForm.addControl('ChequeType', new FormControl('', Validators.required));
        this.entitiRowSelectionForm.controls['ChequeType'].updateValueAndValidity();
        //this.entitiRowSelectionForm.addControl('TerminalID', new FormControl('', Validators.required));
        //this.entitiRowSelectionForm.controls['TerminalID'].updateValueAndValidity();
        break;
      case 5:
        this.entitiRowSelectionForm.addControl('PayeeBankCode', new FormControl(''));
        this.entitiRowSelectionForm.controls['PayeeBankCode'].updateValueAndValidity();
        this.entitiRowSelectionForm.addControl('PayeeBankName', new FormControl('', Validators.required));
        this.entitiRowSelectionForm.controls['PayeeBankName'].updateValueAndValidity();
        this.entitiRowSelectionForm.addControl('ChequeDate', new FormControl('', Validators.required));
        this.entitiRowSelectionForm.controls['ChequeDate'].updateValueAndValidity();
        // defect 3080- make required for bank transfer
        this.entitiRowSelectionForm.addControl('InstrumentRefNo', new FormControl('', [Validators.required]));
        this.entitiRowSelectionForm.controls['InstrumentRefNo'].updateValueAndValidity();

        break;
    }
  }


  entitiRowSelectionFormGroup(): FormGroup {
    return this.fb.group({
      CounterPartyReferenceNo: [],
      LocationCode: [localStorage.getItem('locationcode')],
      BranchCode: [localStorage.getItem('locationcode')],
      LocationDesc: [],
      CountryCode: [1],
      CostCenterCode: [localStorage.getItem('costcentre')],
      ClassCode: [],
      CostCenterName: [],
      CounterPartyRef: [],
      TotallingAccName: [],
      Class: [],
      Description: [],
      Amount: [0, [Validators.required]],
      Amt: [],
      BranchName: [],
      RefTransactionID: [],
      IsCreditEntry: [true],
      RefTransactionType: [3],
      RefTranTypeDesc: [],
      RefTranType: [],
      PolicyID: [],
      PolicyNumber: [],
      ModifiedBy: [],
      ReceiptDate: [],
      AnalysisCode: [],
      DepartmentCode: [],
      DepartmentName: [],
      RefTransactionSerialNo: [],
      PlaceHolderCode: [],
      GLCode: [4, Validators.required],
      GLCodeDesc: ['4-HSBC BANK MIDDLE EAST - Deira', Validators.required],
      GLAccountName: [],
      GLAccount: [],
      RegionCode: [localStorage.getItem('regioncode')],
      TotallingAccCode: [1110],
      ClaimID: [],
      VoucherType: [],
      TransactionNo: [],
      PolicyYear: [],
      PolicyType: [],
      VoucherNo: [],
      RefPolicyNo: [],
      RefPolicyYear: [],
      ReferenceID1: [],
      ReferenceID2: [],
      SerialNo: [0],
      Endt_ID: [],
      // Aaded new formControlName to make row readonly if coming from selection rows
      newAddedRow: false
    });
  }

  setHiddenValue(ev, iter, key, setKey) {
    (<FormArray>this.entitiRowSelectionForm.controls['ReceiptDetails']).controls[iter].get(key).setValue(ev.item[setKey]);
    (<FormArray>this.entitiRowSelectionForm.controls['ReceiptDetails']).controls[iter].get(key).setValue(ev.item[setKey]);
    let glAccntId = parseInt(ev.item[setKey]);
    let selGLAccnt = this.glaccount[iter].filter(data => data.GLCode === glAccntId)[0]; 
    //if(selAccount.length > 0){
      this.setReqValFormArrayControl('AnalysisCode', iter, selGLAccnt.ProjectIndicator ? true : false);
      this.setReqValFormArrayControl('Department', iter, selGLAccnt.Department ? true : false);
    //}
  }
  setReqValFormArrayControl(contrlname, index, isRequired) {
    //isRequired = true;
    let selCtrl = (<FormArray>this.entitiRowSelectionForm.controls['ReceiptDetails']).controls[index].get(contrlname);
    
    if(contrlname === 'AnalysisCode'){
      this.entitiRowSelectionForm.value.ReceiptDetails[index].isPIRequired = isRequired;
    }
    if(contrlname === 'DepartmentCode'){
      this.entitiRowSelectionForm.value.ReceiptDetails[index].isDepRequired = isRequired;
    }
    if(isRequired){
      if(selCtrl.value === null || selCtrl.value === ''){
      selCtrl.setValidators([Validators.required]);
      selCtrl.markAsTouched();
      selCtrl.markAsDirty();
      selCtrl.setErrors({ 'incorrect': true });
      }
      (<FormArray>this.entitiRowSelectionForm.controls['ReceiptDetails']).controls[index].updateValueAndValidity();
    }
    else{
      selCtrl.clearValidators();
    }
  }

  changeDepartment(event, index){
    this.entitiRowSelectionForm.value.ReceiptDetails[index].isDepRequired = false;
  }

  changeProjectIndicator(event, index){
    this.entitiRowSelectionForm.value.ReceiptDetails[index].isPIRequired = false;
  }
  setCreditEntry(ev, iter, key, data) {
    const actualData = Number(data.controls['Amount'].value);
    const curdata = -(data.controls['Amount'].value);
    data.controls['Amount'].patchValue(curdata);
    this.getSum();
    if (actualData === 0 || actualData === undefined) {
      this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
      this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
      this.bsModalRef.content.modelBodyContent = RSAMSGConstants.EMPTYAMOUNTCHECK;
      this.bsModalRef.content.cancelBtn = RSAMSGConstants.OKTEXT;
      ev.target.checked = true;

    }
    (<FormArray>this.entitiRowSelectionForm.controls['ReceiptDetails']).controls[iter].get(key).setValue(ev.target.checked);
    if (this.totalAmount < 0) {
      ev.target.checked = true;
      this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
      this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
      this.bsModalRef.content.modelBodyContent = RSAMSGConstants.CREDITEXCEEDMSG;
      this.bsModalRef.content.cancelBtn = RSAMSGConstants.OKTEXT;
      data.controls['Amount'].patchValue(-curdata);
      this.getSum();
    }
  }


  // setting current Tab Index to activiate tab
  setcurrentTbIndex(tab) {
    switch (tab) {
      case 'Cash':
        this.currentTbIndex = 2;
        break;
      case 'Cheque':
        this.currentTbIndex = 0;
        break;
      case 'Credit Card':
        this.currentTbIndex = 1;
        break;
      case 'Bank Transfer':
        this.currentTbIndex = 3;
    }
  }
  // Displaying the  confirmation alert on tab click
  confirmTabSwitch(event) {
    console.log(event.target.tagName);
    const parentElement = event.target.parentElement;
    const target = event.target.parentElement.text;
    if (event.target.tagName === 'SPAN' && !parentElement.classList.contains('active') && parentElement.classList.contains('nav-link')) {
      if (this.entitiRowSelectionForm.dirty) {
        // --- showing popup only you have added or changed something
        this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
        this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
        // Will move the content to RSAMSGConstants once approved // 
        this.bsModalRef.content.modelBodyContent = RSAMSGConstants.PAYMENTMODECHANGEMSG;
        this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
        this.bsModalRef.content.actionBtn = RSAMSGConstants.BTNPROCEED;
        this.bsModalRef.content.valueChange.subscribe((data) => {
          console.log(data);
          // changing the currentTbIndex if user proceed
          if (data = RSAMSGConstants.BTNPROCEED) {
            console.log(this.currentTbIndex);
            setTimeout(() => {
              this.setcurrentTbIndex(target);
            }, 0);
            setTimeout(() => {
              this.tabset.tabs.forEach(item => {
                if (item.heading == target) {
                  item.active = true;
                }
              });
            }, 1);
            //if state exists make it as false.  
            if (localStorage.getItem('ERStateExists') != null) {
              localStorage.setItem('ERStateExists', 'false');
              // this.isStateClosed=true;
            }
          }
        });
      } else {
        setTimeout(() => {
          this.setcurrentTbIndex(target);
        }, 0);
        setTimeout(() => {
          this.tabset.tabs.forEach(item => {
            if (item.heading == target) {
              item.active = true;
            }
          });
        }, 1);

      }

    }
  }


  setTerminalCode(ev, key, setKey) {
    console.log(ev, 'ev');
    this.entitiRowSelectionForm.controls[key].setValue(ev.item[setKey]);
  }
  setBankCode(ev, iter, key) {
    this.entitiRowSelectionForm.controls[key].setValue(ev.item.BankCode);
  }

  addReceipt(item, len?, newAdded?) {
    this.glaccount[len] = this.cachedGL;
    const control = <FormArray>this.entitiRowSelectionForm.controls['ReceiptDetails'];
    console.log(control);
    const newRow = this.entitiRowSelectionFormGroup();
    newRow.patchValue(item);
    if (!newAdded) {
      newRow.patchValue({ 'Amount': (item.Amount).toFixed(2) });
    }
    control.push(newRow);
    const CurrentAmount = (<FormArray>this.entitiRowSelectionForm.controls['ReceiptDetails']).controls[len - 1].get('Amount').value;
    if (newAdded) {
      this.setFormArrayCTRLDefaultValue('GLCode', len, 4);
      this.setFormArrayCTRLDefaultValue('GLCodeDesc', len, '4-HSBC BANK MIDDLE EAST - Deira');
      newRow.patchValue({ 'newAddedRow': true });
      // this.getTotallingDetailData(len, false);
      console.log(this.cachedDtlTot, 'len');
      console.log(len, 'len');
      this.costcentredata[len] = this.cachedCostcentredata;
      this.dtltotallingacc[len] = this.cachedDtlTot;

    }
    const newAddedRow = (<FormArray>this.entitiRowSelectionForm.controls['ReceiptDetails']).controls[len - 1].get('newAddedRow').value;
    console.log(newAddedRow, 'newaddrow');

  }

  getReceiptDetails(entitiRowSelectionForm) {
    return entitiRowSelectionForm.controls.ReceiptDetails.controls;
  }
  get cshpayeename() { return this.entitiRowSelectionForm.get('PayeeName'); }
  get cshdetails() { return this.entitiRowSelectionForm.get('EnglishDescription'); }
  get payeebankcode() { return this.entitiRowSelectionForm.get('PayeeBankCode'); }
  get chequedate() { return this.entitiRowSelectionForm.get('ChequeDate'); }
  get instrumentrefno() { return this.entitiRowSelectionForm.get('InstrumentRefNo'); }
  get terminalid() { return this.entitiRowSelectionForm.get('TerminalUserID'); }
  get chequeType() { return this.entitiRowSelectionForm.get('ChequeType'); }
  //get terminalid() { return this.entitiRowSelectionForm.get('TerminalID'); }
  get expirydate() { return this.entitiRowSelectionForm.get('ExpiryDate'); }
  get chequeno() { return this.entitiRowSelectionForm.get('ChequeNo'); }
  get receiptdate() { return this.entitiRowSelectionForm.get('ReceiptDate'); }
  get receiptRows() { return <FormArray>this.entitiRowSelectionForm.get('ReceiptDetails'); }
  get instrumentdate() { return this.entitiRowSelectionForm.get('InstrumentDate'); }

  reSetForm(param) {
    /*set default value here and reset */
    if (param == 1) {
      const arrayFields = ['EnglishDescription', 'ChequeNo', 'PayeeBankCode',
        'PayeeBankName', 'ExpiryDate', 'InstrumentRefNo', 'TerminalUserID', 'ChequeType', 'TransactionNo'];
      this.entitiRowSelectionForm.controls['LocationCode'].reset(localStorage.getItem('locationcode'));
      this.entitiRowSelectionForm.controls['CostCenterCode'].reset(localStorage.getItem('costcentre'));
      this.entitiRowSelectionForm.controls['TotallingAccCode'].reset(1110);
      this.getBankData(true);
      this.entitiRowSelectionForm.controls['RecevierBankCode'].reset(14);
      // this.entitiRowSelectionForm.controls['PayeeName'].reset();
      this.entitiRowSelectionForm.controls['EnglishDescription'].reset();

      arrayFields.forEach((val) => {
        if (this.entitiRowSelectionForm.controls[val] != null && this.entitiRowSelectionForm.controls[val] != undefined) {
          this.entitiRowSelectionForm.controls[val].reset();
        }
      });
      if (this.RcptMode == 2) {
        this.entitiRowSelectionForm.controls['InstrumentDate'].setValue('');
      }
      if (this.RcptMode == 5) {
        this.entitiRowSelectionForm.controls['PayeeBankCode'].setValue('');
        this.entitiRowSelectionForm.controls['ChequeDate'].setValue('');
      }
      if (this.RcptMode == 8) {
        this.entitiRowSelectionForm.controls['TerminalUserID'].setValue(this.defaultUserId || this.terminals[0].UserID);
        this.entitiRowSelectionForm.controls['TerminalID'].setValue(this.defaultTerminalId ||this.terminals[0].TerminalID);
      }
      this.clearerrors();
    } else if (param === 2) {
      (<FormArray>this.entitiRowSelectionForm.controls['ReceiptDetails']).controls.forEach(item => {

        if (item.get('newAddedRow').value !== true) {
          if (this.currentTbIndex == 3) { // defect fix 681 for Bank Transfer
            item.get('Amount').setValue('');
          } else {
            const description = item.get('Description').value;
            const amount = item.get('Amount').value;

            item.reset();
            item.get('Amount').setValue(amount);
            item.get('Description').setValue(description);
          }
        } else {
          item.reset();
          item.get('newAddedRow').setValue(true);
        }
      });
      (<FormArray>this.entitiRowSelectionForm.controls['ReceiptDetails']).controls.map(item => {
        item.get('LocationCode').setValue(localStorage.getItem('locationcode'));
        item.get('CostCenterCode').setValue(localStorage.getItem('costcentre'));
        item.get('RefTransactionType').setValue(3);
        item.get('TotallingAccCode').setValue(1110);
        // item.get('RecevierBankCode').reset(14);
        this.setBankData(1110);
        if (this.currentTbIndex != 3 && item.get('newAddedRow').value !== true) {
          item.get('GLCode').setValue(4);
          item.get('GLCodeDesc').setValue('4-HSBC BANK MIDDLE EAST - Deira');
        }
      });

      this.getSum();
    }
    this.GetAccountingDates();
  }

  deleteReceipt(index: number, itemrow) {
    console.log(itemrow, 'itemrow');
    if (index >= 1) {
      this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
      this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
      this.bsModalRef.content.modelBodyContent = RSAMSGConstants.DELETEMSGRECEIPTL;
      this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
      this.bsModalRef.content.actionBtn = RSAMSGConstants.BTNPROCEED;
      this.bsModalRef.content.valueChange.subscribe((data) => {
        if (data = RSAMSGConstants.BTNPROCEED) {
          const control = <FormArray>this.entitiRowSelectionForm.controls['ReceiptDetails'];
          control.removeAt(index);
          this.getSum();
        }
      });
    } else {
      this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
      this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
      this.bsModalRef.content.modelBodyContent = RSAMSGConstants.CANTDELETEFIRSTROW;
      this.bsModalRef.content.cancelBtn = RSAMSGConstants.OKTEXT;
    }
  }

  checkIsformDirty() {
    this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
    this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
    this.bsModalRef.content.modelBodyContent = RSAMSGConstants.DIRTYFLAGMSGRECIPT;
    this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
    this.bsModalRef.content.actionBtn = RSAMSGConstants.BTNPROCEED;
    this.bsModalRef.content.valueChange.subscribe((data) => {
      if (data = 'Proceed') {
        this.modalService.hide(1);
        this.gridApiService.unCheck();
        this.sharedService.sendMessage('close');
        if (localStorage.getItem('ERStateExists') != null) {
          localStorage.setItem('ERStateExists', 'false');
          this.isStateClosed=true
        }
      }
    });
  }

  clearGLCode(indx, val) {
    this.setFormArrayCTRLDefaultValue('GLCode', indx, '');
    this.setFormArrayCTRLDefaultValue('GLCodeDesc', indx, '');
  }

  validateDetailInfo() {
    this.glerrorcount = 0;
    this.amountZeroCheck = 0;
    this.amountLimitCheck = 0;
    (<FormArray>this.entitiRowSelectionForm.controls['ReceiptDetails']).controls.map(item => {
      item.get('Amount').updateValueAndValidity();
      item.get('Amount').markAsTouched();
      item.get('GLCode').updateValueAndValidity();
      item.get('GLCode').markAsTouched();

      if (item.get('GLCode').value == '1133') {

        item.get('DepartmentCode').setValidators([Validators.required]);
        item.get('AnalysisCode').setValidators([Validators.required]);
        item.get('DepartmentCode').updateValueAndValidity();
        item.get('DepartmentCode').markAsTouched();
        item.get('AnalysisCode').updateValueAndValidity();
        item.get('AnalysisCode').markAsTouched();

      }

      if (item.get('GLCode').value == '1133') {
        if (item.get('DepartmentCode').value == null || item.get('DepartmentCode').value == undefined || item.get('DepartmentCode').value == "") {
          this.glerrorcount = this.glerrorcount + 1;
        }
        if (item.get('AnalysisCode').value == null || item.get('AnalysisCode').value == undefined || item.get('AnalysisCode').value == "") {
          this.glerrorcount = this.glerrorcount + 1;
        }
      }
      if (item.get('GLCode').value == null ||
        item.get('GLCode').value == undefined ||
        item.get('GLCode').value == "") {
        this.glerrorcount = this.glerrorcount + 1;
      }
      if (item.get('Amount').value == null || item.get('Amount').value == 0 ||
        item.get('Amount').value == undefined || item.get('Amount').value == "") {
        this.glerrorcount = this.glerrorcount + 1;
        this.amountZeroCheck = this.amountZeroCheck + 1;
      }

      if (item.get('Amount').value > 999999999.99) {
        this.glerrorcount = this.glerrorcount + 1;
        this.amountLimitCheck = this.amountLimitCheck + 1;
        return false;
      }
    });
  }

  getVoucherDetailsLength() {
    return this.entitiRowSelectionForm.controls.ReceiptDetails['controls'].length;
  }
  submitForm(bsModalRef, receiptno) {
    this.validateDetailInfo();
    if (this.amountZeroCheck > 0) {
      this.alertService.warn(RSAMSGConstants.AMOUNTZEROCHECK);
      return false;
    }
    if (this.amountLimitCheck > 0) {
      this.alertService.warn(RSAMSGConstants.AMOUNTEXCEEDMSG);
      return false;
    }
    if (this.glerrorcount > 0) {
      return false;
    }
    this.usersReq = (this.approverusers !== undefined && this.approverusers !== '' &&
      this.approverusers.length > 0);
    // Removing newAddedRow key from entitiRowSelectionForm
    this.entitiRowSelectionForm.value.ReceiptDetails.map((item, i) => {
      if (item.newAddedRow) {
        delete item.newAddedRow;
      }
    });
    console.log(this.entitiRowSelectionForm.value, 'value');
    let formval = this.entitiRowSelectionForm.value;
    formval["ChequeDate"] = formval["ChequeDateFld"];
    console.log(this.entitiRowSelectionForm.value, 'formval');
    if (this.totalAmount > 0) {
      if (!(localStorage.getItem('country') == '3')) {
        if (this.totalAmount > 99999 && !this.usersReq) {
          return false;
        }
      }
      if (this.prevReceipt == null || this.prevReceipt == undefined) {
        this.prevReceipt = 0;
        formval.ReceiptDetails.map((element, index) => {
          element.SerialNo = 0;
        });
      }
      formval["ReceiptNo"] = this.prevReceipt;

      //send serialNo in update
      if (this.prevReceipt > 0 && (this.previewDataDtl != null || this.previewDataDtl != undefined)) {
        formval.ReceiptDetails.map((element, index) => {
          if (index < this.previewDataDtl.length) {
            element.SerialNo = this.previewDataDtl[index].SerialNo;
          }
        });
      }
      this.createservice.createReceipt(JSON.stringify(formval)).subscribe(
        dataReturn => {
          this.returnValue = dataReturn;
          this.returnValue['approverlist'] = this.approverusers;
          this.returnValue['ondemand'] = false;
          // this.gridApiService.unCheck();
          //this.bsModalRef.hide();
          this.previewFlag = true;
          this.bsModalRef = this.modalService.show(ReceiptpreviewComponent, { class: 'preview-modal-dailog', backdrop: 'static', keyboard: false });
          this.bsModalRef.content.data = this.returnValue;
          this.bsModalRef.content.totalAmount = this.totalAmount;
          // this.bsModalRef.content.backdrop = true;
        },
        errorRturn => {
          this.errorMsg = errorRturn;
        }
      );
    }

    if (this.totalAmount <= 0) {
      this.alertService.warn(RSAMSGConstants.AMOUNTTEXTREQ);
    }

  }

  goPrevious() {
    this.level = 1;
  }
  collapseToheader() {
    this.collapsetoheader = !this.collapsetoheader;
    // (!this.collapsetoheader) ? this.modalService._showBackdrop() : this.modalService.removeBackdrop();
    // this.gridApiService.unCheck();
  }
  GetAccountingDates() {
    this.minDateRd = new Date(localStorage.getItem('accntStartDate'));
    this.maxDateRd = new Date(localStorage.getItem('accntEndDate'));
    const sysDate = new Date();
    if (sysDate < this.minDateRd) {
      this.receiptAccountingDate = new DatePipe('en-US').transform(this.minDateRd, 'dd/MM/yyyy');
    }
    else{
      this.receiptAccountingDate = new DatePipe('en-US').transform(sysDate, 'dd/MM/yyyy');
    }
    this.receiptdate.setValue(this.receiptAccountingDate);
  }
  changeVoucherDate() {
    if (this.receiptdate.value) {
      const receiptDate = new Date(this.receiptdate.value);
      this.receiptdate.setValue(this.receiptAccountingDate);
      let showConfirm;
      let modelContent;
      let getConfirm;
      if (receiptDate > this.maxDateRd) {
        showConfirm = true;
        getConfirm = true;
        modelContent = RSAMSGConstants.VOUCHERDATEGREATERTHANACCOUNTINGEND;
      }
      else if(receiptDate < this.minDateRd){
        showConfirm = true;
        getConfirm = false;
        modelContent = RSAMSGConstants.VOUCHERDATELESSERTHANACCOUNTINGEND;
      }
      if(showConfirm){
        this.receiptdate.setValue(this.receiptAccountingDate);
        this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
        this.bsModalRef.content.modelTitle = '';
        this.bsModalRef.content.modelBodyContent = modelContent;
        this.bsModalRef.content.cancelBtn = getConfirm ? RSAMSGConstants.NOTEXT : null;
        this.bsModalRef.content.actionBtn = getConfirm ? RSAMSGConstants.YESTEXT : RSAMSGConstants.OKTEXT;
        this.bsModalRef.content.valueChange.subscribe((data) => {
          if (data.toString().trim() === 'YES') {
            this.receiptAccountingDate = new DatePipe('en-US').transform(receiptDate, 'dd/MM/yyyy');
            this.receiptdate.setValue(this.receiptAccountingDate);
          }
          this.bsModalRef.hide();
        });
      }
      else{
        this.receiptAccountingDate = new DatePipe('en-US').transform(receiptDate, 'dd/MM/yyyy');
        this.receiptdate.setValue(this.receiptAccountingDate);
      }
    }
  }
  setTerminal(val: any) {
    const currentTerminalID = this.terminals.filter(item => item.UserID == val);
    this.entitiRowSelectionForm.get('TerminalID').setValue(currentTerminalID[0].TerminalID);
  }
}

