import { Component, OnInit, Input } from '@angular/core';
import { BaseSearchComponent } from '../basesearch/basesearch.component';
import { NoresultsmsgComponent } from '../noresultsmsg/noresultsmsg.component';
import { SearchService } from '../../service/search.service';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { PaymentpreviewComponent } from 'src/app/finance/preview/uae/paymentpreview/paymentpreview.component';
import { MessageService } from 'src/app/core/message/service/message.service';
import { CancelPaymentComponent } from 'src/app/finance/payments/cancel-payment/cancel-payment.component';
import { UserAutherizationService } from 'src/app/core/authorization/userauth.service';

@Component({
  selector: 'rsa-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.scss']
})
export class PaymentComponent extends BaseSearchComponent implements OnInit {

  @Input('resultdata') resultdata: any = [];
  @Input('paymentNo') paymentNo: any;
  @Input('category') category: any;
  glnumber: string;
  showtabledata = -1;
  idnumber = '201838683';
  name = ' ';
  pageSize = 15;
  currentpage: any = 1;
  eventRef;
  showCancelDialog = false;
  PaymentID;
  headerdata;
  bsModalRef: BsModalRef;
  previewresult;
  errorMsg;
   claim:string;
  isClaimPayment=false;
  isPayment:boolean;
  totalAmount;
  constructor(private allowAccess: UserAutherizationService, private searchService: SearchService, private modalService: BsModalService,
    private messageService: MessageService) { super(); }

  ngOnInit() {

    super.ngOnInit();
	if(this.category==14){
      this.claim='Claim';
      this.isClaimPayment=true;
    }
    this.isPayment = this.accessItem(202);
  }
  toggle(index: number): void {
    this.showtabledata = (this.showtabledata !== index) ? index : -1;
  }
  checkbox(index: number, resuldata) {

  }
  pageChanged(ev) {
    this.currentpage = ev;
  }

  updateTableHeader(data) {
    this.headerdata = data;

  }
  cancelPayment(ev, data) {
    this.eventRef = ev;
    if (ev.target.checked) {
      this.showCancelDialog = true;
      this.createButton([{ id: '9', name: ' Cancel Payment', access: this.accessItem(202) },]);
      this.PaymentID = data.VoucherNo;
      this.totalAmount= data.Amount;
    } else {
      this.showCancelDialog = false;
    }
  }

  showCancelReceiptDialog() {
    this.showCancelDialog = false;  
    const initialState = {
      PaymentID: this.PaymentID,
      backdrop: true,
      paymentData: this.resultdata,
      ignoreBackdropClick: true,
      isClaimPayment:this.isClaimPayment,
      class: 'receipt-cancel-model',     
      ev: this.eventRef.target
    };
    this.bsModalRef = this.modalService.show(CancelPaymentComponent,
      Object.assign({}, { backdrop: true },
        { ignoreBackdropClick: true }, { initialState }, { class: 'receipt-cancel-model' })
    );
    this.messageService.getMessage().subscribe(result => {
      console.log('results', result);
      // this.messageService.clearMessage();
    });
  }

  hideSnackBar() {
    this.showCancelDialog = false;
    this.eventRef.target.checked = false;
  }

  previewPayment() {
        this.previewresult = this.resultdata[0];
        this.bsModalRef = this.modalService.show(PaymentpreviewComponent, { class: 'preview-modal-dailog', ignoreBackdropClick: true });
        this.bsModalRef.content.data = this.previewresult;
        this.bsModalRef.content.claimPayment=this.isClaimPayment;
        this.bsModalRef.content.totalAmount = this.previewresult.Amount;
        this.bsModalRef.content.backdrop = true;
        this.bsModalRef.content.isView=true;
  }
  accessItem(functionid){
    return this.allowAccess.isAllowed(functionid)
  }
}
