import { Component, OnInit, Input } from '@angular/core';
import { SearchService } from '../../service/search.service';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { SharedService } from 'src/app/finance/services/shared.service';
import { BsModalService } from 'ngx-bootstrap/modal';
import { RSAENDPOINTConstants } from '../../../../core/constants/rsa.api.end.points';
import { BaseSearchComponent } from '../basesearch/basesearch.component';
import { NoresultsmsgComponent } from '../noresultsmsg/noresultsmsg.component';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';
import { CreatePaymentComponent } from 'src/app/finance/payments/create-payment/create-payment.component';
import { GridApiService } from 'src/app/shared/datatable/services/grid-api-service';
import { CnpreviewComponent } from 'src/app/finance/preview/uae/cnpreview/cnpreview.component';
import { PaymentpreviewComponent } from 'src/app/finance/preview/uae/paymentpreview/paymentpreview.component';
import { UserAutherizationService } from 'src/app/core/authorization/userauth.service';
@Component({
  selector: 'rsa-creditnote',
  templateUrl: './credit-note.component.html',
  styleUrls: ['./credit-note.component.scss']
})
export class CreditnoteComponent extends BaseSearchComponent implements OnInit {

  @Input('resultdata') resultdata: any = [];
  @Input('creditNoteNo') creditNoteNo: any;
  @Input('category') category: any;
  @Input() settingsdata: any;
  @Input() headerdata: any;

  glnumber: string;
  idnumber = '';
  name = ' ';
  pageSize = 15;
  currentpage: any = 1;
  totalAmount = 0;
  totalCount = 0;
  showSnackBar = false;
  bsModalRef: BsModalRef;
  customerName;
  selectedItems = [];
  newSelectedRowEntitiDataTable = [];
  selectedTransactionItems = [];
  isCN: boolean;

  constructor(private allowAccess: UserAutherizationService, private searchService: SearchService, private modalService: BsModalService,
    private sharedService: SharedService, private gridApiService: GridApiService,
    private alertService: AlertService) { super() }

  ngOnInit() {
    super.ngOnInit();
    this.isCN = this.accessItem(210);
    this.createButton([
      { id: '14', name: 'Payment', access: this.accessItem(211) }
    ]);
    this.sharedService.getMessage().subscribe(val => {
      console.log(val);
      if (val) {
        this.updateSelectedItemData();
        this.unSelectCheckbox();
      } else {
        this.unSelectCheckbox();
      }
    });
  }
  pageChanged(ev) {
    this.currentpage = ev;
  }
  updateTableHeader(data) {
    this.headerdata = data;
  }
  selectCreditNoteData(index, ev) {
    this.selectedItems = [];
    this.totalAmount = 0;
    this.totalCount = 0;
    this.resultdata[0].policyDetails.map((ele, index) => {
      if (this.selectedTransactionItems[index]) {
        this.selectedItems.push(ele);
        this.totalCount = this.totalCount + 1;
        this.totalAmount = this.totalAmount + ((ele.Amount != null && ele.Amount != undefined) ? parseFloat(ele.Amount) : 0)
      }
    });
    this.showSnackBar = (this.selectedItems.length > 0) ? true : false;
  }

  updateSelectedItemData() {
    this.newSelectedRowEntitiDataTable = [];
    for (let i = 0, l = this.selectedItems.length; i < l; i++) {
      const item = this.selectedItems[i];
      item.Amount = -(item.Amount);
      item.RefTranType = "CREDIT NOTE";
      item.RefTransactionType = 10;
      item.RefTransactionID = item.CreditNoteNo;
      this.newSelectedRowEntitiDataTable[i] = item;
      console.log(this.newSelectedRowEntitiDataTable, 'newSelectedRowEntitiDataTablefunct');
    }
  }

  buttonHandler(e) {
    let flagDisplay = false;
    // if (this.totalAmount > 0 && e === '14') {
    //   this.alertService.warn(RSAMSGConstants.MSGPAYMENTLESSZERO);
    //   return false;
    // }
    // else if (this.totalAmount < 0 && e === '11') {
    //   this.alertService.warn(RSAMSGConstants.CREDITEXCEEDMSG);
    //   return false;
    // }
    if (e === '14') {

      /* validation not req here confrimed by rahul */
      // if (this.totalAmount > 0) {
      //   this.alertService.warn(RSAMSGConstants.MSGPAYMENTLESSZERO);
      //   return false;
      // }
      this.updateSelectedItemData();
      const totalAmount = this.newSelectedRowEntitiDataTable.reduce((prevVal, elem) => prevVal + elem.Amount, 0);

      const initialState = {
        backdrop: true,
        ignoreBackdropClick: false,
        selectedRowEntitiDataTable: this.selectedItems,
        customerName: this.customerName,
        totalAmount: totalAmount,
        ondemandFlag: false,
        isRowPaymentEntity: true,
        isCN: true,
      };
      this.showSnackBar = false;
      this.bsModalRef = this.modalService.show(CreatePaymentComponent, {
        class: 'create-modal-dailog',
        initialState
      });
    }
    if (flagDisplay) {
      this.showSnackBar = false;
      this.bsModalRef.content.totalamount = this.totalAmount;
      this.bsModalRef.content.totalcount = this.totalCount;
      this.bsModalRef.content.selectedRowEntitiDataTable = this.selectedItems;
    }
  }
  hideSnackBar(e) {
    this.showSnackBar = false;
    this.selectedTransactionItems = [];
  }
  unSelectCheckbox() {
    this.gridApiService.unCheck();
  }

  previewCreditNote() {
    this.bsModalRef = this.modalService.show(CnpreviewComponent, { class: 'preview-modal-dailog', ignoreBackdropClick: true });
    this.bsModalRef.content.data = this.resultdata[0];
    this.bsModalRef.content.fromCategory = 5;
    this.bsModalRef.content.totalAmount = this.resultdata[0].totalAmount;
    this.bsModalRef.content.backdrop = true;
    this.bsModalRef.content.isView = true;
  }
  previewPayment(paymentData) {
    if (paymentData) {
      this.bsModalRef = this.modalService.show(PaymentpreviewComponent, { class: 'preview-modal-dailog', ignoreBackdropClick: true });
      this.bsModalRef.content.data = paymentData;
      this.bsModalRef.content.claimPayment = false;
      this.bsModalRef.content.totalAmount = paymentData.Amount;
      this.bsModalRef.content.backdrop = true;
      this.bsModalRef.content.isView = true;
    }
  }

  accessItem(functionid) {
    return this.allowAccess.isAllowed(functionid)
  }
}
