import { Component, OnInit, Input } from '@angular/core';
import { SearchService } from '../../service/search.service';
import { RSAENDPOINTConstants } from '../../../../core/constants/rsa.api.end.points';
import { BaseSearchComponent } from '../basesearch/basesearch.component';
import { NoresultsmsgComponent } from '../noresultsmsg/noresultsmsg.component';
import { MessageService } from 'src/app/core/message/service/message.service';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { CreatejvComponent } from 'src/app/finance/createjv/createjv.component';
import { CreateZerojvComponent } from '../../../createjv/create-zerojv/create-zerojv.component';
import { CreateReversejvComponent } from '../../../createjv/create-reversejv/create-reversejv.component';
import { JvpreviewComponent } from 'src/app/finance/preview/uae/jvpreview/jvpreview.component';
import { DrfatService } from 'src/app/finance/drfats/drafts-results/services/drafts.service';
import { UserAutherizationService } from 'src/app/core/authorization/userauth.service';

@Component({
  selector: 'rsa-journal',
  templateUrl: './journal.component.html',
  styleUrls: ['./journal.component.scss']
})
export class JournalComponent extends BaseSearchComponent implements OnInit {

  errormsg: string;
  cathecoulmnHeaderConfigData: any;
  coulmnHeaderConfigData: any;
  isopen: boolean;
  @Input('resultdata') resultdata: any = [];
  @Input('journalNo') journalNo: any;
  @Input('category') category: any;
  @Input() settingsdata: any;
  @Input() headerdata: any;

  glnumber: string;
  idnumber = '';
  name = ' ';
  pageSize = 15;
  currentpage: any = 1;
  eventRef;
  showCancelDialog = false;
  jvNo;
  bsModalRef: BsModalRef;
  newSelectedRowJvDataTable;
  selectedRowJvDataTable;
  jvDetailData: any = [];
  isJournal:boolean;
  

  constructor(private allowAccess: UserAutherizationService, private searchService: SearchService, private modalService: BsModalService,
    private messageService: MessageService,private drfatService: DrfatService) { super(); }

  ngOnInit() {
    super.ngOnInit();
    this.isJournal = this.accessItem(214);
  }

  pageChanged(ev) {
    this.currentpage = ev;
  }
  updateTableHeader(data) {
    this.headerdata = data;
  }


  checkJv(ev,jvNo) {


    this.eventRef = ev;
    if (ev.target.checked) {
      this.showCancelDialog = true;
      this.createButton([
        { id: '111', name: 'Reverse Jv', access: this.accessItem(215)},
        { id: '222', name: 'Zero Jv',  access: this.accessItem(216)},
      ]);
      this.jvNo = jvNo;
    } else {
      this.showCancelDialog = false;
    }
    
  }
  accessItem(functionid){
    return this.allowAccess.isAllowed(functionid)
  }
     showZeroReverseDialog(e)
        {
          console.log('this.resultdata[0]:=>',this.resultdata[0])
          this.showCancelDialog = false;
          const initialState = {
            selectedRowItem: this.resultdata[0],
            backdrop: true,
            ignoreBackdropClick: true,
            class: 'receipt-cancel-model',
            ev: this.eventRef.target
          };
            if(e == '111'){              

             this.bsModalRef = this.modalService.show(CreateReversejvComponent, { class: 'create-modal-dailog',initialState  });
         
                                
            }
            if(e == '222'){
                        
              this.bsModalRef = this.modalService.show(CreateZerojvComponent, { class: 'create-modal-dailog',initialState  });
              this.bsModalRef.content.title = 'Journal Voucher';
                 
            }
          



        }

        hideSnackBar() {
          this.showCancelDialog = false;
          this.eventRef.target.checked = false;
        }

        //Jv preview 
        Jvpreview(journalNo) {
          this.drfatService.getDrfatsJournal(journalNo).subscribe((data) => {
            this.jvDetailData = data;
            this.jvDetailData['fromDraftView'] = 'true';
            console.log(data, 'detaildata');
            this.bsModalRef = this.modalService.show(JvpreviewComponent, { class: 'preview-modal-dailog', ignoreBackdropClick: true });
            this.bsModalRef.content.data = this.jvDetailData;
            this.bsModalRef.content.backdrop = true;
          });
        }

}
