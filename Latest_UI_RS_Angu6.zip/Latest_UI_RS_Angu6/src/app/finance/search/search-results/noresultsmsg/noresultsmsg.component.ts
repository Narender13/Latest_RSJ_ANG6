import { Component, OnInit, Input } from '@angular/core';
import { RSAMSGConstants } from '../../../../core/constants/rsa.msg.constants';
@Component({
  selector: 'rsa-no-result',
  templateUrl: './noresultsmsg.component.html',
  styleUrls: ['./noresultsmsg.component.css']
})
export class NoresultsmsgComponent implements OnInit {
  constructor() { }
  msg: string;

  ngOnInit() {
    this.msg = RSAMSGConstants.NORESULTMSG;
  }

}
