import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, FormArray, Validators } from '@angular/forms';
import { slideInOut } from '../../../../shared/animation/slidein';
import { AdvocateService } from './service/advocate.service';
import { catchError, map, shareReplay } from 'rxjs/operators';
import { ConfirmationDialogComponent } from 'src/app/shared/custom-model/custom-model.component';
import { SuccessDialogComponent } from 'src/app/shared/custom-success-model/custom-success-model.component';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';
import { DatePipe } from '@angular/common';
import { Router} from '@angular/router';

@Component({
  selector: 'rsa-create-advocate',
  templateUrl: './create-advocate.component.html',
    styleUrls: ['./create-advocate.component.scss'],
    animations: [slideInOut]
})
export class CreateAdvocateComponent implements OnInit {

    advocateForm: FormGroup;
    clonedAdvocate: FormGroup;
    submitted = false;
    address = false;
    address1 = false;
    address2 = false;
    isArabicField = false;
    errorname: boolean;
    erroremail: boolean;
    errorphonenumber: boolean;
    errormobilenumber: boolean;
    erroraddress: boolean;
    errorEngNameexists: boolean;
    errorPhoneNumberexists: boolean;
    errorMobileNumberexists: boolean;
    errorEngEmailexists: boolean;
    specializationList: any[];
    statusList: any[];
    ratingList: any[];
    returnValue: any;

    selectedTypeVal: any;
    errorCategoryExists: boolean;
    @ViewChild('newSpecialization') private newSpecialization: ElementRef;
    isCategoryAdded: boolean;
   

  today = new Date();
  constructor(private fb: FormBuilder, private advocateService: AdvocateService,
      public bsModalRef: BsModalRef, private modalService: BsModalService,private router: Router) { }
  ngOnInit() {
     this.createEntityForm();
      this.fieldStatusChanges();
      this.getspecialization();
      this.getstatus();
      this.getrating();
      
  }
  createEntityForm(): void {
      this.advocateForm = this.fb.group({
          //Code: [1],
          EngName: ['', Validators.required],
          ArabicName: [''],
          EngEmail: ['', [Validators.required, Validators.email]],
          PhoneNumber: ['', Validators.required],
          MobileNumber: ['', Validators.required],
          Fax: [''],
          EngAddress1: ['', Validators.required],
          ArabicAddress1: [''],
          EngAddress2: [''],
          ArabicAddress2: [''],
          EngAddress3: [''],
          ArabicAddress3: [''],
          EngZIP: [''],
          Court: [''],
          Specilisation: [''],
          CumlativeFees: [''],
          CumlativeCases: [''],
          Rating: [''],
          Status: [''],
          PreparedByStr: [localStorage.getItem('userId')],
          IsValid: [0]
      });
  }
  get namedesc() {
      return this.advocateForm.get('EngName');
  };
  get emaildesc() {
      return this.advocateForm.get('EngEmail');
  };
  get phonenumberdesc() {
      return this.advocateForm.get('PhoneNumber');
  }
  get mobilenumberdesc() {
      return this.advocateForm.get('MobileNumber');
  }
 
  get addressdesc() {
      return this.advocateForm.get('EngAddress1');
  }
  fieldStatusChanges() {
      this.clearerrors();
      this.namedesc.statusChanges.subscribe(
          status => {
              this.errorname = (status == 'INVALID');
          }
      );
      this.emaildesc.statusChanges.subscribe(
          status => {
              this.erroremail = (status == 'INVALID');
          }
      );
      this.phonenumberdesc.statusChanges.subscribe(
          status => {
              this.errorphonenumber = (status == 'INVALID');
          }
      );
      this.mobilenumberdesc.statusChanges.subscribe(
          status => {
              this.errormobilenumber = (status == 'INVALID');
          }
      );
     
      this.addressdesc.statusChanges.subscribe(
          status => {
              this.erroraddress = (status == 'INVALID');
             
          }
      );
  }
  clearerrors() {
      this.errorname = false;
      this.erroremail = false;
      this.errorphonenumber = false;
      this.errormobilenumber = false;
      this.erroraddress = false;
      this.errorEngNameexists = false;
      this.errorPhoneNumberexists = false;
      this.errorMobileNumberexists = false;
      this.errorEngEmailexists = false;
  }
  getspecialization() {
      this.advocateService.getspecialization().subscribe(
          dataReturn => {
              this.specializationList = dataReturn;
          },
          errorRturn => {
              console.log(errorRturn);
          }
      );
  }
  getstatus() {
      this.advocateService.getstatus().subscribe(
          dataReturn => {
              this.statusList = dataReturn;
          },
          errorRturn => {
              console.log(errorRturn);
          }
      );
  }
  getrating() {
      this.advocateService.getrating().subscribe(
          dataReturn => {
              this.ratingList = dataReturn;
          },
          errorRturn => {
              console.log(errorRturn);
          }
      );
  }
  get f() { return this.advocateForm.controls; }
  setErrorInvalid() {
      this.errorname = this.namedesc.invalid;
      this.erroremail = this.emaildesc.invalid;
      this.errorphonenumber = this.phonenumberdesc.invalid;
      this.errormobilenumber = this.mobilenumberdesc.invalid;
      this.erroraddress = this.addressdesc.invalid;
  }
  submitForm() {
      this.setErrorInvalid();
      if (this.advocateForm.invalid) {
          return;
      }
      else {
          console.log("\n second form values" + JSON.stringify(this.advocateForm.value) + "\n");
          let clonedAdvocateForm: any = this.advocateForm.value;
          clonedAdvocateForm.AdvSpec = { "EDesc": this.isCategoryAdded ? this.specializationList[this.specializationList.length - 1].E_desc : "", "IsNewSel": this.advocateForm.controls['Specilisation'].value === '0' ? true : false };
          console.log("cloned values\n" + JSON.stringify(clonedAdvocateForm));
          this.advocateService.createAdvocate(JSON.stringify(clonedAdvocateForm)).subscribe(
              dataReturn => {
                  this.returnValue = dataReturn;
                  console.log(this.returnValue, 'this.returnValue');
                  if (this.returnValue.IsValid == 0) {
                      this.bsModalRef = this.modalService.show(SuccessDialogComponent, { class: 'confirmation-dailog-box modal-md', ignoreBackdropClick: true });
                      this.bsModalRef.content.modelTitle = '';
                      this.bsModalRef.content.modelBodyContent = "Advocate Succesfully created";
                      this.bsModalRef.content.smallMessage = "ID: " + this.returnValue.Code;
                      this.bsModalRef.content.bigMessage =" Advocate Name: "+ this.returnValue.EngName;
                      this.bsModalRef.content.actionBtn = "Close";
                      this.bsModalRef.content.valueChange.subscribe((data) => {
                          console.log(" success datat" + data);
                          if (data == 'Close') {
                              console.log("close btn clicked");
                          } else {
                              console.log(" else close");
                          }
                          this.resetForm();
                      });
                  }
                  else if (this.returnValue.IsValid == 2) {
                      this.errorEngNameexists = true;
                      this.errorPhoneNumberexists = true;
                      this.errorMobileNumberexists = true;
                      this.errorEngEmailexists = true;
                  }
              },
              errorRturn => {
                  console.log(errorRturn);
              }
          );
      }
  }
  resetForm() {
      let arrayFormFields = ['EngName', 'ArabicName', 'EngEmail', 'PhoneNumber', 'MobileNumber', 'Fax',
          'EngAddress1', 'ArabicAddress1', 'EngAddress2', 'ArabicAddress2', 'EngAddress3', 'ArabicAddress3', 'EngZIP',
          'Court', 'Specilisation', 'CumlativeFees', 'CumlativeCases', 'Rating', 'Status'];
      this.advocateForm.controls['IsValid'].reset(0);
      arrayFormFields.forEach((val) => {
          if (this.advocateForm.controls[val] != null && this.advocateForm.controls[val] != undefined) {
              this.advocateForm.controls[val].reset();
          }
      });
      this.clearerrors();
    }
    addNewCategory(catValue: any) {
        if (catValue === 'newCategoryType') {
            console.log(catValue + " new category " + this.advocateForm.controls['Specilisation'].value);
            this.selectedTypeVal = catValue;
            this.advocateForm.controls['Specilisation'].setValue("");
        }

    }
    addToCateroryList() {
        this.newSpecialization.nativeElement.value = this.newSpecialization.nativeElement.value.trim(); 
        if (this.newSpecialization.nativeElement.value) {
            if (this.checkDuplicatesInCategoryList() == true) {
                console.log("gggg");
                this.errorCategoryExists = true;
            } else {
                let newCategory: any = { "Code": 0, "E_desc": this.newSpecialization.nativeElement.value };
                this.isCategoryAdded = true;
                this.specializationList.push(newCategory);
               // this.advocateForm.controls['Specilisation'].setValue("");
                this.selectedTypeVal = "";
                this.errorCategoryExists = false;
            }

        }
    }
    hideAddCategory() {
        this.advocateForm.controls['Specilisation'].setValue("");
        this.selectedTypeVal = "";
        this.errorCategoryExists = false;
    }
    checkDuplicatesInCategoryList() {
        let duplicateValueExists: boolean = false;
        this.specializationList.forEach((item) => {
            if (this.newSpecialization.nativeElement.value == item.E_desc) {
                duplicateValueExists = true;
            }
        });
        return duplicateValueExists;
    }
    cancelForm(){
        this.router.navigate(['/home']);
    }


}
