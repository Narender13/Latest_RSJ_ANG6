import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RecoveryeditComponent } from './recoveryedit.component';

describe('RecoveryeditComponent', () => {
  let component: RecoveryeditComponent;
  let fixture: ComponentFixture<RecoveryeditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RecoveryeditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RecoveryeditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
