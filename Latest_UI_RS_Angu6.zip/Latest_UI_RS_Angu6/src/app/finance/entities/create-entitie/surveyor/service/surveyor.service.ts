import { Injectable } from '@angular/core';
import { HttpHeaders, HttpErrorResponse, HttpClient, HttpParams, } from '@angular/common/http';
import { RSAENDPOINTConstants } from 'src/app/core/constants/rsa.api.end.points';
import { handleErrorObservable } from 'src/app/shared/utilites/helper';
import { catchError, map, shareReplay } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class SurveyorService {

    constructor(private http: HttpClient) { }
    createSurveyor(params: any) {
        return this.http.post<any>(RSAENDPOINTConstants.CREATESURVEYOR, params).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('createSurveyor')));
    }
    getPayeeBankNames() {
        return this.http.get<any>(RSAENDPOINTConstants.LOADPAYEEBANKNAMES).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getPayeeBankNames')));

    }
    getBranchNames(params: any) {
        return this.http.get<any>(RSAENDPOINTConstants.ADMINMASTER + params).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getBranchNames')));
    } 
   
    getNationality() {
        return this.http.get<any>(RSAENDPOINTConstants.NATIONALITY).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getNationality')));
    } 
    getcorrbankname() {
        return this.http.get<any>(RSAENDPOINTConstants.LOADPAYEEBANKNAMES).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getcorrbankname')));

    }
    getspecialization() {
        return this.http.get<any>(RSAENDPOINTConstants.SPECIALIZATION).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getspecialization')));

    }
    getstatus() {
        return this.http.get<any>(RSAENDPOINTConstants.STATUS).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getstatus')));

    }
    getrating() {
        return this.http.get<any>(RSAENDPOINTConstants.RATING).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getrating')));

    }
    getqualification() {
        return this.http.get<any>(RSAENDPOINTConstants.QUALIFICATION).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getqualification')));

    }
    getSurveyorDetails(params: any) {
        return this.http.get<any>(RSAENDPOINTConstants.GETSURVEYOR + params).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getSurveyorDetails')));
    }
    updateSurveyorDetails(params: any) {
        return this.http.put<any>(RSAENDPOINTConstants.UPDATESURVEYOR, params).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('updateSurveyorDetails')));
    }
   
}
