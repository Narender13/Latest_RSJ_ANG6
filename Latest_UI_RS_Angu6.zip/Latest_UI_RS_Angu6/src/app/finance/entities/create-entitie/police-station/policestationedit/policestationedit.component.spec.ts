import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PolicestationeditComponent } from './policestationedit.component';

describe('PolicestationeditComponent', () => {
  let component: PolicestationeditComponent;
  let fixture: ComponentFixture<PolicestationeditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PolicestationeditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PolicestationeditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
