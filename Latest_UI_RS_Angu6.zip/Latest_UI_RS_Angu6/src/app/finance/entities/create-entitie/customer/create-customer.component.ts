import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, FormArray, Validators, } from '@angular/forms';
import { slideInOut } from '../../../../shared/animation/slidein';
import { catchError, map, shareReplay } from 'rxjs/operators';
import { CustomerService } from 'src/app/finance/entities/create-entitie/customer/service/customer.service';
import { ConfirmationDialogComponent } from 'src/app/shared/custom-model/custom-model.component';
import { SuccessDialogComponent } from 'src/app/shared/custom-success-model/custom-success-model.component';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';
import { DatePipe } from '@angular/common';
import { Router} from '@angular/router';


@Component({
    selector: 'rsa-create-customer',
    templateUrl: './create-customer.component.html',
    styleUrls: ['./create-customer.component.scss'],
    animations: [slideInOut]
})
export class CreateCustomerComponent implements OnInit {
    customerForm: FormGroup;
    isArabicField = false;
    address1 = false;
    address2 = false;
    submitted = false;
    today = new Date();   
    errorCustomerType: boolean;
    errorName: boolean;
    errorNameExists:boolean;
    errorRegNo: boolean;
    errorRegNoExists:boolean;
    errorRegExpDate: boolean;
    errorVatRegno: boolean;
    errorVatRegnoExists:boolean;
    errorBranch:boolean;
    errorEmail: boolean;
    errorEmailExists:boolean;
    errorPhoneno: boolean;
    errorPhonenoExists:boolean;
    errorMobileno: boolean;
    errorMobilenoExists:boolean;
    errorAddress1: boolean;
    errorAddress2: boolean;
    errorBuildingno: boolean;
    errorStreet: boolean;
    errorPObox: boolean;
    errorPostalCode: boolean;
    errorNationality: boolean;
    customerTypes: any = [];
    brokerNames: any = [];
    titles: any = [];
    vatCodes: any = [];
    nationalityList: any = [];
    branchList: any = [];
    bankNamesList: any = [];
    customerGroupList: any = [];
    statusList: any = [];
    accountExecutiveList: any = [];
    returnValue: any;
    isOman: any;
  

    //application: AllowedApplicationModules[] = [];
    
    constructor(
        private fb: FormBuilder,
        protected customerService: CustomerService,public bsModalRef: BsModalRef,
        private modalService: BsModalService,private router: Router) { }

    ngOnInit() {
        this.createEntiteForm();
        this.fieldStatusChanges();
        this.getPayeeBankNames();
        this.getBranchNames();
        this.getCustomerType();
        this.getBrokerNames();
        this.getTitle();
        this.getVatCode();
        this.getNations();
        this.getStatus();
        this.getAcExcecutive();
        this.isOman = localStorage.getItem('defaultcity') == 'NLGIC' ? true : false;
    }
    createEntiteForm(): void {
        this.customerForm = this.fb.group({
          //  CustomerId:[1],
            CustomerType: ['', Validators.required],
            BrokerCode: [],
            NameTitle: [],
            EName: ['', Validators.required],
            AName:[],
            ERegsitrationNo: ['', Validators.required],
            RegnExpDate: ['', Validators.required],
            VATCode: [],
            VATRegistrationNo: ['', Validators.required],
            EEmailId: ['', [Validators.required, Validators.email]],
            EPhoneNo: ['', Validators.required],
            EMobileNo: ['', Validators.required],
            FaxNo: [],
            EAddress1: ['', Validators.required],
            AAddress1:[],
            EAddress2: ['', Validators.required],
            AAddress2: [],
            EBuildingNo: ['', Validators.required],
            EStreet: ['', Validators.required],
            EPOBox: ['', Validators.required],
            EPostalCode: ['', Validators.required],
            Nationality: ['', Validators.required],
            Branch: [localStorage.getItem('locationcode'), Validators.required],
            BenfBank: [],
            BenfAccNo: [],
            IBANNo: [],
            BenfBankAdd: [],
            BenfSwiftCode: [],
            BenfSortCode: [],
            CorrBank: [],
            CorrAccNo: [],
            CorrBankSwiftCode: [],
            CorrBankAddr: [],
            CorrSortCode: [],
            CustomerGroup: [],
            Business: [],
            //ERemarks: [],
            PPIdentifier: [],
            TurnOver: [],
            NoOfEmployees: [],
            ClaimsCoInsurance: [],
            CreditAmount: [],
            CreditDays: [],
            Status: [],
            AccExecutive: [],
            ExcessDebit: [],
            IntimationAlerts: [],
           
            PreparedByStr: [localStorage.getItem('userId')],
            IsValid:[0]

           
        });
    }
    clearerrors() {
        this.errorCustomerType = false;
        this.errorName = false;
        this.errorNameExists=false;
        this.errorRegNo = false;
        this.errorRegNoExists=false;
        this.errorRegExpDate = false;
        this.errorVatRegno = false;
        this.errorVatRegnoExists=false;
        this.errorBranch=false;
        this.errorEmail = false;
        this.errorEmailExists=false;
        this.errorPhoneno = false;
        this.errorPhonenoExists=false;
        this.errorMobileno = false;
        this.errorMobilenoExists=false;
        this.errorAddress1 = false;
        this.errorAddress2 = false;
        this.errorBuildingno = false;
        this.errorStreet = false;
        this.errorPObox = false;
        this.errorPostalCode = false;
        this.errorNationality = false;
    } 
    get custtype() { return this.customerForm.get('CustomerType'); }
    get name() { return this.customerForm.get('EName'); }
    get regno() { return this.customerForm.get('ERegsitrationNo'); }
    get regexpdate() { return this.customerForm.get('RegnExpDate'); }
    get vatregno() { return this.customerForm.get('VATRegistrationNo'); }
    get email() { return this.customerForm.get('EEmailId'); }
    get phoneno() { return this.customerForm.get('EPhoneNo'); }
    get mobileno() { return this.customerForm.get('EMobileNo'); }
    get address() { return this.customerForm.get('EAddress1'); }
    get adddress() { return this.customerForm.get('EAddress2'); }
    get buildingno() { return this.customerForm.get('EBuildingNo'); }
    get street() { return this.customerForm.get('EStreet'); }
    get pobox() { return this.customerForm.get('EPOBox'); }
    get postalcode() { return this.customerForm.get('EPostalCode'); }
    get nationality() { return this.customerForm.get('Nationality'); }
    get branch(){return this.customerForm.get('Branch');}
    changeExpiryDate() {
        if (this.customerForm.controls['RegnExpDate'].value) {
          const RegnExpDate = new Date(this.customerForm.controls['RegnExpDate'].value);
          this.customerForm.controls['RegnExpDate'].setValue(new DatePipe('en-US').transform(RegnExpDate, 'dd/MM/yyyy'));
        }    
    }
        
 // onDateValueChange(ev) {
    //  this.customerForm.controls['RegnExpDate'].setValue(new DatePipe('en-US').transform(new Date(ev), 'dd/MM/yyyy'));
  // }
    fieldStatusChanges() {

        this.clearerrors();
        this.custtype.statusChanges.subscribe(
            status => {
                this.errorCustomerType = (status == 'INVALID');
           
            }
        );
        this.name.statusChanges.subscribe(
            status => {
                this.errorName = (status == 'INVALID');
             
            }
        );
        this.regno.statusChanges.subscribe(
            status => {
                this.errorRegNo = (status == 'INVALID');
               
            }
        );
        this.regexpdate.statusChanges.subscribe(
            status => {
                this.errorRegExpDate = (status == 'INVALID');
                
            }
        );
        this.vatregno.statusChanges.subscribe(
            status => {
                this.errorVatRegno = (status == 'INVALID');
              
            }
        );
        this.email.statusChanges.subscribe(
            status => {
                this.errorEmail = (status == 'INVALID');
             
            }
        );
        this.phoneno.statusChanges.subscribe(
            status => {
                this.errorPhoneno = (status == 'INVALID');
                
            }
        );
        this.mobileno.statusChanges.subscribe(
            status => {
                this.errorMobileno = (status == 'INVALID');
                
            }
        );
        this.address.statusChanges.subscribe(
            status => {
                this.errorAddress1 = (status == 'INVALID');
               
            }
        );
        this.adddress.statusChanges.subscribe(
            status => {
                this.errorAddress2 = (status == 'INVALID');
               
            }
        );
        this.buildingno.statusChanges.subscribe(
            status => {
                this.errorBuildingno = (status == 'INVALID');
             
            }
        );
        this.street.statusChanges.subscribe(
            status => {
                this.errorStreet = (status == 'INVALID');
           
            }
        );
        this.pobox.statusChanges.subscribe(
            status => {
                this.errorPObox = (status == 'INVALID');
            
            }
        );
        this.postalcode.statusChanges.subscribe(
            status => {
                this.errorPostalCode = (status == 'INVALID');
              
            }
        );
        this.nationality.statusChanges.subscribe(
            status => {
                this.errorNationality = (status == 'INVALID');
               
            }
        );
        this.branch.statusChanges.subscribe(
            status=>{
                this.errorBranch=(status=='INVALID');
            }
        )
    }
   
    get f() { return this.customerForm.controls; }

    submitForm() {   

        this.errorCustomerType = this.custtype.invalid;
        this.errorName = this.name.invalid;
        this.errorRegNo = this.regno.invalid;
        this.errorRegExpDate = this.regexpdate.invalid;
        this.errorVatRegno = this.vatregno.invalid;
        this.errorEmail = this.email.invalid;
        this.errorPhoneno = this.phoneno.invalid;
        this.errorMobileno = this.mobileno.invalid;
        this.errorAddress1 = this.address.invalid;
        this.errorAddress2 = this.adddress.invalid;
        this.errorBuildingno = this.buildingno.invalid;
        this.errorStreet = this.street.invalid;
        this.errorPObox = this.pobox.invalid;
        this.errorPostalCode = this.postalcode.invalid;
        this.errorNationality = this.nationality.invalid;
        this.errorBranch=this.branch.invalid;

        if (this.customerForm.invalid) {
            return;
        }
        else {     
          if(this.customerForm.value.ExcessDebit==true){
            this.customerForm.value.ExcessDebit="Y";
          }
          if(this.customerForm.value.IntimationAlerts==true){
            this.customerForm.value.IntimationAlerts="Y";
          }

          console.log("\n second form values"+JSON.stringify(this.customerForm.value)+"\n");
       
            this.customerService.createCustomer(JSON.stringify(this.customerForm.value)).subscribe(
                dataReturn => {
                    this.returnValue = dataReturn;
                    
                    console.log(this.returnValue, 'this.returnValue');

                    //success modal
                    if(this.returnValue.IsValid==0){
                        this.bsModalRef = this.modalService.show(SuccessDialogComponent, { class: 'confirmation-dailog-box modal-md', ignoreBackdropClick: true });
                        this.bsModalRef.content.modelTitle = '';
                        this.bsModalRef.content.modelBodyContent ="Customer successfully created.";
                        this.bsModalRef.content.smallMessage="ID: "+this.returnValue.Code;
                        this.bsModalRef.content.bigMessage = "Customer Name: "+this.returnValue.EngName;
                       // this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
                        this.bsModalRef.content.actionBtn ="Close";
                        this.bsModalRef.content.valueChange.subscribe((data) => {
                            console.log(" success datat" + data);
                            if(data=='Close'){
                                console.log("close btn clicked");
                            }else {
                                console.log(" else close");
                            }
                             this.resetForm();
                        });
                   }else if(this.returnValue.IsValid==1){
                        //alert modal
                     this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md', ignoreBackdropClick: true });
                     this.bsModalRef.content.modelTitle = '';
                     this.bsModalRef.content.modelBodyContent ="Alert! Other than VAT Registration Number and Registration Number remaining fields  already exists.";
                     this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
                     this.bsModalRef.content.actionBtn = "Proceed";
                     this.bsModalRef.content.valueChange.subscribe((data) => {
                         console.log("datat" + data);  
                        
                         if(data ='Proceed'){                            
                            console.log("proceed btn clicked");
                            this.customerForm.value.IsValid=1;
                            this.submitForm();
                        }
                        else   if(data ='PROCEED'){
                            console.log("erer");
                        }
                        else {
                            console.log(" else close");
                        }   
                     });
                     //end for alert modal
                   }
                   else if(this.returnValue.IsValid==2){
                    this.errorEmailExists=true;
                    this.errorMobilenoExists=true;
                    this.errorNameExists=true;
                    this.errorPhonenoExists=true;
                    this.errorVatRegnoExists=true;
                    this.errorRegNoExists=true;
                   } 
                },
                errorRturn => {
                    console.log(errorRturn);
                }
            );
        }

             
        //console.log(this.customerForm.value);
     
    }
    getPayeeBankNames() {
        this.customerService.getPayeeBankNames().subscribe(
            dataReturn => {
                //console.log("data" + JSON.stringify(dataReturn));
                this.bankNamesList = dataReturn;
            },
            errorRturn => {
              console.log(errorRturn);
            }
        );
    }
   getBranchNames() {
        const param = 'ctyCode=' + localStorage.getItem('countrycode') +
            '&regCode=' + localStorage.getItem('regioncode');
        this.customerService.getBranchNames(param).subscribe(
            dataReturn => {
                //console.log("data1" + JSON.stringify(dataReturn));
                this.branchList = dataReturn;
               // this.customerForm.get('Branch').disable();
            },
            errorRturn => {
                console.log(errorRturn);
            }
        );
    }
    getCustomerType() {
        this.customerService.getCustomerType().subscribe(
            dataReturn => {
                //console.log("data3" + JSON.stringify(dataReturn));
                this.customerTypes = dataReturn;
            },
            errorRturn => {
                console.log(errorRturn);
            }
        );
    }
    getBrokerNames() {
        this.customerService.getBrokerNames().subscribe(
            dataReturn => {
                //console.log("data4" + JSON.stringify(dataReturn));
                this.brokerNames = dataReturn;
            },
            errorRturn => {
                console.log(errorRturn);
            }
        );
    }
    getTitle() {
        this.customerService.getTitle().subscribe(
            dataReturn => {
                //console.log("data5" + JSON.stringify(dataReturn));
                this.titles = dataReturn;
            },
            errorRturn => {
                console.log(errorRturn);
            }
        );
    }
    getVatCode() {
        this.customerService.getVatCode().subscribe(
            dataReturn => {
                //console.log("data6" + JSON.stringify(dataReturn));
                this.vatCodes = dataReturn;
            },
            errorRturn => {
                console.log(errorRturn);
            }
        );
    }
    getNations() {
        this.customerService.getNations().subscribe(
            dataReturn => {
                //console.log("data7" + JSON.stringify(dataReturn));
                this.nationalityList = dataReturn;
            },
            errorRturn => {
                console.log(errorRturn);
            }
        );
    }
    getCustomerGroup(custype:any) {
        console.log("custid"+custype);
        const param = 'userId=' + localStorage.getItem('LoggedInUserId') +
            '&custTypCode=' +custype+'&ctyCode='+localStorage.getItem('countrycode')+'&regCode='+localStorage.getItem('regioncode');
         /*   const param = 'userId=' + 181+
            '&custTypCode=' +custype+'&ctyCode='+localStorage.getItem('countrycode')+'&regCode='+localStorage.getItem('regioncode');*/
        this.customerService.getCustomerGroup(param).subscribe(
            dataReturn => {
                //console.log("data7" + JSON.stringify(dataReturn));
                this.customerGroupList = dataReturn;
            },
            errorRturn => {
                console.log(errorRturn);
            }
        );
    }
    getStatus() {
        this.customerService.getStatus().subscribe(
            dataReturn => {
                //console.log("data7" + JSON.stringify(dataReturn));
                this.statusList = dataReturn;
            },
            errorRturn => {
                console.log(errorRturn);
            }
        );
    }
    getAcExcecutive() {
        this.customerService.getAcExcecutive().subscribe(
            dataReturn => {
                //console.log("data7" + JSON.stringify(dataReturn));
                this.accountExecutiveList = dataReturn;
            },
            errorRturn => {
                console.log(errorRturn);
            }
        );
    }
    resetForm() {
        let arrayFormFields = ['CustomerType', 'BrokerCode', 'NameTitle', 'EName', 'AName',
        'ERegsitrationNo', 'RegnExpDate', 'VATCode', 'VATRegistrationNo', 'EEmailId', 'EPhoneNo','EMobileNo',
        'FaxNo','EAddress1','AAddress1','EAddress2','AAddress2','EBuildingNo','EStreet','EPOBox','EPostalCode',
        'Nationality','BenfBank','BenfAccNo','IBANNo','BenfBankAdd','BenfSwiftCode','BenfSortCode','CorrBank',
        'CorrAccNo','CorrBankSwiftCode','CorrBankAddr','CorrSortCode','CustomerGroup','Business','PPIdentifier','TurnOver',
        'NoOfEmployees','ClaimsCoInsurance','CreditAmount','CreditDays','Status','AccExecutive','ExcessDebit','IntimationAlerts'];
    //  this.customerForm.controls['CustomerId'].reset(1);
   //   this.customerForm.controls['PreparedByStr'].reset("test@ae.rsagroup.com");
      this.customerForm.controls['IsValid'].reset(0);
      arrayFormFields.forEach((val) => {
        if (this.customerForm.controls[val] != null && this.customerForm.controls[val] != undefined) {
          this.customerForm.controls[val].reset();
        }
      });
      this.clearerrors();
    }
    cancelForm(){
        this.router.navigate(['/home']);
    }
}


