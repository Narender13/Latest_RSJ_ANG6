import { Injectable } from '@angular/core';
import { HttpHeaders, HttpErrorResponse, HttpClient, HttpParams, } from '@angular/common/http';
import { RSAENDPOINTConstants } from 'src/app/core/constants/rsa.api.end.points';
import { handleErrorObservable } from 'src/app/shared/utilites/helper';
import { catchError, map, shareReplay } from 'rxjs/operators'; 

@Injectable({
  providedIn: 'root'
})     
export class CompanyService {  

    constructor(private http: HttpClient) { }
    getCompanyType() {
        return this.http.get<any>(RSAENDPOINTConstants.TYPE).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getCompanyType')));
    } 
    getVatCode() {
       return this.http.get<any>(RSAENDPOINTConstants.VATCODE).pipe(
          map(res => res), 
          catchError(handleErrorObservable<any>('getVatCode')));
  } 
 getCategory() {
    return this.http.get<any>(RSAENDPOINTConstants.COMP_CATEGORY).pipe(
        map(res => res),
        catchError(handleErrorObservable<any>('getCategory')));
} 
 getStatus() {
     return this.http.get<any>(RSAENDPOINTConstants.STATUS).pipe(
      map(res => res),
         catchError(handleErrorObservable<any>('getStatus')));
}  
getBranchStatus() {
    return this.http.get<any>(RSAENDPOINTConstants.STATUS).pipe(
      map(res => res),
        catchError(handleErrorObservable<any>('getBranchStatus')));
}
createCompany(params:any) {
  return this.http.post<any>(RSAENDPOINTConstants.CREATECOMPANY, params).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('createCompany')));
}
getCompanyDetails(params:any) {
  return this.http.get<any>(RSAENDPOINTConstants.GETCOMPANY+params).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('getCompanyDetails')));
}
updateCompany(params:any) {
  return this.http.put<any>(RSAENDPOINTConstants.UPDATECOMPANY,params).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('updateCompany')));
  }




}

