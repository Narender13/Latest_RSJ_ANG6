import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, FormArray, Validators } from '@angular/forms';

import { EntiteCreateService } from '../services/entite-create.service';
import { UserAutherizationService } from 'src/app/core/authorization/userauth.service';

@Component({
  selector: 'rsa-entities',
  templateUrl: './entities.component.html',
  styleUrls: ['./entities.component.scss']
})
export class EntitiesComponent implements OnInit {

  entiteType: any;
  selectentitie = 'Agent';
  errorMsg: string;
  entiteMasterdata: any;
  constructor(private fb: FormBuilder, private createEntite: EntiteCreateService,private allowAccess: UserAutherizationService) { }


  ngOnInit() {
    this.getEntiteDetails();
    if(!this.displayMenuItem(400)){
      this.selectentitie='Select Entity';
    }
  }


  getEntiteDetails(): void {
    this.createEntite.getEntitieType().subscribe((data) => {
      this.entiteMasterdata = data;
      this.entiteType = this.entiteMasterdata.EntiteType;
    },
      errorRturn => this.errorMsg = errorRturn);
  }
  displayMenuItem(functionid){
    return this.allowAccess.isAllowed(functionid);
  }
  displayEntityItem(taskName) {
    let tasks = {
      'Agent': 400,
      'Advocate': 401,
      'Broker': 402,
      'Customer': 403,
      'Company': 404,
      'Police Station':405,
      'Recovery Agent':406,
      'Surveyor':408,
      'Repairer':407
    }
    let functionidVal = tasks[taskName];
    //console.log('functionidVal>>>>',functionidVal);
    return this.displayMenuItem(parseInt(functionidVal));
  }

  

}
