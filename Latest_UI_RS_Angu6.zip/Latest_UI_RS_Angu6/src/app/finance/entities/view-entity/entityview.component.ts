import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, FormArray, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
@Component({
  selector: 'rsa-entity-view',
  templateUrl: './entityview.component.html',
  styleUrls: ['./entityview.component.scss']
})
export class EntityViewComponent implements OnInit {

  entityType: number;
  selectentity = 'Agent';
  errorMsg: string;
  entiteMasterdata: any;
  entityCode:number;
  constructor(private fb: FormBuilder,private route: ActivatedRoute,
    private router: Router) { }


  ngOnInit() {
     this.route
    .queryParams
    .subscribe(params => {
      // Defaults to 0 if no query param provided.
      console.log("params"+params['EType'] +"id"+params['ECode']);
      this.entityType=params['EType'];   
      this.entityCode=params['ECode'];
    });
  
  }


}
