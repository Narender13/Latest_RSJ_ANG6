import { Component, OnInit, ViewChild, ElementRef, OnDestroy } from '@angular/core';
import { SharedService } from '../../services/shared.service';
import { FormBuilder, FormControl, FormGroup, FormArray, Validators, ControlContainer } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';
import { ConfirmationDialogComponent } from 'src/app/shared/custom-model/custom-model.component';
import { BsModalService } from 'ngx-bootstrap/modal';
import { TabsetComponent } from 'ngx-bootstrap/tabs';
import { CreateReceipt } from '../../search/model/create-receipt';
import { UtilityClass } from 'src/app/shared/utilites/helper-class';
import { MasterDataService } from 'src/app/finance/services/finance.masterdata.service';
import { CreatePayment } from 'src/app/finance/search/model/create-payment';
import { BasevoucherComponent } from 'src/app/finance/basevoucher/basevoucher.component';
import { CreatePaymentService } from 'src/app/finance/payments/create-payment/service/create-payment.service';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { PaymentpreviewComponent } from 'src/app/finance/preview/uae/paymentpreview/paymentpreview.component';
import { BatchUploadService } from 'src/app/finance/search/service/batch-upload.service';
import { ExcelService } from 'src/app/finance/search/service/excel.service';
import { AddNewTransactionComponent } from 'src/app/shared/add-new-transaction/add-new-transaction.component';
import { RSAConstants } from 'src/app/core/constants/rsaconstant';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'rsa-create-payment',
  templateUrl: './create-payment.component.html',
  styleUrls: ['./create-payment.component.scss']
})
export class CreatePaymentComponent extends BasevoucherComponent implements OnInit, OnDestroy {
  title = 'Payment';
  currency = 'AED';
  errorpayee: boolean;
  errordetail: boolean;
  /* form error-feilds */
  errorbankcodeCheque: boolean;
  errorChequeTypeCheque: boolean;
  errorChequeTypeBankT: boolean;
  errorbankcodeBanktransfer: boolean;
  errorpaayeebanknameCheque: boolean;
  errorpaayeebanknameBanktransfer: boolean;
  errorchequedateCheque: boolean;
  errorchequedateBankT: boolean;
  errorchequedateCreditCard: boolean;
  errorchequenoCheque: boolean;
  errorchequenoCreditCard: boolean;
  errorterminalID: boolean;
  errorexpirydate: boolean;
  errorBeneficiaryBankBankT: boolean;
  errorBeneficiaryBankCurrencyBankBankT: boolean;
  errorBeneficiaryAccNoBankBankT: boolean;
  errorBeneficiarySwiftCodeBankBankT: boolean;
  errorBeneficiarySortCodeBankBankT: boolean;
  errorIBANBankBankT: boolean;
  errorCorrespondentBankBankBankT: boolean;
  errorBothfieldsDataBankT: boolean;
  errorCorrespondentAccNoBankBankT: boolean;
  errorCorrespondentBankSwiftCodeBankBankT: boolean;
  errorCorrespondentBankSortCodeBankBankT: boolean;
  matchedRecords = [];
  isUploadUnmatched;
  returnValue: any;
  usersReq;
  symbol;
  createPayment: CreatePayment;
  animatedClass = true;
  isBatch = false;
  selectedRowEntitiDataTable: any = [];
  ondemandFlag = true;
  paymentBulkForm: FormGroup;
  fileUploadForm: FormGroup;
  clonedPayments: CreatePayment;
  ifUploadSuccess = true;
  matchedDetails: any = [];
  bulkuploadData: any;
  totalMatchedAmount: any;
  totalIntialAmount: any;
  headerDescription: string = "";
  paymentVATFlag = false;
  @ViewChild('tabset') tabset: TabsetComponent;
  @ViewChild('batchTotalAmt') batchTotalAmount: ElementRef;
  ifnewlyAddedRow = false;
  paymentDetails: any;
  paymentClaimDetails: any;
  isPolicyPayment: false;
  isStateExist: boolean;
  isStateClosed: boolean = false;
  toggleValueCredit = [];
  defaultPaymentMode: number;
  previewBlocked = false;

  constructor(
    protected sharedService: SharedService,
    private fb: FormBuilder,
    protected modalService: BsModalService,
    protected bsModalRef: BsModalRef,
    protected masterDataService: MasterDataService,
    protected utilityClass: UtilityClass,
    protected createPaymentService: CreatePaymentService,
    private alertService: AlertService,
    private batchUploadService: BatchUploadService,
    private excelService: ExcelService
  ) {
    super(masterDataService, sharedService, modalService, utilityClass, bsModalRef);
    //super.setMinMaxDate();
  }


  ngOnInit() {
    /* super with method is calling from BasevoucherComponent */
    const PMode = this.paymentMode;
    this.createPaymentForm(this.paymentMode);
    this.mainVoucherForm.controls.DefaultPaymentMode.setValue(PMode);
    super.getEntityDefaultData();
    super.getAllBranchData();
    super.getAllCostCenterData({ ev: null, index: 0, flag: true });
    super.getAllTotallingData(true);
    super.getAllgetLookupBanksData();
    super.getAllPayeeBankData(true);
    super.getAllDeptData();
    super.getAllProjData();
    super.getAllMasterData2();
    super.getAllBankCurrency();
    this.fieldStatusChanges();
    super.getBankData(true);
    super.getModelPreviousClose();
    super.closeModel();
    super.getAllTranData();
    super.getAllInstrumentTypes();
    this.symbol = (localStorage.getItem('symbol'));
    //super.setMinMaxDate();

    this.getDetailsArrayFormGroup();
    super.getSettlementTypeData();
    this.GetAccountingDates();

    if (this.headerDescription != null && this.headerDescription != undefined && this.headerDescription != '') {
      this.setHeaderDescription(this.headerDescription);
    }
    console.log(this.customerName, 'customername');
    if (!this.ondemandFlag) {
      this.customerName = this.selectedRowEntitiDataTable[0].CustomerName || this.customerName || '';
      this.setPayeName();
    }
    setTimeout(() => {
      console.log(this.entitydata, 'entiytdata');
      console.log(this.isPaymentFromEntity);
      if (this.isPaymentFromEntity || this.claimPayment) {
        this.setPayeName();
      }
    }, 0);
    this.fileUploadForm = this.fb.group({
      fileContent: [],
    });
    /* implemeted below code for mutiple policy creation*/
    this.isStateExist = false;
    this.updateFromSession();
    if (this.currentTbIndex == 0 && this.isStateExist) {
      this.updateTabValues();
    }
    this.sharedService.getMessage().subscribe(val => {
      if (val == 'ClearState' || val == 'close') {
        if (localStorage.getItem('PaymentStateExists') != null) {
          localStorage.setItem('PaymentStateExists', 'false');
          this.isStateClosed = true
        }
      }
    });
    this.setPaymentDetails();
  }
  ngOnDestroy() {
    if (!this.isStateClosed) {
      this.addToSession();
    }
  }
  addToSession() {
    if (this.mainVoucherForm.dirty || this.mainVoucherForm.touched) {
      let totallingAccCode = this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.value;
      let recevierBankCode = this.mainVoucherForm.controls.accountInfo['controls'].RecevierBankCode.value;
      let description = this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription.value;
      let payeeName = this.mainVoucherForm.controls.detailInfo['controls'].PayeeName.value;
      var commonData = { CurrentTabIndex: this.currentTbIndex, TotallingAccCode: totallingAccCode, RecevierBankCode: recevierBankCode, Description: description, PayeeName: payeeName }
      localStorage.setItem('CommonPaymentData', JSON.stringify(commonData));
      let contentData = this.getContentData();
      localStorage.setItem('PaymentContentData', JSON.stringify(contentData));
      localStorage.setItem('PaymentStateExists', 'true');
    }

  }
  getContentData() {
    var contentData: any;
    if (this.currentTbIndex == 0) {
      let chequeDate = this.mainVoucherForm.controls.chequeInfo['controls'].ChequeDate.value;
      let chequeNo = this.mainVoucherForm.controls.chequeInfo['controls'].ChequeNo.value;
      let chequeType = this.mainVoucherForm.controls.chequeInfo['controls'].ChequeType.value;
      contentData = { ChequeDate: chequeDate, ChequeNo: chequeNo, ChequeType: chequeType }
    }
    if (this.currentTbIndex == 2) {
      let beneficiaryBank = this.mainVoucherForm.controls.bankTransfer['controls'].BeneficiaryBank.value;
      //let payeeBankCode = this.mainVoucherForm.controls.bankTransfer['controls'].PayeeBankCode.value;
      let beneficiaryBankCurrency = this.mainVoucherForm.controls.bankTransfer['controls'].BeneficiaryBankCurrency.value;
      let beneficiaryAccNo = this.mainVoucherForm.controls.bankTransfer['controls'].BeneficiaryAccNo.value;
      let beneficiarySwiftCode = this.mainVoucherForm.controls.bankTransfer['controls'].BeneficiarySwiftCode.value;
      let beneficiarySortCode = this.mainVoucherForm.controls.bankTransfer['controls'].BeneficiarySortCode.value;
      let correspondentBank = this.mainVoucherForm.controls.bankTransfer['controls'].CorrespondentBank.value;
      let iban = this.mainVoucherForm.controls.bankTransfer['controls'].IBAN.value;
      let CorrespondentAccNo = this.mainVoucherForm.controls.bankTransfer['controls'].CorrespondentAccNo.value;
      let correspondentBankSwiftCode = this.mainVoucherForm.controls.bankTransfer['controls'].CorrespondentBankSwiftCode.value;
      let correspondentBankSortCode = this.mainVoucherForm.controls.bankTransfer['controls'].CorrespondentBankSortCode.value;
      let payeeBankName = this.mainVoucherForm.controls.bankTransfer['controls'].PayeeBankName.value;
      let chequeType = this.mainVoucherForm.controls.bankTransfer['controls'].ChequeType.value;
      let chequeDate = this.mainVoucherForm.controls.bankTransfer['controls'].ChequeDate.value;
      let instrumentRefNo = this.mainVoucherForm.controls.bankTransfer['controls'].InstrumentRefNo.value;

      contentData = {
        BeneficiaryBank: beneficiaryBank, BeneficiaryBankCurrency: beneficiaryBankCurrency, BeneficiaryAccNo: beneficiaryAccNo,
        BeneficiarySwiftCode: beneficiarySwiftCode, BeneficiarySortCode: beneficiarySortCode, CorrespondentBank: correspondentBank, IBAN: iban,
        CorrespondentAccNo: CorrespondentAccNo, CorrespondentBankSwiftCode: correspondentBankSwiftCode, CorrespondentBankSortCode: correspondentBankSortCode,
        PayeeBankName: payeeBankName, ChequeType: chequeType, ChequeDate: chequeDate, InstrumentRefNo: instrumentRefNo
      }
    }
    return contentData;
  }
  getDateClrlValue(contrlName: string) {
    if (this.mainVoucherForm.controls[contrlName].dirty || this.mainVoucherForm.controls[contrlName].touched) {
      return this.mainVoucherForm.controls[contrlName].value;
    }
    else {
      return null;
    }
  }
  updateFromSession() {
    let paymentStateExists = localStorage.getItem('PaymentStateExists');
    if (paymentStateExists == 'true') {
      let itemDetail = localStorage.getItem('CommonPaymentData');
      if (itemDetail) {
        this.isStateExist = true;
        let commonData = JSON.parse(itemDetail);
        this.currentTbIndex = commonData.CurrentTabIndex;
        setTimeout(() => {
          this.tabset.tabs[this.currentTbIndex].active = true;

        }, 1);
        //alert('hi');
      }
    }

  }

  updateTabValues() {
    let itemDetail = localStorage.getItem('CommonPaymentData')
    let paymentStateExists = localStorage.getItem('PaymentStateExists');
    if (paymentStateExists == 'true') {
      if (itemDetail) {
        this.isStateExist = true;
        let commonData = JSON.parse(itemDetail);
        this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.setValue(commonData.TotallingAccCode);
        if (commonData.Description) {
          this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription.setValue(commonData.Description);
        }
        if (commonData.PayeeName) {
          this.mainVoucherForm.controls.detailInfo['controls'].PayeeName.setValue(commonData.PayeeName);
        }
        this.mainVoucherForm.markAsDirty();
        setTimeout(() => {
          this.getBankData(true);

        }, 500);

        setTimeout(() => {
          this.tabset.tabs[this.currentTbIndex].active = true;
          // alert(this.receiverdataBankName.length+'Time out');
          this.mainVoucherForm.controls.accountInfo['controls'].RecevierBankCode.setValue(commonData.RecevierBankCode);
        }, 500);
        this.updateContentData();
      }
    }

  }

  updateContentData() {
    let itemDetail = localStorage.getItem('PaymentContentData');
    if (itemDetail) {
      let contentData = JSON.parse(itemDetail);
      if (this.currentTbIndex == 0) {
        if (contentData.ChequeDate) this.mainVoucherForm.controls.chequeInfo['controls'].ChequeDate.setValue(this.getDateFormat(contentData.ChequeDate));
        if (contentData.ChequeNo) this.mainVoucherForm.controls.chequeInfo['controls'].ChequeNo.setValue(contentData.ChequeNo);
        if (contentData.ChequeType) this.mainVoucherForm.controls.chequeInfo['controls'].ChequeType.setValue(contentData.ChequeType);
      }
      if (this.currentTbIndex == 2) {
        if (contentData.BeneficiaryBank) this.mainVoucherForm.controls.bankTransfer['controls'].BeneficiaryBank.setValue(contentData.BeneficiaryBank);
        if (contentData.BeneficiaryBankCurrency) this.mainVoucherForm.controls.bankTransfer['controls'].BeneficiaryBankCurrency.setValue(contentData.BeneficiaryBankCurrency);
        if (contentData.BeneficiaryAccNo) this.mainVoucherForm.controls.bankTransfer['controls'].BeneficiaryAccNo.setValue(contentData.BeneficiaryAccNo);
        if (contentData.BeneficiarySwiftCode) this.mainVoucherForm.controls.bankTransfer['controls'].BeneficiarySwiftCode.setValue(contentData.BeneficiarySwiftCode);
        if (contentData.BeneficiarySortCode) this.mainVoucherForm.controls.bankTransfer['controls'].BeneficiarySortCode.setValue(contentData.BeneficiarySortCode);
        if (contentData.CorrespondentBank) this.mainVoucherForm.controls.bankTransfer['controls'].CorrespondentBank.setValue(contentData.CorrespondentBank);
        if (contentData.IBAN) this.mainVoucherForm.controls.bankTransfer['controls'].IBAN.setValue(contentData.IBAN);
        if (contentData.CorrespondentAccNo) this.mainVoucherForm.controls.bankTransfer['controls'].CorrespondentAccNo.setValue(contentData.CorrespondentAccNo);
        if (contentData.CorrespondentBankSwiftCode) this.mainVoucherForm.controls.bankTransfer['controls'].CorrespondentBankSwiftCode.setValue(contentData.CorrespondentBankSwiftCode);
        if (contentData.CorrespondentBankSortCode) this.mainVoucherForm.controls.bankTransfer['controls'].CorrespondentBankSortCode.setValue(contentData.CorrespondentBankSortCode);
        if (contentData.PayeeBankName) this.mainVoucherForm.controls.bankTransfer['controls'].PayeeBankName.setValue(contentData.PayeeBankName);
        if (contentData.ChequeType) this.mainVoucherForm.controls.bankTransfer['controls'].ChequeType.setValue(contentData.ChequeType);
        if (contentData.ChequeDate) this.mainVoucherForm.controls.bankTransfer['controls'].ChequeDate.setValue(this.getDateFormat(contentData.ChequeDate));
        if (contentData.InstrumentRefNo) this.mainVoucherForm.controls.bankTransfer['controls'].InstrumentRefNo.setValue(contentData.InstrumentRefNo);
      }
    }
  }
  getDateFormat(val: any) {
    if (val.length > 10) {
      return new DatePipe('en-US').transform(new Date(val), 'dd/MM/yyyy');
    }
    else return val;
  }
  checkIsformDirtyPM() {
    this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
    this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
    this.bsModalRef.content.modelBodyContent = RSAMSGConstants.DIRTYFLAGMSGRECIPT;
    this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
    this.bsModalRef.content.actionBtn = RSAMSGConstants.BTNPROCEED;
    this.bsModalRef.content.valueChange.subscribe((data) => {
      if (data = 'Proceed') {
        this.modalService.hide(1);
        this.sharedService.sendMessage('close');
        this.isStateClosed = true;
      }
    });
  }
  /* end*/
  setPayeName() {
    if (this.customerName !== '' && this.customerName !== undefined) {
      this.mainVoucherForm.controls.detailInfo['controls'].PayeeName.setValue(this.customerName);
    }
  }
  setHeaderDescription(desc) {
    this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription.setValue(desc);

  }

  /* create entiti form */
  createPaymentForm(param): void {
    if (this.mainVoucherForm && this.mainVoucherForm.controls.DefaultPaymentMode) {
      this.defaultPaymentMode = this.mainVoucherForm.controls.DefaultPaymentMode.value;
    }
    this.mainVoucherForm = null;
    //let tranDate = localStorage.getItem('tranAccntMnthStrtDate') ? new Date(localStorage.getItem('tranAccntMnthStrtDate')) : new Date();
    this.mainVoucherForm = this.fb.group({
      VoucherDate: [new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy')],
      Amount: [''],
      PaymentMode: [this.paymentMode],
      PrintDate: [new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy')],
      ReceiptType: [0],
      PreparedBy: [localStorage.getItem(RSAConstants.LoggedInUserId)],
      PreparedDate: [new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy')],
      ApprovedBy: [1],
      ModifiedBy: [],
      Approvers: this.fb.array([]),
      CustomerID: [],
      TerminalID: [],
      TerminalUserID: [20],
      TerminalUserName: [],
      CountryCode: [1],
      RegionCode: [localStorage.getItem('regioncode')],
      ReprintNo: [],
      ArabicDescription: [],
      ChequeDateFld: [],
      VendorCode: [],
      DefaultPaymentMode: [this.defaultPaymentMode],
      chequeInfo: this.fb.group({
        ChequeNo: [''],
        ChequeDate: [new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy'), Validators.required],
        ChequeType: ['', Validators.required],
        PayeeBankCode: [''],
        PayeeBankName: [''],
      }),
      bankTransfer: this.fb.group({
        InstrumentRefNo: [''],
        ChequeDate: [new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy'), Validators.required],
        // PayeeBankCode: [, Validators.required],
        PayeeBankName: [''],
        BeneficiaryBank: ['', Validators.required],
        BeneficiaryBankCurrency: ['', Validators.required],
        BeneficiaryAccNo: [''],
        BeneficiarySwiftCode: ['', Validators.required],
        BeneficiarySortCode: ['', Validators.required],
        CorrespondentBank: [],
        ChequeType: ['', Validators.required],
        IBAN: [''],
        CorrespondentAccNo: [''],
        CorrespondentBankSwiftCode: [''],
        CorrespondentBankSortCode: ['']
      }),
      detailInfo: this.fb.group({
        PayeeName: ['', Validators.required],
        EnglishDescription: ['', Validators.required],
      }),
      accountInfo: this.fb.group({
        LocationCode: [localStorage.getItem('locationcode')],
        CostCenterCode: [localStorage.getItem('costcentre')],
        TotallingAccCode: [1110],
        RecevierBankCode: [24],
      }),
      VoucherDetails: this.fb.array([])
    });
  }


  /* form array for recept details */
  createPaymentArrayGroup(): FormGroup {
    return this.fb.group({
      CounterPartyRef: [],
      LocationCode: [localStorage.getItem('locationcode')],
      BranchCode: [localStorage.getItem('locationcode')],
      LocationDesc: ['Dubai'],
      CountryCode: [1],
      CostCenterCode: [localStorage.getItem('costcentre')],
      Description: [],
      Amount: [0, Validators.required],
      SettlementType: ['', Validators.required],
      RefTransactionID: [],
      RefTransactionType: [5],
      IsDebitEntry: [true],
      PolicyID: [],
      PolicyNumber: [],
      ModifiedBy: [],
      SerialNo: [],
      ReceiptDate: [],
      AnalysisCode: [],
      DepartmentCode: [],
      Department: [],
      RefTransactionSerialNo: [],
      GLCode: [4, Validators.required],
      GLCodeDesc: ['4-HSBC BANK MIDDLE EAST - Deira', Validators.required],
      RegionCode: [localStorage.getItem('regioncode')],
      TotallingAccCode: [1110],
      // PolicyYear: [],
      // PolicyType: [],
      Endt_ID: [],
      PlaceHolderCode: [],
      GLAccountName: [],
      CostCenterName: [],
      TotallingAccName: [],
      BranchName: [],
      GLAccount: [],
      ClassCode: [],
      ClaimID: [],
      VoucherType: [],
      TransactionNo: [],
      RefTranType: [],
      VoucherNo: [],
      ClaimNumber: [],
      ClaimYear: [],
      CauseOfLoss: [],
      NatureOfLoss: [],
      CauseOfLossDesc: [],
      NatureOfLossDesc: [],

      // Aaded new formControlName to make row readonly if coming from selection rows
      newAddedRow: false
    });
  }

  getDetailsArrayFormGroup() {
    console.log(this.selectedRowEntitiDataTable, 'selectedRowEntitiDataTable');
    console.log(this.claimPayment, 'claimPayment');
    const control = <FormArray>this.mainVoucherForm.controls['VoucherDetails'];
    if (!this.ondemandFlag && !this.claimPayment) {
      this.selectedRowEntitiDataTable.map((item, index) => {
        const group = this.createPaymentArrayGroup();
        console.log('item.amount>>>****', item.amount);
        item['IsDebitEntry'] = (item.Amount < 0) ? false : true;
        console.log('item>>>****', item);
        group.patchValue(item);
        group.get('newAddedRow').setValue(false);
        control.push(group);
      });
    } else if (this.claimPayment) {
      this.selectedRowEntitiDataTable.map((item, index) => {
        const group = this.createPaymentArrayGroup();
        console.log('item.amount>>>****', item.amount);
        item['IsDebitEntry'] = (item.Amount < 0) ? false : true;
        console.log('item>>>****', item);
        group.patchValue(item);
        group.get('newAddedRow').setValue(false);
        if ((index % 2) !== 0) {
          if (item.VATAmount !== 0) {
            control.push(group);
          }
        }
        if ((index % 2) === 0) {
          control.push(group);
        }
        const ctrl = <FormArray>this.mainVoucherForm.controls['VoucherDetails'];
        ctrl.controls.forEach((val, i) => {
          const amount = val.get('Amount').value;
          this.toggleValueCredit[i] = amount < 0 ? false : true;
        });
        console.log(this.toggleValueCredit, 'this.toggleValueCredit');
      });
    } else {
      if (!this.editPaymentFromPrevious) {
        control.push(this.createPaymentArrayGroup());
      }
    }
  }

  /* set receipt mode and set default values   */
  setReceiptMode(val, paymentname, ev) {
    if (!ev.tabset) { return; } // fix for tab resetting all values on double click
    this.mainVoucherForm.controls['PaymentMode'].setValue(val);
    this.paymentMode = val;
    this.paymentname = paymentname;
    if (!this.editPaymentFromPrevious) {
      this.createPaymentForm(this.paymentMode);
      this.getDetailsArrayFormGroup();
    }
    if (this.editPaymentFromPrevious) {
      this.resetOnlyPaymentModeHeaderDetails(val);
      this.clearerrors();
    }
    this.GetAccountingDates();
    this.receiverdataBankName = this.cachedReceiverBankData;
    this.totallingacc = this.cachedTotAcc;
    this.payeedataBankName = this.cachedPayeeBankData;
    this.mainVoucherForm.controls.chequeInfo['controls'].ChequeNo.setValue('');
    if (this.defaultPaymentMode !== this.paymentMode) {
      this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription.setValue('');
    } else {
      this.setHeaderDescription(this.headerDescription);
    }
    this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.setValue('1110');
    this.mainVoucherForm.controls.accountInfo['controls'].RecevierBankCode.setValue('24');
    //this.getDetailsArrayFormGroup();
    this.fieldStatusChanges();
    if (this.isPaymentFromEntity || this.claimPayment) {
      this.setPayeName();
    }
    if (!this.ondemandFlag) {
      this.customerName = this.selectedRowEntitiDataTable[0].CustomerName || this.selectedRowEntitiDataTable[0].PayeeName ||
        this.selectedRowEntitiDataTable[0].NameOfParty || '';
      this.setPayeName();
    }
    if (this.isStateExist) {
      this.updateTabValues();
    }
    this.setPaymentDetails();
  }


  /* using req fields and update status  */
  fieldStatusChanges() {
    this.clearerrors();
    this.cshpayeename.statusChanges.subscribe(
      status => {
        this.errorpayee = (status === 'INVALID');
        console.log(this.errorpayee, 'his.errorpayee');
      }
    );
    this.cshdetails.statusChanges.subscribe(
      status => {
        this.errordetail = (status === 'INVALID');
      }
    );

    /* for cheque */
    if (this.payeebankcodeCheque != null && this.payeebankcodeCheque !== undefined) {
      this.payeebankcodeCheque.statusChanges.subscribe(
        status => {
          this.errorbankcodeCheque = (status === 'INVALID');
        }
      );
    }
    if (this.chequeTypeCheque != null && this.chequeTypeCheque !== undefined) {
      this.chequeTypeCheque.statusChanges.subscribe(
        status => {
          this.errorChequeTypeCheque = (status === 'INVALID');
        }
      );
    }

    if (this.chequedateCheque != null && this.chequedateCheque !== undefined) {
      this.chequedateCheque.statusChanges.subscribe(
        status => {
          this.errorchequedateCheque = (status === 'INVALID');
        }
      );
    }


    if (this.chequeno != null && this.chequeno !== undefined) {
      this.chequeno.statusChanges.subscribe(
        status => {
          this.errorchequenoCheque = (status === 'INVALID');
        }
      );
    }



    /* for banktransfer */

    // if (this.chequedateBankT != null && this.chequedateBankT !== undefined) {
    //   this.chequedateBankT.statusChanges.subscribe(
    //     status => {
    //       this.errorchequedateBankT = (status === 'INVALID');
    //     }
    //   );
    // }
    if (this.chequeTypeBankT != null && this.chequeTypeBankT !== undefined) {
      this.chequeTypeBankT.statusChanges.subscribe(
        status => {
          this.errorChequeTypeBankT = (status === 'INVALID');
        }
      );
    }


    // if (this.payeebankcodeBankt != null && this.payeebankcodeBankt !== undefined) {
    //   this.payeebankcodeBankt.statusChanges.subscribe(
    //     status => {
    //       this.errorbankcodeBanktransfer = (status === 'INVALID');
    //     }
    //   );
    // }

    if (this.payeebanknameBankt != null && this.payeebanknameBankt !== undefined) {
      this.payeebanknameBankt.statusChanges.subscribe(
        status => {
          this.errorpaayeebanknameBanktransfer = (status === 'INVALID');
        }
      );
    }

    if (this.expirydate != null && this.expirydate !== undefined) {
      this.expirydate.statusChanges.subscribe(
        status => {
          this.errorexpirydate = (status === 'INVALID');
        }
      );
    }

    if (this.beneficiaryBankBankt != null && this.beneficiaryBankBankt !== undefined) {
      this.beneficiaryBankBankt.statusChanges.subscribe(
        status => {
          this.errorBeneficiaryBankBankT = (status === 'INVALID');
        }
      );
    }

    if (this.beneficiaryBankCurrencyBankt != null && this.beneficiaryBankCurrencyBankt !== undefined) {
      this.beneficiaryBankCurrencyBankt.statusChanges.subscribe(
        status => {
          this.errorBeneficiaryBankCurrencyBankBankT = (status === 'INVALID');
        }
      );
    }

    if (this.beneficiaryAccNoBankt != null && this.beneficiaryAccNoBankt !== undefined) {
      this.beneficiaryAccNoBankt.statusChanges.subscribe(
        status => {
          this.errorBeneficiaryAccNoBankBankT = (status === 'INVALID');
        }
      );
    }

    if (this.beneficiarySwiftCodeBankt != null && this.beneficiarySwiftCodeBankt !== undefined) {
      this.beneficiarySwiftCodeBankt.statusChanges.subscribe(
        status => {
          this.errorBeneficiarySwiftCodeBankBankT = (status === 'INVALID');
        }
      );
    }

    if (this.beneficiarySortCodeBankt != null && this.beneficiarySortCodeBankt !== undefined) {
      this.beneficiarySortCodeBankt.statusChanges.subscribe(
        status => {
          this.errorBeneficiarySortCodeBankBankT = (status === 'INVALID');
        }
      );
    }

    if (this.correspondentBankBankt != null && this.correspondentBankBankt !== undefined) {
      this.correspondentBankBankt.statusChanges.subscribe(
        status => {
          this.errorCorrespondentBankBankBankT = (status === 'INVALID');
        }
      );
    }

    if (this.IbanBankt != null && this.IbanBankt !== undefined) {
      this.IbanBankt.statusChanges.subscribe(
        status => {
          this.errorIBANBankBankT = (status === 'INVALID');
        }
      );
    }

    if (this.correspondentAccNoBankt != null && this.correspondentAccNoBankt !== undefined) {
      this.correspondentAccNoBankt.statusChanges.subscribe(
        status => {
          this.errorCorrespondentAccNoBankBankT = (status === 'INVALID');
        }
      );
    }

    if (this.correspondentBankSwiftCodeBankt != null && this.correspondentBankSwiftCodeBankt !== undefined) {
      this.correspondentBankSwiftCodeBankt.statusChanges.subscribe(
        status => {
          this.errorCorrespondentBankSwiftCodeBankBankT = (status === 'INVALID');
        }
      );
    }

    if (this.correspondentBankSortCodeBankt != null && this.correspondentBankSortCodeBankt !== undefined) {
      this.correspondentBankSortCodeBankt.statusChanges.subscribe(
        status => {
          this.errorCorrespondentBankSortCodeBankBankT = (status === 'INVALID');
        }
      );
    }

  }

  /* clear all errors after reset   */
  clearerrors() {
    this.errorpayee = false;
    this.errordetail = false;
    this.errorbankcodeCheque = false;
    this.errorChequeTypeCheque = false;
    this.errorChequeTypeBankT = false;
    this.errorbankcodeBanktransfer = false;
    this.errorpaayeebanknameCheque = false;
    this.errorpaayeebanknameBanktransfer = false;
    this.errorchequedateCheque = false;
    this.errorchequedateBankT = false;
    this.errorchequedateCreditCard = false;
    this.errorchequenoCheque = false;
    this.errorterminalID = false;
    this.errorexpirydate = false;
    this.errorBeneficiaryBankBankT = false;
    this.errorBeneficiaryBankCurrencyBankBankT = false;
    this.errorBeneficiaryAccNoBankBankT = false;
    this.errorBeneficiarySwiftCodeBankBankT = false;
    this.errorBeneficiarySortCodeBankBankT = false;
    this.errorIBANBankBankT = false;
    this.errorBothfieldsDataBankT = false;
  }

  /* get the controls of each fields   */
  get cshpayeename() { return this.mainVoucherForm.controls.detailInfo['controls'].PayeeName; }
  get cshdetails() { return this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription; }
  get payeebankcodeCheque() {
    return this.mainVoucherForm.controls.chequeInfo['controls'].PayeeBankCode;
  }
  get beneficiaryBankBankt() {
    return this.mainVoucherForm.controls.bankTransfer['controls'].BeneficiaryBank;
  }
  get payeebankcodeBankt() {
    return this.mainVoucherForm.controls.bankTransfer['controls'].PayeeBankCode;
  }
  get beneficiaryBankCurrencyBankt() {
    return this.mainVoucherForm.controls.bankTransfer['controls'].BeneficiaryBankCurrency;
  }
  get beneficiaryAccNoBankt() {
    return this.mainVoucherForm.controls.bankTransfer['controls'].BeneficiaryAccNo;
  }
  get beneficiarySwiftCodeBankt() {
    return this.mainVoucherForm.controls.bankTransfer['controls'].BeneficiarySwiftCode;
  }
  get beneficiarySortCodeBankt() {
    return this.mainVoucherForm.controls.bankTransfer['controls'].BeneficiarySortCode;
  }
  get correspondentBankBankt() {
    return this.mainVoucherForm.controls.bankTransfer['controls'].CorrespondentBank;
  }
  get IbanBankt() {
    return this.mainVoucherForm.controls.bankTransfer['controls'].IBAN;
  }
  get correspondentAccNoBankt() {
    return this.mainVoucherForm.controls.bankTransfer['controls'].CorrespondentAccNo;
  }
  get correspondentBankSwiftCodeBankt() {
    return this.mainVoucherForm.controls.bankTransfer['controls'].CorrespondentBankSwiftCode;
  }
  get correspondentBankSortCodeBankt() {
    return this.mainVoucherForm.controls.bankTransfer['controls'].CorrespondentBankSortCode;
  }
  get payeebanknameBankt() {
    return this.mainVoucherForm.controls.bankTransfer['controls'].PayeeBankName;
  }
  get chequedateCheque() {
    return (this.mainVoucherForm.controls.chequeInfo['controls'].ChequeDate);
  }
  get chequeTypeCheque() {
    return (this.mainVoucherForm.controls.chequeInfo['controls'].ChequeType);
  }
  get chequedateBankT() {
    return (this.mainVoucherForm.controls.bankTransfer['controls'].ChequeDate);
  }
  get instrumentrefnoBankT() {
    return (this.mainVoucherForm.controls.bankTransfer['controls'].InstrumentRefNo);
  }
  get chequeTypeBankT() {
    return (this.mainVoucherForm.controls.bankTransfer['controls'].ChequeType);
  }
  get expirydate() { return this.mainVoucherForm.get('ExpiryDate'); }
  get chequeno() {
    return this.mainVoucherForm.controls.chequeInfo['controls'].ChequeNo;
  }

  settingTotalingAccountTrans() {
    if (!this.ondemandFlag) {
      // this.setDescription();
      this.selectedRowEntitiDataTable.map((item, index) => {
        if (!this.editPaymentFromPrevious) {
          super.getTotallingDetailData({ index: index, flag: true });
        } else {
          super.getTotallingDetailData({ index: index, flag: false });
        }
      });
    }
  }
  setPolicyDdescriptions() {
    if (!this.ondemandFlag) {
      this.selectedRowEntitiDataTable.map((item, index) => {
        this.setFormArrayCTRLDefaultValue('Description', index, item.Description);
      });
    }
  }


  /* set Description in receptdetails desc   */
  setDescription() {
    (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls[0].get('Description').setValue(this.cshdetails.value);
  }

  /* go next valiadtion depending on receipt mode   */
  goNext() {
    console.log(this.mainVoucherForm.controls.chequeInfo['controls']);
    if (this.paymentMode === 1) {
      this.errorpayee = this.cshpayeename.invalid;
      console.log(this.errorpayee, 'errorpayee');
      this.errordetail = this.cshdetails.invalid;
      console.log(this.errordetail, 'errordetail');
      if (!this.errorpayee && !this.errordetail) {
        this.level = 2;
        if (this.ondemandFlag) {
          this.setDescription();
          super.getTotallingDetailData({ index: 0, flag: true });
        }
        this.settingTotalingAccountTrans();
      }
    }

    if (this.paymentMode === 2) {
      this.errorpayee = this.cshpayeename.invalid;
      console.log(this.errorpayee);
      this.errordetail = this.cshdetails.invalid;

      // if (this.payeebankcodeCheque != null && this.payeebankcodeCheque !== undefined) {
      //   this.errorbankcodeCheque = this.payeebankcodeCheque.invalid;
      //   console.log(this.payeebankcodeCheque.invalid, 'this.payeebankcode.invalid');
      // }
      console.log(this.mainVoucherForm.controls.chequeInfo['controls'].ChequeNo, " chhhhhhhhhhh")
      if (this.mainVoucherForm.controls.chequeInfo['controls'].ChequeType.value == '3') {
        this.mainVoucherForm.controls.chequeInfo['controls'].ChequeNo.setValidators([Validators.required]);
        this.mainVoucherForm.controls.chequeInfo['controls'].ChequeNo.updateValueAndValidity();
      } else {
        this.mainVoucherForm.controls.chequeInfo['controls'].ChequeNo.clearValidators();
        this.mainVoucherForm.controls.chequeInfo['controls'].ChequeNo.updateValueAndValidity();
      }
      if (this.chequedateCheque != null && this.chequedateCheque !== undefined) {
        this.errorchequedateCheque = this.chequedateCheque.invalid;
      }


      if (this.chequeTypeCheque != null && this.chequeTypeCheque !== undefined) {
        this.errorChequeTypeCheque = this.chequeTypeCheque.invalid;
      }

      if (this.chequeno != null && this.chequeno !== undefined) {
        this.errorchequenoCheque = this.chequeno.invalid;
      }
      if (!this.errorpayee && !this.errordetail &&
        !this.errorchequedateCheque && !this.errorchequenoCheque && !this.errorChequeTypeCheque) {
        if (this.isBatch && (!this.totalIntialAmount || this.totalIntialAmount == 0)) {
          return false;
        }
        this.level = 2;
        if (this.ondemandFlag) {
          this.setDescription();
          super.getTotallingDetailData({ index: 0, flag: true });
        }
        this.settingTotalingAccountTrans();

      }
    }


    if (this.paymentMode === 5) {
      this.errorpayee = this.cshpayeename.invalid;
      this.errordetail = this.cshdetails.invalid;

      // if (this.chequedateBankT != null && this.chequedateBankT !== undefined) {
      //   this.errorchequedateBankT = this.chequedateBankT.invalid;

      // }

      // if (this.payeebankcodeBankt != null && this.payeebankcodeBankt !== undefined) {
      //   this.errorbankcodeBanktransfer = this.payeebankcodeBankt.invalid;
      // }

      if (this.beneficiaryBankBankt != null && this.beneficiaryBankBankt !== undefined) {
        this.errorBeneficiaryBankBankT = this.beneficiaryBankBankt.invalid;
      }

      if (this.beneficiaryBankCurrencyBankt != null && this.beneficiaryBankCurrencyBankt !== undefined) {
        this.errorBeneficiaryBankCurrencyBankBankT = this.beneficiaryBankCurrencyBankt.invalid;
      }

      // if (this.beneficiaryAccNoBankt != null && this.beneficiaryAccNoBankt !== undefined) {
      //   this.errorBeneficiaryAccNoBankBankT = this.beneficiaryAccNoBankt.invalid;
      // }
      if (this.beneficiaryAccNoBankt != null && this.beneficiaryAccNoBankt !== undefined) {
        if (!this.IbanBankt.value && !this.beneficiaryAccNoBankt.value) {
          this.errorBeneficiaryAccNoBankBankT = true;
          this.errorIBANBankBankT = true;
          this.errorBothfieldsDataBankT = false;
        } else if (this.IbanBankt.value && this.beneficiaryAccNoBankt.value) {
          this.errorBothfieldsDataBankT = true;
        } else {
          this.errorBeneficiaryAccNoBankBankT = this.errorIBANBankBankT = this.errorBothfieldsDataBankT = false;
        }
      }

      if (this.beneficiarySwiftCodeBankt != null && this.beneficiarySwiftCodeBankt !== undefined) {
        this.errorBeneficiarySwiftCodeBankBankT = this.beneficiarySwiftCodeBankt.invalid;
      }

      if (this.beneficiarySortCodeBankt != null && this.beneficiarySortCodeBankt !== undefined) {
        this.errorBeneficiarySortCodeBankBankT = this.beneficiarySortCodeBankt.invalid;
      }

      if (this.correspondentBankBankt != null && this.correspondentBankBankt !== undefined) {
        this.errorCorrespondentBankBankBankT = this.correspondentBankBankt.invalid;
      }

      if (this.IbanBankt != null && this.IbanBankt !== undefined) {
        if (!this.IbanBankt.value && !this.beneficiaryAccNoBankt.value) {
          this.errorIBANBankBankT = true;
          this.errorBeneficiaryAccNoBankBankT = true;
          this.errorBothfieldsDataBankT = false;
        } else if (this.IbanBankt.value && this.beneficiaryAccNoBankt.value) {
          this.errorBothfieldsDataBankT = true;
        } else {
          this.errorBeneficiaryAccNoBankBankT = this.errorIBANBankBankT = this.errorBothfieldsDataBankT = false;
        }
        // this.errorIBANBankBankT = this.IbanBankt.invalid;
        console.log(this.errorbankcodeBanktransfer, 'errorbankcodeBanktransfer');
      }

      if (this.correspondentAccNoBankt != null && this.correspondentAccNoBankt !== undefined) {
        this.errorCorrespondentAccNoBankBankT = this.correspondentAccNoBankt.invalid;
      }

      if (this.correspondentBankSwiftCodeBankt != null && this.correspondentBankSwiftCodeBankt !== undefined) {
        this.errorCorrespondentBankSwiftCodeBankBankT = this.correspondentBankSwiftCodeBankt.invalid;
      }

      if (this.correspondentBankSortCodeBankt != null && this.correspondentBankSortCodeBankt !== undefined) {
        this.errorCorrespondentBankSortCodeBankBankT = this.correspondentBankSortCodeBankt.invalid;
      }


      if (this.chequeTypeBankT != null && this.chequeTypeBankT !== undefined) {
        this.errorChequeTypeBankT = this.chequeTypeBankT.invalid;
      }

      if (!this.errorpayee &&
        !this.errordetail &&
        !this.errorbankcodeBanktransfer && !this.errorCorrespondentBankSortCodeBankBankT &&
        !this.errorCorrespondentBankSwiftCodeBankBankT && !this.errorCorrespondentAccNoBankBankT
        && !this.errorIBANBankBankT && !this.errorCorrespondentBankBankBankT && !this.errorBeneficiarySortCodeBankBankT
        && !this.errorBeneficiarySwiftCodeBankBankT && !this.errorBothfieldsDataBankT &&
        !this.errorBeneficiaryAccNoBankBankT && !this.errorBeneficiaryBankCurrencyBankBankT
        && !this.errorBeneficiaryBankBankT && !this.errorChequeTypeBankT) {
        if (this.isBatch && this.totalAmount < 0) {
          return false;
        }
        this.level = 2;
        if (this.ondemandFlag) {
          this.setDescription();
          super.getTotallingDetailData({ index: 0, flag: true });

        }
        this.settingTotalingAccountTrans();
      }
    }
    /* policyDetails to be set on payment screen-defect 5419 */
    if (this.level === 2 && this.isPolicyPayment) {
      this.setPolicyDdescriptions();
    }

  }

  /* add receipt in review screen */
  addReceipt(item?, len?, newAdded?) {
    this.ifnewlyAddedRow = (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls[len - 1].get('newAddedRow').value;
    if (super.validateAmount(len)) {
      const control = <FormArray>this.mainVoucherForm.controls['VoucherDetails'];
      const CurrentAmount = (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls[len - 1].get('Amount').value;
      const newRow = this.createPaymentArrayGroup();
      newRow.patchValue(item);
      control.push(newRow);
      if (newAdded) {
        if (this.isPaymentFromEntity) {
          this.setFormArrayCTRLDefaultValue('TotallingAccCode', len, this.defaultTotallingAccCode);
          this.setFormArrayCTRLDefaultValue('GLCode', len, this.defaultGLCode);
          this.setFormArrayCTRLDefaultValue('GLCodeDesc', len, this.defaultGLCodeDesc);
        }
        this.setFormArrayCTRLDefaultValue('GLCode', len, 4);
        this.setFormArrayCTRLDefaultValue('GLCodeDesc', len, '4-HSBC BANK MIDDLE EAST - Deira');
        newRow.patchValue({ 'newAddedRow': true });
        if (this.claimPayment) {
          super.getAllTotallingData(true);
          console.log(this.cachedTotAcc, ' cachedTotAcc');
          this.setFormArrayCTRLDefaultValue('TotallingAccCode', len, this.cachedTotAcc[0].Code);
          this.setFormArrayCTRLDefaultValue('Description', len, 'Claim No: ' + this.selectedRowEntitiDataTable[0].ClaimNumber);
          this.dtltotallingacc[len] = this.cachedTotAcc;
        } else {
          // this.getTotallingDetailData(len, false);
          console.log(this.cachedDtlTot, 'len');
          console.log(len, 'len');
          this.dtltotallingacc[len] = this.cachedDtlTot;
        }
        this.glaccount[len] = this.cachedGL;
      }
      // this.getTotallingDetailData(len);
      console.log(this.cachedDtlTot, 'len');
      console.log(len, 'len');
      this.glaccount[len] = this.cachedGL;
    }

  }

  reSetForm(params) {
    const param = params.defaultParam;
    /*set default value here and reset */
    if (param === 1) {
      super.validateAllFormFields(this.mainVoucherForm);
      this.mainVoucherForm.controls.accountInfo['controls'].LocationCode.reset(localStorage.getItem('locationcode'));
      this.mainVoucherForm.controls.accountInfo['controls'].CostCenterCode.reset(localStorage.getItem('costcentre'));
      this.mainVoucherForm.controls.RegionCode.reset(localStorage.getItem('regioncode'));
      this.mainVoucherForm.controls.CountryCode.reset(localStorage.getItem('country'));
      this.mainVoucherForm.controls.PreparedBy.reset(localStorage.getItem(RSAConstants.LoggedInUserId));
      this.mainVoucherForm.controls.ApprovedBy.reset(1);
      this.mainVoucherForm.controls.PaymentMode.reset(this.paymentMode);
      this.mainVoucherForm.controls.TerminalUserID.reset(20);
      this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.reset(1110);
      this.getBankData(true);
      this.mainVoucherForm.controls.accountInfo['controls'].RecevierBankCode.reset(24);
      this.mainVoucherForm.controls.VoucherDate.setValue(new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy'));
      if (this.isBatch) {
        this.batchTotalAmount.nativeElement.value = '';
        this.totalAmount = 0;
      }
      this.setPayeName();
      this.clearerrors();
      if (this.isBatch) {
        this.batchTotalAmount.nativeElement.value = '';
      }
    } else if (param === 2) {
      (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls.map(item => {
        item.get('LocationCode').setValue(localStorage.getItem('locationcode'));
        item.get('CostCenterCode').setValue(localStorage.getItem('costcentre'));
        item.get('RefTransactionType').setValue(3);
        item.get('TotallingAccCode').setValue(1110);
        item.get('GLCode').setValue(4);
        item.get('GLCodeDesc').setValue('4-HSBC BANK MIDDLE EAST - Deira');
        item.get('Amount').reset('');
        item.get('Description').setValue('');
        item.get('AnalysisCode').setValue('');
        item.get('Department').setValue('');

      });
      this.getActualAmountSum();

    }
    this.GetAccountingDates();
  }
  updatePaymentVoucherValues(dataReturn: any) {
    this.mainVoucherForm.addControl('VoucherNo', new FormControl(dataReturn.VoucherNo, Validators.required));
  }

  /* update  form values to create-receipt objects*/
  upDateCreatePaymentValues() {
    console.log(this.mainVoucherForm.controls.ChequeDateFld.value, 'this.mainVoucherForm.controls.ChequeDateFld.value;');
    this.createPayment = new CreatePayment();
    const mainFormFieldArray = ['VoucherDate', 'RegionCode', 'Amount', 'PaymentMode', 'ReceiptType', 'ModifiedBy',
      'VendorCode', 'PreparedBy', 'PreparedDate', 'ApprovedBy', 'CustomerID', 'TerminalUserID', 'TerminalUserName',
      'CountryCode', 'ArabicDescription', 'Approvers'];
    mainFormFieldArray.forEach(item => {
      this.createPayment[item] = this.mainVoucherForm.controls[item].value;
    });

    if (this.mainVoucherForm.controls['VoucherNo']) {
      this.createPayment['VoucherNo'] = this.mainVoucherForm.controls['VoucherNo'].value;
    }
    // assign null values
    this.createPayment.PrintDate = null;
    // assign batch when batch payment
    if (this.isBatch) { this.createPayment['Batch'] = true; }
    //
    // this.createPayment.RegionCode = this.mainVoucherForm.controls.accountInfo['controls'].RegionCode.value;
    this.createPayment.LocationCode = this.mainVoucherForm.controls.accountInfo['controls'].LocationCode.value;
    this.createPayment.CostCenterCode = this.mainVoucherForm.controls.accountInfo['controls'].CostCenterCode.value;
    this.createPayment.TotallingAccCode = this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.value;
    this.createPayment.RecevierBankCode = this.mainVoucherForm.controls.accountInfo['controls'].RecevierBankCode.value;
    this.createPayment.Name = this.mainVoucherForm.controls.detailInfo['controls'].PayeeName.value;
    this.createPayment.E_Desc = this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription.value;
    this.createPayment.PmtDetails = this.mainVoucherForm.controls['VoucherDetails'].value;

    if (this.paymentMode === 2) {
      this.createPayment.ChequeNo = this.mainVoucherForm.controls.chequeInfo['controls'].ChequeNo.value;
      this.createPayment.ChequeType = this.mainVoucherForm.controls.chequeInfo['controls'].ChequeType.value;
      this.createPayment.ChequeDate = this.mainVoucherForm.controls.ChequeDateFld.value;
      this.createPayment.PayeeBankCode = this.mainVoucherForm.controls.chequeInfo['controls'].PayeeBankCode.value;
      this.createPayment.PayeeBankName = this.mainVoucherForm.controls.chequeInfo['controls'].PayeeBankName.value;
    }

    if (this.paymentMode === 5) {
      this.createPayment.InstrumentRefNo = this.mainVoucherForm.controls.bankTransfer['controls'].InstrumentRefNo.value;
      this.createPayment.ChequeNo = this.mainVoucherForm.controls.bankTransfer['controls'].InstrumentRefNo.value;
      this.createPayment.ChequeDate = this.mainVoucherForm.controls.ChequeDateFld.value;
      this.createPayment.ChequeType = this.mainVoucherForm.controls.bankTransfer['controls'].ChequeType.value;
      // this.createPayment.PayeeBankCode = this.mainVoucherForm.controls.bankTransfer['controls'].PayeeBankCode.value;
      this.createPayment.BeneficiaryBank = this.mainVoucherForm.controls.bankTransfer['controls'].BeneficiaryBank.value;
      this.createPayment.BeneficiaryBankCurrency = this.mainVoucherForm.controls.bankTransfer['controls'].BeneficiaryBankCurrency.value;
      this.createPayment.BeneficiaryAccNo = this.mainVoucherForm.controls.bankTransfer['controls'].BeneficiaryAccNo.value;
      this.createPayment.BeneficiarySwiftCode = this.mainVoucherForm.controls.bankTransfer['controls'].BeneficiarySwiftCode.value;
      this.createPayment.BeneficiarySortCode = this.mainVoucherForm.controls.bankTransfer['controls'].BeneficiarySortCode.value;
      this.createPayment.CorrespondentBank = this.mainVoucherForm.controls.bankTransfer['controls'].CorrespondentBank.value;
      this.createPayment.IBAN = this.mainVoucherForm.controls.bankTransfer['controls'].IBAN.value;
      this.createPayment.CorrespondentAccNo = this.mainVoucherForm.controls.bankTransfer['controls'].CorrespondentAccNo.value;
      // tslint:disable-next-line:max-line-length
      this.createPayment.CorrespondentBankSwiftCode = this.mainVoucherForm.controls.bankTransfer['controls'].CorrespondentBankSwiftCode.value;
      this.createPayment.ChequeNo = this.mainVoucherForm.controls.bankTransfer['controls'].InstrumentRefNo.value;
      this.createPayment.CorrespondentBankSortCode = this.mainVoucherForm.controls.bankTransfer['controls'].CorrespondentBankSortCode.value;

    }
  }


  submitBulkPayment() {
    this.upDateCreatePaymentValues();
    this.matchedRecords.forEach((data, index) => {
      if (this.paymentMode === 5) {
        this.matchedDetails[index].ChequeDate = data.VoucherDate;
      } else {
        this.matchedDetails[index].ChequeDate = data.Cheque_Date;
      }
      this.matchedDetails[index].Amount = this.matchedDetails[index].NetAmount;
    });

    this.createPayment['PmtDetails'] = this.matchedDetails;
    this.createPayment['GLCode'] = this.defaultGLCode;
    this.createPayment['Filename'] = this.matchedDetails[0].Filename;
    // this.createPayment['TotallingAccCode'] = this.defaultTotallingAccCode;
    // for issue on draft payment as in point 19 in email
    this.createPayment['TotallingAccCode'] = this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.value
    console.log(this.createPayment);
    this.createPaymentService.createPayment(JSON.stringify(this.createPayment)).subscribe(
      dataReturn => {
        this.returnValue = dataReturn;
        console.log(dataReturn);
        this.updatePaymentVoucherValues(dataReturn);

        this.returnValue['approverlist'] = this.approverusers;
        this.returnValue['ondemand'] = true;
        const initialState = {
          'isBatch': true,
          'totalReceiptAmount': this.totalAmount || 0
        };
        console.log(this.returnValue, 'this.returnValue');
        this.previewFlag = true;
        this.bsModalRef = this.modalService.show(PaymentpreviewComponent, {
          class: 'preview-modal-dailog', initialState,
          backdrop: 'static',
          keyboard: false,
        });
        this.bsModalRef.content.data = this.returnValue;
        this.bsModalRef.content.totalAmount = this.totalAmount;
        this.bsModalRef.content.backdrop = true;
      },
      errorRturn => {
        this.errorMsg = errorRturn;
      }
    );
  }

  submitPayment() {
    super.validateDetailInfo();
    if (this.glerrorcount > 0) {
      return false;
    }
    this.usersReq = (this.approverusers !== undefined && this.approverusers !== '' &&
      this.approverusers.length > 0);
    if (!(localStorage.getItem('country') == '3')) {
      if (this.totalAmount > 99999 && !this.usersReq)//UAE no approver needed
      {
        return false;
      }
    }

    if (this.prevPreviewID == null || this.prevPreviewID === undefined) {
      this.prevPreviewID = 0;
      this.createPayment['VoucherNo'] = this.prevPreviewID;
    }
    if (!this.isCN) {
      this.createPayment['PmtDetails'].forEach(detail => {
        detail.PolicyNumber = null;
      });
    }
    this.preSubmission();
    if (this.claimPayment) {
      this.createPaymentService.createClaimPayment(JSON.stringify(this.clonedPayments)).subscribe(
        dataReturn => {
          this.returnValue = dataReturn;
          console.log(dataReturn, " createClaimPayment");
          this.updatePaymentVoucherValues(dataReturn);
          this.returnValue['approverlist'] = this.approverusers;
          this.returnValue['ondemand'] = true;
          console.log(this.returnValue, 'this.returnValue createClaimPayment');
          this.previewFlag = true;
          this.bsModalRef = this.modalService.show(PaymentpreviewComponent, {
            class: 'preview-modal-dailog',
            backdrop: 'static',
            keyboard: false
          });
          this.bsModalRef.content.data = this.returnValue;
          this.bsModalRef.content.totalAmount = this.totalAmount;
          this.bsModalRef.content.claimPayment = true;
          this.bsModalRef.content.backdrop = true;
        },
        errorRturn => {
          this.errorMsg = errorRturn;
        }
      );
    } else {
      this.createPaymentService.createPayment(JSON.stringify(this.clonedPayments)).subscribe(
        dataReturn => {
          this.returnValue = dataReturn;
          console.log(dataReturn);
          this.updatePaymentVoucherValues(dataReturn);
          this.returnValue['approverlist'] = this.approverusers;
          this.returnValue['ondemand'] = true;
          console.log(this.returnValue, 'this.returnValue ');
          this.previewFlag = true;
          this.bsModalRef = this.modalService.show(PaymentpreviewComponent, {
            class: 'preview-modal-dailog',
            backdrop: 'static',
            keyboard: false
          });
          this.bsModalRef.content.data = this.returnValue;
          this.bsModalRef.content.totalAmount = this.totalAmount;
          this.bsModalRef.content.claimPayment = false;
          this.bsModalRef.content.backdrop = true;
        },
        errorRturn => {
          this.errorMsg = errorRturn;
        }
      );
    }
  }

  /* create-receipt form*/
  submitForm() {

    this.editPaymentFromPrevious = false; //resetting the status of Previous button click from Preview window.
    if (this.isBatch) {
      this.fileUploadForm.get('fileContent').markAsTouched();
      console.log(this.fileUploadForm.valid);
      if (!this.fileUploadForm.valid || this.matchedDetails.length <= 0) {
        return false;
      }
      if (this.totalMatchedAmount >= 0) {
        this.alertService.error(RSAMSGConstants.DEBITEXCEEDMSG);
        this.previewBlocked = true;
        return false;
      }
      if (Math.abs(this.totalMatchedAmount) > Math.abs(this.totalIntialAmount)) {
        this.alertService.error('Payment Amount is less than amount of uploaded transactions.');
        return false;
      }
      this.submitBulkPayment();

    } else {
      console.log(this.ondemandFlag);
      super.validateDetailInfo();
      this.upDateCreatePaymentValues();
      console.log(this.createPayment, ' this.createPayment');
      if (this.amountZeroCheck > 0) {
        this.alertService.warn(RSAMSGConstants.AMOUNTZEROCHECK);
        return false;
      }
      if (this.amountLimitCheck > 0) {
        this.alertService.warn(RSAMSGConstants.AMOUNTEXCEEDMSG);
        return false;
      }
      if (this.totalAmount === 0 && this.claimPayment) {
        this.alertService.warn(RSAMSGConstants.AMOUNTZERO);
        return false;
      }
      if (this.ondemandFlag) {
        if (this.glerrorcount > 0) {
          return false;
        }
        if (this.claimPayment) {
          this.submitPayment();
          return false;
        }
        if (this.totalAmount <= 0) {
          this.alertService.warn(RSAMSGConstants.DEBITEXCEEDMSG);
          return false;
        }
        if (this.totalAmount > 0) {
          this.submitPayment();
          return false;
        }
      } else {
        if (this.totalAmount <= 0 && !this.claimPayment && this.glerrorcount >= 0) {
          this.alertService.warn(RSAMSGConstants.DEBITEXCEEDMSG);
          return false;
        }
        this.submitPayment();
      }
    }
  }
  /* check single or batch upload */
  checkSingleOrbatch(e) {
    this.isBatch = !this.isBatch;
    this.totalAmount = 0;
    if (this.isBatch) {
      /*Removing VoucherDetails formarray items while coming from
     periviuos toggle from Single to Batch - Narender - 26/02/2019 Defect ID 5307  */
      const formarray = (<FormArray>this.mainVoucherForm.controls['VoucherDetails']);
      this.clearFormArray(formarray);
      formarray.push(this.createPaymentArrayGroup());
    }
  }
  clearFormArray(formArray: FormArray) {
    while (formArray.length !== 0) {
      formArray.removeAt(0);
    }
  }

  uploadXlsFile(e) {
    if (e.target.files && e.target.files.length) {
      if (e.target.files[0].name.indexOf('.xlsx') === -1) {
        this.alertService.warn(`Please upload a valid Excel file.`);
        return false;
      } else {
        if (e.target.files[0].name.length > 50) {
          this.alertService.warn(`File name cannot exceed 50 characters.`);
          return false;
        }

      }
    }
    if (e.target.files && e.target.files.length) {
      const selectedFiles = e.target.files;
      console.log(selectedFiles.item(0), 'selectedFiles.item(0)');
      this.batchUploadService.uploadBatchFile(selectedFiles.item(0),
        { 'gl': this.defaultGLCode, 'acc': this.defaultTotallingAccCode }).subscribe((data) => {
          this.bulkuploadData = data;
          console.log(this.bulkuploadData, 'Data from API for payment bulk');
          if (Array.isArray(this.bulkuploadData) && this.bulkuploadData.length) {
            console.log(data, 'Data from API-Payment Bulk Upload');
            if (this.checkRecieptCommision.commisionValid === false) {
              this.alertService.warn(`Amount and Commission is blank for Voucher No : ${this.checkRecieptCommision.voucherNo}
              and PolicyNo : ${this.checkRecieptCommision.policyNo}!!`);
              return false;
            }
            this.ifUploadSuccess = false;
            this.matchedRecords = data.filter(item => item.Matched !== false) || [];
            this.setMatchedUnmatched(this.matchedRecords);
          } else {
            this.alertService.error('Invalid data from API');

          }
        });
    }
  }
  get checkRecieptCommision(): any {
    let bulkdata = {};
    this.bulkuploadData.map((item) => {
      if (item.Message !== null) {
        bulkdata = {
          commisionValid: false,
          voucherNo: item.VoucherNo,
          policyNo: item.PolicyNumber
        };
        return false;
      }
    });
    return bulkdata;
  }
  clearXlsFile(e: any) {
    e.target.value = '';
  }

  setMatchedUnmatched(data: any[]) {
    if (Array.isArray(data) && data.length) {
      let receiptDetails = {};
      for (const item of data) {
        receiptDetails = {
          CounterPartyRef: null,
          LocationCode: localStorage.getItem('locationcode'),
          CountryCode: item.Cty_Code,
          ChequeDate: item.Cheque_Date,
          BranchCode: localStorage.getItem('locationcode'),
          LocationDesc: 'Dubai',
          CostCenterCode: localStorage.getItem('costcentre'),
          Description: item.Description,
          Amount: item.GrossAmount || item.Amount || 0,
          RefTransactionID: item.Ref_Tran_Id || '',
          RefTransactionType: item.Ref_Tran_Type,
          TransactionType: item.TransactionType,
          IsDebitEntry: true,
          PolicyID: item.PolicyID || '',
          PolicyNumber: item.PolicyNumber,
          ModifiedBy: item.ModifyBy || '',
          Filename: item.Filename,
          ReceiptDate: new DatePipe('en-US').transform(new Date(), 'dd-MM-yyyy'),
          CustomerID: item.Customer_Id,
          AnalysisCode: '',
          DepartmentCode: '',
          Department: '',
          VoucherDate: item.VoucherDate || null,
          Commision: item.Commision || 0,
          NetAmount: item.NetAmount || Number(item.GrossAmount || item.Amount) + Number(item.Commision),
          RefTransactionSerialNo: item.SerialNo,
          GLCode: this.defaultGLCode,
          GLCodeDesc: this.defaultGLCodeDesc,
          RegionCode: localStorage.getItem('regioncode'),
          TotallingAccCode: this.defaultTotallingAccCode,
          PolicyYear: item.PolicyYear || '',
          PolicyType: item.PolicyType || '',
          PlaceHolderCode: null,
          Endt_ID: item.EndtId,
          GLAccountName: null,
          CostCenterName: null,
          TotallingAccName: null,
          BranchName: null,
          DepartmentName: '',
          GLAccount: null,
          ClassCode: item.ClassCode,
          ClaimID: item.Claim_Id,
          VoucherType: null,
          TransactionNo: null,
          RefTranType: null,
          VoucherNo: item.VoucherNo || null,
          ExcelVoucherNo: item.VoucherNo || null,
          CityCode: item.CityCode,
          // Aaded new formControlName to make row readonly if coming from selection rows
          newAddedRow: false,
          CauseOfLoss: '',
          NatureOfLoss: '',
          settlementType: ''
        };

        this.matchedDetails.push(receiptDetails);

      }
      this.getMatchedUnmatchedAmtsum(this.matchedDetails);
    }
  }
  // get paymentRows() { return <FormArray>this.paymentBulkForm.get('paymentBulkFormArray'); }
  deleteMatchedRecord(index, row) {
    this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
    this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
    this.bsModalRef.content.modelBodyContent = RSAMSGConstants.DELETEMSGRECEIPTL;
    this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
    this.bsModalRef.content.actionBtn = RSAMSGConstants.BTNPROCEED;
    this.bsModalRef.content.valueChange.subscribe((data) => {
      if (data = 'Proceed') {
        console.log(index);
        this.matchedDetails.splice(index, 1);
        this.matchedRecords.splice(index, 1);
        this.getMatchedUnmatchedAmtsum(this.matchedDetails);
      }
      if (this.totalMatchedAmount >= 0) {
        // this.alertService.error(RSAMSGConstants.DEBITEXCEEDMSG);
         this.previewBlocked = true;
         return false;
       } else {
         this.previewBlocked = false;
       }
    });
    
  }
  getbatchTotalAmt(amt: any) {
    if (this.isBatch) {
      this.totalAmount = amt;
      this.totalIntialAmount = -Math.abs(amt);
    }

  }
  // getMatchedUnmatchedAmtsum(data: any[]) {
  //   if (toString.call(data) !== '[object Array]') {
  //     return false;
  //   }
  //   let total = 0;
  //   for (let i = 0; i < data.length; i++) {
  //     if (isNaN(data[i].Amount)) {
  //       continue;
  //     }
  //     total += Number(data[i].Amount);
  //   }
  //   this.totalMatchedAmount = total.toFixed(2);
  // }


  getMatchedUnmatchedAmtsum(data: any[]) {
    if (toString.call(data) !== '[object Array]') {
      return false;
    }
    let total = 0;
    let comm = 0;
    for (let i = 0; i < data.length; i++) {
      total += Number(data[i].Amount) || 0;
      comm += Number(data[i].Commision) || 0;
    }
    const net = Number(total) + Number(comm);
    this.totalMatchedAmount = net.toFixed(2);
  }
  addNewTransaction() {
    const initialState = {
      'branchdata': this.branchdata,
      'costcentredata': this.costcentredata,
      'glaccount': this.glaccount,
      'isEntityPaymentFeildReq': !this.ondemandFlag,
      'voucherDetailsLength': this.voucherDetailsLength,
      'transactiontype': this.transactiontype,
      'department': this.department,
      'pjctindicator': this.pjctindicator,
      'TotallingAccCode': this.defaultTotallingAccCode,
      'GLCodeDesc': this.defaultGLCodeDesc,
      'loccode': this.mainVoucherForm.controls.accountInfo['controls'].LocationCode.value,
      'ccode': this.mainVoucherForm.controls.accountInfo['controls'].CostCenterCode.value,
      'totAccCode': this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.value,
      'EnglishDescription': this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription.value,
      'isPaymentFromEntity': this.isPaymentFromEntity,
      'defaultGLCode': this.defaultGLCode,
      'cachedGL': this.cachedGL,
      'settlementType': this.settlementTypeData
    };


    this.bsModalRef = this.modalService.show(AddNewTransactionComponent,
      { class: 'gray modal-add-new-receipt', ignoreBackdropClick: true, backdrop: true, initialState });
    this.bsModalRef.content.actionBtn = RSAMSGConstants.BTNPROCEED;
    this.bsModalRef.content.dtltotallingacc = this.dtltotallingacc;
    // this.bsModalRef.content.defaultGLCode = this.defaultGLCode;
    this.bsModalRef.content.valueChange.subscribe((data) => {
      console.log(data);
      data['Filename'] = this.matchedDetails[0].Filename;
      this.matchedDetails.push(data);
      this.getMatchedUnmatchedAmtsum(this.matchedDetails);
      if (this.totalMatchedAmount >= 0) {
        // this.alertService.error(RSAMSGConstants.DEBITEXCEEDMSG);
         this.previewBlocked = true;
         return false;
       } else {
         this.previewBlocked = false;
       }
    });
    
  }

  resetOnlyPaymentModeHeaderDetails(val) {
    if (val == 1) {
      this.mainVoucherForm.controls.detailInfo['controls'].PayeeName.reset();
      this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription.reset();
    }
    if (val == 2) {
      this.mainVoucherForm.controls.chequeInfo['controls'].ChequeNo.reset('');
      this.mainVoucherForm.controls.chequeInfo['controls'].ChequeDate.reset(new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy'));
      this.mainVoucherForm.controls.chequeInfo['controls'].PayeeBankCode.reset('');
      this.mainVoucherForm.controls.chequeInfo['controls'].PayeeBankName.reset('');
      this.mainVoucherForm.controls.detailInfo['controls'].PayeeName.reset();
      this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription.reset();
    }

    if (val == 5) {
      this.mainVoucherForm.controls.bankTransfer['controls'].InstrumentRefNo.reset();
      this.mainVoucherForm.controls.bankTransfer['controls'].ChequeDate.reset(new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy'));
      this.mainVoucherForm.controls.bankTransfer['controls'].PayeeBankName.reset();
      this.mainVoucherForm.controls.bankTransfer['controls'].BeneficiaryBank.reset();
      this.mainVoucherForm.controls.bankTransfer['controls'].BeneficiaryBankCurrency.reset();
      this.mainVoucherForm.controls.bankTransfer['controls'].BeneficiarySwiftCode.reset();
      this.mainVoucherForm.controls.bankTransfer['controls'].BeneficiarySortCode.reset();
      this.mainVoucherForm.controls.bankTransfer['controls'].CorrespondentBank.reset();
      this.mainVoucherForm.controls.bankTransfer['controls'].IBAN.reset();
      this.mainVoucherForm.controls.bankTransfer['controls'].CorrespondentAccNo.reset();
      this.mainVoucherForm.controls.bankTransfer['controls'].CorrespondentBankSwiftCode.reset();
      this.mainVoucherForm.controls.bankTransfer['controls'].CorrespondentBankSortCode.reset();
      this.mainVoucherForm.controls.detailInfo['controls'].PayeeName.reset();
      this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription.reset();
    }
  }
  preSubmission() {
    let flagtoggle: boolean = false;
    let amt: number = 0;
    this.clonedPayments = Object.assign({}, this.createPayment);
    this.clonedPayments.PmtDetails.forEach((element, index) => {
      flagtoggle = element.IsDebitEntry;
      if (!flagtoggle) {
        element.Amount = (Math.abs(element.Amount) * -1);
      }
      if (this.paymentVATFlag && !this.ifnewlyAddedRow) {
        if ((index % 2) !== 0) {
          console.log(element, 'element');
          element.VATAmount = element.Amount;
          element.Amount = element.Amount;
        }
        element['PAYMENTVATflag'] = true;
      }
    });
    console.log('this.clonedPayments', this.clonedPayments);
  }

  getActualAmountSum() {
    let total: number = 0;
    let amt: number = 0;
    let actualamt: number = 0;
    let flagtoggle: boolean = false;
    (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls.forEach((element, index) => {

      if (this.getFromFormArrayControlVal("Amount", index) != undefined
        && this.getFromFormArrayControlVal("Amount", index) != null) {
        flagtoggle = this.getFromFormArrayControlVal("IsDebitEntry", index);
        amt = parseFloat(this.getFromFormArrayControlVal("Amount", index));
        amt = Math.abs(amt);
        actualamt = (flagtoggle) ? amt : (amt * -1);
        console.log('flagtoggle:' + flagtoggle + ",amt:" + amt + ",actualamt:" + actualamt);
        total = total + actualamt;
      }

    });

    this.totalAmount = (total == null || total == undefined || isNaN(total)) ? 0.00 : total;
  }
  setPaymentDetails() {
    if (this.paymentDetails !== '' && this.paymentDetails !== undefined) {
      this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription.setValue(this.paymentDetails);
    }
    if (this.paymentClaimDetails !== '' && this.paymentClaimDetails !== undefined) {
      this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription.setValue(this.paymentClaimDetails);
    }
  }
}

