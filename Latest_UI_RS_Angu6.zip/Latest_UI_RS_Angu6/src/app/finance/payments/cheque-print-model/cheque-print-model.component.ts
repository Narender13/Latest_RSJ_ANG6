import { Component, Input, ViewChild, EventEmitter, OnInit, Output, ElementRef } from '@angular/core';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { FormGroup, Validators, FormBuilder, FormArray } from '@angular/forms';
import { ChequePrintService } from '../cheque-print/service/cheque-print.service';
import { ChequePrint } from '../cheque-print/model/cheque-print.model';
@Component({
    selector: 'app-chque-print-dialog',
    templateUrl: './cheque-print-model.component.html',
    styleUrls: ['./cheque-print-model.component.scss']
})
export class ChequePrintDialogComponent implements OnInit {
    noBtn: string;
    yesBtn: string;
    cancelBtn: string;
    printBtn: string;
    modelTitle: string;
    modelBodyContent: string;
    smallMessage: string;
    comment: string;
    chequeNumber: number;
    showPrint: boolean;
    showReprint: boolean;
    // reprintPopup = false;
    chequeReprintForm: FormGroup;
    damagedChequeForm: FormGroup;
    errorMsg: string;
    selectedVouchersList: any = [];
    selectedChequesList: any = [];
    paymentType: string;
    countryCode: number;
    selectedBankCode: string;
    @Output() valueChange = new EventEmitter();

    constructor(
        private fb: FormBuilder,
        private chequeService: ChequePrintService,
        public bsModalRef: BsModalRef) {

    }
    ngOnInit() {

    }
    createForm() {
        this.damagedChequeForm = this.fb.group({
            vouchersList: this.fb.array([this.createFormGroup()])
        });

        const list = this.selectedVouchersList.map((item) => {
            return this.fb.group({
                id: item.id,
                Status: false,
                Remark: '',

            });
        });

        const arrayList = this.fb.array(list);
        this.damagedChequeForm.setControl('vouchersList', arrayList);
    }
    createFormGroup() {

        return this.fb.group({
            id: null,
            Status: false,
            Remark: '',
        });
    }
    valueChanged(e) {
        this.valueChange.emit(e.srcElement.innerText);
        this.bsModalRef.hide();
    }
    reSetForm(): void {
        this.chequeReprintForm.controls['ChequeNumber'].reset();
        this.chequeReprintForm.controls['Comment'].reset();
    }
    showRePrintDialog(): void {
        this.showPrint = false;
        this.showReprint = true;
        // this.reprintPopup = false;
    }
    updateSelectedList(e, item, index, remark) {
        const isCheckBoxSelect = e.srcElement.checked;
        if (isCheckBoxSelect) {
            item.Remark = remark;
            this.damagedChequeForm.controls.vouchersList['controls'][index].controls.Remark.setValidators(Validators.required);
            this.damagedChequeForm.controls.vouchersList['controls'][index].controls.Remark.updateValueAndValidity();
            this.selectedChequesList.push({ item: item, i: index });
            console.log(this.selectedChequesList, 'selectedChequesList');
        } else {
            this.damagedChequeForm.controls.vouchersList['controls'][index].controls.Remark.clearValidators(Validators.required);
            this.damagedChequeForm.controls.vouchersList['controls'][index].controls.Remark.updateValueAndValidity();
            this.selectedChequesList.splice(index, 1);
        }
    }
    updateComment(item, remark, index) {
        if (this.selectedChequesList.length > 0) {
            item.Remark = remark;
            this.selectedChequesList[index].item = item;
        }
        console.log('item', item);
    }
    updateDamagedCheques(): void {
        console.log(this.selectedChequesList, 'selectedDamagedChequesList');
        // this.reprintPopup = true;
        const selectedIds = this.selectedChequesList.map(data => data.item.VoucherNo);
        const selectedComments = this.selectedChequesList.map(data => data.item.Remark);
        const param = {
            VoucherNos: selectedIds || 0,
            paymentType: this.paymentType,
            Remarks: selectedComments || null
        };
        this.chequeService.ChangeChequePrintDamaged(param).subscribe(data => {
            this.bsModalRef.hide();
            this.valueChange.emit('damaged');
        });
    }
    setVoucherChequeNumber(chequeNumber: number) {
        this.selectedVouchersList.forEach((item, index) => {
            item.ChequeNo = chequeNumber + index + 1;
        });
    }
    get isValid() { return this.damagedChequeForm.controls['Remark'].valid; }

}
