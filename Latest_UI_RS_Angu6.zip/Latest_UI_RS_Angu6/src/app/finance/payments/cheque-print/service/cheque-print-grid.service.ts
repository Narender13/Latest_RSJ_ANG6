import { Injectable } from '@angular/core';
import { DatePipe } from '@angular/common';

@Injectable({
    providedIn: 'root'
})

export class ChequePrintGridService {
    constructor(public datepipe: DatePipe) { }
    getColumnHeaderPropertyNames() {
        return [
            {
                headerName: 'Voucher No',
                field: 'VoucherNo',
                width: 150,
                headerCheckboxSelection: true,
                headerCheckboxSelectionFilteredOnly: true,
                checkboxSelection: true,
                filter: 'agNumberColumnFilter',
                filterParams: { selectAllOnMiniFilter: true, cellHeight: 30, },
                headerTooltip: 'Voucher No',
            },
            {
                headerName: 'Cheque Number',
                field: 'ChequeNo',
                width: 150,
                hide: true,
                filter: 'agNumberColumnFilter',
                filterParams: { selectAllOnMiniFilter: true, cellHeight: 30, },
                headerTooltip: 'Cheque Number',
            },
            {
                headerName: 'Voucher Date',
                field: 'VoucherDate',
                width: 140,
                filter: 'agDateColumnFilter',
                headerTooltip: 'Voucher Date',
                valueFormatter: (data) => {
                    console.log(data.value, 'value');
                    return data.value;
                }
            },
            {
                headerName: 'Cheque Date',
                field: 'ChequeDate',
                width: 140,
                hide: true,
                filter: 'agDateColumnFilter',
                headerTooltip: 'Cheque Date',
                valueFormatter: (data) => {
                    console.log(data.value, 'value');
                    return data.value;
                }
            },
            {
                headerName: 'Print Date',
                field: 'PrintDate',
                width: 120,
                filter: 'agDateColumnFilter',
                headerTooltip: 'Print Date',
                valueFormatter: (data) => {
                    return data.value;
                }
            },
            {
                headerName: 'Payee Name',
                field: 'Payee',
                filter: 'agSetColumnFilter',
                headerTooltip: 'Payee Name',

            },
            {
                headerName: 'Description',
                field: 'Particulars',
                width: 130,
                filter: 'agSetColumnFilter',
                headerTooltip: 'Description',
            },
            {
                headerName: 'Amount',
                field: 'Amount',
                width: 120,
                type: 'numericColumn',
                filter: 'agNumberColumnFilter',
                cellRenderer: 'currencyRenderer',
                headerTooltip: 'Amount',
                valueFormatter: function (params) {
                    return Math.floor(params.value).toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
                }
            },
            {
                headerName: 'Status',
                field: 'Status',
                width: 120,
                filter: 'agSetColumnFilter',
                headerTooltip: 'Status'
            },
            {
                headerName: 'Remarks',
                field: 'Remarks',
                filter: 'agSetColumnFilter',
                headerTooltip: 'Remarks'
            }
        ];
    }
}

