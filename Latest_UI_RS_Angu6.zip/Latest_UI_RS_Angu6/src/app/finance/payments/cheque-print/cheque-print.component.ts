import { Component, OnInit, ViewChild, EventEmitter, AfterViewInit, Input } from '@angular/core';
import { Router } from '@angular/router';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';

import { SharedService } from '../../services/shared.service';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { MasterDataService } from '../../services/finance.masterdata.service';
import { ChequePrintService } from './service/cheque-print.service';
import { GridOptions } from 'ag-grid-community';
import { ChequePrintGridService } from './service/cheque-print-grid.service';
import { GridApiService } from 'src/app/shared/datatable/services/grid-api-service';
import { AgGridNg2 } from 'ag-grid-angular';
import { CurrencyRendererComponent } from 'src/app/shared/datatable/services/currency-renderer.component';
import { ChequePrint } from './model/cheque-print.model';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';
import { ChequePrintDialogComponent } from '../cheque-print-model/cheque-print-model.component';

@Component({
    // tslint:disable-next-line:component-selector
    selector: 'rsa-cheque-print',
    templateUrl: './cheque-print.component.html',
    styleUrls: ['./cheque-print.component.scss', '../../../shared/datatable/datatable.component.scss']
})
export class ChequePrintComponent implements OnInit, AfterViewInit {
    @ViewChild('agGrid') agGrid: AgGridNg2;
    title = 'Cheque Print';
    chequeForm: FormGroup;
    paymentType: string;
    payeedataBankName: any = [];
    errorMsg: string;
    isClaims = false;
    isInSpool = true;
    userID = 18100;
    rowData: ChequePrint[] = [];
    selectedVouchersList: ChequePrint[] = [];
    selectedBankCode: number;
    gridApi;
    gridColumnApi;
    paginationOptions = [];
    @Input() gridConfiguration: GridOptions = {};
    columnDefs = [];
    frameworkComponents;
    domLayout;
    isResults = false;
    chequeStatus: TextValuePair[] = [];
    currentpageSize: number;
    currentPageStart: number;
    currentPageEnd: number;
    totalCount: number;
    // snakbar
    showSnackbar = false;
    showCreateReceiptForm;
    config = {
        backdrop: false,
        ignoreBackdropClick: false,
        class: 'create-modal-dailog'
    };
    constructor(
        public bsModalRef: BsModalRef,
        private modalService: BsModalService,
        private fb: FormBuilder,
        private chequeService: ChequePrintService,
        private masterDataService: MasterDataService,
        private gridservice: ChequePrintGridService,
        private gridApiService: GridApiService

    ) {
        this.getBankData();
        this.paginationOptions = [
            { label: 'Ten', value: '10' },
            { label: 'hundred', value: '100' },
            { label: 'fivehundred', value: '500' },
            { label: 'thousand', value: '1000' }
        ];

        this.chequeStatus = [
            { id: 0, value: 'In Spool' },
            { id: 1, value: 'Damaged' },
        ];

        this.frameworkComponents = {
            currencyRenderer: CurrencyRendererComponent,
        };
        this.gridConfiguration = <GridOptions>{
            columnDefs: this.gridservice.getColumnHeaderPropertyNames(),
            rowData: this.rowData,
            rowHeight: 40,
            headerHeight: 40,
            pagination: true,
            floatingFiltersHeight: 40,
            paginationPageSize: 10,
            enableRangeSelection: false,
            rowSelection: 'multiple',
            animateRows: true,
            enableColResize: true,
            enableFilter: true,
            suppressContextMenu: true,
            enableSorting: true,
            suppressCellSelection: true,
            suppressRowClickSelection: false,
            defaultColDef: {
                enableRowGroup: false, enableValue: true,
                suppressMovable: true,
                minWidth: 100, menuTabs: ['filterMenuTab', '', '']
            },
        };
        this.domLayout = 'autoHeight';
    }

    ngOnInit() {
        this._buildForm();
        this.gridApiService.isUnCheck().subscribe(() => {
            this.gridConfiguration.api.deselectAll();
        });
        this.currentpageSize = 10;
        this.currentPageStart = 1;

        if (this.rowData.length <= 0) {
            this.currentPageStart = 0;
        }
        if (this.rowData.length <= this.currentpageSize) {
            this.currentPageEnd = this.rowData.length;
        } else {
            this.currentPageEnd = this.currentpageSize;
        }
    }
    // tslint:disable-next-line:use-life-cycle-interface
    ngAfterViewInit() {
        // this.gridConfiguration.api.sizeColumnsToFit();
    }
    _buildForm() {
        this.chequeForm = this.fb.group({
            chequeNumber: ['', Validators.maxLength(12)],
            CountryCode: [1],
            LocationCode: [localStorage.getItem('locationcode')],
            RegionCode: [localStorage.getItem('regioncode')],
            PayeeBankCode: [''],
        });
    }
    onGridReady(params) {
        this.gridApi = params.api;
        this.gridColumnApi = params.columnApi;
        this.gridConfiguration.api.setRowData(this.rowData);
        params.api.paginationGoToPage(0);
        this.gridConfiguration.api.sizeColumnsToFit();
    }
    onRowSelected(params) {
        // const isSelect = params.node.isSelected();
        const selectedRows = this.gridApi.getSelectedRows();
        // const currRowData = params.data;
        const count = selectedRows.length;
        this.totalCount = count;
        if (count) {
            this.showSnackbar = true;
            this.selectedVouchersList = selectedRows;

        } else {
            this.showSnackbar = false;
        }
    }
    onPaginationChanged() {
        if (this.gridApi) {
            const currentpage = this.gridApi.paginationGetCurrentPage() + 1;

            this.currentPageStart = (this.currentpageSize * (currentpage - 1)) + 1;
            if (this.rowData.length <= this.currentpageSize * currentpage) {
                this.currentPageEnd = this.rowData.length;
            } else {
                this.currentPageEnd = this.currentpageSize * currentpage;
            }
            if (this.rowData.length <= 0) {
                this.currentPageStart = 0;
            }

        }
    }
    onPageSizeChanged(newPageSize) {
        const value = +(newPageSize.srcElement.value);
        this.gridApi.paginationSetPageSize(value);
        this.gridApi.sizeColumnsToFit();
        this.currentpageSize = value;
    }
    onBanknameChange(e) {
        const value = +(e.srcElement.value);
        if (value) {
            this.selectedBankCode = value;
            this.getChequeData(this.isClaims, this.isInSpool);
        }
        this.close();
    }
    changeStatus(e) {
        this.close();

        const value = +(e.srcElement.value);
        if (value === 0) {
            if (this.gridColumnApi) {
                this.gridColumnApi.setColumnVisible('VoucherNo', true);
                this.gridColumnApi.setColumnVisible('ChequeNo', false);
                this.gridColumnApi.setColumnVisible('ChequeDate', false);
                this.gridColumnApi.setColumnVisible('VoucherDate', true);
                this.gridConfiguration.suppressRowClickSelection = false;
                // this.gridColumnApi.setColumnVisible('Remarks', false);
            }
        } else if (value === 1) {
            if (this.gridColumnApi) {
                this.gridColumnApi.setColumnVisible('VoucherNo', false);
                this.gridColumnApi.setColumnVisible('ChequeNo', true);
                this.gridColumnApi.setColumnVisible('ChequeDate', true);
                this.gridColumnApi.setColumnVisible('VoucherDate', false);
                this.gridConfiguration.suppressRowClickSelection = true;
                // this.gridColumnApi.setColumnVisible('Remarks', true);
            }
        }
        this.isInSpool = value === 0 ? true : false;
        this.getChequeData(this.isClaims, this.isInSpool);
    }
    checkGeneralOrClaims(e) {
        this.isClaims = !this.isClaims;
        console.log(this.isClaims);
        this.getChequeData(this.isClaims, this.isInSpool);
        this.close();
    }
    getBankData() {
        const ccentre = localStorage.getItem('costcentre');
        const totcode = 1110;

        const param = 'totallingAccCode=' + totcode +
            '&costCenter=' + ccentre;
        this.masterDataService.getBankData(param).subscribe(
            dataReturn => {
                this.payeedataBankName = dataReturn;
                this.selectedBankCode = this.payeedataBankName[0].BankCode || null;
                this.getChequeData(this.isClaims, this.isInSpool);
            },
            errorRturn => this.errorMsg = errorRturn
        );
    }
    getChequeData(isClaims: boolean, isInSpool: boolean) {
        const paymenttype = isClaims ? 'ClaimsPayment' : 'GenericPayment';
        const param = 'bankCode=' + this.selectedBankCode + '&paymentType=' + paymenttype;

        this.chequeService.getChequePrintData(param)
            .subscribe(
                dataReturn => {
                    this.rowData = dataReturn.filter(data => data !== null && data.VoucherNo !== null);
                    if (this.rowData != null && this.rowData.length > 0) {
                        this.rowData = this.rowData.sort((a, b) => b.VoucherNo - a.VoucherNo);
                    }
                    console.log(dataReturn, 'typeof(dataReturn)');
                    if (!isInSpool) {
                        this.rowData = this.rowData.filter(data => data.Status === 'Damaged');
                    }
                    this.isResults = true;
                },
                errorRturn => this.errorMsg = errorRturn
            );
    }

    unSelectCheckbox() {
        this.gridApiService.unCheck();
    }
    buttonHandler() {
        // update cheque status as printed
        const chequeLastNumber = parseInt(this.getFormCtrlValue('chequeNumber'), 0);
        this.setVoucherChequeNumber(chequeLastNumber);
        let selectedIds = '';
        // const userId = localStorage.getItem('userid'); -- taking default as 18100

        this.selectedVouchersList.forEach(data => {
            if (selectedIds !== '') {
                selectedIds = selectedIds + ',';
            }
            selectedIds = selectedIds + data.VoucherNo.toString();
        });
        const countrycode = this.getFormCtrlValue('CountryCode');
        const paymenttype = this.isClaims ? 'ClaimsPayment' : 'GenericPayment';
        const param = 'strVoucherNos=' + selectedIds + '&bankCodes=' + this.selectedBankCode + '&paymentTypes=' + paymenttype
            + '&lastChequeNumber=' + chequeLastNumber + '&countryCode=' + countrycode + '&userID=' + this.userID;

        this.chequeService.ChangeChequePrintPrinted(param).subscribe(data => {
            this.printCheques(data, 'application/pdf', 'ChequePrint.pdf');
        });

        // assign model values
        // tslint:disable-next-line:max-line-length
        this.bsModalRef = this.modalService.show(ChequePrintDialogComponent, { class: 'confirmation-dailog-box-cheque-print modal-md', backdrop: 'static', keyboard: false });
        this.bsModalRef.content.modelTitle = RSAMSGConstants.CHEQUEPRINTSUCCESS;
        this.bsModalRef.content.modelBodyContent = this.totalCount + ' Cheque(s) Printed';
        this.bsModalRef.content.showPrint = true;
        this.bsModalRef.content.showReprint = false;
        // tslint:disable-next-line:max-line-length
        this.bsModalRef.content.selectedVouchersList = this.selectedVouchersList;

        this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
        this.bsModalRef.content.yesBtn = RSAMSGConstants.YESTEXT;
        this.bsModalRef.content.printBtn = RSAMSGConstants.PRINTTEXT;
        this.bsModalRef.content.noBtn = RSAMSGConstants.NOTEXT;
        this.bsModalRef.content.chequeNumber = this.chequeForm.get('chequeNumber').value;
        this.bsModalRef.content.paymentType = paymenttype;
        this.bsModalRef.content.countryCode = countrycode;
        this.bsModalRef.content.selectedBankCode = this.selectedBankCode;
        this.bsModalRef.content.createForm();
        console.log('Name:' + this.chequeForm.get('chequeNumber').value);

        this.bsModalRef.content.valueChange.subscribe((newdata) => {
            // update  grid data
            this.getChequeData(this.isClaims, this.isInSpool);
            this.close();
        });
    }

    close() {
        this.showSnackbar = false;
        this.chequeForm.controls['chequeNumber'].reset();
        this.unSelectCheckbox();
    }

    setVoucherChequeNumber(chequeNumber: number) {
        this.selectedVouchersList.forEach((item, index) => {
            item.ChequeNo = chequeNumber + index + 1;
        });
    }

    getFormCtrlValue(contrlName) {
        return this.chequeForm.controls[contrlName].value;
    }
    public printCheques(blob: any, type: string, filename: string) {
        const blobfile = new Blob([blob], { type: type });
        const url = URL.createObjectURL(blobfile);
        const id = filename + (new Date()).getTime().toString();
        // tslint:disable-next-line:max-line-length
        const printWindow = window.open(url, id);

        printWindow.print();
        printWindow.addEventListener('afterprint', () => {
            printWindow.close();
        });
        // printWindow.close();
    }
    onQuickFilterChanged(e) {
        this.gridApi.setQuickFilter(e.data);
    }
}
interface TextValuePair {
    id: number;
    value: string;
}
