import { Component, OnInit } from '@angular/core';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';

@Component({
  selector: 'rsa-page401',
  templateUrl: './page401.component.html',
  styleUrls: ['./page401.component.scss']
})
export class Page401Component implements OnInit {
  
  constructor(private adalSvc: MsAdalAngular6Service) { }

  ngOnInit() {
   
  }
logout(){
  this.adalSvc.logout();
  localStorage.clear();
}
}
