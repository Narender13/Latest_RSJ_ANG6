import { Injectable } from '@angular/core';
import { HttpClient, HttpClientModule, HttpHeaders } from '@angular/common/http';
import { Response } from "@angular/http";
// import { Observable } from 'rxjs';
// import 'rxjs/add/operator/map';
import { Router } from '@angular/router';
import { RSAConstants } from 'src/app/core/constants/rsaconstant';
import { RSAENDPOINTConstants } from 'src/app/core/constants/rsa.api.end.points';
import { map, catchError } from 'rxjs/operators';
import { handleErrorObservable } from 'src/app/shared/utilites/helper';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';

@Injectable()
export class AuthService {
  
  //readonly rootUrl = 'http://localhost:4200/assets/json/credentials.json';
  allowedroles:any=[];
  returndata:any;
  errormsg:string;
  constructor(private http: HttpClient, private router: Router,private adalSvc: MsAdalAngular6Service ) { }

  login(userName:string,password:string){
    
    let data: string = "username=" + userName + "&password=" + password + "&grant_type=password";
    let reqHeader: HttpHeaders = new HttpHeaders({'Content-Type': 'application/x-www-urlencoded','No-Auth':'True' });
    return this.http.post(RSAENDPOINTConstants.LOGIN_INTERNAL, data, { headers: reqHeader }).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('login error')));
  }
  goHome(){
    this.router.navigateByUrl('/home');
  }
  setAuthToken(data:any){
    localStorage.setItem(RSAConstants.token,data.access_token);
  }
  getAuthToken():string{
    return localStorage.getItem(RSAConstants.token);
  // return localStorage.getItem("userToken");
  
  }
  setRefreshToken(data:any){
    localStorage.setItem(RSAConstants.token,data.refresh_token);
  }
  getRefreshToken():string{
    return localStorage.getItem(RSAConstants.token);
  }
  clearAuthToken(){
    localStorage.removeItem(RSAConstants.token);
  }  
  logout(){
    if(window.localStorage){
      localStorage.removeItem(RSAConstants.token);
      localStorage.removeItem('userProfileObject');
      this.adalSvc.logout();
      localStorage.clear();
    }      
    this.router.navigateByUrl('/login');
  }

     sendToken(token: string) {
        localStorage.setItem(RSAConstants.token, token);
      }
      getToken() {
        return localStorage.getItem(RSAConstants.token);
      }
      isLoggednIn() {
      //  console.log(localStorage.getItem('LoggedInUser'));
        if(localStorage.getItem(RSAConstants.token)!==null){
          return true;
        }else{
         // console.log("false");
          return false;
        }
      }
      setUserInfo(userinfo:object){
        localStorage.setItem('userProfileObject', JSON.stringify(userinfo));
        if(localStorage.getItem('userProfileObject')){
          var userProfile = JSON.parse(localStorage.getItem('userProfileObject'));
          console.log("user profile info"+JSON.stringify(userProfile));
          //this.username=userProfile.userName;
          console.log("user name"+userProfile.userName);
          localStorage.setItem('userId',userProfile.userName);
          let username=userProfile.userName.split('.');
          var result=username[1].split('@');
          localStorage.setItem('userName',username[0]+' '+result[0]);
        }
      }

      getUserID(){
      return  localStorage.getItem('userId');
      }
      getUserName(){
      return  localStorage.getItem('userName');
      }
      
   
}
