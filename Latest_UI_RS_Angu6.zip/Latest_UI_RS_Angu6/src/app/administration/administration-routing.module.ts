import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminHomeComponent } from './admin-home/admin-home.component';
import { AdminMastersComponent } from './admin-masters/admin-masters.component';

const routes: Routes = [
  { path: '',
  children:[
    {path:'',component:AdminHomeComponent, data: { breadcrumb: 'admin', path: 'Finance Admin' }},
    { path: ':masterName', component: AdminMastersComponent, data: { breadcrumb: 'admin', path: 'Finance Admin' } },
  ]
}
   
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdministrationRoutingModule { }
