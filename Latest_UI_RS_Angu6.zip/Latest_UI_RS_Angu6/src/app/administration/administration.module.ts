import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../shared/shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AdministrationRoutingModule } from './administration-routing.module';
import { AdminHomeComponent } from './admin-home/admin-home.component';
import { AdminMastersComponent } from './admin-masters/admin-masters.component';
import { InstrumentTypesComponent} from './admin-masters/instrument-types/instrument-types.component';
import { AgGridModule } from 'ag-grid-angular';
import 'ag-grid-enterprise';
import { ModalModule } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { AgGridAdminEditViewButtonComponent } from 'src/app/administration/admin-masters/ag-grid-edit-view-button/ag-grid-edit-view-button.component';
import {AgCustomTextComponent} from 'src/app/shared/ag-custom-text/ag-custom-text.component';
import { TransactionsComponent } from './admin-masters/transactions/transactions.component';
import { PaymentmodesComponent } from './admin-masters/paymentmodes/paymentmodes.component';
import { CostCentersComponent } from './admin-masters/cost-centers/cost-centers.component';
@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    AdministrationRoutingModule,
    AgGridModule.withComponents([  
      AgGridAdminEditViewButtonComponent,
     AgCustomTextComponent,
    ]),
    ModalModule.forRoot()
  ],
  declarations: [AdminHomeComponent, AdminMastersComponent,InstrumentTypesComponent,AgGridAdminEditViewButtonComponent, TransactionsComponent, PaymentmodesComponent, CostCentersComponent ],
  entryComponents: [],
  providers:[BsModalRef]
})
export class AdministrationModule { }
