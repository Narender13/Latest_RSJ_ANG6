import { Injectable } from '@angular/core';
import { HttpParams, HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { map, catchError, tap, shareReplay } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { RSAENDPOINTConstants } from 'src/app/core/constants/rsa.api.end.points';
import { handleErrorObservable } from 'src/app/shared/utilites/helper';
import { Instrumenttypes } from './../admin-masters/instrument-types/Model/instrumenttypes';
import { Transactions } from './../admin-masters/transactions/model/transactions';
import {PaymentModes} from './../admin-masters/paymentmodes/model/paymentmodes';
import {CostCenter} from './../admin-masters/cost-centers/model/costcenter';
@Injectable({
  providedIn: 'root'
})
export class AdminMastersService {

  constructor(private http: HttpClient) { }

  getAdminUrlsList(): Observable<any> {
    return this.http.get(RSAENDPOINTConstants.FINANCEADMINMASTERS).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('getAdminUrlsList')));
  }
  getInstrumentTypes(): Observable<Array<Instrumenttypes>> {
    return this.http.get(RSAENDPOINTConstants.INSRUMENTTYPES + '/GetAll').pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('getInstrumentTypes')));
  }
  addInstrumentType(params): Observable<Instrumenttypes> {
    return this.http.post<Instrumenttypes>(RSAENDPOINTConstants.INSRUMENTTYPES + '/Post', params).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('addInstrumentType')));
  }
  updateInstrumentType(params): Observable<Instrumenttypes> {
    return this.http.put<Instrumenttypes>(RSAENDPOINTConstants.INSRUMENTTYPES + '/Put', params).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('updateInstrumentType')));
  }
  deleteInstrumentType(params): Observable<Instrumenttypes> {
    return this.http.delete<Instrumenttypes>(RSAENDPOINTConstants.INSRUMENTTYPES + '/Delete?id=' + params).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('deleteInstrumentType')));
  }
  gettransactions(): Observable<Array<Transactions>> {
    return this.http.get(RSAENDPOINTConstants.TRANSACTIONS + '/GetAll').pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('gettransactions')));

  }
  updatetransactions(params): Observable<Transactions> {
    return this.http.put<Transactions>(RSAENDPOINTConstants.TRANSACTIONS + '/Put', params).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('updatetransactions')));
  }
  createtransactions(params): Observable<Transactions> {
    return this.http.post<Transactions>(RSAENDPOINTConstants.TRANSACTIONS + '/Post', params).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('createtransactions')));
  }

  deletetransactions(params) {
    return this.http.delete<Transactions>(RSAENDPOINTConstants.TRANSACTIONS + '/Delete?id=' + params).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('deletetransactions')));
  }
  getPaymentMode(): Observable<Array<PaymentModes>> {
    return this.http.get(RSAENDPOINTConstants.PAYMENTMODES + '/GetAll').pipe(
        map(res => res),
        catchError(handleErrorObservable<any>('getPaymentMode')));
}
createPaymentMode(params): Observable<PaymentModes> {
    return this.http.post<PaymentModes>(RSAENDPOINTConstants.PAYMENTMODES + '/Post', params).pipe(
        map(res => res),
        catchError(handleErrorObservable<any>('createPaymentMode')));
}
updatePaymentMode(params): Observable<PaymentModes> {
    return this.http.put<PaymentModes>(RSAENDPOINTConstants.PAYMENTMODES + '/Put', params).pipe(
        map(res => res),
        catchError(handleErrorObservable<any>('updatePaymentMode')));
}
deletePaymentMode(params): Observable<PaymentModes> {
    return this.http.delete<PaymentModes>(RSAENDPOINTConstants.PAYMENTMODES + '/Delete?pmCode=' + params).pipe(
        map(res => res),
        catchError(handleErrorObservable<any>('deletePaymentMode')));
 }
 getCostCenters(): Observable<Array<CostCenter>> {
  return this.http.get(RSAENDPOINTConstants.COSTCENTER + '/GetAll').pipe(
    map(res => res),
    catchError(handleErrorObservable<any>('getCostCenters')));
}
addCostCenters(params): Observable<CostCenter> {
  return this.http.post<CostCenter>(RSAENDPOINTConstants.COSTCENTER + '/Post', params).pipe(
    map(res => res), 
    catchError(handleErrorObservable<any>('addCostCenters'))); 
}
 updateCostCenter(params): Observable<CostCenter> {
  return this.http.put<CostCenter>(RSAENDPOINTConstants.COSTCENTER + '/Put', params).pipe(
    map(res => res),
    catchError(handleErrorObservable<any>('updateCostCenter')));
}
removeCostCenters(params): Observable<CostCenter> {
  return this.http.delete<CostCenter>(RSAENDPOINTConstants.COSTCENTER + '/Delete?ccCode=' + params).pipe(
    map(res => res),
    catchError(handleErrorObservable<any>('removeCostCenters')));
} 
}
