import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { AdminMastersService } from './../services/admin-masters.service';
import { UserAutherizationService } from 'src/app/core/authorization/userauth.service';
@Component({
  selector: 'rsa-admin-home',
  templateUrl: './admin-home.component.html',
  styleUrls: ['./admin-home.component.scss']
})
export class AdminHomeComponent implements OnInit {
  adminMasters:any=[];
  username: string;
  welcomeInfo: any = { 'welcomeMsg': 'HELLO!', 'msg1': 'what do you want to analyse', 'msg2': 'today?' };
  private selectedIndex = 0;
  constructor(private _service:AdminMastersService,private allowAccess: UserAutherizationService) { }

  ngOnInit() {
    this.getAdminUrlsList();
    this.username = localStorage.getItem('userName');
  }
  getAdminUrlsList() {
    this._service.getAdminUrlsList().subscribe((data) => {
      this.adminMasters=data;
    });
  }  
  displayMenuItem(functionid){
    return this.allowAccess.isAllowed(functionid);
  }

}
