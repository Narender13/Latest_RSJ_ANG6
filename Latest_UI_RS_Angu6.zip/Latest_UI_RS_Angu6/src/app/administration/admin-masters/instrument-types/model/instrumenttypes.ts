export class Instrumenttypes {
    Code: number;
    ArabicDescription: string;
    EnglishDescription: string;
    message: string;
}
