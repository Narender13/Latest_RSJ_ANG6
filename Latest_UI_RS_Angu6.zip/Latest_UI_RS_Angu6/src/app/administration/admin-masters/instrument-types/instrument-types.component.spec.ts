import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InstrumentTypesComponent } from './instrument-types.component';

describe('MastersComponent', () => {
    let component: InstrumentTypesComponent;
    let fixture: ComponentFixture<InstrumentTypesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
        declarations: [InstrumentTypesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
      fixture = TestBed.createComponent(InstrumentTypesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
