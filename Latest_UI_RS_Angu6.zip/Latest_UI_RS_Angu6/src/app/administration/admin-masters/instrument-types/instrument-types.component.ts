﻿import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AgGridNg2 } from 'ag-grid-angular';
import { GridOptions } from 'ag-grid-community/dist/lib/entities/gridOptions';
import { AgGridAdminEditViewButtonComponent } from 'src/app/administration/admin-masters/ag-grid-edit-view-button/ag-grid-edit-view-button.component';
import { AdminMastersService } from './../../services/admin-masters.service';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { Instrumenttypes } from './Model/instrumenttypes';
import { ConfirmationDialogComponent } from 'src/app/shared/custom-model/custom-model.component';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';
import { AgCustomTextComponent } from 'src/app/shared/ag-custom-text/ag-custom-text.component';

@Component({
  selector: 'rsa-instrument-types',
  templateUrl: './instrument-types.component.html',
  styleUrls: ['./instrument-types.component.scss']
})
export class InstrumentTypesComponent implements OnInit, AfterViewInit {
    @ViewChild('agGrid') agGrid: AgGridNg2;
    gridApi;
    gridColumnApi;
    paginationOptions: TextValuePair[] = [];
    rowData: any[] = [];
    columnDefs: Array<object> = [];
    domLayout;
    instrumentTypes: Instrumenttypes;
    gridConfiguration: GridOptions = {};
    frameworkComponents;
    editingRowIndex: number;
    suppressClickEdit;
    currentEditRow;
    ModifiedBy: any;
    PreparedBy: any;
    isRowEditing: boolean = false;
    selectedRowIndex;
    constructor(private fb: FormBuilder, private _adminMasterService: AdminMastersService, private alertService: AlertService,
        private modalService: BsModalService, public bsModalRef: BsModalRef ) {
        this.domLayout = 'autoHeight';
    }

    ngOnInit() {
        this.getAllInstrumentTpes();
        this.columnDefs = [
            {
                headerName: '', field: 'name', headerCheckboxSelection: true, headerCheckboxSelectionFilteredOnly: true, checkboxSelection: true
            },
              
            {
                headerName: 'Code', field: 'Code', sortable: true, filter: 'agTextColumnFilter', editable: false
            },
            { headerName: 'English Description', field: 'EnglishDescription', sortable: true, filter: 'agTextColumnFilter', editable: true, cellEditor: 'agTextInput', maxLength: 40},
            {
                headerName: 'الوصف العربي', field: 'ArabicDescription', sortable: true, filter: 'agTextColumnFilter', editable: true, cellEditor: 'agTextInput', maxLength: 40
                
            },
            {
                headerName: 'Action',
                field: 'value',
                cellRendererFramework: AgGridAdminEditViewButtonComponent,
                cellRendererParams: {
                    inActoionLink: 'InstrumentTypes'
                },
                colId: 'editSaveBtn',
                filter: 'none',
                headerClass: 'hidefilter'
            }
        ];

        this.frameworkComponents = {agTextInput: AgCustomTextComponent };
        this.GetcolumnDefs();
        this.suppressClickEdit = true;
    }
    GetcolumnDefs() {
        this.gridConfiguration = <GridOptions>{
            columnDefs: this.columnDefs,
            rowSelection: 'multiple',
            postProcessPopup: function (params) {
                const ePopup = params.ePopup;
                ePopup.style.top = '14.9838px';
            },
            rowData: this.rowData,
            rowHeight: 40,
            headerHeight: 40,
            pagination: true,
            floatingFiltersHeight: 40,
            paginationPageSize: 20,
            enableRangeSelection: true,
            rowMultiSelectWithClick: true,
            animateRows: true,
            enableColResize: true,
            enableFilter: true,
            suppressContextMenu: true,
            enableSorting: true,
            editType: 'cel',
            defaultColDef: {
                enableRowGroup: false,
                enableValue: true,
                suppressMovable: true,
                minWidth: 100,
                menuTabs: ['filterMenuTab', '', '']
            },
            context: {
                componentParent: this
            },
        };
    }
    addNewRow(): any {
        let editedData = this.rowData.filter(data => data.editMode === true && data.isNewRow === true);
        if (editedData.length > 0) {
            this.alertService.warn('Please save/cancel the data which already added.');
        }
        else {
            let newItem = { Code: 0, EnglishDescription: '', ArabicDescription: '', isNewRow: true, editMode: true, PreparedBy: localStorage.getItem('LoggedInUserId')};
            this.rowData.push(newItem);
            this.gridConfiguration.api.setRowData(this.rowData);
            this.gridApi.paginationGoToPage(0);
            this.onParentEditClicked(this.rowData.length - 1);
        }
    }
   getAllInstrumentTpes(): any {
       this._adminMasterService.getInstrumentTypes().subscribe((data) => {
            this.rowData = data;
            //console.log(data, this.rowData);
        });
    }
    onParentCancel(rowIndex) {
        this.gridApi.stopEditing();
        let selRowData = this.rowData[rowIndex];
        if (selRowData.isNewRow) {
            this.rowData.splice(rowIndex, 1);
        }
        else {
            this.currentEditRow.editMode = false;
            this.rowData[rowIndex] = this.currentEditRow;
        }
        this.gridConfiguration.api.setRowData(this.rowData);
        this.gridApi.paginationGoToPage(0);
        this.suppressClickEdit = true;
        this.isRowEditing = false;
    }
    setAutoHeight() {
        setTimeout(() => {
            this.gridApi.setDomLayout('autoHeight');
        }, 200);

    }
    ngAfterViewInit() {
        this.fitToCoulmn();
        this.setAutoHeight();
    }
    fitToCoulmn() {
        setTimeout(() => {
            this.gridApi.sizeColumnsToFit();
        }, 200);
    }
    onGridReady(params) {
        console.log(params, 'params');
        this.gridApi = params.api;
        this.gridColumnApi = params.columnApi;
        this.gridConfiguration.api.setRowData(this.rowData);
        params.api.paginationGoToPage(0);
        this.fitToCoulmn();
    }
    editRowData(rowIndex, column) {
        this.gridApi.startEditingCell({
            rowIndex: rowIndex,
            colKey: column
        });
        this.isRowEditing = true;
    }
   onCellDoubleClicked($event) {
    this.selectedRowIndex = $event.rowIndex !== null ? $event.rowIndex : null;
    let colId = $event.column ? $event.column.colId : null;
        if(this.selectedRowIndex && colId){
            this.allowEditing(this.selectedRowIndex, colId);  
        }         
    }

    onCellClicked($event) {
       this.selectedRowIndex = $event.rowIndex !== null ? $event.rowIndex : null;
       let colId = $event.column ? $event.column.colId : null;
       if(this.selectedRowIndex && colId){
        this.allowEditing(this.selectedRowIndex, colId);
       }          
    }

    onCellFocused($event) {
        this.selectedRowIndex = $event.rowIndex !== null ? $event.rowIndex : null;
        let colId = $event.column ? $event.column.colId : null;
        if(this.selectedRowIndex && colId){
            this.allowEditing(this.selectedRowIndex, colId);
        }           
    }
    allowEditing(rowIndex, colId) {
        if (this.isRowEditing) {
            if (rowIndex !== this.editingRowIndex) {
                this.suppressClickEdit = true;
                this.gridApi.stopEditing();
            }
            else {
                this.suppressClickEdit = false;
                this.editRowData(rowIndex, colId);
            }
        }
    }
   onParentEditClicked(rowIndex) {
        let editedData = this.rowData.filter(data => data.editMode === true);
        let currentEditData = this.rowData[rowIndex];
        let allowRowEdit = false;
        if (editedData.length !== 0) {
            if (editedData[0].Code === currentEditData.Code) {
                allowRowEdit = true;
            }
        }
        else {
            allowRowEdit = true;
        }
        if (allowRowEdit) {
            this.suppressClickEdit = false;
            this.editingRowIndex = rowIndex;
            currentEditData.editMode = true;
            this.currentEditRow = Object.assign({}, currentEditData);
            this.editRowData(rowIndex, 'EnglishDescription');
            return true;
        }
        else {
            this.alertService.warn('Please save/cancel the data which already modifed.');
            return false;
        }
    }
    validateData(currentData) {
        if (currentData.EnglishDescription === "") {
            this.alertService.error('English Description is empty');
            return 'EnglishDescription';
        }
        return '';
    }
    onParentSaveClicked(id, rowIndex) {
        console.log(this.rowData);
        this.gridApi.stopEditing();
        let updatedData = this.rowData.filter(data => data.Code === id);
        console.log(updatedData);
        if (updatedData.length > 0) {
            let validate = this.validateData(updatedData[0]);
            if (validate === '') {
                if (id === 0) {
                    this._adminMasterService.addInstrumentType(JSON.stringify(updatedData[0])).subscribe(
                        dataReturn => {
                            if (!dataReturn) {
                                this.alertService.warn('English Description already exists');
                                this.editRowData(rowIndex, 'EnglishDescription');
                            }
                            else {
                                this.alertService.success('Data saved successfully.');
                                this.isRowEditing = false;
                                this.getAllInstrumentTpes();
                                return true;
                            }
                        },
                        errorRturn => {
                            this.alertService.error('something went wrong');
                            this.editRowData(rowIndex, 'EnglishDescription');
                            return false;
                        }
                    );
                }
                else {
                    updatedData[0].ModifiedBy = localStorage.getItem('LoggedInUserId');
                    this._adminMasterService.updateInstrumentType(JSON.stringify(updatedData[0])).subscribe(
                        dataReturn => {
                                updatedData[0].editMode = false;
                                this.isRowEditing = false;
                                this.alertService.success('Data updated successfully.');
                                this.getAllInstrumentTpes();
                                return true;
                        },
                        errorRturn => {
                            this.alertService.error('something went wrong');
                            this.editRowData(rowIndex, 'EnglishDescription');
                            return false;
                        }
                    );
                }
            }
            else {
                this.editRowData(rowIndex, validate);
                return false;
            }
        }
    }
    onParentDeleteClicked(id, rowIndex) {
        this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
        this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
        this.bsModalRef.content.modelBodyContent = RSAMSGConstants.DELETEMSGRECEIPTL;
        this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
        this.bsModalRef.content.actionBtn = RSAMSGConstants.BTNPROCEED;
        this.bsModalRef.content.valueChange.subscribe((data) => {
            console.log("Code"+ data);
            if (data = RSAMSGConstants.BTNPROCEED) {
                this._adminMasterService.deleteInstrumentType(id).subscribe(
                    dataReturn => {
                            this.alertService.success('Data deleted successfully.');
                            this.getAllInstrumentTpes();
                    },
                    errorRturn => {
                        console.log(errorRturn);
                    }
                );
            }
        });
    }
}

interface TextValuePair {
    id: number;
    value: string;
}
