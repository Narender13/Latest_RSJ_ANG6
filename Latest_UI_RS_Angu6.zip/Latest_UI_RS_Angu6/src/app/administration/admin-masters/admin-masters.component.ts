import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AdminMastersService } from 'src/app/administration/services/admin-masters.service';
@Component({
  selector: 'rsa-admin-masters',
  templateUrl: './admin-masters.component.html',
  styleUrls: ['./admin-masters.component.scss']
})
export class AdminMastersComponent implements OnInit {
  
   adminMasterType:string;
  constructor(private route: ActivatedRoute,
    private router: Router,private _masterService:AdminMastersService) {
      this.route.params.subscribe(params => {
        this.adminMasterType = params['masterName'];
        console.log("admin msatertype "+this.adminMasterType);
      });
     }

  ngOnInit() {
  }

}
