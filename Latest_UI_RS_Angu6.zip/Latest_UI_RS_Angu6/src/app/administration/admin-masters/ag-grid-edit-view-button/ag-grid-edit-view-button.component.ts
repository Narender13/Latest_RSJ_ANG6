import { Component, OnInit, ViewChild } from '@angular/core';
import { ICellRendererAngularComp, AgGridNg2 } from 'ag-grid-angular';
import { GridOptions } from 'ag-grid-community';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
@Component({
  selector: 'rsa-admin-ag-grid-edit-view-button',
  templateUrl: './ag-grid-edit-view-button.component.html',
  styleUrls: ['./ag-grid-edit-view-button.component.scss']
})
export class AgGridAdminEditViewButtonComponent implements ICellRendererAngularComp {
  @ViewChild('agGrid') agGrid: AgGridNg2;
  gridConfiguration: GridOptions;
  public params: any;
  showSave = false;
  showCancel = false;
  parentComponent;
  pageName: string;
  constructor(private alertService: AlertService) {
  }

  agInit(params: any): void {
    //console.log(params, 'params');
    this.params = params;
    this.parentComponent = this.params.context.componentParent;
    this.pageName = params.inActoionLink;    
      if (this.pageName === 'InstrumentTypes' || this.pageName === 'Transactions' || this.pageName === 'PaymentModes' ||  this.pageName === 'CostCenters') {
          if (this.params.data.isNewRow) {
              this.showSave = true;
              this.showCancel = true;
          }
      }     
  }

  editCall(rowIndex) {    
    if(this.params.data.editMode){
      this.alertService.warn('Please save/cancel the data which already modifed.');
      return false;
    }
    else{
      let edited = this.parentComponent.onParentEditClicked(rowIndex);
      if (edited) {
          this.showSave = true;
          this.showCancel = true;
      }
    }
  }
    deleteCall(id, rowIndex) {        
        this.parentComponent.onParentDeleteClicked(id, rowIndex);
    }
  saveCall(id, rowIndex) {
      let saved = this.parentComponent.onParentSaveClicked(id, rowIndex);
      if (saved) {
          this.showSave = false;
          this.showCancel = false;
      }
  }
  cancelCall(rowIndex) {
    this.parentComponent.onParentCancel(rowIndex);
    this.showCancel = false;
    this.showSave = false;
  }
  refresh(): boolean {
    return false;
  }

}
