import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AgGridEditViewButtonComponent } from './ag-grid-edit-view-button.component';

describe('AgGridEditViewButtonComponent', () => {
  let component: AgGridEditViewButtonComponent;
  let fixture: ComponentFixture<AgGridEditViewButtonComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AgGridEditViewButtonComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgGridEditViewButtonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
