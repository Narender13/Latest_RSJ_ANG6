import { Component, OnInit, ViewChild, AfterViewInit, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Observable } from 'rxjs';
import { TypeaheadMatch } from 'ngx-bootstrap';
import { Transactions } from '../transactions/model/transactions';
import { AdminMastersService } from './../../services/admin-masters.service';
import { AgGridNg2 } from 'ag-grid-angular';
import { GridOptions } from 'ag-grid-community/dist/lib/entities/gridOptions';
import { AgGridAdminEditViewButtonComponent } from 'src/app/administration/admin-masters/ag-grid-edit-view-button/ag-grid-edit-view-button.component';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { ConfirmationDialogComponent } from 'src/app/shared/custom-model/custom-model.component';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';
import { AgCustomTextComponent } from 'src/app/shared/ag-custom-text/ag-custom-text.component';

@Component({
    selector: 'rsa-transactions',
    templateUrl: './transactions.component.html',
    styleUrls: ['./transactions.component.scss']
})
export class TransactionsComponent implements OnInit, AfterViewInit {
    @ViewChild('agGrid') agGrid: AgGridNg2;
    gridApi;
    gridColumnApi;
    paginationOptions: TextValuePair[] = [];
    transactiontypes: Transactions;
    rowData: any[] = [];
    columnDefs: Array<object> = [];
    domLayout;
    gridConfiguration: GridOptions = {};
    editingRowIndex: number;
    suppressClickEdit;
    currentEditRow: any;
    isRowEditing: boolean = false;
    frameworkComponents;
    selectedRowIndex;
    constructor(private fb: FormBuilder, private _adminMasterService: AdminMastersService,
        private alertService: AlertService, private modalService: BsModalService, public bsModalRef: BsModalRef) {
        this.domLayout = 'autoHeight';
    }

    ngOnInit() {
        this.defineColumnDefs();
        this.GetGridOptions();
        this.gettransactions();
        this.suppressClickEdit = true;
    }
    defineColumnDefs() {
        this.columnDefs = [
            { headerName: '', field: 'name', headerCheckboxSelection: true, headerCheckboxSelectionFilteredOnly: true, checkboxSelection: true, },
            {
                headerName: 'Code', field: 'Code', sortable: true, filter: 'agTextColumnFilter', editable: false,
            },
            { headerName: 'English Description', field: 'EnglishDescription', sortable: true, filter: 'agTextColumnFilter', editable: true, cellEditor: 'agTextInput', maxLength: 60 },
            { headerName: 'الوصف العربي', field: 'ArabicDescription', sortable: true, filter: 'agTextColumnFilter', editable: true, cellEditor: 'agTextInput', maxLength: 60 },
            {
                headerName: 'Action',
                field: 'value',
                cellRendererFramework: AgGridAdminEditViewButtonComponent,
                cellRendererParams: {
                    inActoionLink: 'Transactions'
                },
                colId: 'editSaveBtn',
                filter: 'none',
                headerClass: 'hidefilter'
            }
        ];
        this.frameworkComponents = { agTextInput: AgCustomTextComponent };
        // this.components = { inputField: getInputField() };
    }


    GetGridOptions() {
        this.gridConfiguration = <GridOptions>{
            columnDefs: this.columnDefs,
            postProcessPopup: function (params) {
                const ePopup = params.ePopup;
                ePopup.style.top = '14.9838px';
            },
            // rowData: this.rowData,
            rowHeight: 40,
            headerHeight: 40,
            pagination: true,
            floatingFiltersHeight: 40,
            paginationPageSize: 20,
            enableRangeSelection: true,
            rowSelection: 'single',
            rowMultiSelectWithClick: true,
            animateRows: true,
            enableColResize: true,
            enableFilter: true,
            suppressContextMenu: true,
            enableSorting: true,
            // suppressExcelExport = true,
            editType: 'cel',
            defaultColDef: {
                enableRowGroup: false,
                enableValue: true,
                suppressMovable: true,
                headerCheckboxSelectionFilteredOnly: false,
                minWidth: 100,
                menuTabs: ['filterMenuTab', '', '']
            },
            context: {
                componentParent: this
            },
        };
    }

    onCellDoubleClicked($event) {
        this.selectedRowIndex = $event.rowIndex !== null ? $event.rowIndex : null;
        let colId = $event.column ? $event.column.colId : null;
        if (this.selectedRowIndex && colId) {
            this.allowEditing(this.selectedRowIndex, colId);
        }
    }

    onCellClicked($event) {
        this.selectedRowIndex = $event.rowIndex !== null ? $event.rowIndex : null;
        let colId = $event.column ? $event.column.colId : null;
        if (this.selectedRowIndex && colId) {
            this.allowEditing(this.selectedRowIndex, colId);
        }
    }

    onCellFocused($event) {
        this.selectedRowIndex = $event.rowIndex !== null ? $event.rowIndex : null;
        let colId = $event.column ? $event.column.colId : null;
        if (this.selectedRowIndex && colId) {
            this.allowEditing(this.selectedRowIndex, colId);
        }
    }
    allowEditing(rowIndex, colId) {
        if (this.isRowEditing) {
            if (rowIndex !== this.editingRowIndex) {
                this.suppressClickEdit = true;
                this.gridApi.stopEditing();
            }
            else {
                this.suppressClickEdit = false;
                this.editRowData(rowIndex, colId);
            }
        }
    }



    validateData(currentData) {
        if (currentData.EnglishDescription === "") {
            this.alertService.error('English Description is empty');
            return 'EnglishDescription';
        }
        if (currentData.ArabicDescription === "") {
            this.alertService.error('Arabic Description is empty');
            return 'ArabicDescription';
        }
        return '';
    }
    setDataError(rowIndex, isError) {
        let selData = this.rowData[rowIndex];
        selData.isError = isError;
    }



    setAutoHeight() {
        setTimeout(() => {
            this.gridApi.setDomLayout('autoHeight');
        }, 200);

    }

    ngAfterViewInit() {
        this.fitToCoulmn();
        this.setAutoHeight();
    }
    fitToCoulmn() {
        setTimeout(() => {
            this.gridApi.sizeColumnsToFit();
        }, 200);
    }


    onGridReady(params) {
        console.log(params, 'params');
        this.gridApi = params.api;
        this.gridColumnApi = params.columnApi;
        this.gridConfiguration.api.setRowData(this.rowData);
        params.api.paginationGoToPage(0);
        this.fitToCoulmn();
    }

    addNewRow(): any {
        //let Code =  this.rowData.length + 1;
        let editedData = this.rowData.filter(data => data.editMode === true && data.isNewRow === true);
        if (editedData.length > 0) {
            this.alertService.warn('Please save/cancel the data which already added.');
        }
        else {
            let newItem = { Code: 0, EnglishDescription: '', ArabicDescription: '', PreparedBy: localStorage.getItem('LoggedInUserId'), isNewRow: true, editMode: true };
            //this.gridApi.updateRowData({ add: [newItem] });
            this.rowData.push(newItem);
            this.gridConfiguration.api.setRowData(this.rowData);
            this.gridApi.paginationGoToPage(0);
            //var sort = [{colId: "StartDate",sort: "desc"}];
            //this.gridApi.setSortModel(sort);
            this.onParentEditClicked(this.rowData.length - 1);
        }
    }
    gettransactions(): any {
        this._adminMasterService.gettransactions().subscribe((data) => {
            this.rowData = data;
        //    console.log(data, this.rowData);
        });
    }
    getRowData() {
        return this.rowData;
    }
    onParentEditClicked(rowIndex) {
        let editedData = this.rowData.filter(data => data.editMode === true);
        let currentEditData = this.rowData[rowIndex];
        let allowRowEdit = false;
        if (editedData.length !== 0) {
            if (editedData[0].Code === currentEditData.Code) {
                allowRowEdit = true;
            }
        }
        else {
            allowRowEdit = true;
        }
        if (allowRowEdit) {
            this.suppressClickEdit = false;
            this.editingRowIndex = rowIndex;
            currentEditData.editMode = true;
            this.currentEditRow = Object.assign({}, currentEditData);
            this.editRowData(rowIndex, 'EnglishDescription');
            return true;
        }
        else {
            this.alertService.warn('Please save/cancel the data which already modifed.');
            return false;
        }
    }

    onParentCancel(rowIndex) {
        this.gridApi.stopEditing();
        let selRowData = this.rowData[rowIndex];
        if (selRowData.isNewRow) {
            this.rowData.splice(rowIndex, 1);
        }
        else {
            this.currentEditRow.editMode = false;
            this.rowData[rowIndex] = this.currentEditRow;
        }
        this.gridConfiguration.api.setRowData(this.rowData);
        this.gridApi.paginationGoToPage(0);
        this.suppressClickEdit = true;
        this.isRowEditing = false;
    }
    editRowData(rowIndex, column) {
        this.gridApi.startEditingCell({
            rowIndex: rowIndex,
            colKey: column
        });
        this.isRowEditing = true;
    }
    onParentSaveClicked(id, rowIndex) {
        console.log(this.rowData);
        this.gridApi.stopEditing();

        let updatedData = this.rowData.filter(data => data.Code === id);
        console.log(updatedData);
        if (updatedData.length > 0) {

            let validate = this.validateData(updatedData[0]);
            if (validate === '') {
                if (id === 0) {

                    this._adminMasterService.createtransactions(updatedData[0]).subscribe(
                        dataReturn => {
                            if (!dataReturn) {
                                this.alertService.warn('Record already exists');
                                this.editRowData(rowIndex, 'EnglishDescription');
                            }
                            else {
                                this.alertService.success('Data saved successfully.');
                                this.isRowEditing = false;
                                this.gettransactions();
                                return true;
                            }
                        },
                        errorRturn => {
                            this.alertService.error('something went wrong');
                            this.editRowData(rowIndex, 'EnglishDescription');
                            return false;
                        }
                    );
                }
                else {
                    updatedData[0].ModifiedBy = localStorage.getItem('LoggedInUserId');
                    this._adminMasterService.updatetransactions(updatedData[0]).subscribe(
                        dataReturn => {
                            updatedData[0].editMode = false;
                            this.isRowEditing = false;
                            this.alertService.success('Data updated successfully.');
                            this.gettransactions();
                            return true;
                        },
                        errorRturn => {
                            this.alertService.error('something went wrong');
                            this.editRowData(rowIndex, 'EnglishDescription');
                            return false;
                        }
                    );
                }
            }
            else {
                this.editRowData(rowIndex, validate);
                return false;
            }
        }
    }

    onParentDeleteClicked(id, rowIndex) {
        this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
        this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
        this.bsModalRef.content.modelBodyContent = RSAMSGConstants.DELETEMSGRECEIPTL;
        this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
        this.bsModalRef.content.actionBtn = RSAMSGConstants.BTNPROCEED;
        this.bsModalRef.content.valueChange.subscribe((data) => {
            if (data = RSAMSGConstants.BTNPROCEED) {
                this._adminMasterService.deletetransactions(id).subscribe(
                    dataReturn => {
                        if (!dataReturn.success) {
                            // dataReturn.errors.forEach(element => {
                            //     this.alertService.error(element);
                            //    });

                            // }
                            // else {
                            this.alertService.success('Data deleted successfully.');
                            this.gettransactions();
                            //}
                        }
                        errorRturn => {
                            console.log(errorRturn);
                            // this.alertService.error('Something went wrong');
                        }
                    });
            }
        });

    }
}
interface TextValuePair {
    id: number;
    value: string;
}





