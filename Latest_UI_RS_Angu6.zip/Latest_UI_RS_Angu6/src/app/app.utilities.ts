
import { LicenseManager } from 'ag-grid-enterprise';
export class DatatableUtilities {
    static registerLicenseKey(licenceKey: string) {
        LicenseManager.setLicenseKey(licenceKey);
    }
}
export const AG_GRID_LICENSE_KEY = `Oxytech_Solutions_Pvt_Ltd_on_behalf_of_NTT_DATA_GLOBAL_DELIVERY_SERVICES_PRIVATE_LIMITED__1Devs6_September_2019__MTU2NzcyNDQwMDAwMA==1a9a24dea1d4b06a30c9f1c999955469`;


