import { Component, ChangeDetectorRef, OnInit, OnDestroy } from '@angular/core';
import { Router, NavigationEnd, ActivatedRoute, RouteConfigLoadStart, RouteConfigLoadEnd } from '@angular/router';
import { LoaderService } from './core/loader/loader-service';
import { HomeService } from './home/services/home.service';
import { Subscription } from 'rxjs';
import { AppLoadService } from 'src/app/app-load.service';
import { RSAConstants } from 'src/app/core/constants/rsaconstant';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import { store } from '@angular/core/src/render3/instructions';
import { AuthService } from './core/guard/services/auth.service';
import { MessageService } from 'src/app/core/message/service/message.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit, OnDestroy {
  isHome: boolean;
  isLoading: boolean;
  countrycode: any;
  errorMsg: string;
  bannerurl: string;
  profileurl: string;
  private userData: any;
  hideHeader: boolean = false;
  returndata: any;
  errormsg: any;
  private subscription: Subscription;
  isAuthenticated: boolean;
  isAuthorized: boolean;
  isAuthorizedFlag: boolean;
  allowedFunctions: any = [];

  constructor(private messageService: MessageService, private router: Router, private homeservice: HomeService, private loaderService: LoaderService,
    private cdr: ChangeDetectorRef, private appLoadService: AppLoadService, private adalSvc: MsAdalAngular6Service, private auth: AuthService
  ) {

    this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        this.isHome = this.router.url === '/home' ? true : false;
      }
      if (event instanceof RouteConfigLoadStart) {
        this.isLoading = true;
      } else if (event instanceof RouteConfigLoadEnd) {
        this.isLoading = false;
      }
      // this.hideHeader = this.router.url.includes('accessdenied');
    });
    this.subscription = this.loaderService.isLoading().subscribe(loading => {
      this.isLoading = loading;
    });

  }
  ngOnInit() {

    if (this.adalSvc.isAuthenticated) {
      this.isAuthenticated = true;
      localStorage.setItem('locationcode', '20');
      this.checkRSASingleSignOn();
    }
    // else{      
    //   this.adalSvc.login();
    // }

    this.messageService.getMessage().subscribe((data) => {

      if (data != null || data != undefined) {
        //this.getBannerUrl();
        this.isAuthorizedFlag = data.isAuthorized || this.getAuth();
        console.log('messageservice in app', this.isAuthorizedFlag);
        if (!data.isAuthorized)
          this.router.navigate(['accessdenied']);
        else
          this.getBannerUrl();
      }
    });

  }
  getBannerUrl() {
    this.bannerurl = localStorage.getItem("bannerurl");
  }
  getUserId() {
    return localStorage.getItem('userId');
    //  return 'ravi.kesari@rsame.com';
  }
  getLocationCode() {
    return 13;
  }
  ngOnDestroy() {

  }
  getAuth() {
    return (localStorage.getItem('isAuthorized') == 'true')
  }

  doAuthorizationRSA() {

    let returnVal = true;
    this.appLoadService.getUserAuthorizationData().subscribe(
      data => {
        this.returndata = data;
        //alert(this.returndata.AllowedFunctionalIds.length);
        if (this.returndata == null ||
          this.returndata == undefined ||
          this.returndata.AllowedFunctionalIds == null ||
          this.returndata.AllowedFunctionalIds == '' ||
          this.returndata.AllowedFunctionalIds.length == 0
        ) {
          this.isAuthorized = false;
          returnVal = false;
          this.messageService.sendMessage({ 'isAuthorized': false });

        }
        else {
          if (window.localStorage) {
            this.allowedFunctions = this.returndata.AllowedFunctionalIds;
            localStorage.setItem(RSAConstants.functionids, JSON.stringify(this.returndata.AllowedFunctionalIds));
            localStorage.setItem(RSAConstants.allowedModules, JSON.stringify(this.returndata.AllowedApplicationModules));
            localStorage.setItem(RSAConstants.allowedLocations, JSON.stringify(this.returndata.AllowedLocations));
            localStorage.setItem(RSAConstants.allowedMenuitems, JSON.stringify(this.returndata.AllowedMenuItems));
            localStorage.setItem(RSAConstants.allowedTasklists, JSON.stringify(this.returndata.AllowedTaskList));
            localStorage.setItem(RSAConstants.LoggedInUserId, JSON.stringify(this.returndata.LoggedInUserId));
            localStorage.setItem(RSAConstants.allowedAdminMenuitems, JSON.stringify(this.returndata.AllowedAdminMenuItems));

            this.isAuthorized = true;
            localStorage.setItem('isAuthorized', 'true');
            this.messageService.sendMessage({ 'isAuthorized': true });

          }
          else {
            this.isAuthorized = false;
            returnVal = false;
            this.messageService.sendMessage({ 'isAuthorized': false });
            this.router.navigate(['accessdenied']);
          }
        }
      },
      error => {

        this.errormsg = error;
        returnVal = false;
        console.log("RSA Application app component Authorization failed...", this.errormsg);
        this.isAuthorized = false;
        this.messageService.sendMessage({ 'isAuthorized': false });
        this.router.navigate(['/accessdenied']);

      }
    );
    return returnVal;
  }

  checkRSASingleSignOn() {
    let returnval: boolean = true;


    if (this.adalSvc.isAuthenticated) {
      if (this.adalSvc.userInfo)
        this.auth.setUserInfo(this.adalSvc.userInfo);
      this.adalSvc.acquireToken(RSAConstants.ADFS_APP_URL).subscribe((token: string) => {
        if (token == null) {
          this.getRefreshToken();
        } else {
          this.auth.sendToken(token);
          this.doAuthorizationRSA();
        }
      });

    }
    else {
      this.logoutADFC();
    }

  }
  getRefreshToken() {
    console.log("refreshed token");
    this.adalSvc.RenewToken(RSAConstants.ADFS_APP_URL);
    this.adalSvc.acquireToken(RSAConstants.ADFS_APP_URL).subscribe((token: string) => {
      this.auth.sendToken(token);
      this.doAuthorizationRSA();
    });
  }

  logoutADFC() {
    this.adalSvc.logout();
    localStorage.clear();
  }

}

