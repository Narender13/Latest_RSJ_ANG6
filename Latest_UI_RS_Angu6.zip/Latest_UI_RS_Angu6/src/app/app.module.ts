import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule, DatePipe, registerLocaleData } from '@angular/common';
import { CoreModule } from './core/core.module';
import { LOCALE_ID } from '@angular/core';
import { LoginModule } from 'src/app/login/login.module';
import { SharedModule } from './shared/shared.module';
import { AppRoutingModule } from './app.routing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AngularFontAwesomeModule } from 'angular-font-awesome';
import { LocationStrategy, HashLocationStrategy } from '@angular/common';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import 'ag-grid-enterprise';
import { BsModalRef } from 'ngx-bootstrap';
import { BsModalService } from 'ngx-bootstrap/modal';
import { PdfViewerModule } from 'ng2-pdf-viewer';
import { NgxCurrencyModule } from 'ngx-currency';
import { customCurrencyMaskConfig, dynamicLocationUrlChange } from './shared/utilites/helper';
import { CURRENCY_MASK_CONFIG } from 'ngx-currency/src/currency-mask.config';
import localeFr from '@angular/common/locales/fr';
registerLocaleData(localeFr);
//import { DraftHeaderComponent } from './src/app/finance/drfats/draft-header/draft-header.component';
import { AuthenticationGuard, MsAdalAngular6Module } from 'microsoft-adal-angular6';
import { RSAConstants } from 'src/app/core/constants/rsaconstant';
import { AuthService } from 'src/app/core/guard/services/auth.service';




import { AppLoadService } from 'src/app/app-load.service';
@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    //  DraftHeaderComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    CoreModule,
    AppRoutingModule,
    CommonModule,
    AngularFontAwesomeModule,
    // NgxToggleModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
    HttpClientModule,
    PdfViewerModule,
    NgxCurrencyModule.forRoot(customCurrencyMaskConfig),
    MsAdalAngular6Module.forRoot({
      tenant: RSAConstants.ADFS_TENANT,
      instance: RSAConstants.ADFS_INSTANCE,
      clientId: RSAConstants.ADFC_CLIENT_ID,
      redirectUri: window.location.origin,
      displayCall: dynamicLocationUrlChange,
      endpoints: {
        endpoint: RSAConstants.ADFC_ENDPOINT_ID
      },
      navigateToLoginRequestUrl: false,
      cacheLocation: RSAConstants.ADFS_CACHE_LOCATION,
      callback: RSAConstants.ADFS_APP_URL
    }),
    NgxCurrencyModule.forRoot(customCurrencyMaskConfig),
    LoginModule

  ],
  providers: [DatePipe, BsModalRef, BsModalService,
    AppLoadService, AuthService, AuthenticationGuard, { provide: LocationStrategy, useClass: HashLocationStrategy },
    { provide: CURRENCY_MASK_CONFIG, useValue: customCurrencyMaskConfig },
  ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  bootstrap: [AppComponent]
})
export class AppModule {
  public endpoint: any = RSAConstants.ADFS_END_POINT_URL;
}
